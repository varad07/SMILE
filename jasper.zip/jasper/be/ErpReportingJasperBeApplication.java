package in.ecgc.smile.erp.reporting.jasper.be;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

/**
 * Reporting Service Jasper BE REST API
 * 
 * @version 1.0 09-August-2023
 * @Author Jagruti Tiwari, CDAC Mumbai
 * 
 */

@SpringBootApplication(scanBasePackages = "in.ecgc.smile.erp")
@ConfigurationPropertiesScan(basePackages = { "in.ecgc.smile.erp" })
@EnableDiscoveryClient
@EnableSwagger2
@EnableFeignClients
public class ErpReportingJasperBeApplication {
	public static void main(String[] args) {
		SpringApplication.run(ErpReportingJasperBeApplication.class, args);
	}

	@Bean(name = "reportMessageSource")
	public MessageSource messageSource() {
		ReloadableResourceBundleMessageSource messageSource = new ReloadableResourceBundleMessageSource();
		messageSource.setBasename("classpath:messages/jasper_report");
		messageSource.setDefaultEncoding("UTF-8");
		messageSource.setCacheSeconds(30);
		return messageSource;
	}
}
