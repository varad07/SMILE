package in.ecgc.smile.erp.reporting.jasper.be.utils.pebp;

import in.ecgc.smile.erp.reporting.jasper.be.utils.queries.DaoQueryInterface;

public enum PebPQuery implements DaoQueryInterface{
	

	PEB_P_02_A_01(
			"select a.Policy_no as \"Policy Number\", TO_CHAR(a.issue_date,'DD-MM-YYYY') as \"Issue Date\", b.exporter_name as \"Exporter Name\", c.buyer_name as \"Buyer Name\", d.project_country as \"Country Name\", a.policy_type as \"Policy Type\", a.rt_id as \"Cover Type\", reporting.to_rupee(e.contract_value ::numeric) as \"Contract Value\", reporting.to_rupee(a.cover_value ::numeric) as \"Amount Covered\", reporting.to_rupee(f.maximum_liability ::numeric) as \"Maximum Liability\", TO_CHAR(a.policy_start_date,'DD-MM-YYYY') as \"Policy Start Date\", TO_CHAR(a.policy_end_date,'DD-MM-YYYY') as \"Policy End Date\" from policy_uw.ecgc_peb_ecie_policy_details a join policy_uw.ecgc_peb_ecie_asses_exporter_details b on a.proposal_id = b.proposal_number join policy_uw.ecgc_peb_ecie_asses_buyer_details c on b.proposal_number = c.proposal_number join policy_uw.ecgc_peb_ecie_asses_country_details d on c.proposal_number = d.proposal_number join policy_uw.ecgc_peb_ecie_proposal_details e on d.proposal_number = e.proposal_number join policy_uw.ecgc_peb_ecie_project_details f on e.proposal_number = f.proposal_number left join country.ecgc_cud_country_mst g on g.country_id = d.country_id where a.issue_date between :fromDate ::date and :toDate::date and d.project_country like :country and UPPER(a.rt_id) like UPPER(:coverType)"),
	PEB_P_03_A_01(
			"select a.policy_type as \"Policy Type\", a.Policy_no as \"Policy Number\", TO_CHAR(a.issue_date,'DD-MM-YYYY') as \"Issue Date\", b.exporter_name as \"Exporter Name\", c.buyer_name as \"Buyer Name\", d.project_country as \"Country\", reporting.to_rupee(e.contract_value ::numeric) as \"Project Value\", reporting.to_rupee(a.cover_value ::numeric) as \"Amount Covered\", reporting.to_rupee(f.maximum_liability ::numeric) as \"Maximum Liability\", g.neia_risk_percentage as \"NEIA Share(%)\", g.ecgc_risk_percentage as \"ECGC Share In ML\", TO_CHAR(a.policy_start_date,'DD-MM-YYYY') as \"Policy Start date\", TO_CHAR(a.policy_end_date,'DD-MM-YYYY') as \"Policy End Date\" from policy_uw.ecgc_peb_ecie_policy_details a left join policy_uw.ecgc_peb_ecie_asses_exporter_details b on a.policy_no = b.policy_no and a.proposal_id = b.proposal_number left join policy_uw.ecgc_peb_ecie_asses_buyer_details c on b.policy_no = c.policy_no and b.proposal_number = c.proposal_number left join policy_uw.ecgc_peb_ecie_asses_country_details d on c.proposal_number = d.proposal_number left join policy_uw.ecgc_peb_ecie_proposal_details e on d.proposal_number = e.proposal_number left join policy_uw.ecgc_peb_ecie_project_details f on e.proposal_number = f.proposal_number left join policy_uw.ecgc_peb_ecie_asses_risk_sharing_ecgc_neia_details g on f.proposal_number = g.proposal_number left join country.ecgc_cud_country_mst h on d.country_id = h.country_id where d.project_country = :country and b.exporter_code ::varchar like :exporterCode");
	private String query;

	private PebPQuery(String query) {
		this.query = query;
	}

	public String getQuery() {
		return query;
	}

}
