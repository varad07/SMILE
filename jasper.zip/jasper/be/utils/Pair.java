package in.ecgc.smile.erp.reporting.jasper.be.utils;

/**
 * An utility class for stores any information that needs to exist as a pair.
 *
 * @param <E1> Generics indicating the type information for the first one in the
 *             pair.
 * @param <E2> Generics indicating the type information for the second one in
 *             the pair.
 */
public class Pair<E1, E2> {
    private E1 first;

    private E2 second;

    public Pair(E1 first, E2 second) {
        this.first = first;
        this.second = second;
    }

    public E1 first() {
        return getFirst();
    }

    public void setFirst(E1 first) {
        this.first = first;
    }

    public E2 second() {
        return getSecond();
    }

    public void setSecond(E2 second) {
        this.second = second;
    }

    public E1 getFirst() {
        return first;
    }

    public E2 getSecond() {
        return second;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((first == null) ? 0 : first.hashCode());
        result = prime * result + ((second == null) ? 0 : second.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Pair other = (Pair) obj;
        if (first == null) {
            if (other.first != null)
                return false;
        } else if (!first.equals(other.first))
            return false;
        if (second == null) {
            if (other.second != null)
                return false;
        } else if (!second.equals(other.second))
            return false;
        return true;
    }

}
