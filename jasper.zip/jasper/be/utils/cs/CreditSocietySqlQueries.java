package in.ecgc.smile.erp.reporting.jasper.be.utils.cs;

public interface CreditSocietySqlQueries {

	public static final String GET_CS_TRIAL_BALANCE_ALL_LOC = "SELECT * FROM reporting.ecgc_credit_society_trial_bal_all_loc where input_date = :input_date and (dr_amount = 0 or cr_amount = 0 ) order by maingl_cd , subgl_cd";

	public static final String GET_CS_TRIAL_BALANCE_ALL_LOC_NOT_NIL = "SELECT * FROM reporting.ecgc_credit_society_trial_bal_all_loc where input_date = :input_date and (dr_amount != 0 or cr_amount != 0 ) order by maingl_cd , subgl_cd";

	public static final String GET_CS_TRIAL_BALANCE_ALL_LOC_DR_CR_AMOUNT = "select sum(dr_amount) as total_dr, sum(cr_amount) as total_cr\r\n"
			+ "FROM reporting.ecgc_credit_society_trial_bal_all_loc where\r\n"
			+ "gl_type = :glType and input_date = :input_date";

	public static final String GETERATE_CS_TRIAL_BALANCE_ALL_LOC = "call reporting.create_credit_society_trial_balance_all_location_view_based(:input_date, 0)";

	public static final String GET_CS_BANK_RECONCILIATION = "SELECT * FROM reporting.ecgc_credit_society_bank_reconciliation_credsoc12 where input_date = :input_date and (dr_amount = 0 or cr_amount = 0 )";

	public static final String GET_CS_BANK_RECONCILIATION_NOT_NIL = "SELECT * FROM reporting.ecgc_credit_society_bank_reconciliation_credsoc12 where input_date = :input_date and (dr_amount != 0 or cr_amount != 0 )";

	public static final String GET_CS_BANK_RECONCILIATION_DR_CR_AMOUNT = "select sum(dr_amount) as total_dr, sum(cr_amount) as total_cr\r\n"
			+ "FROM reporting.ecgc_credit_society_bank_reconciliation_credsoc12 where\r\n"
			+ "gl_type = :glType and input_date = :input_date";
	
	public static final String GETERATE_CS_BANK_RECONCILIATION = "call reporting.create_cs_bank_reconciliation_all_location_view_based(:input_date, 0)";
	
	public static final String GET_ALL_GL_CODES = "select *  from cs.ecgc_cs_entity_gl_mst where pl_level = 'employee' ";
	
	public static final String GET_PL_CODES = "select distinct d.emp_no ,d.emp_alias,d.rank_cd  from cs.ecgc_cs_entity_gl_mst a  \r\n"
			+ "join\r\n"
			+ "cs.ecgc_cs_gl_txn_dtl b on a.maingl_cd = b.maingl_cd and a.subgl_cd = b.subgl_cd join emp_mgmt.ecgc_hrd_emp_mst d   ON NULLIF(b.personal_ledger_cd, '')::integer = d.emp_no\r\n"
			+ "where a.pl_level = 'employee' and a.maingl_cd = :mainGlCd and a.subgl_cd = :subGlCd";

	public static final String GET_TRIAL_BAL_BY_PL = "call reporting.get_cs_trial_balance_gl_pl_wise(:mainglCd,:subglCd,:plCd,:inputDate,'0','0')";

	public static final String GET_CS_TRIAL_BAL_BY_GL = "CALL reporting.get_cs_trial_balance_gl_wise(:mainglCd, :subglCd, :balancedt, '0', '0')";

}
