package in.ecgc.smile.erp.reporting.jasper.be.utils.ecib;

public class EcibQueries {

	public static final String GET_ECIB_ROXBO_R11 = "SELECT\r\n" + "a.bank_code ,\r\n" + "a.cover_type,\r\n"
			+ "b.expoter_code,\r\n"

			+ "b.calculated_adp,\r\n"

			+ "b.calculated_adp_inr,\r\n"

			+ "a.\"month\" , a.\"year\" \r\n" + "FROM\r\n" + "uw.ecgc_ecib_wt_monthly_dcln a INNER join\r\n"
			+ "uw.ecgc_ecib_wt_mdpa_amd_exporterwise_entry b ON\r\n"
			+ "a.wt_monthly_dcln_id = b.wt_monthly_dcln_id \r\n" + "WHERE b.calculated_adp_inr > 1000000000\r\n"
			+ "AND (\r\n" + "          (a.\"year\" = :FromYear AND a.\"month\" >= :FromMonth) OR\r\n"
			+ "        (a.\"year\" > :FromYear AND a.\"year\" < :ToYear) OR\r\n"
			+ "        (a.\"year\" = :ToYear AND a.\"month\" <= :ToMonth)" + "    )\r\n" + "    group by\r\n"
			+ "   a.bank_code,\r\n" + "a.cover_type,\r\n" + "b.expoter_code,\r\n" + "b.calculated_adp,\r\n"
			+ "b.calculated_adp_inr,\r\n" + "a.\"month\" , a.\"year\"\r\n" + "order by  a.\"year\" ";

	public static final String GET_ECIB_IN_U_R04 = "select \r\n" + "a.cover_number as \"coverNumber\",\r\n"
			+ "b.application_type as \"freshRenewal\",\r\n" + "a.bank_branch_name as \"bankBranchName\",\r\n"
			+ "a.exporter_name as \"exporterName\",\r\n" + "a.ml as \"ecibCoverValue\",\r\n"
			+ "(a.cover_end_date - a.cover_start_date):: text as \"coverPeriod\",\r\n"
			+ "round(a.approved_cover_percentage_nr / a.approved_cover_percentage_dr * 100::numeric, 2) AS \"percentageOfCover\",\r\n"
			+ "a.approved_prem_rate as \"premiumRate\",\r\n" + "a.lc_only_flg as \"lcCoverForShipOnly\",\r\n"
			+ "a.associates_only_flg as \"lcCoverShipAssociate\",\r\n" + "a.nursing_flg as \"nursingEcibCover\",\r\n"
			+ "c.balance_amt as \"balAsDpInAcc\",\r\n" + "a.remarks as \"remarks\"\r\n" + "\r\n" + "from \r\n"
			+ "uw.ecgc_ecib_in_cover a \r\n" + "join\r\n" + "uw.ecgc_ecib_in_prop_sys b\r\n" + "on\r\n"
			+ "a.in_prop_sys_id = b.in_prop_sys_id\r\n" + "join\r\n" + "uw.ecgc_ecib_in_prop_decision c\r\n"
			+ "on b.in_prop_sys_id = c.in_prop_sys_id\r\n" + "\r\n" + "where\r\n" + "\r\n"
			+ "a.cover_type =  :coverType  \r\n" + "and a.issue_date between :fromDate and :toDate";

	public static final String GET_ECIB_ROXBO_R12 = "SELECT\r\n"

			+ "b.expoter_code,\r\n"

			+ "b.calculated_adp,\r\n"

			+ "b.calculated_adp_inr,\r\n"

			+ "a.\"month\" , a.\"year\" \r\n" + "FROM\r\n" + "uw.ecgc_ecib_wt_monthly_dcln a INNER join\r\n"
			+ "uw.ecgc_ecib_wt_mdpa_amd_exporterwise_entry b ON\r\n"
			+ "a.wt_monthly_dcln_id = b.wt_monthly_dcln_id \r\n" + "WHERE b.calculated_adp_inr > 1000000000\r\n"
			+ "AND (\r\n" + "          (a.\"year\" = :FromYear AND a.\"month\" >= :FromMonth) OR\r\n"
			+ "        (a.\"year\" > :FromYear AND a.\"year\" < :ToYear) OR\r\n"
			+ "        (a.\"year\" = :ToYear AND a.\"month\" <= :ToMonth)" + "    )\r\n" + "    group by\r\n"
			+ "b.expoter_code,\r\n" + "b.calculated_adp,\r\n" + "b.calculated_adp_inr,\r\n"
			+ "a.\"month\" , a.\"year\"\r\n" + "order by  a.\"year\" ";

	public static final String GET_ECIB_IN_U_R16 = "select \n" + "a.cover_number as \"coverNumber\",\n"
			+ "a.cover_type as \"coverType\",\n" + "b.bank_name as \"bankName\",\n"
			+ "c.bank_branch_name as \"bankBranchName\",\n" + "d.exporter_name as \"exporterName\",\n"
			+ "CASE WHEN d.highest_os_amt IS NULL THEN 0.0 ELSE d.highest_os_amt::numeric END as \"riskValue\",\n"
			+ "CASE WHEN a.prum_adjustment IS NULL THEN 0.0 ELSE a.prum_adjustment::numeric END as \"premiumAdjusted\",\n"
			+ "cast(a.month as integer) as \"month\",\n" + "cast(a.year as integer) as \"year\"\n" + "\n" + "from \n"
			+ "uw.ecgc_ecib_in_bipc_dcln a\n" + "join\n" + "uw.ecgc_ecib_bank_mst b\n"
			+ "on a.bank_code  = b.bank_code \n" + "join\n" + "uw.ecgc_ecib_bank_branch_mst c\n"
			+ "on b.bank_code = c.bank_code and a.bank_branch_code = c.bank_branch_code \n" + "join \n"
			+ "uw.ecgc_ecib_in_bipc_dcln_dtl_exporterwise d\n"
			+ "on a.in_bipc_declaratoin_id = d.in_bipc_declaratoin_id\n" + "WHERE \n"
			+ "       (cast(a.year as integer) = :fromYear AND cast(a.month as integer) >= :fromMonth) OR\n"
			+ "        (cast(a.year as integer) > :fromYear AND cast(a.year as integer) <  :toYear) OR\n"
			+ "        (cast(a.year as integer) =  :toYear AND cast(a.month as integer) <= :toMonth)";

	public static final String GET_ECIB_WT_U_R63 = "select \n" + "a.cover_type as \"ecibType\",\n"
			+ "b.bank_name as \"bankName\",\n"
			+ "CASE WHEN a.total_prum_remitted_by_branch_for_exporter IS NULL THEN 0.0 ELSE a.total_prum_remitted_by_branch_for_exporter::numeric END as \"premiumEarned\",\n"
			+ "CASE WHEN a.calculated_adp IS NULL THEN 0.0 ELSE a.calculated_adp::numeric END as \"riskValue\"\n"
			+ "from \n" + "uw.ecgc_ecib_wt_monthly_dcln a\n" + "join\n" + "uw.ecgc_ecib_bank_mst b\n"
			+ "on a.bank_code = b.bank_code\n" + "Where\n" + "((a.year  = :fromYear AND a.month  >= :fromMonth) OR\n"
			+ " (a.year  > :fromYear AND a.year  <  :toYear) OR\n" + " (a.year  =  :toYear AND a.month  <= :toMonth))";

	public static final String GET_ECIB_TYPEWISE = "select \n" + "a.cover_type as \"ecibType\",\n"
			+ "CASE WHEN sum(a.total_prum_remitted_by_branch_for_exporter) IS NULL THEN 0.0 ELSE sum(a.total_prum_remitted_by_branch_for_exporter)::numeric END as \"premiumEarned\",\n"
			+ "CASE WHEN sum(a.calculated_adp) IS NULL THEN 0.0 ELSE sum(a.calculated_adp)::numeric END as \"riskValue\"\n"
			+ "from \n" + "uw.ecgc_ecib_wt_monthly_dcln a\n" + "Where\n"
			+ "((a.year  = :fromYear AND a.month  >= :fromMonth) OR\n"
			+ " (a.year  > :fromYear AND a.year  <  :toYear) OR\n" + " (a.year  =  :toYear AND a.month  <= :toMonth))\n"
			+ "group by  a.cover_type";

	public static final String GET_ECIB_BANKWISE = "select \n" + "b.bank_name as \"bankName\",\n"
			+ "CASE WHEN sum(a.total_prum_remitted_by_branch_for_exporter) IS NULL THEN 0.0 ELSE sum(a.total_prum_remitted_by_branch_for_exporter)::numeric END as \"premiumEarned\",\n"
			+ "CASE WHEN sum(a.calculated_adp) IS NULL THEN 0.0 ELSE sum(a.calculated_adp)::numeric END as \"riskValue\"\n"
			+ "from \n" + "uw.ecgc_ecib_wt_monthly_dcln a\n" + "join\n" + "uw.ecgc_ecib_bank_mst b\n"
			+ "on a.bank_code = b.bank_code \n" + "Where\n" + "((a.year  = :fromYear AND a.month  >= :fromMonth) OR\n"
			+ " (a.year  > :fromYear AND a.year  <  :toYear) OR\n" + " (a.year  =  :toYear AND a.month  <= :toMonth))\n"
			+ " group by  b.bank_name";

	public static final String GET_ECIB_WT_U_R64 = "select\n" + "a.cover_type as \"ecibType\",\n"
			+ "c.description as \"ecgcBranchName\",\n"
			+ "CASE WHEN a.total_prum_remitted_by_branch_for_exporter IS NULL THEN 0.0 ELSE a.total_prum_remitted_by_branch_for_exporter::numeric END as \"premiumEarned\",\n"
			+ "CASE WHEN a.calculated_adp IS NULL THEN 0.0 ELSE a.calculated_adp::numeric END as \"riskValue\"\n"
			+ "from \n" + "uw.ecgc_ecib_wt_monthly_dcln a\n" + "join\n" + "uw.ecgc_ecib_bank_branch_mst b\n"
			+ "on a.bank_branch_code = b.bank_branch_code and a.bank_code = b.bank_code\n" + "join\n"
			+ "org_struct.ecgc_logical_loc_mst c\n" + "on b.logical_location_code = c.logicalloc_cd\n" + "\n"
			+ "where \n" + "\n" + "((a.year  = :fromYear AND a.month  >= :fromMonth) OR\n"
			+ " (a.year  > :fromYear  AND a.year  < :toYear) OR\n" + " (a.year  = :toYear AND a.month  <= :toMonth))";

	public static final String GET_ECIB_TYPEWISE1 = "select \n" + "a.cover_type as \"ecibType\",\n"
			+ "CASE WHEN sum(a.total_prum_remitted_by_branch_for_exporter) IS NULL THEN 0.0 ELSE sum(a.total_prum_remitted_by_branch_for_exporter)::numeric END as \"premiumEarned\",\n"
			+ "CASE WHEN sum(a.calculated_adp) IS NULL THEN 0.0 ELSE sum(a.calculated_adp)::numeric END as \"riskValue\"\n"
			+ "from \n" + "uw.ecgc_ecib_wt_monthly_dcln a\n" + "join\n" + "uw.ecgc_ecib_bank_mst b\n"
			+ "on a.bank_code = b.bank_code\n" + "join \n" + "uw.ecgc_ecib_bank_branch_mst c\n"
			+ "on a.bank_branch_code = c.bank_branch_code \n" + "join\n" + "org_struct.ecgc_logical_loc_mst d\n"
			+ "on c.logical_location_code = d.logicalloc_cd\n" + "where \n"
			+ "((a.year  = :fromYear AND a.month  >= :fromMonth) OR\n"
			+ " (a.year  > :fromYear  AND a.year  < :toYear) OR\n" + " (a.year  = :toYear AND a.month  <= :toMonth))\n"
			+ " group by a.cover_type\n";

	public static final String GET_ECIB_BANKWISE1 = "select \n" + "b.bank_name as \"bankName\",\n"
			+ "CASE WHEN sum(a.total_prum_remitted_by_branch_for_exporter) IS NULL THEN 0.0 ELSE sum(a.total_prum_remitted_by_branch_for_exporter)::numeric END as \"premiumEarned\",\n"
			+ "CASE WHEN sum(a.calculated_adp) IS NULL THEN 0.0 ELSE sum(a.calculated_adp)::numeric END as \"riskValue\"\n"
			+ "from \n" + "uw.ecgc_ecib_wt_monthly_dcln a\n" + "join\n" + "uw.ecgc_ecib_bank_mst b\n"
			+ "on a.bank_code = b.bank_code\n" + "join \n" + "uw.ecgc_ecib_bank_branch_mst c\n"
			+ "on a.bank_branch_code = c.bank_branch_code \n" + "join\n" + "org_struct.ecgc_logical_loc_mst d\n"
			+ "on c.logical_location_code = d.logicalloc_cd\n" + "where \n"
			+ "((a.year  = :fromYear AND a.month  >= :fromMonth) OR\n"
			+ " (a.year  > :fromYear  AND a.year  < :toYear) OR\n" + " (a.year  = :toYear AND a.month  <= :toMonth))\n"
			+ " group by b.bank_name";

	public static final String GET_ALL_COVER_TYPES = "select distinct cover_type from uw.ecgc_ecib_wt_monthly_dcln order by cover_type  asc;";

	public static final String GET_YEAR = "select distinct year from uw.ecgc_ecib_wt_monthly_dcln order by year  desc;";

	public static final String GET_MONTH = "select distinct month from uw.ecgc_ecib_wt_monthly_dcln order by month  asc;";

}
