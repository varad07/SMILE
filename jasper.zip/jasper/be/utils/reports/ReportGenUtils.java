package in.ecgc.smile.erp.reporting.jasper.be.utils.reports;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.text.DecimalFormat;

public class ReportGenUtils {
    public static String valueOf(Object value) {
        return value == null ? " " : value.toString();
    }

    public static String valueForBigDecimal(Object value) {
        if (value == null || String.valueOf(value).isEmpty()) {
            return String.valueOf(0);
        }

        String v = String.valueOf(value);
        if (v.contains("₹")) {
            return v.replaceAll("[₹,]", "").trim();
        }
        return v;

    }

    public static String formatIntoCurrency(final BigDecimal value, final boolean flag) {
        final StringBuilder sb = new StringBuilder();
        if (!flag) {
            return String.valueOf(value);
        }
        sb.append("₹");
        final int check = value.compareTo(new BigDecimal(1000));
        if (check < 0) {
            sb.append(format("##0.00", value));
        } else {
            final BigDecimal hundreds = value.remainder(new BigDecimal(1000));
            final BigInteger other = (value.divide(new BigDecimal(1000)).toBigInteger());
            sb.append(format(",#0", other) + ',' + format("000.00", hundreds));
        }
        return sb.toString();
    }

    private static String format(final String pattern, final Object value) {
        return new DecimalFormat(pattern).format(value);
    }

    private ReportGenUtils() {

    }
}
