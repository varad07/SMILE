package in.ecgc.smile.erp.reporting.jasper.be.utils;

import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.util.Locale;

public class FORMATS {

	public static final DateTimeFormatter DATE_FORMATS ;

	static {
		DATE_FORMATS = new DateTimeFormatterBuilder()
			.appendOptional(DateTimeFormatter.ofPattern("yyyy-MM-dd"))
			.appendOptional(DateTimeFormatter.ofPattern("yyyy/MMM/dd"))
			.appendOptional(DateTimeFormatter.ofPattern("yyyy-MMM-dd"))
	        .appendOptional(DateTimeFormatter.ofPattern("yyyy/MM/dd"))
	        .appendOptional(DateTimeFormatter.ofPattern("yyyy.MM.dd"))
	        .appendOptional(DateTimeFormatter.ofPattern("dd-MM-yyyy"))
	        .appendOptional(DateTimeFormatter.ofPattern("dd-MMM-yyyy"))
	        .appendOptional(DateTimeFormatter.ofPattern("dd-MMMM-yyyy"))
	        .appendOptional(DateTimeFormatter.ofPattern("dd/MM/yyyy"))
	        .appendOptional(DateTimeFormatter.ofPattern("dd.MM.yyyy"))
	        .appendOptional(DateTimeFormatter.ofPattern("MMM dd, yyyy"))
	        .appendOptional(DateTimeFormatter.ofPattern("dd MMM yyyy"))
	        .appendOptional(DateTimeFormatter.ofPattern("yyyy MMM dd"))
            .toFormatter(Locale.ENGLISH);
	}
}

