package in.ecgc.smile.erp.reporting.jasper.be.utils.poluw;

public interface PoluwQueries {

	public static final String POLICY_TYPES = "SELECT DISTINCT product_id AS product_alias\r\n"
			+ "FROM issue_endorse.ecgc_pol_schedule\r\n" + "ORDER BY product_id";
	

	public static final String GET_PREMIUM_PAID_DETAILS_SCR_ETP_BWP_SPP_SEP = "select c.exporter_cd,c.reg_company_name,c.group_cd,sch.product_id,sch.policy_no,sch.logicalloc_cd,sum(b.premium_chged) AS premium_chged\r\n"
			+ " FROM issue_endorse.ecgc_pol_schedule sch JOIN shd_rod_lossmin.ecgc_pol_shd_dtls_adj b ON sch.policy_no= b.pol_num join exp_mst.ecgc_pol_expo_mst c on sch.exporter_cd = c.exporter_cd \r\n"
			+ " where sch.product_id  = :policyType AND b.adjusted_dt>=:strt_dt AND b.adjusted_dt<:end_dt\r\n"
			+ " group by c.exporter_cd,c.reg_company_name,c.group_cd,sch.product_id,sch.policy_no,sch.logicalloc_cd";

	public static final String GET_PREMIUM_PAID_DETAILS_SITES_MITES_SPP = "select c.exporter_cd,c.reg_company_name,c.group_cd,sch.product_id,sch.policy_no,sch.logicalloc_cd,sum(b.premium_paid) AS premium_paid\r\n"
			+ "FROM issue_endorse.ecgc_pol_schedule sch JOIN shd_rod_lossmin.ecgc_pol_shd_sites_mites_spp_adj b ON sch.policy_no= b.pol_num join exp_mst.ecgc_pol_expo_mst c on sch.exporter_cd = c.exporter_cd \r\n"
			+ "where sch.product_id  = :policyType AND b.adjusted_dt>=:strt_dt AND b.adjusted_dt<:end_dt\r\n"
			+ "group by c.exporter_cd,c.reg_company_name,c.group_cd,sch.product_id,sch.policy_no,sch.logicalloc_cd";

	public static final String GET_PREMIUM_PAID_DETAILS_CSA_CGE = "select c.exporter_cd,c.reg_company_name,c.group_cd,sch.product_id,sch.policy_no,sch.logicalloc_cd,sum(b.premium_chged) AS premium_chged\r\n"
			+ " FROM issue_endorse.ecgc_pol_schedule sch JOIN shd_rod_lossmin.ecgc_pol_shd_csa_cge_adj b ON sch.policy_no= b.pol_num join exp_mst.ecgc_pol_expo_mst c on sch.exporter_cd = c.exporter_cd \r\n"
			+ " where sch.product_id  = :policyType AND b.adjusted_dt>=:strt_dt AND b.adjusted_dt<:end_dt\r\n"
			+ " group by c.exporter_cd,c.reg_company_name,c.group_cd,sch.product_id,sch.policy_no,sch.logicalloc_cd";

	public static final String GET_PREMIUM_PAID_DETAILS_MBEP_SBEP = "select c.exporter_cd,c.reg_company_name,c.group_cd,sch.product_id,sch.policy_no,sch.logicalloc_cd,sum(b.premium_paid) AS premium_paid\r\n"
			+ " FROM issue_endorse.ecgc_pol_schedule sch JOIN shd_rod_lossmin.ecgc_pol_shd_sbep_mbep_adj b ON sch.policy_no= b.pol_num join exp_mst.ecgc_pol_expo_mst c on sch.exporter_cd = c.exporter_cd \r\n"
			+ " where sch.product_id  = :policyType AND b.adjusted_dt>=:strt_dt AND b.adjusted_dt<:end_dt\r\n"
			+ " group by c.exporter_cd,c.reg_company_name,c.group_cd,sch.product_id,sch.policy_no,sch.logicalloc_cd";

	public static final String GET_EXPOSURE_BASED_RV_AND_PREMIUM = "select b.region_id_fk ,b.office_id_fk ,a.policy_no,\r\n"
			+ " case\r\n" + "	 when a.product_id IN ('MBE', 'MBF') THEN a.ml_ll_all\r\n"
			+ "     when a.product_id in ('SBE', 'SBF') then A.ml_ll_all * 4 \r\n" + " end as risk_value,\r\n"
			+ " sum(c.premium_paid) as total_premium_paid\r\n" + "   from \r\n"
			+ " issue_endorse.ecgc_pol_schedule a join org_struct.ecgc_hrd_office_region_rel b on a.logicalloc_cd = b.office_id_fk \r\n"
			+ " join shd_rod_lossmin.ecgc_pol_shd_sbep_mbep_adj c on a.policy_no = c.pol_num \r\n"
			+ " where c.prem_adj_status = 'Y' \r\n" + " and c.adjusted_dt>=:strt_dt and c.adjusted_dt<:end_dt\r\n"
			+ " group by b.region_id_fk ,a.policy_no,Risk_Value,b.office_id_fk \r\n" + " union \r\n"
			+ " select b.region_id_fk ,b.office_id_fk ,a.policy_no,\r\n" + " case\r\n"
			+ "	 when a.product_id = 'MITES' THEN a.ml_ll_all * 3\r\n"
			+ "     when a.product_id in ('SITES', 'SSP') then A.ml_ll_all * 4 \r\n" + " end as risk_value,\r\n"
			+ " sum(c.premium_paid) as total_premium_paid\r\n" + "   from \r\n"
			+ " issue_endorse.ecgc_pol_schedule a join org_struct.ecgc_hrd_office_region_rel b on a.logicalloc_cd = b.office_id_fk \r\n"
			+ " join shd_rod_lossmin.ecgc_pol_shd_sites_mites_spp_adj c on a.policy_no = c.pol_num \r\n"
			+ " where c.prem_adj_status = 'Y' and c.adjusted_dt>=:strt_dt and c.adjusted_dt<:end_dt\r\n"
			+ " group by b.region_id_fk ,a.policy_no,Risk_Value,b.office_id_fk";

	public static final String GET_REGION = "select distinct region_id_fk from org_struct.ecgc_hrd_office_region_rel";

	public static final String GET_REGION_BRANCH="SELECT \r\n"
			+ "    b.region_id_fk as \"region\",\r\n"
			+ "    a.office_id as \"officeId\"\r\n"
			+ "FROM \r\n"
			+ "    org_struct.ecgc_hrd_office_mst a\r\n"
			+ "JOIN \r\n"
			+ "    org_struct.ecgc_hrd_office_region_rel b  \r\n"
			+ "ON \r\n"
			+ "    a.office_id = b.office_id_fk\r\n"
			+ "ORDER BY \r\n"
			+ "    b.region_id_fk";
}
