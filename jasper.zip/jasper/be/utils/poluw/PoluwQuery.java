package in.ecgc.smile.erp.reporting.jasper.be.utils.poluw;

import in.ecgc.smile.erp.reporting.jasper.be.utils.queries.DaoQueryInterface;

public enum PoluwQuery implements DaoQueryInterface {

	POL_ST_A_UW_012_A_01(
			"WITH cte AS (SELECT d.region_id_fk AS Region_Code, a.dest_cnty_cd AS Country, a.commodity_cd AS Commodity, b.logicalloc_cd AS Branch, c.product_id AS Policy_Type, SUM(a.giv_inr) AS Risk_Value, SUM(b.premium_chged) AS Premium_Adjusted FROM shd_rod_lossmin.ecgc_pol_shd_dtls a JOIN shd_rod_lossmin.ecgc_pol_shd_dtls_adj b ON a.pol_num = b.pol_num AND a.logicalloc_cd::text = b.logicalloc_cd::text JOIN issue_endorse.ecgc_pol_schedule c ON b.pol_num = c.policy_no AND b.logicalloc_cd::text = c.logicalloc_cd::text JOIN org_struct.ecgc_hrd_office_region_rel d ON c.logicalloc_cd::text = d.office_id_fk::text WHERE c.pol_end_dt BETWEEN :fromDate::date AND :toDate::date GROUP BY Region_Code, Country, Commodity, Branch, Policy_Type UNION SELECT d.region_id_fk AS Region_Code, a.dest_cnty_cd AS Country, a.commodity_cd AS Commodity, b.logicalloc_cd AS Branch, c.product_id AS Policy_Type, SUM(a.giv_inr) AS Risk_Value, SUM(b.premium_chged) AS Premium_Adjusted FROM shd_rod_lossmin.ecgc_pol_shd_csa_cge_mdecl a JOIN shd_rod_lossmin.ecgc_pol_shd_csa_cge_adj b ON a.pol_num = b.pol_num AND a.logicalloc_cd::text = b.logicalloc_cd::text JOIN issue_endorse.ecgc_pol_schedule c ON b.pol_num = c.policy_no AND b.logicalloc_cd::text = c.logicalloc_cd::text JOIN org_struct.ecgc_hrd_office_region_rel d ON c.logicalloc_cd::text = d.office_id_fk::text WHERE c.pol_end_dt BETWEEN :fromDate::date AND :toDate::date GROUP BY Region_Code, Country, Commodity, Branch, Policy_Type) SELECT Region_Code, Country, Commodity, Branch, Policy_Type, Risk_Value, Premium_Adjusted FROM cte WHERE cte.Policy_Type = :policyType AND Region_Code = :region"),
	
	POL_ST_A_UW_010_A_01("SELECT\r\n"
			+ "        CASE\r\n"
			+ "            WHEN row_number() OVER (PARTITION BY ecgc_pol_expo_mst.region_cd ORDER BY ecgc_pol_expo_mst.preferred_ecgc_branch) = 1 THEN ecgc_pol_expo_mst.region_cd\r\n"
			+ "            ELSE NULL::character varying\r\n"
			+ "        END AS \"Region\",\r\n"
			+ "        CASE\r\n"
			+ "            WHEN GROUPING(ecgc_pol_expo_mst.region_cd) = 0 AND GROUPING(ecgc_pol_expo_mst.preferred_ecgc_branch) = 0 THEN ecgc_pol_expo_mst.preferred_ecgc_branch::text\r\n"
			+ "            ELSE ('Subtotal of '::text || ecgc_pol_expo_mst.region_cd::text) || 'Exporters Count'::text\r\n"
			+ "        END AS \"Branch Name\",\r\n"
			+ "    count(DISTINCT ecgc_pol_expo_mst.exporter_cd) AS \"Exporter Count\"\r\n"
			+ "   FROM exp_mst.ecgc_pol_expo_mst\r\n"
			+ "     JOIN issue_endorse.ecgc_pol_schedule ON ecgc_pol_expo_mst.exporter_cd = ecgc_pol_schedule.exporter_cd\r\n"
			+ "  WHERE ecgc_pol_schedule.pol_closure_flg = 'N'::bpchar and exp_mst.ecgc_pol_expo_mst.created_dt <= :inputDate::date\r\n"
			+ "  GROUP BY GROUPING SETS ((ecgc_pol_expo_mst.region_cd, ecgc_pol_expo_mst.preferred_ecgc_branch), (ecgc_pol_expo_mst.region_cd))\r\n"
			+ "HAVING GROUPING(ecgc_pol_expo_mst.preferred_ecgc_branch) = 1 OR GROUPING(ecgc_pol_expo_mst.region_cd) = 0\r\n"
			+ "  ORDER BY ecgc_pol_expo_mst.region_cd, ecgc_pol_expo_mst.preferred_ecgc_branch"),
	
	POL_ST_A_UW_019_A_01("SELECT \r\n"
			+ "    e.region_id_fk AS \"Region Code\",\r\n"
			+ "    d.branch_name AS \"ECGC Branch Name\",\r\n"
			+ "    d.office_id  AS \"Logical Location Code\",\r\n"
			+ "    c.product_id AS \"Policy Type\",\r\n"
			+ "    COUNT(a.shpmnt_seq_id) AS \"No Of Shipments\",\r\n"
			+ "    CASE\r\n"
			+ "        WHEN SUM(a.giv_inr)::double precision = 0::double precision THEN '₹ 0.00'::text\r\n"
			+ "        ELSE '₹'::text || TO_CHAR(SUM(a.giv_inr), 'FM999,999,999,999,999,999,999,999,999,999.00'::text)\r\n"
			+ "    END AS \"Risk Value\",\r\n"
			+ "    CASE\r\n"
			+ "        WHEN SUM(b.premium_chged)::double precision = 0::double precision THEN '₹ 0.00'::text\r\n"
			+ "        ELSE '₹'::text || TO_CHAR(SUM(b.premium_chged), 'FM999,999,999,999,999,999,999,999,999,999.00'::text)\r\n"
			+ "    END AS \"Premium Adjusted\"\r\n"
			+ "FROM \r\n"
			+ "    shd_rod_lossmin.ecgc_pol_shd_dtls a\r\n"
			+ "    JOIN shd_rod_lossmin.ecgc_pol_shd_dtls_adj b ON a.shpmnt_seq_id = b.shpmnt_seq_id\r\n"
			+ "    JOIN issue_endorse.ecgc_pol_schedule c ON a.pol_num = c.policy_no AND a.pol_num = c.policy_no\r\n"
			+ "    JOIN org_struct.ecgc_branch_mst d ON c.logicalloc_cd::text = d.office_id::text\r\n"
			+ "    JOIN org_struct.ecgc_hrd_office_region_rel e ON d.office_id::text = e.office_id_fk::text\r\n"
			+ "WHERE \r\n"
			+ "    e.region_id_fk = :input\r\n"
			+ "    AND a.shpment_dt BETWEEN CAST(:fromDate AS date) AND CAST(:toDate AS date)\r\n"
			+ "GROUP BY \r\n"
			+ "   d.office_id , c.product_id, e.region_id_fk, d.branch_name\r\n"
			+ "\r\n"
			+ "UNION\r\n"
			+ "\r\n"
			+ "SELECT \r\n"
			+ "    e.region_id_fk AS \"Region Code\",\r\n"
			+ "    d.branch_name AS \"ECGC Branch Name\",\r\n"
			+ "    d.office_id AS \"Logical Location Code\",\r\n"
			+ "    c.product_id AS \"Policy Type\",\r\n"
			+ "    COUNT(f.shpmnt_seq_id) AS \"No Of Shipments\",\r\n"
			+ "    CASE\r\n"
			+ "        WHEN SUM(f.giv_inr)::double precision = 0::double precision THEN '₹ 0.00'::text\r\n"
			+ "        ELSE '₹'::text || TO_CHAR(SUM(f.giv_inr), 'FM999,999,999,999,999,999,999,999,999,999.00'::text)\r\n"
			+ "    END AS \"Risk Value\",\r\n"
			+ "    CASE\r\n"
			+ "        WHEN SUM(b.premium_chged)::double precision = 0::double precision THEN '₹ 0.00'::text\r\n"
			+ "        ELSE '₹'::text || TO_CHAR(SUM(b.premium_chged), 'FM999,999,999,999,999,999,999,999,999,999.00'::text)\r\n"
			+ "    END AS \"Premium Adjusted\"\r\n"
			+ "FROM \r\n"
			+ "    shd_rod_lossmin.ecgc_pol_shd_dtls a\r\n"
			+ "    JOIN shd_rod_lossmin.ecgc_pol_shd_csa_cge_adj b ON a.shpmnt_seq_id = b.shpmnt_seq_id\r\n"
			+ "    JOIN issue_endorse.ecgc_pol_schedule c ON a.pol_num = c.policy_no AND b.pol_num = c.policy_no\r\n"
			+ "    JOIN org_struct.ecgc_branch_mst d ON c.logicalloc_cd::text = d.office_id::text\r\n"
			+ "    JOIN org_struct.ecgc_hrd_office_region_rel e ON d.office_id::text = e.office_id_fk::text\r\n"
			+ "    JOIN shd_rod_lossmin.ecgc_pol_shd_csa_cge_mdecl f ON a.shpmnt_seq_id::text = f.shpmnt_seq_id::text\r\n"
			+ "WHERE \r\n"
			+ "    e.region_id_fk = :input\r\n"
			+ "    AND f.shpment_dt BETWEEN CAST(:fromDate AS date) AND CAST(:toDate AS date)\r\n"
			+ "GROUP BY \r\n"
			+ "    d.office_id , c.product_id, e.region_id_fk, d.branch_name;\r\n"
			+ ""),
	
	POL_ST_A_UW_019_B_01("SELECT \r\n"
			+ "    e.region_id_fk AS \"Region Code\",\r\n"
			+ "    d.branch_name AS \"ECGC Branch Name\",\r\n"
			+ "    d.office_id  AS \"Logical Location Code\",\r\n"
			+ "    c.product_id AS \"Policy Type\",\r\n"
			+ "    COUNT(a.shpmnt_seq_id) AS \"No Of Shipments\",\r\n"
			+ "    CASE\r\n"
			+ "        WHEN SUM(a.giv_inr)::double precision = 0::double precision THEN '₹ 0.00'::text\r\n"
			+ "        ELSE '₹'::text || TO_CHAR(SUM(a.giv_inr), 'FM999,999,999,999,999,999,999,999,999,999.00'::text)\r\n"
			+ "    END AS \"Risk Value\",\r\n"
			+ "    CASE\r\n"
			+ "        WHEN SUM(b.premium_chged)::double precision = 0::double precision THEN '₹ 0.00'::text\r\n"
			+ "        ELSE '₹'::text || TO_CHAR(SUM(b.premium_chged), 'FM999,999,999,999,999,999,999,999,999,999.00'::text)\r\n"
			+ "    END AS \"Premium Adjusted\"\r\n"
			+ "FROM \r\n"
			+ "    shd_rod_lossmin.ecgc_pol_shd_dtls a\r\n"
			+ "    JOIN shd_rod_lossmin.ecgc_pol_shd_dtls_adj b ON a.shpmnt_seq_id = b.shpmnt_seq_id\r\n"
			+ "    JOIN issue_endorse.ecgc_pol_schedule c ON a.pol_num = c.policy_no AND a.pol_num = c.policy_no\r\n"
			+ "    JOIN org_struct.ecgc_branch_mst d ON c.logicalloc_cd::text = d.office_id::text\r\n"
			+ "    JOIN org_struct.ecgc_hrd_office_region_rel e ON d.office_id::text = e.office_id_fk::text\r\n"
			+ "WHERE \r\n"
			+ "    d.office_id  = :input\r\n"
			+ "    AND a.shpment_dt BETWEEN CAST(:fromDate AS date) AND CAST(:toDate AS date)\r\n"
			+ "GROUP BY \r\n"
			+ "   d.office_id , c.product_id, e.region_id_fk, d.branch_name\r\n"
			+ "\r\n"
			+ "UNION\r\n"
			+ "\r\n"
			+ "SELECT \r\n"
			+ "    e.region_id_fk AS \"Region Code\",\r\n"
			+ "    d.branch_name AS \"ECGC Branch Name\",\r\n"
			+ "    d.office_id AS \"Logical Location Code\",\r\n"
			+ "    c.product_id AS \"Policy Type\",\r\n"
			+ "    COUNT(f.shpmnt_seq_id) AS \"No Of Shipments\",\r\n"
			+ "    CASE\r\n"
			+ "        WHEN SUM(f.giv_inr)::double precision = 0::double precision THEN '₹ 0.00'::text\r\n"
			+ "        ELSE '₹'::text || TO_CHAR(SUM(f.giv_inr), 'FM999,999,999,999,999,999,999,999,999,999.00'::text)\r\n"
			+ "    END AS \"Risk Value\",\r\n"
			+ "    CASE\r\n"
			+ "        WHEN SUM(b.premium_chged)::double precision = 0::double precision THEN '₹ 0.00'::text\r\n"
			+ "        ELSE '₹'::text || TO_CHAR(SUM(b.premium_chged), 'FM999,999,999,999,999,999,999,999,999,999.00'::text)\r\n"
			+ "    END AS \"Premium Adjusted\"\r\n"
			+ "FROM \r\n"
			+ "    shd_rod_lossmin.ecgc_pol_shd_dtls a\r\n"
			+ "    JOIN shd_rod_lossmin.ecgc_pol_shd_csa_cge_adj b ON a.shpmnt_seq_id = b.shpmnt_seq_id\r\n"
			+ "    JOIN issue_endorse.ecgc_pol_schedule c ON a.pol_num = c.policy_no AND b.pol_num = c.policy_no\r\n"
			+ "    JOIN org_struct.ecgc_branch_mst d ON c.logicalloc_cd::text = d.office_id::text\r\n"
			+ "    JOIN org_struct.ecgc_hrd_office_region_rel e ON d.office_id::text = e.office_id_fk::text\r\n"
			+ "    JOIN shd_rod_lossmin.ecgc_pol_shd_csa_cge_mdecl f ON a.shpmnt_seq_id::text = f.shpmnt_seq_id::text\r\n"
			+ "WHERE \r\n"
			+ "    d.office_id  = :input\r\n"
			+ "    AND f.shpment_dt BETWEEN CAST(:fromDate AS date) AND CAST(:toDate AS date)\r\n"
			+ "GROUP BY \r\n"
			+ "    d.office_id , c.product_id, e.region_id_fk, d.branch_name;\r\n"
			+ "")
	
	
	;
	
	private String query;

	private PoluwQuery(String query) {
		this.query = query;
	}

	public String getQuery() {
		return query;
	}

	
}
