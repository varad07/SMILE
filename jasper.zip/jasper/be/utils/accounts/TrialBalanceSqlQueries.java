package in.ecgc.smile.erp.reporting.jasper.be.utils.accounts;

public interface TrialBalanceSqlQueries {

	public static final String GET_TRIAL_BALANCE_ALL_LOC = "SELECT * FROM reporting.ecgc_acct_trial_bal_all_loc where input_date = :input_date and (dr_amount = 0 or cr_amount = 0 ) order by maingl_cd , subgl_cd";

	public static final String GET_TRIAL_BALANCE_ALL_LOC_NOT_NIL = "SELECT * FROM reporting.ecgc_acct_trial_bal_all_loc where input_date = :input_date and (dr_amount != 0 or cr_amount != 0 ) order by maingl_cd , subgl_cd";

	public static final String GET_TRIAL_BALANCE_ALL_LOC_COUNT = "SELECT count(*) as count FROM reporting.ecgc_acct_trial_bal_all_loc where input_date = :input_date";

	public static final String GET_TRIAL_BALANCE_LOC_WISE = "select * from reporting.ecgc_acct_trial_bal_location_wise \r\n"
			+ "where input_date = :input_date and logical_loc_cd = :logical_loc_cd and (dr_amount = 0 or cr_amount = 0 ) order by maingl_cd , subgl_cd";

	public static final String GET_TRIAL_BALANCE_STATE_WISE = "select * from reporting.ecgc_acct_trial_bal_state_wise \r\n"
			+ "where input_date = :input_date and state = :state and (dr_amount = 0 or cr_amount = 0 ) order by maingl_cd , subgl_cd";

	public static final String GET_TRIAL_BALANCE_REGION_WISE = "select * from reporting.ecgc_acct_trial_bal_region_wise \r\n"
			+ "where input_date = :input_date and region = :region and (dr_amount = 0 or cr_amount = 0 ) order by maingl_cd , subgl_cd";

	public static final String GET_TRIAL_BALANCE_GL_WISE = "select * from reporting.ecgc_acct_trial_bal_by_gl_code_all_location \r\n"
			+ "where input_date = :input_date and mainglCd = :mainglCd and subGlCd = :subGlCd and (dr_amount = 0 or cr_amount = 0 ) order by mainglCd , subGlCd";

	public static final String GET_TRIAL_BALANCE_STATE_WISE_NOT_NIL = "select * from reporting.ecgc_acct_trial_bal_state_wise \r\n"
			+ "where input_date = :input_date and state = :state and (dr_amount != 0 or cr_amount != 0 ) order by maingl_cd , subgl_cd";

	public static final String GET_TRIAL_BALANCE_REGION_WISE_NOT_NIL = "select * from reporting.ecgc_acct_trial_bal_region_wise \r\n"
			+ "where input_date = :input_date and region = :region and (dr_amount != 0 or cr_amount != 0 ) order by maingl_cd , subgl_cd";

	public static final String GET_TRIAL_BALANCE_GL_WISE_NOT_NIL = "select * from reporting.ecgc_acct_trial_bal_by_gl_code_all_location where input_date = :input_date and mainglCd = :mainglCd and subGlCd = :subGlCd and(dr_amount != 0 or cr_amount != 0 ) order by mainglCd , subGlCd";

	public static final String GET_TRIAL_BALANCE_LOC_WISE_NOT_NIL = "select * from reporting.ecgc_acct_trial_bal_location_wise \r\n"
			+ "where input_date = :input_date and logical_loc_cd = :logical_loc_cd and (dr_amount != 0 or cr_amount != 0 ) order by maingl_cd , subgl_cd";

	public static final String GET_TRIAL_BALANCE_LOC_WISE_COUNT = "select count(*) as count from reporting.ecgc_acct_trial_bal_location_wise \r\n"
			+ "where input_date = :input_date and logical_loc_cd = :logical_loc_cd ";

	public static final String GET_TRIAL_BALANCE_LOC_DR_CR_AMOUNT = "select coalesce (sum(dr_amount), 0) as total_dr, coalesce (sum(cr_amount), 0) as total_cr \r\n"
			+ "FROM reporting.ecgc_acct_trial_bal_location_wise where\r\n"
			+ "input_date = :input_date and logical_loc_cd = :logical_loc_cd and\r\n" + "gl_type = :glType";

	public static final String GET_TRIAL_BALANCE_ALL_LOC_DR_CR_AMOUNT = "select sum(dr_amount) as total_dr, sum(cr_amount) as total_cr\r\n"
			+ "FROM reporting.ecgc_acct_trial_bal_all_loc where\r\n" + "gl_type = :glType and input_date = :input_date";

	public static final String GET_TRIAL_BALANCE_STATE_DR_CR_AMOUNT = "select coalesce (sum(dr_amount), 0) as total_dr, coalesce (sum(cr_amount), 0) as total_cr \r\n"
			+ "FROM reporting.ecgc_acct_trial_bal_state_wise where\r\n"
			+ "input_date = :input_date and state = :state and\r\n" + "gl_type = :glType";

	public static final String GET_TRIAL_BALANCE_REGION_DR_CR_AMOUNT = "select coalesce (sum(dr_amount), 0) as total_dr, coalesce (sum(cr_amount), 0) as total_cr \r\n"
			+ "FROM reporting.ecgc_acct_trial_bal_region_wise where\r\n"
			+ "input_date = :input_date and region = :region and\r\n" + "gl_type = :glType";

	public static final String GET_TRIAL_BALANCE_GL_DR_CR_AMOUNT = "select coalesce (sum(dr_amount), 0) as total_dr, coalesce (sum(cr_amount), 0) as total_cr \r\n"
			+ "FROM reporting.ecgc_acct_trial_bal_by_gl_code_all_location where\r\n"
			+ "input_date = :input_date and mainglCd = :mainglCd and subGlCd = :subGlCd  and\r\n" + "gl_type = :glType";

	// -----------------

	public static final String GETERATE_TRIAL_BALANCE_ALL_LOC = "call reporting.create_trial_balance_all_location_view_based(:input_date, 0)";

	public static final String GETERATE_TRIAL_BALANCE_LOC_WISE = "call reporting.create_trial_balance_location_wise_view_based(:input_date,:logical_location, 0)";

	public static final String GETERATE_TRIAL_BALANCE_STATE_WISE = "call reporting.create_trial_balance_state_wise_view_based(:input_date,:state, 0)";

	public static final String GETERATE_TRIAL_BALANCE_REGION_WISE = "call reporting.create_trial_balance_region_wise_view_based(:input_date,:region, 0)";

	public static final String GETERATE_TRIAL_BALANCE_GL_WISE = "call reporting.create_trial_balance_gl_code_wise_all_location_view_based(:inputDate,:mainglCd, :subGlCd, 0)";

	public static final String GET_TRIAL_BAL_BY_LOGLOC = "call reporting.get_trial_balance_gl_loc_wise(:mainglCd,:subglCd,:balancedt,:logicallocCd,'0','0')";

	public static final String GET_CS_TRIAL_BAL_BY_GL = "CALL reporting.get_cs_trial_balance_gl_wise(:mainglCd, :subglCd, :balancedt, '0', '0')";

	public static final String GET_TRIAL_BAL_FOR_ALL_LOGLOC = "call reporting.get_trial_balance_gl_wise(:mainglCd,:subglCd,:balancedt,'0','0')";

	public static final String GET_TRIAL_BAL_BY_LOC_PLCD = "call reporting.get_trial_balance_gl_loc_pl_wise(:mainglCd, :subglCd, :balancedt, :logicalLocCd, :plCd, 1, 1,'V','V')";

	public static final String GET_TRIAL_BAL_BY_TCODE_WISE = "call reporting.get_trial_balance_gl_loc_tcode_wise(:inp_tb_json, 0, 0)";

	public static final String GET_TRIAL_BAL_BY_TCODE_SUBBF_WISE = "call reporting.get_trial_balance_gl_loc_tcode_subbf_wise(:inp_tb_json, 0, 0)";

	public static final String GET_ECGC_BRANCH_CODE_LIST = "select logicalloc_cd from org_struct.ecgc_logical_loc_mst order by logicalloc_cd";

	public static final String GET_STATE_LIST = "select distinct state_id from org_struct.ecgc_hrd_state_mst order by state_id";

	public static final String GET_REGION_LIST = "select distinct region_id_fk from  org_struct.ecgc_hrd_office_region_rel order by region_id_fk";

	// pf trial balace

	public static final String GETERATE_PF_TRIAL_BALANCE_ALL_LOC = "call reporting.create_pf_accounts_trial_balance_all_location_view_based(:input_date, 0)";

	public static final String GET_PF_TRIAL_BALANCE_ALL_LOC = "SELECT * FROM reporting.ecgc_pf_acct_trial_bal_all_loc where input_date = :input_date and (dr_amount = 0 or cr_amount = 0 ) order by maingl_cd , subgl_cd";

	public static final String GET_PF_TRIAL_BALANCE_ALL_LOC_NOT_NIL = "SELECT * FROM reporting.ecgc_pf_acct_trial_bal_all_loc where input_date = :input_date and (dr_amount != 0 or cr_amount != 0 ) order by maingl_cd , subgl_cd";

	public static final String GET_PF_TRIAL_BALANCE_ALL_LOC_DR_CR_AMOUNT = "select sum(dr_amount) as total_dr, sum(cr_amount) as total_cr\r\n"
			+ "FROM reporting.ecgc_pf_acct_trial_bal_all_loc where\r\n"
			+ "gl_type = :glType and input_date = :input_date";

	public static final String GET_TRIAL_BAL_BY_LOGLOC_SUBBF_WISE = "call reporting.get_trial_balance_gl_loc_subbif_wise(:mainglCd,:subglCd,:balancedt,:logicallocCd,:subbfCd,'0','0')";

	public static final String GET_TRIAL_BAL_BY_LOGLOC_SUBBF_LIST_WISE = "call reporting.get_trial_balance_gl_loc_subbif_list_wise(:mainglCd,:subglCd,:balancedt,:logicallocCd,:subbfCdList,'0','0')";

	// public static final String GET_TRIAL_BAL_BY_LOGLOC_SUBBF_WISE = "call accounts.get_trial_balance_gl_loc_subbif_wise(:mainglCd,:subglCd,:balancedt,:logicallocCd,:subbfCd,'0','0')";

	// public static final String GET_TRIAL_BAL_BY_LOGLOC_SUBBF_LIST_WISE = "call accounts.get_trial_balance_gl_loc_subbif_list_wise(:mainglCd,:subglCd,:balancedt,:logicallocCd,:subbfCdList,'0','0')";

}