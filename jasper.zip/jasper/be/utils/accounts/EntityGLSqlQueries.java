package in.ecgc.smile.erp.reporting.jasper.be.utils.accounts;

public interface EntityGLSqlQueries {

	public static final String GET_ENTITY_GL = "select * from accounts.ecgc_acct_entity_gl_mst where maingl_cd =:mainCode and subgl_cd =:subCode";

	public static final String GET_ENTITY_BANK_GL = "select * from cs.ecgc_cs_entity_gl_mst where maingl_cd = :mainCode and subgl_cd = :subCode";

	
	
}
