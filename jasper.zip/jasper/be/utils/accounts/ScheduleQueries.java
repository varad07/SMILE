package in.ecgc.smile.erp.reporting.jasper.be.utils.accounts;

public class ScheduleQueries {
	
	public static final String CHECK_FOR_DATE="select count(*) from reporting.ecgc_acct_trial_bal_all_loc_schedule_cur\r\n"
												+ "where input_date = :inputDate;";
	
	
	public static final String GET_SCHEDULE_BALANCE =
			"select \r\n"
			+ "				sum(tb.dr_amount) dr_amount , \r\n"
			+ "				sum(tb.cr_amount) cr_amount \r\n"
			+ "				from \r\n"
			+ "				reporting.ecgc_acct_trial_bal_all_loc_schedule_cur  tb \r\n"
			+ "				inner join  \r\n"
			+ "				reporting.ecgc_acct_schedule_cd_gl_mapping_final schmapp \r\n"
			+ "				on \r\n"
			+ "				tb.maingl_cd = schmapp.maingl_cd	and  \r\n"
			+ "				tb.subgl_cd = schmapp.subgl_cd \r\n"
			+ "				where \r\n"
			+ "				schmapp.schedule_cd = :scheduleCd \r\n"
			+ "				and schmapp.schedule_item_cd = :scheduleItemCd and input_date = :inputDate";
	
	public static final String GET_SCHEDULE_BALANCE_PRV =
			"select "
			+ "sum(tb.dr_amount) dr_amount , "
			+ "sum(tb.cr_amount) cr_amount "
			+ "from "
			+ "reporting.ecgc_acct_trial_bal_all_loc_schedule_prv tb "
			+ "inner join  "
			+ "reporting.ecgc_acct_schedule_cd_gl_mapping_final schmapp "
			+ "on "
			+ "tb.maingl_cd = schmapp.maingl_cd	and  "
			+ "tb.subgl_cd = schmapp.subgl_cd "
			+ "where "
			+ "schmapp.schedule_cd = :scheduleCd "
			+ "and schmapp.schedule_item_cd = :scheduleItemCd and input_date = :inputDate";
	
	public static final String GENERATE_CUR_TB="call reporting.create_trial_balance_all_location_view_based_schedule_cur_dt(:inputDate,0)";
	
	
	public static final String GENERATE_PR_TB="call reporting.create_trial_balance_all_location_view_based_schedule_prv_dt(:inputDate, 0)";

}
