package in.ecgc.smile.erp.reporting.jasper.be.utils.queries;

public interface DaoQueryInterface {
    public String getQuery();

    public static <T extends Enum<T> & DaoQueryInterface> String getValueOf(Class<T> queryClass, String reportId)
            throws NullPointerException, IllegalArgumentException {

        return Enum.valueOf(queryClass, reportId).getQuery();

    }

}
