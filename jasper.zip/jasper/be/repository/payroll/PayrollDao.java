package in.ecgc.smile.erp.reporting.jasper.be.repository.payroll;

public interface PayrollDao {

}
