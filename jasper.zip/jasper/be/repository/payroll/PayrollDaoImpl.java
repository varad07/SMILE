package in.ecgc.smile.erp.reporting.jasper.be.repository.payroll;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcOperations;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;


@Repository
public class PayrollDaoImpl implements PayrollDao{
	
	
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	private JdbcOperations jdbcOperations;
	private static final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(PayrollDaoImpl.class);
	
	public PayrollDaoImpl(DataSource dataSource) {
		super();
		jdbcOperations = new JdbcTemplate(dataSource);
		namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(dataSource);
	}

}
