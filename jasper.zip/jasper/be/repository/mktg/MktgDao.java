package in.ecgc.smile.erp.reporting.jasper.be.repository.mktg;

import java.util.List;

import in.ecgc.smile.erp.reporting.jasper.be.model.mktg.FormIXAgencyOrgStmt;
import in.ecgc.smile.erp.reporting.jasper.be.model.mktg.MKTIDRAI07;
import in.ecgc.smile.erp.reporting.jasper.be.model.mktg.MKTIRDAI02;
import in.ecgc.smile.erp.reporting.jasper.be.model.mktg.MKTIRDAI05Model;

public interface MktgDao {
	
	public List<FormIXAgencyOrgStmt> getListMktIDRAI04(String fromDate, String toDate);

	public List<MKTIRDAI05Model> getListMktIDRAI05(String fromDate, String toDate);

	public List<MKTIRDAI02> getListMktIDRAI02(String fromDate, String toDate);

	public List<MKTIDRAI07> getListMktIDRAI07(String fromDate, String toDate);

}
