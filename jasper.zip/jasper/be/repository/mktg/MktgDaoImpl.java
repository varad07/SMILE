package in.ecgc.smile.erp.reporting.jasper.be.repository.mktg;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcOperations;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import in.ecgc.smile.erp.reporting.jasper.be.model.mktg.FormIXAgencyOrgStmt;
import in.ecgc.smile.erp.reporting.jasper.be.model.mktg.MKTIDRAI07;
import in.ecgc.smile.erp.reporting.jasper.be.model.mktg.MKTIRDAI02;
import in.ecgc.smile.erp.reporting.jasper.be.model.mktg.MKTIRDAI05Model;
import in.ecgc.smile.erp.reporting.jasper.be.utils.mktg.MktgQueries;


@Repository
public class MktgDaoImpl implements MktgDao {
	
	
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	private JdbcOperations jdbcOperations;
	private static final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(MktgDaoImpl.class);
 
	public MktgDaoImpl(DataSource dataSource) {
		super();
		jdbcOperations = new JdbcTemplate(dataSource);
		namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(dataSource);
	}

	@Override
	public List<FormIXAgencyOrgStmt> getListMktIDRAI04(String fromDate, String toDate) throws DataAccessException {
		
		String sql = MktgQueries.GET_MKTIDRAI04;
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		
		Date fromDt = null;
		Date toDt = null;
		
		try {
			fromDt = sdf.parse(fromDate);
			toDt = sdf.parse(toDate);
		} catch (ParseException e) {
			logger.error("Exception occurred DaoImpl",e.getMessage());
		}
		
		MapSqlParameterSource param = new MapSqlParameterSource();
		param.addValue("fromDate", fromDt);
		param.addValue("toDate", toDt);
		
		List<FormIXAgencyOrgStmt> result;
		try {
			result = namedParameterJdbcTemplate.query(sql, param, new FormIXAgencyOrgStmtRowMapper());
			if(result!=null) {
				return result;
			}
			else {
				return null;
			}
		} catch (DataAccessException e) {
			logger.error("Exception occurred DaoImpl",e.getMessage());
		}
		return null;
		
	
		
		
	}

	@Override
	public List<MKTIRDAI05Model> getListMktIDRAI05(String fromDate, String toDate) {
		
		String sql = MktgQueries.GET_MKTIDRAI05;
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		
		Date fromDt = null;
		Date toDt = null;
		
		try {
			fromDt = sdf.parse(fromDate);
			toDt = sdf.parse(toDate);
		} catch (ParseException e) {
			logger.error("Exception occurred DaoImpl",e.getMessage());
		}
		
		MapSqlParameterSource param = new MapSqlParameterSource();
		param.addValue("fromDate", fromDt);
		param.addValue("toDate", toDt);
		
		List<MKTIRDAI05Model> result;
		try {
			result = namedParameterJdbcTemplate.query(sql, param, new MKTIRDAI05ModelRowMapper());
			if(result!=null) {
				return result;
			}
			else {
				return null;
			}
		} catch (DataAccessException e) {
			logger.error("Exception occurred DaoImpl",e.getMessage());;
		}
		return null;
	}

	@Override
	public List<MKTIRDAI02> getListMktIDRAI02(String fromDate, String toDate) {
		
		String sql = MktgQueries.GET_MKTIDRAI02;
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		
		Date fromDt = null;
		Date toDt = null;
		
		try {
			fromDt = sdf.parse(fromDate);
			toDt = sdf.parse(toDate);
		} catch (ParseException e) {
			logger.error("Exception occurred DaoImpl",e.getMessage());
		}
		
		MapSqlParameterSource param = new MapSqlParameterSource();
		param.addValue("fromDate", fromDt);
		param.addValue("toDate", toDt);
		
		List<MKTIRDAI02> result;
		try {
			result = namedParameterJdbcTemplate.query(sql, param, new MKTIRDAI02ModelRowMapper());
			if(result!=null) {
				return result;
			}
			else {
				return null;
			}
		} catch (DataAccessException e) {
			logger.error("Exception occurred DaoImpl",e.getMessage());
		}
		return null;
	}

	

	@Override
	public List<MKTIDRAI07> getListMktIDRAI07(String fromDate, String toDate) {
		
		String sql = MktgQueries.GET_MKTIDRAI07;
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		
		Date fromDt = null;
		Date toDt = null;
		
		try {
			fromDt = sdf.parse(fromDate);
			toDt = sdf.parse(toDate);
		} catch (ParseException e) {
			logger.error("Exception occurred DaoImpl",e.getMessage());
		}
		
		MapSqlParameterSource param = new MapSqlParameterSource();
		param.addValue("fromDate", fromDt);
		param.addValue("toDate", toDt);
		
		List<MKTIDRAI07> result;
		try {
			result = namedParameterJdbcTemplate.query(sql, param, new MKTIRDAI07ModelRowMapper());
			if(result!=null) {
				return result;
			}
			else {
				return null;
			}
		} catch (DataAccessException e) {
			logger.error("Exception occurred DaoImpl",e.getMessage());
		}
		return null;
	}
	

}


class FormIXAgencyOrgStmtRowMapper implements RowMapper<FormIXAgencyOrgStmt> {
	@Override
	public FormIXAgencyOrgStmt mapRow(ResultSet rs, int rowNum) throws SQLException {
		FormIXAgencyOrgStmt formIXAgencyOrgStmt = new FormIXAgencyOrgStmt();
		
		formIXAgencyOrgStmt.setBrokerageAgencyTypeId(rs.getString("brokerageAgencyTypeId"));
		formIXAgencyOrgStmt.setNoAtBeginningOfQuater(rs.getLong("noAtBeginningOfQuater"));
		formIXAgencyOrgStmt.setAdditionDuringQuarter(rs.getLong("additionDuringQuarter"));
	
		return formIXAgencyOrgStmt;
	}
}


class MKTIRDAI05ModelRowMapper implements RowMapper<MKTIRDAI05Model> {
	
	@Override
	public MKTIRDAI05Model mapRow(ResultSet rs, int rowNum) throws SQLException {
		MKTIRDAI05Model mktirdai05Model = new MKTIRDAI05Model();
		
		mktirdai05Model.setOffice_name(rs.getString("office_name"));
		mktirdai05Model.setOffice_type_id_fk(rs.getString("office_type_id_fk"));
		mktirdai05Model.setOffices_at_beginning(rs.getLong("offices_at_beginning"));
		mktirdai05Model.setOffices_during_quarter(rs.getLong("offices_during_quarter"));
		mktirdai05Model.setOffices_closed_during_quarter(rs.getLong("offices_closed_during_quarter"));
		mktirdai05Model.setOffices_at_end_of_quarter(rs.getLong("offices_at_end_of_quarter"));
		mktirdai05Model.setOffices_relocated_during_quarter(rs.getString("offices_relocated_during_quarter"));
		
		return mktirdai05Model;
	}
	
	
}


class MKTIRDAI02ModelRowMapper implements RowMapper<MKTIRDAI02> {
	
	@Override
	public MKTIRDAI02 mapRow(ResultSet rs, int rowNum) throws SQLException {
		MKTIRDAI02 mktirdai02 = new MKTIRDAI02();
		
		mktirdai02.setOffice_name(rs.getString("office_name"));
		mktirdai02.setOffice_type_id_fk(rs.getString("office_type_id_fk"));
		mktirdai02.setNew_offices(rs.getLong("new_offices"));
		mktirdai02.setOffices_closed_during_month(rs.getLong("offices_closed_during_month"));
		mktirdai02.setOffices_relocated_during_month(rs.getString("offices_relocated_during_month"));
		
		return mktirdai02;
	}
	
	
}


class MKTIRDAI07ModelRowMapper implements RowMapper<MKTIDRAI07> {
	
	@Override
	public MKTIDRAI07 mapRow(ResultSet rs, int rowNum) throws SQLException {
		MKTIDRAI07 mktirdai07 = new MKTIDRAI07();
		
		mktirdai07.setAgents(rs.getString("agents"));
		mktirdai07.setNoOfPolicyCurrentQuarter(rs.getLong("noOfPolicyCurrentQuarter"));
		mktirdai07.setPremiumAmtOfCurrentQuarter(rs.getString("premiumAmtOfCurrentQuarter"));
		mktirdai07.setNoOfpolicyPrvYrCurrentQuarter(rs.getLong("noOfpolicyPrvYrCurrentQuarter"));
		mktirdai07.setPremiumAmtOfPrvYrCurrentQuarter(rs.getString("premiumAmtOfPrvYrCurrentQuarter"));
		mktirdai07.setNoOfPoliciesUptoThePeriodCurrentYr(rs.getLong("noOfPoliciesUptoThePeriodCurrentYr"));
		mktirdai07.setPremiumAmtUptoThePeriodCurrentYr(rs.getString("premiumAmtUptoThePeriodCurrentYr"));
		mktirdai07.setNoOfPolicyUptoThePeriodPrvYr(rs.getLong("noOfPolicyUptoThePeriodPrvYr"));
		mktirdai07.setPremiumAmtUptoThePeriodPrvYr(rs.getString("premiumAmtUptoThePeriodPrvYr"));
		
		
		return mktirdai07;
	}
	
	
}




