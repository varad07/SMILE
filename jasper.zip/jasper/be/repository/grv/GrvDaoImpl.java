package in.ecgc.smile.erp.reporting.jasper.be.repository.grv;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcOperations;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import in.ecgc.smile.erp.reporting.jasper.be.model.grv.Grv_R01;
//import in.ecgc.smile.erp.reporting.jasper.be.model.Grv.MKTIRDAI02Model;
//import in.ecgc.smile.erp.reporting.jasper.be.utils.Grv.GrvQueries;
import in.ecgc.smile.erp.reporting.jasper.be.model.grv.PragatiReport;
import in.ecgc.smile.erp.reporting.jasper.be.utils.grv.GrvQueries;


@Repository
public class GrvDaoImpl implements GrvDao {
	
	
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	private JdbcOperations jdbcOperations;
	private static final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(GrvDaoImpl.class);
 
	private static final Logger LOGGER = LoggerFactory.getLogger(GrvDaoImpl.class);

	
	public GrvDaoImpl(DataSource dataSource) {
		super();
		jdbcOperations = new JdbcTemplate(dataSource);
		namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(dataSource);
	}

	@Override
	public List<PragatiReport> getPragatiReport(int month, int year) throws DataAccessException {
		// TODO Auto-generated method stub
		
		String sql = GrvQueries.GET_PRAGATI_REPORT;
		
		LOGGER.info("proposal_month :::  {}",month);
		LOGGER.info("proposal_year :::  {}",year);

		
		
		MapSqlParameterSource param = new MapSqlParameterSource();
		param.addValue("month", month);
		param.addValue("year", year);
		
		List<PragatiReport> result;
		try {
			
			result = namedParameterJdbcTemplate.query(sql, param, new PragatiReportRowMapper());
			if(result!=null) {
				return result;
			}
			else {
				return null;
			}
		} catch (DataAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
		
	}

	@Override
	public List<Grv_R01> getGrv_R01(int year) throws DataAccessException{
        String sql = GrvQueries.GRV_R01;

		LOGGER.info("proposal_year :::  {}",year);
	
		MapSqlParameterSource param = new MapSqlParameterSource();

		param.addValue("year", year);
		
		List<Grv_R01> result;
		try {
			
			result = namedParameterJdbcTemplate.query(sql, param, new Grv_R01RowMapper());
			if(result!=null) {
				return result;
			}
			else {
				return null;
			}
		} catch (DataAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	

}



class Grv_R01RowMapper implements RowMapper<Grv_R01> {
	@Override
	public Grv_R01 mapRow(ResultSet rs, int rowNum) throws SQLException {
		Grv_R01 grv_R01 = new Grv_R01();
		
		grv_R01.setAdditions_during_the_quarter(rs.getInt("Additions_During_the_Quarter"));
		grv_R01.setComplaints_pending(rs.getInt("Complaints_Pending"));
		grv_R01.setFully_accepted(rs.getInt("Fully_Accepted"));
		grv_R01.setGrv_complaint_type(rs.getString("Grv_complaint_type"));
		grv_R01.setOpening_balance(rs.getInt("Opening_Balance"));
		grv_R01.setPartially_accepted(rs.getInt("Partially_Accepted"));
		grv_R01.setQuarter(rs.getDouble("quarter"));
		grv_R01.setRejected(rs.getInt("Rejected"));
		grv_R01.setYear(rs.getDouble("year"));
		
		
		//pragatiReport.setWeek(rs.getInt("week"));
		return grv_R01;
	}
}


class PragatiReportRowMapper implements RowMapper<PragatiReport> {
	@Override
	public PragatiReport mapRow(ResultSet rs, int rowNum) throws SQLException {
		PragatiReport pragatiReport = new PragatiReport();
		//pragatiReport.setAdditionDuringQuarter(rs.getLong("additionDuringQuarter"));

		pragatiReport.setWeek(rs.getInt("week"));
		pragatiReport.setNo_of_complaints_a(rs.getLong("no_of_complaints_a"));
		pragatiReport.setNo_of_complaints_b(rs.getLong("no_of_complaints_b"));
		pragatiReport.setNo_of_complaints_c(rs.getLong("no_of_complaints_c"));
		pragatiReport.setNo_of_complaints_d(rs.getLong("no_of_complaints_d"));
		pragatiReport.setTotal_e(rs.getLong("total_e"));
		pragatiReport.setNo_of_complaints_g(rs.getLong("no_of_complaints_g"));
		pragatiReport.setFavour(rs.getLong("favour"));
		pragatiReport.setFavour_percent(rs.getLong("favour_percent"));
		pragatiReport.setAgainst(rs.getLong("against"));
		pragatiReport.setAgainst_percent(rs.getLong("against_percent"));
		
		
		return pragatiReport;
	}
}






