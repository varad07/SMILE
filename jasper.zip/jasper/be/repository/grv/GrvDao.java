package in.ecgc.smile.erp.reporting.jasper.be.repository.grv;

import java.util.List;

import in.ecgc.smile.erp.reporting.jasper.be.model.grv.Grv_R01;
import in.ecgc.smile.erp.reporting.jasper.be.model.grv.PragatiReport;
import in.ecgc.smile.erp.reporting.jasper.be.model.mktg.FormIXAgencyOrgStmt;

public interface GrvDao {
	
	public List<PragatiReport> getPragatiReport(int month, int year);
	
	public List<Grv_R01> getGrv_R01(int year);

}
