package in.ecgc.smile.erp.reporting.jasper.be.repository.Poluw;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import in.ecgc.smile.erp.reporting.jasper.be.model.poluw.poluw_013;



public class ExposureRiskValuePremiumAdjustedRowMapper implements RowMapper<poluw_013> {

	

	@Override
	public poluw_013 mapRow(ResultSet rs, int rowNum) throws SQLException {
		poluw_013 premiumPaidDetailsObj = new poluw_013();

		premiumPaidDetailsObj.setRegionName(rs.getString("region_id_fk"));
		premiumPaidDetailsObj.setLogicalloccd(rs.getString("office_id_fk"));
		premiumPaidDetailsObj.setPolicyNo(rs.getInt("policy_no"));
		premiumPaidDetailsObj.setRiskvalue(rs.getBigDecimal("risk_value"));
		premiumPaidDetailsObj.setTotalPremiumPaid(rs.getBigDecimal("total_premium_paid"));

		return premiumPaidDetailsObj;
	}

	
}