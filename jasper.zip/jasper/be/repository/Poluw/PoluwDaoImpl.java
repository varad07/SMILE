package in.ecgc.smile.erp.reporting.jasper.be.repository.Poluw;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcOperations;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.databind.ObjectMapper;

import in.ecgc.smile.erp.reporting.jasper.be.model.poluw.RegionBranch;
import in.ecgc.smile.erp.reporting.jasper.be.model.poluw.poluw_011;
import in.ecgc.smile.erp.reporting.jasper.be.model.poluw.poluw_013;

import in.ecgc.smile.erp.reporting.jasper.be.utils.poluw.PoluwQueries;

@Repository
@Transactional
public class PoluwDaoImpl implements PoluwDao {

	private static final Logger log = LoggerFactory.getLogger(PoluwDaoImpl.class);

	@Autowired
	private ObjectMapper objectMapper; // Autowire the ObjectMapper

	private NamedParameterJdbcOperations namedParameterJdbcOperations;
	@SuppressWarnings("unused")
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	@Autowired
	public PoluwDaoImpl(DataSource dataSource) {
		namedParameterJdbcOperations = new NamedParameterJdbcTemplate(dataSource);
		namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(dataSource);
	}

	@Override
	public List<String> getAllPolicyTypes() {
		log.info("Calling method getAllPolicyTypes :");
		HashMap<String, Object> paramMap = new HashMap<>();
		return namedParameterJdbcOperations.queryForList(PoluwQueries.POLICY_TYPES, paramMap, String.class);
	}

	@Override
	public List<poluw_011> getPremiumAdjusted(List<String> polTypeList, LocalDate fromDt, LocalDate toDt) {
		try {
			/*
			 * toDt.setHours(23); toDt.setMinutes(59); toDt.setSeconds(59);
			 * 
			 */
			List<poluw_011> listPremiumPaidDtlsFinal = new ArrayList<>();

			for (String a : polTypeList) {
				String policyType = a;
				// Local
				List<poluw_011> listPremiumPaidDtls = new ArrayList<>();
				if (policyType.equalsIgnoreCase("SCR") || policyType.equalsIgnoreCase("SEP")
						|| policyType.equalsIgnoreCase("ETP") || policyType.equalsIgnoreCase("BWP")
						|| policyType.equalsIgnoreCase("SSP") || policyType.equalsIgnoreCase("MEP")
						|| policyType.equalsIgnoreCase("SRC") || policyType.equalsIgnoreCase("SEC")
						|| policyType.equalsIgnoreCase("SME")) {

					String sql = PoluwQueries.GET_PREMIUM_PAID_DETAILS_SCR_ETP_BWP_SPP_SEP;
					SqlParameterSource param = new MapSqlParameterSource().addValue("policyType", policyType)
							.addValue("strt_dt", fromDt).addValue("end_dt", toDt);

					listPremiumPaidDtls = namedParameterJdbcTemplate.query(sql, param, new PremiumDetailsRowMapper());
					listPremiumPaidDtlsFinal.addAll(listPremiumPaidDtls);

					log.info("List of PremiumPaidDetails {}", listPremiumPaidDtls);
					log.info("List of PremiumPaidDetails Size {}", listPremiumPaidDtls.size());

					// return listPremiumPaidDtls;
				}

				if (policyType.equalsIgnoreCase("MITES") || policyType.equalsIgnoreCase("SITES")
						|| policyType.equalsIgnoreCase("SPP")) {

					String sql = PoluwQueries.GET_PREMIUM_PAID_DETAILS_SITES_MITES_SPP;
					SqlParameterSource param = new MapSqlParameterSource().addValue("policyType", policyType)
							.addValue("strt_dt", fromDt).addValue("end_dt", toDt);

					listPremiumPaidDtls = namedParameterJdbcTemplate.query(sql, param,
							new PremiumDetailsMitesSitesSppRowMapper());

					listPremiumPaidDtlsFinal.addAll(listPremiumPaidDtls);

					log.info("List of PremiumPaidDetails {}", listPremiumPaidDtls);
					log.info("List of PremiumPaidDetails Size {}", listPremiumPaidDtls.size());

					// return listPremiumPaidDtls;

				}

				if (policyType.equalsIgnoreCase("CSA") || policyType.equalsIgnoreCase("CGE")) {

					String sql = PoluwQueries.GET_PREMIUM_PAID_DETAILS_CSA_CGE;
					SqlParameterSource param = new MapSqlParameterSource().addValue("policyType", policyType)
							.addValue("strt_dt", fromDt).addValue("end_dt", toDt);

					listPremiumPaidDtls = namedParameterJdbcTemplate.query(sql, param, new PremiumDetailsRowMapper());

					listPremiumPaidDtlsFinal.addAll(listPremiumPaidDtls);

					log.info("List of PremiumPaidDetails {}", listPremiumPaidDtls);
					log.info("List of PremiumPaidDetails Size {}", listPremiumPaidDtls.size());

					// return listPremiumPaidDtls;

				}

				if (policyType.equalsIgnoreCase("MBE") || policyType.equalsIgnoreCase("SBE")
						|| policyType.equalsIgnoreCase("MBF") || policyType.equalsIgnoreCase("SBF")) {

					String sql = PoluwQueries.GET_PREMIUM_PAID_DETAILS_MBEP_SBEP;
					SqlParameterSource param = new MapSqlParameterSource().addValue("policyType", policyType)
							.addValue("strt_dt", fromDt).addValue("end_dt", toDt);

					listPremiumPaidDtls = namedParameterJdbcTemplate.query(sql, param,
							new PremiumDetailsMitesSitesSppRowMapper());
					listPremiumPaidDtlsFinal.addAll(listPremiumPaidDtls);

					log.info("List of PremiumPaidDetails {}", listPremiumPaidDtls);
					log.info("List of PremiumPaidDetails Size {}", listPremiumPaidDtls.size());

					// return listPremiumPaidDtls;

				}

			}

			return listPremiumPaidDtlsFinal;

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return null;

	}

	@Override
	public List<poluw_013> getExpoBasedRiskValPremiumAdjusted(LocalDate fromDt, LocalDate toDt) {
		try {
			/*
			 * toDt.setHours(23); toDt.setMinutes(59); toDt.setSeconds(59);
			 */

			String sql = PoluwQueries.GET_EXPOSURE_BASED_RV_AND_PREMIUM;
			SqlParameterSource param = new MapSqlParameterSource().addValue("strt_dt", fromDt).addValue("end_dt", toDt);

			List<poluw_013> listPremiumPaidDtls = namedParameterJdbcTemplate.query(sql, param,
					new ExposureRiskValuePremiumAdjustedRowMapper());

			log.info("List of PremiumPaidDetails {}", listPremiumPaidDtls);
			log.info("List of PremiumPaidDetails Size {}", listPremiumPaidDtls.size());

			return listPremiumPaidDtls;

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return null;

	}

	@Override
	public List<String> getRegion() throws DataAccessException {
		final String query = PoluwQueries.GET_REGION;

		try {
			return namedParameterJdbcTemplate.queryForList(query, new MapSqlParameterSource(), String.class);
		} catch (DataAccessException e) {
			e.printStackTrace();
			throw e;
		}
	}

	@Override
	public List<RegionBranch> getRegionBranchInfo() {
		try {
			

			String sql = PoluwQueries.GET_REGION_BRANCH;
			
			List<RegionBranch> listRB = namedParameterJdbcTemplate.query(sql,
					 (rs, rowNum) -> {
			            RegionBranch regionBranch = new RegionBranch();
			            regionBranch.setRegion(rs.getString("region"));
			            regionBranch.setOfficeId(rs.getString("officeId"));
			            return regionBranch;
			        });

			return listRB;

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return null;
	}
	
	

}
