package in.ecgc.smile.erp.reporting.jasper.be.repository.Poluw;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import in.ecgc.smile.erp.reporting.jasper.be.model.poluw.poluw_011;

public class PremiumDetailsRowMapper implements RowMapper<poluw_011> {

	@Override
	public poluw_011 mapRow(ResultSet rs, int rowNum) throws SQLException {
		// TODO Auto-generated method stub
		poluw_011 premiumPaidDetailsObj = new poluw_011();

		premiumPaidDetailsObj.setExportercd(rs.getString("exporter_cd"));
		premiumPaidDetailsObj.setExporterName(rs.getString("reg_company_name"));
		premiumPaidDetailsObj.setExportergrp(rs.getString("group_cd"));
		premiumPaidDetailsObj.setPolicyType(rs.getString("product_id"));
		premiumPaidDetailsObj.setPolicyNo(rs.getInt("policy_no"));
		premiumPaidDetailsObj.setLogicalloccd(rs.getString("logicalloc_cd"));
		premiumPaidDetailsObj.setAdjAmt(rs.getBigDecimal("premium_chged"));

		return premiumPaidDetailsObj;
	}

}
