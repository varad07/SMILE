package in.ecgc.smile.erp.reporting.jasper.be.repository.Poluw;

import java.time.LocalDate;
import java.util.List;

import org.springframework.dao.DataAccessException;

import in.ecgc.smile.erp.reporting.jasper.be.model.poluw.RegionBranch;
import in.ecgc.smile.erp.reporting.jasper.be.model.poluw.poluw_011;
import in.ecgc.smile.erp.reporting.jasper.be.model.poluw.poluw_013;

public interface PoluwDao {

	public List<String> getAllPolicyTypes();


	public List<poluw_011> getPremiumAdjusted(List<String> polTypeList, LocalDate fromDt, LocalDate toDt);


	public List<poluw_013> getExpoBasedRiskValPremiumAdjusted(LocalDate fromDt, LocalDate toDt);
	
	public List<String> getRegion() throws DataAccessException;


	public List<RegionBranch> getRegionBranchInfo();

}
