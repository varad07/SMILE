package in.ecgc.smile.erp.reporting.jasper.be.repository.pebp;

public class PebPImpl {

}
