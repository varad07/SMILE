package in.ecgc.smile.erp.reporting.jasper.be.repository.accounts;

import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.EntityGL;

public interface EntityGLMasterDao {
	
	EntityGL findGLByGLCode(String mainGLCode, String subGLCode);

	EntityGL findGLByBankGLCode(String mainGLCode, String subGLCode);
	
}
