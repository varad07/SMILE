package in.ecgc.smile.erp.reporting.jasper.be.repository.accounts;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.management.ServiceNotFoundException;
import javax.sql.DataSource;

import org.apache.commons.lang.StringUtils;
import org.jfree.util.Log;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataAccessResourceFailureException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcOperations;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.databind.ObjectMapper;

import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.EntityGL;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.GLCodeStmtIn;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.GLRangeStmt;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.GLStmt;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.GlStmtIn;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.TCodes;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.TdsDetails;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.TrialBalance;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.TcodeLevel.TcodeLevelStmtOut;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.TcodeLevel.TcodeTransactions;
import in.ecgc.smile.erp.reporting.jasper.be.service.accounts.EntityGLMasterService;
import in.ecgc.smile.erp.reporting.jasper.be.service.external.VendorManagementService;
import in.ecgc.smile.erp.reporting.jasper.be.utils.accounts.GlTxnSqlQueries;
import in.ecgc.smile.erp.sys.auth.be.service.UserInfoService;

@Repository
@Transactional
public class GlTxnDaoImpl implements GlTxnDao {

	private NamedParameterJdbcOperations namedParameterJdbcOperations;
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	@Autowired
	VendorManagementService vendorManagementService;

	@Autowired
	EntityGLMasterService entityGLMasterService;
	
	@Autowired
	ObjectMapper objectMapper;

	// @Autowired
	// GlTxnService glTxnService;

	private BigDecimal txnTotal = BigDecimal.ZERO;

	
	private String openingFlag = "";
	
	private String openingNegativeFlag = ""; 
	
	public BigDecimal getTxnTotal() {
		return txnTotal;
	}

	public void setTxnTotal(BigDecimal txnTotal) {
		this.txnTotal = txnTotal;
	}
	
	

	public String getOpeningFlag() {
		return openingFlag;
	}

	public void setOpeningFlag(String openingFlag) {
		this.openingFlag = openingFlag;
	}

	
	public String getOpeningNegativeFlag() {
		return openingNegativeFlag;
	}

	public void setOpeningNegativeFlag(String openingNegativeFlag) {
		this.openingNegativeFlag = openingNegativeFlag;
	}



	private static final Logger log = LoggerFactory.getLogger(GlTxnDaoImpl.class);
//	GlTxnDaoImpl txnDao;

	UserInfoService userInfoService;

	@Autowired
	public GlTxnDaoImpl(DataSource dataSource) {
		namedParameterJdbcOperations = new NamedParameterJdbcTemplate(dataSource);
		namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(dataSource);
	}

	@Override
	public List<GLStmt> getTCodewiseGLTxnStatement(GlStmtIn glStmtIn) {
		log.info("Inside GlTxnDaoImpl#getTcodewiseGLTxnStatement :{}", glStmtIn);

		Map<String, Object> paramMap = new HashMap<>();
		paramMap.put("logicalLoc", glStmtIn.getLogicallocCd());
		paramMap.put("mainGlCd", glStmtIn.getMainglCd());
		paramMap.put("subGlCd", glStmtIn.getSubglCd());
		// paramMap.put("plCd", glStmtIn.getPersonalLedgerCd());
		paramMap.put("subBifurcation", glStmtIn.getSubBfCd());
		// paramMap.put("subBifCd", glStmtIn.getSubBfCd());
		paramMap.put("fromDt", glStmtIn.getFromDt());
		paramMap.put("toDt", glStmtIn.getToDt());
		paramMap.put("t1", glStmtIn.getT1());
		paramMap.put("t2", glStmtIn.getT2());
		paramMap.put("t3", glStmtIn.getT3());
		paramMap.put("t4", glStmtIn.getT4());
		paramMap.put("t5", glStmtIn.getT5());
		paramMap.put("t6", glStmtIn.getT6());
		paramMap.put("t7", glStmtIn.getT7());
		paramMap.put("t8", glStmtIn.getT8());
		paramMap.put("t9", glStmtIn.getT9());
		paramMap.put("t10", glStmtIn.getT10());
		paramMap.put("t11", glStmtIn.getT11());
		paramMap.put("t12", glStmtIn.getT12());
		paramMap.put("t13", glStmtIn.getT13());
		paramMap.put("t14", glStmtIn.getT14());
		paramMap.put("t15", glStmtIn.getT15());
		paramMap.put("t16", glStmtIn.getT16());
		paramMap.put("t17", glStmtIn.getT17());
		paramMap.put("t18", glStmtIn.getT18());
		paramMap.put("t19", glStmtIn.getT19());
		paramMap.put("t20", glStmtIn.getT20());
		paramMap.put("t21", glStmtIn.getT21());
		paramMap.put("t22", glStmtIn.getT22());
		paramMap.put("t23", glStmtIn.getT23());
		paramMap.put("t24", glStmtIn.getT24());
		paramMap.put("t25", glStmtIn.getT25());
		paramMap.put("t26", glStmtIn.getT26());
		paramMap.put("t27", glStmtIn.getT27());
		paramMap.put("t28", glStmtIn.getT28());
		paramMap.put("t29", glStmtIn.getT29());
		paramMap.put("t30", glStmtIn.getT30());
		paramMap.put("t31", glStmtIn.getT31());
		paramMap.put("t32", glStmtIn.getT32());
		paramMap.put("t33", glStmtIn.getT33());
		paramMap.put("t34", glStmtIn.getT34());
		paramMap.put("t35", glStmtIn.getT35());
		paramMap.put("t36", glStmtIn.getT36());

		paramMap.forEach((key, value) -> {
			if (value == null || StringUtils.isBlank(value.toString())) {
				paramMap.put(key, "");
			}
		});

		boolean isSubBfCd = false;

		if (glStmtIn.getSubBfCd() != null) {
			paramMap.put("subBifCd", glStmtIn.getSubBfCd());
			isSubBfCd = true;
		}

		List<String> applicableTcodes = new ArrayList<>();

		String regex = "^t\\d{1,2}$";
		paramMap.forEach((key, value) -> {
			if (value != "" && key.matches(regex)) {
				applicableTcodes.add(key);
			}
		});

		log.info("list of applicable tcodes is {}", applicableTcodes);
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("select "
				+ "h.gl_txn_no , h.txn_dt, d.dr_cr_flg , d.gl_txn_type , d.txn_amt , d.txn_remarks "
				+ "from accounts.ecgc_acct_gl_txn_hdr h , accounts.ecgc_acct_gl_txn_dtl d "
				+ "where d.gl_txn_type = h.gl_txn_type and d.gl_txn_no = h.gl_txn_no and d.logical_loc_cd = h.logical_loc_cd "
				+ "and d.maingl_cd = :mainGlCd and d.subgl_cd = :subGlCd and d.logical_loc_cd = :logicalLoc");

		if (!applicableTcodes.isEmpty()) {
			queryBuilder.append(" AND ");
			for (int i = 0; i < applicableTcodes.size(); i++) {
				if (i > 0) {
					queryBuilder.append(" AND ");
				}
				queryBuilder.append(applicableTcodes.get(i)).append(" = ").append(":").append(applicableTcodes.get(i));
			}
		}

		if (isSubBfCd) {
			queryBuilder.append(" AND sub_bifurcation = :subBifCd");
		}

		queryBuilder.append(" AND txn_dt between :fromDt and :toDt order by h.txn_dt asc ,h.gl_txn_no  asc;");

		String sqlQuery = queryBuilder.toString();
		log.info("Generated SQL Query : {}", sqlQuery);
		try {
			return namedParameterJdbcTemplate.query(sqlQuery, paramMap, new RowMapper<GLStmt>() {

				@Override
				public GLStmt mapRow(ResultSet rs, int rowNum) throws SQLException {
					GLStmt glStmt = new GLStmt();
					if (rs.getDate("txn_dt") != null)
						glStmt.setTxnDate(rs.getDate("txn_dt").toLocalDate());
					glStmt.setTxnNo(rs.getString("gl_txn_no"));
					glStmt.setTxnType(rs.getString("gl_txn_type"));
					if (rs.getString("dr_cr_flg").equalsIgnoreCase("CR")) {
						glStmt.setTxnCrAmt(BigDecimal.valueOf(rs.getDouble("txn_amt")));
						glStmt.setTxnDrAmt(BigDecimal.ZERO);
					} else if (rs.getString("dr_cr_flg").equalsIgnoreCase("DR")) {
						glStmt.setTxnDrAmt(BigDecimal.valueOf(rs.getDouble("txn_amt")));
						glStmt.setTxnCrAmt(BigDecimal.ZERO);
					}
					glStmt.setRemark(rs.getString("txn_remarks"));
					return glStmt;
				}
			});
		} catch (DataAccessException e) {
			throw new DataAccessResourceFailureException("Failed to get GL statement");
		}
	}

	@Override
	public List<GLStmt> getTransactionTypewiseGLTxnStatement(String logicallocCd, String txnType, String fromDt,
			String toDt) {
		log.info("Inside GlTxnDaoImpl#getTransactionTypewiseGLTxnStatement (Obj) : {} {} {} {}", logicallocCd, txnType,
				fromDt, toDt);

		Map<String, Object> paramMap = new HashMap<>();
		paramMap.put("logicallocCd", logicallocCd);
		paramMap.put("txnType", txnType);
		paramMap.put("fromDt", fromDt);
		paramMap.put("toDt", toDt);

		paramMap.forEach((key, value) -> {
			if (value == null || StringUtils.isBlank(value.toString())) {
				paramMap.put(key, "");
			}
		});

		log.info("DB Param Map : {}", paramMap);

		String sqlQuery = GlTxnSqlQueries.GET_TRANSACTION_TYPE_WISE_GL_STATEMENT;
		log.info("Query : {}", sqlQuery);

		try {
			return namedParameterJdbcTemplate.query(sqlQuery, paramMap, new RowMapper<GLStmt>() {

				@Override
				public GLStmt mapRow(ResultSet rs, int rowNum) throws SQLException {
					GLStmt glStmt = new GLStmt();
					TCodes tcodes = new TCodes();
					if (rs.getDate("txn_dt") != null)
						glStmt.setTxnDate(rs.getDate("txn_dt").toLocalDate());
					glStmt.setTxnNo(rs.getString("gl_txn_no"));
					glStmt.setTxnType(rs.getString("gl_txn_type"));
					if (rs.getString("dr_cr_flg").equalsIgnoreCase("CR")) {
						glStmt.setTxnCrAmt(BigDecimal.valueOf(rs.getDouble("txn_amt")));
						glStmt.setTxnDrAmt(null);
					} else if (rs.getString("dr_cr_flg").equalsIgnoreCase("DR")) {
						glStmt.setTxnDrAmt(BigDecimal.valueOf(rs.getDouble("txn_amt")));
						glStmt.setTxnCrAmt(null);
					}
					glStmt.setRemark(rs.getString("txn_remarks"));
					glStmt.setGlName(rs.getString("gl_name"));
					glStmt.setMainGLCd(rs.getString("maingl_cd"));
					glStmt.setSubGLCd(rs.getString("subgl_cd"));
					tcodes.setT1(rs.getString("t1"));
					tcodes.setT2(rs.getString("t2"));
					tcodes.setT3(rs.getString("t3"));
					tcodes.setT4(rs.getString("t4"));
					tcodes.setT5(rs.getString("t5"));
					tcodes.setT6(rs.getString("t6"));
					tcodes.setT7(rs.getString("t7"));
					tcodes.setT8(rs.getString("t8"));
					tcodes.setT9(rs.getString("t9"));
					tcodes.setT10(rs.getString("t10"));
					tcodes.setT11(rs.getString("t11"));
					tcodes.setT12(rs.getString("t12"));
					tcodes.setT13(rs.getString("t13"));
					tcodes.setT14(rs.getString("t14"));
					tcodes.setT15(rs.getString("t15"));
					tcodes.setT16(rs.getString("t16"));
					tcodes.setT17(rs.getString("t17"));
					tcodes.setT18(rs.getString("t18"));
					tcodes.setT19(rs.getString("t19"));
					tcodes.setT20(rs.getString("t20"));
					tcodes.setT21(rs.getString("t21"));
					tcodes.setT22(rs.getString("t22"));
					tcodes.setT23(rs.getString("t23"));
					tcodes.setT24(rs.getString("t24"));
					tcodes.setT25(rs.getString("t25"));
					tcodes.setT26(rs.getString("t26"));
					tcodes.setT27(rs.getString("t27"));
					tcodes.setT28(rs.getString("t28"));
					tcodes.setT29(rs.getString("t29"));
					tcodes.setT30(rs.getString("t30"));
					tcodes.setT31(rs.getString("t31"));
					tcodes.setT32(rs.getString("t32"));
					tcodes.setT33(rs.getString("t33"));
					tcodes.setT34(rs.getString("t34"));
					tcodes.setT35(rs.getString("t35"));
					tcodes.setT36(rs.getString("t36"));

					glStmt.setTcodes(tcodes);

					return glStmt;
				}
			});
		} catch (DataAccessException e) {
			throw new DataAccessResourceFailureException("Failed to get GL statement : {}", e);
		} catch (Exception e) {
			throw new RuntimeException("Failed to get GL statement : " + e.getMessage());
		}
	}

	@Override
	public List<EntityGL> getGLRangeList(String fromMainGlCd, String fromSubGlCd, String toMainGlCd, String toSubGlCd) {

		log.info("Inside GlTxnDaoImpl#getGLRangeList (Obj) : {} {} {} {}", fromMainGlCd, fromSubGlCd, toMainGlCd,
				toSubGlCd);

		Map<String, Object> paramMap = new HashMap<>();
		paramMap.put("fromMainGlCd", fromMainGlCd);
		paramMap.put("fromSubGlCd", fromSubGlCd);
		paramMap.put("toMainGlCd", toMainGlCd);
		paramMap.put("toSubGlCd", toSubGlCd);

		log.info("param map : {}", paramMap);

		return namedParameterJdbcTemplate.query(GlTxnSqlQueries.GET_GL_RANGE_LIST, paramMap, new RowMapper<EntityGL>() {

			@Override
			public EntityGL mapRow(ResultSet rs, int rowNum) throws SQLException {
				EntityGL entityGL = new EntityGL();

				entityGL.setMainglCd(rs.getString("maingl_cd"));
				entityGL.setSubglCd(rs.getString("subgl_cd"));
				entityGL.setGlName(rs.getString("gl_name"));
				entityGL.setGlType(rs.getString("gl_type"));
				return entityGL;
			}
		});

	}

	@Override
	public List<String> getGLRangeLocationList(String fromMainGlCd, String fromSubGlCd, String toMainGlCd,
			String toSubGlCd, String fromDt, String toDt) {

		log.info("Inside GlTxnDaoImpl#getGLRangeLocationList (Obj) : {} {} {} {} {} {}", fromMainGlCd, fromSubGlCd,
				toMainGlCd, toSubGlCd, fromDt, toDt);

		Map<String, String> paramMap = new HashMap<>();
		paramMap.put("fromMainGlCd", fromMainGlCd);
		paramMap.put("fromSubGlCd", fromSubGlCd);
		paramMap.put("toMainGlCd", toMainGlCd);
		paramMap.put("toSubGlCd", toSubGlCd);
		paramMap.put("fromDate", fromDt);
		paramMap.put("toDate", toDt);

		log.info("getGLRangeLocationList param map : {}", paramMap);

		try {
			return namedParameterJdbcTemplate.query(GlTxnSqlQueries.GET_GL_RANGE_LOC_LIST, paramMap,
					new RowMapper<String>() {

						@Override
						public String mapRow(ResultSet rs, int rowNum) throws SQLException {

							return rs.getString("logical_loc_cd");
						}
					});
		} catch (Exception e) {
			log.error("Exception caused due to : {}", e.getMessage());
		}
		return new ArrayList<>();
	}

	@Override
	public List<GLRangeStmt> getGLcodewiseTxnStatement(String mainGlCd, String subGlCd, String logicalLocCd,
			LocalDate fromDate, LocalDate toDate, TrialBalance openingTrialBal) {

		log.info("Inside GlTxnDaoImpl#getGLcodewiseTxnStatement (Obj) :{} {} {} {} {} {}", mainGlCd, subGlCd,
				logicalLocCd, fromDate, toDate, openingTrialBal);

		//StringBuffer openingFlag = new StringBuffer();
		
		  
		if (openingTrialBal.getDrAmount().compareTo(openingTrialBal.getCrAmount()) == 1) {
			txnTotal = openingTrialBal.getDrAmount();
			openingFlag = "DR";
			openingNegativeFlag = "CR";
		} else {
			txnTotal = openingTrialBal.getCrAmount();
			openingFlag = "CR";
			openingNegativeFlag = "DR";
		}

		if (openingTrialBal.getDrAmount().compareTo(openingTrialBal.getCrAmount()) == 0) {
			txnTotal = openingTrialBal.getDrAmount();
			if (openingTrialBal.getGltype().equalsIgnoreCase("ASST")
					|| openingTrialBal.getGltype().equalsIgnoreCase("INCM")) {
				openingFlag = "DR";
				openingNegativeFlag = "CR";
			} else if (openingTrialBal.getGltype().equalsIgnoreCase("LIAB")
					|| openingTrialBal.getGltype().equalsIgnoreCase("EXPD")) {
				openingFlag = "CR";
				openingNegativeFlag = "DR";
			}
		}

		
		
		Map<String, Object> paramMap = new HashMap<>();
		paramMap.put("mainGlCd", mainGlCd);
		paramMap.put("subGlCd", subGlCd);
		paramMap.put("logicalLocCd", logicalLocCd);
		paramMap.put("fromDate", fromDate);
		paramMap.put("toDate", toDate);

		// GET_GL_RANGE_STMT
		return namedParameterJdbcTemplate.query(GlTxnSqlQueries.GET_GL_RANGE_STMT, paramMap,
				new RowMapper<GLRangeStmt>() {

					@Override
					public GLRangeStmt mapRow(ResultSet rs, int rowNum) throws SQLException {
						GLRangeStmt glRangeStmt = new GLRangeStmt();

						glRangeStmt.setTxnNo(rs.getString("gl_txn_no"));
						glRangeStmt.setTxnType(rs.getString("gl_txn_type"));
						
						
						if (rs.getString("dr_cr_flg").equalsIgnoreCase("DR")) {
							glRangeStmt.setTxnDrAmt(rs.getBigDecimal("txn_amt"));
							glRangeStmt.setTxnCrAmt(BigDecimal.ZERO);
							if (openingTrialBal.getDrAmount().compareTo(openingTrialBal.getCrAmount()) == 1) {
								txnTotal = txnTotal.add(rs.getBigDecimal("txn_amt"));

							} else if (openingTrialBal.getCrAmount().compareTo(openingTrialBal.getDrAmount()) == 1) {
								txnTotal = txnTotal.subtract(rs.getBigDecimal("txn_amt"));
							} else if (openingTrialBal.getDrAmount().compareTo(openingTrialBal.getCrAmount()) == 0) {
								if (openingTrialBal.getGltype().equalsIgnoreCase("ASST")
										|| openingTrialBal.getGltype().equalsIgnoreCase("INCM")) {
									txnTotal = txnTotal.add(rs.getBigDecimal("txn_amt"));
								} else {
									txnTotal = txnTotal.subtract(rs.getBigDecimal("txn_amt"));
								}
							}

							if (txnTotal.compareTo(BigDecimal.ZERO) < 0) {
								glRangeStmt.setTxnTotalType(openingNegativeFlag);
							} else {
								glRangeStmt.setTxnTotalType(openingFlag);
							}

						} else if (rs.getString("dr_cr_flg").equalsIgnoreCase("CR")) {
							glRangeStmt.setTxnCrAmt(rs.getBigDecimal("txn_amt"));
							glRangeStmt.setTxnDrAmt(BigDecimal.ZERO);

							if (openingTrialBal.getCrAmount().compareTo(openingTrialBal.getDrAmount()) == 1) {
								txnTotal = txnTotal.add(rs.getBigDecimal("txn_amt"));
							} else if (openingTrialBal.getDrAmount().compareTo(openingTrialBal.getCrAmount()) == 1) {
								txnTotal = txnTotal.subtract(rs.getBigDecimal("txn_amt"));
							} else if (openingTrialBal.getDrAmount().compareTo(openingTrialBal.getCrAmount()) == 0) {
								if (openingTrialBal.getGltype().equalsIgnoreCase("LIAB")
										|| openingTrialBal.getGltype().equalsIgnoreCase("EXPD")) {
									txnTotal = txnTotal.add(rs.getBigDecimal("txn_amt"));
								} else {
									txnTotal = txnTotal.subtract(rs.getBigDecimal("txn_amt"));
								}
							}

							if (txnTotal.compareTo(BigDecimal.ZERO) < 0) {
								glRangeStmt.setTxnTotalType(openingNegativeFlag);
							} else {
								glRangeStmt.setTxnTotalType(openingFlag);
							}
						}
						
						
					
						glRangeStmt.setTxnDate(rs.getDate("txn_dt").toLocalDate());
						glRangeStmt.setTxnTotal(getTxnTotal().abs());
						glRangeStmt.setRemark(rs.getString("txn_remarks"));
						return glRangeStmt;
					}
				});
	}

	@Override
	public List<GLStmt> getGLCodeStatementbyLoc(GLCodeStmtIn glCodeStmtIn) {
		log.info("Inside GlTxnDaoImpl#getGLCodeStatementbyLoc (Obj):{}", glCodeStmtIn);

		Map<String, Object> paramMap = new HashMap<>();
		paramMap.put("logicalLoc", glCodeStmtIn.getLogicallocCd());
		paramMap.put("mainGlCd", glCodeStmtIn.getMainglCd());
		paramMap.put("subGlCd", glCodeStmtIn.getSubglCd());
		paramMap.put("subBifurcation", glCodeStmtIn.getSubBfCd());
		paramMap.put("fromDt", glCodeStmtIn.getFromDt());
		paramMap.put("toDt", glCodeStmtIn.getToDt());

		paramMap.forEach((key, value) -> {
			if (value == null || StringUtils.isBlank(value.toString())) {
				paramMap.put(key, "");
			}
		});

		boolean isSubBfCd = false;

		if (glCodeStmtIn.getSubBfCd() != null) {
			paramMap.put("subBifCd", glCodeStmtIn.getSubBfCd());
			isSubBfCd = true;
		}

		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("select "
				+ "h.gl_txn_no , h.txn_dt, d.dr_cr_flg , d.gl_txn_type , d.txn_amt , d.txn_remarks "
				+ "from accounts.ecgc_acct_gl_txn_hdr h , accounts.ecgc_acct_gl_txn_dtl d "
				+ "where d.gl_txn_type = h.gl_txn_type and d.gl_txn_no = h.gl_txn_no and d.logical_loc_cd = h.logical_loc_cd "
				+ "and d.maingl_cd = :mainGlCd and d.subgl_cd = :subGlCd and d.logical_loc_cd = :logicalLoc");

		if (isSubBfCd) {
			queryBuilder.append(" AND sub_bifurcation = :subBifCd");
		}

		queryBuilder.append(" AND txn_dt between :fromDt and :toDt order by h.txn_dt asc ,h.gl_txn_no  asc;");

		String sqlQuery = queryBuilder.toString();

		log.info("Generated SQL Query : {}", sqlQuery);

		try {
			return namedParameterJdbcTemplate.query(sqlQuery, paramMap, new RowMapper<GLStmt>() {

				@Override
				public GLStmt mapRow(ResultSet rs, int rowNum) throws SQLException {
					GLStmt glStmt = new GLStmt();
					if (rs.getDate("txn_dt") != null)
						glStmt.setTxnDate(rs.getDate("txn_dt").toLocalDate());
					glStmt.setTxnNo(rs.getString("gl_txn_no"));
					glStmt.setTxnType(rs.getString("gl_txn_type"));
					if (rs.getString("dr_cr_flg").equalsIgnoreCase("CR")) {
						glStmt.setTxnCrAmt(BigDecimal.valueOf(rs.getDouble("txn_amt")));
						glStmt.setTxnDrAmt(BigDecimal.ZERO);
					} else if (rs.getString("dr_cr_flg").equalsIgnoreCase("DR")) {
						glStmt.setTxnDrAmt(BigDecimal.valueOf(rs.getDouble("txn_amt")));
						glStmt.setTxnCrAmt(BigDecimal.ZERO);
					}
					glStmt.setRemark(rs.getString("txn_remarks"));
					return glStmt;
				}
			});
		} catch (DataAccessException e) {
			throw new DataAccessResourceFailureException("Failed to get GL statement");
		}
	}

	@Override
	public List<GLStmt> getGLlocGLsubBfCd(GlStmtIn glStmt) {
		log.info("Inside GlTxnDaoImpl#getGLlocGLsubBfCd (Obj) : {}", glStmt);

		Map<String, Object> paramMap = new HashMap<>();
		paramMap.put("logicalLoc", glStmt.getLogicallocCd());
		paramMap.put("mainGlCd", glStmt.getMainglCd());
		paramMap.put("subGlCd", glStmt.getSubglCd());
		paramMap.put("subBifurcation", glStmt.getSubBfCd());
		paramMap.put("fromDt", glStmt.getFromDt());
		paramMap.put("toDt", glStmt.getToDt());

		paramMap.forEach((key, value) -> {
			if (value == null || StringUtils.isBlank(value.toString())) {
				paramMap.put(key, "");
			}
		});

		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("select "
				+ "h.gl_txn_no , h.txn_dt, d.dr_cr_flg , d.gl_txn_type , d.txn_amt , d.txn_remarks "
				+ "from accounts.ecgc_acct_gl_txn_hdr h , accounts.ecgc_acct_gl_txn_dtl d "
				+ "where d.gl_txn_type = h.gl_txn_type and d.gl_txn_no = h.gl_txn_no and d.logical_loc_cd = h.logical_loc_cd "
				+ "and d.maingl_cd = :mainGlCd and d.subgl_cd = :subGlCd and d.logical_loc_cd = :logicalLoc AND sub_bifurcation = :subBifCd"
				+ " AND txn_dt between :fromDt and :toDt order by h.txn_dt asc ,h.gl_txn_no  asc");

		String sqlQuery = queryBuilder.toString();

		log.info("Generated SQL Query : {}", sqlQuery);

		try {
			return namedParameterJdbcTemplate.query(sqlQuery, paramMap, new RowMapper<GLStmt>() {

				@Override
				public GLStmt mapRow(ResultSet rs, int rowNum) throws SQLException {
					GLStmt glStmt = new GLStmt();
					if (rs.getDate("txn_dt") != null)
						glStmt.setTxnDate(rs.getDate("txn_dt").toLocalDate());
					glStmt.setTxnNo(rs.getString("gl_txn_no"));
					glStmt.setTxnType(rs.getString("gl_txn_type"));
					if (rs.getString("dr_cr_flg").equalsIgnoreCase("CR")) {
						glStmt.setTxnCrAmt(BigDecimal.valueOf(rs.getDouble("txn_amt")));
						glStmt.setTxnDrAmt(BigDecimal.ZERO);
					} else if (rs.getString("dr_cr_flg").equalsIgnoreCase("DR")) {
						glStmt.setTxnDrAmt(BigDecimal.valueOf(rs.getDouble("txn_amt")));
						glStmt.setTxnCrAmt(BigDecimal.ZERO);
					}
					glStmt.setRemark(rs.getString("txn_remarks"));
					return glStmt;
				}
			});
		} catch (DataAccessException e) {
			throw new DataAccessResourceFailureException("Failed to get GL statement");
		}
	}

	@Override
	public List<GLStmt> getSubBfwiseGLTxnStatement(GlStmtIn glStmtIn) {
		log.info("Inside GlTxnDaoImpl#getSubBfwiseGLTxnStatement (Obj) : {}", glStmtIn);

		Map<String, Object> paramMap = new HashMap<>();
		paramMap.put("logicalLoc", glStmtIn.getLogicallocCd());
		paramMap.put("mainGlCd", glStmtIn.getMainglCd());
		paramMap.put("subGlCd", glStmtIn.getSubglCd());
		paramMap.put("subBifCd", glStmtIn.getSubBfCd());
		paramMap.put("fromDt", glStmtIn.getFromDt());
		paramMap.put("toDt", glStmtIn.getToDt());

		try {
			return namedParameterJdbcTemplate.query(GlTxnSqlQueries.GET_GL_RANGE_STMT_SUB_BIFURCATION_WISE, paramMap,
					new RowMapper<GLStmt>() {

						@Override
						public GLStmt mapRow(ResultSet rs, int rowNum) throws SQLException {
							GLStmt glStmt = new GLStmt();
							if (rs.getDate("txn_dt") != null)
								glStmt.setTxnDate(rs.getDate("txn_dt").toLocalDate());
							glStmt.setTxnNo(rs.getString("gl_txn_no"));
							glStmt.setTxnType(rs.getString("gl_txn_type"));
							if (rs.getString("dr_cr_flg").equalsIgnoreCase("CR")) {
								glStmt.setTxnCrAmt(BigDecimal.valueOf(rs.getDouble("txn_amt")));
								glStmt.setTxnDrAmt(BigDecimal.ZERO);
							} else if (rs.getString("dr_cr_flg").equalsIgnoreCase("DR")) {
								glStmt.setTxnDrAmt(BigDecimal.valueOf(rs.getDouble("txn_amt")));
								glStmt.setTxnCrAmt(BigDecimal.ZERO);
							}
							glStmt.setRemark(rs.getString("txn_remarks"));
							return glStmt;
						}
					});
		} catch (DataAccessException e) {
			throw new DataAccessResourceFailureException("Failed to get GL statement");
		}
	}

	@Override
	public List<GLStmt> getTcodeAndSubBfwiseGLTxnStatement(GlStmtIn glStmtIn) {
		log.info("Inside GlTxnDaoImpl#getTcodeAndSubBfwiseGLTxnStatement (Obj): {}", glStmtIn);

		Map<String, Object> paramMap = new HashMap<>();
		paramMap.put("logicalLoc", glStmtIn.getLogicallocCd());
		paramMap.put("mainGlCd", glStmtIn.getMainglCd());
		paramMap.put("subGlCd", glStmtIn.getSubglCd());
		paramMap.put("subGlCd", glStmtIn.getSubglCd());
		paramMap.put("subBifCd", glStmtIn.getSubBfCd());
		// paramMap.put("plCd", glStmtIn.getPersonalLedgerCd());
		// paramMap.put("subBifurcation", glStmtIn.getSubBfCd());
		paramMap.put("fromDt", glStmtIn.getFromDt());
		paramMap.put("toDt", glStmtIn.getToDt());
		paramMap.put("t1", glStmtIn.getT1());
		paramMap.put("t2", glStmtIn.getT2());
		paramMap.put("t3", glStmtIn.getT3());
		paramMap.put("t4", glStmtIn.getT4());
		paramMap.put("t5", glStmtIn.getT5());
		paramMap.put("t6", glStmtIn.getT6());
		paramMap.put("t7", glStmtIn.getT7());
		paramMap.put("t8", glStmtIn.getT8());
		paramMap.put("t9", glStmtIn.getT9());
		paramMap.put("t10", glStmtIn.getT10());
		paramMap.put("t11", glStmtIn.getT11());
		paramMap.put("t12", glStmtIn.getT12());
		paramMap.put("t13", glStmtIn.getT13());
		paramMap.put("t14", glStmtIn.getT14());
		paramMap.put("t15", glStmtIn.getT15());
		paramMap.put("t16", glStmtIn.getT16());
		paramMap.put("t17", glStmtIn.getT17());
		paramMap.put("t18", glStmtIn.getT18());
		paramMap.put("t19", glStmtIn.getT19());
		paramMap.put("t20", glStmtIn.getT20());
		paramMap.put("t21", glStmtIn.getT21());
		paramMap.put("t22", glStmtIn.getT22());
		paramMap.put("t23", glStmtIn.getT23());
		paramMap.put("t24", glStmtIn.getT24());
		paramMap.put("t25", glStmtIn.getT25());
		paramMap.put("t26", glStmtIn.getT26());
		paramMap.put("t27", glStmtIn.getT27());
		paramMap.put("t28", glStmtIn.getT28());
		paramMap.put("t29", glStmtIn.getT29());
		paramMap.put("t30", glStmtIn.getT30());
		paramMap.put("t31", glStmtIn.getT31());
		paramMap.put("t32", glStmtIn.getT32());
		paramMap.put("t33", glStmtIn.getT33());
		paramMap.put("t34", glStmtIn.getT34());
		paramMap.put("t35", glStmtIn.getT35());
		paramMap.put("t36", glStmtIn.getT36());

		paramMap.forEach((key, value) -> {
			if (value == null || StringUtils.isBlank(value.toString())) {
				paramMap.put(key, "");
			}
		});

		boolean isSubBfCd = false;

		if (glStmtIn.getSubBfCd() != null) {
			paramMap.put("subBifCd", glStmtIn.getSubBfCd());
			isSubBfCd = true;
		}

		List<String> applicableTcodes = new ArrayList<>();

		String regex = "^t\\d{1,2}$";
		paramMap.forEach((key, value) -> {
			if (value != "" && key.matches(regex)) {
				applicableTcodes.add(key);
			}
		});

		log.info("list of applicable tcodes is {}", applicableTcodes);
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("select "
				+ "h.gl_txn_no , h.txn_dt, d.dr_cr_flg , d.gl_txn_type , d.txn_amt , d.txn_remarks "
				+ "from accounts.ecgc_acct_gl_txn_hdr h , accounts.ecgc_acct_gl_txn_dtl d "
				+ "where d.gl_txn_type = h.gl_txn_type and d.gl_txn_no = h.gl_txn_no and d.logical_loc_cd = h.logical_loc_cd "
				+ "and d.maingl_cd = :mainGlCd and d.subgl_cd = :subGlCd and d.logical_loc_cd = :logicalLoc");

		if (!applicableTcodes.isEmpty()) {
			queryBuilder.append(" AND ");
			for (int i = 0; i < applicableTcodes.size(); i++) {
				if (i > 0) {
					queryBuilder.append(" AND ");
				}
				queryBuilder.append(applicableTcodes.get(i)).append(" = ").append(":").append(applicableTcodes.get(i));
			}
		}

		if (isSubBfCd) {
			queryBuilder.append(" AND sub_bifurcation = :subBifCd");
		}

		queryBuilder.append(" AND txn_dt between :fromDt and :toDt order by h.txn_dt asc ,h.gl_txn_no  asc;");

		String sqlQuery = queryBuilder.toString();
		log.info("Generated SQL Query : {}", sqlQuery);
		try {
			return namedParameterJdbcTemplate.query(sqlQuery, paramMap, new RowMapper<GLStmt>() {

				@Override
				public GLStmt mapRow(ResultSet rs, int rowNum) throws SQLException {
					GLStmt glStmt = new GLStmt();
					if (rs.getDate("txn_dt") != null)
						glStmt.setTxnDate(rs.getDate("txn_dt").toLocalDate());
					glStmt.setTxnNo(rs.getString("gl_txn_no"));
					glStmt.setTxnType(rs.getString("gl_txn_type"));
					if (rs.getString("dr_cr_flg").equalsIgnoreCase("CR")) {
						glStmt.setTxnCrAmt(BigDecimal.valueOf(rs.getDouble("txn_amt")));
						glStmt.setTxnDrAmt(BigDecimal.ZERO);
					} else if (rs.getString("dr_cr_flg").equalsIgnoreCase("DR")) {
						glStmt.setTxnDrAmt(BigDecimal.valueOf(rs.getDouble("txn_amt")));
						glStmt.setTxnCrAmt(BigDecimal.ZERO);
					}
					glStmt.setRemark(rs.getString("txn_remarks"));
					return glStmt;
				}
			});
		} catch (DataAccessException e) {
			throw new DataAccessResourceFailureException("Failed to get GL statement");
		}
	}

	@Override
	public List<TdsDetails> getdetailsOfAmtPaidUnderTDSForYear(String logicallocCd, String fiscalYear) {
		log.info("Inside GlTxnDaoImpl#getdetailsOfAmtPaidUnderTDSForYear logicallocCd,fiscalYear(Obj): {} {}",
				logicallocCd, fiscalYear);

		Map<String, Object> paramMap = new HashMap<>();
		paramMap.put("logicallocCd", logicallocCd);
		paramMap.put("fiscalYear", fiscalYear);

		paramMap.forEach((key, value) -> {
			if (value == null || StringUtils.isBlank(value.toString())) {
				paramMap.put(key, "");
			}
		});

		log.info("DB Param Map : {}", paramMap);

		String sqlQuery = GlTxnSqlQueries.GET_DETAILS_OF_AMT_PAID_UNDER_TDS_FOR_YEAR;

		try {
			return namedParameterJdbcTemplate.query(sqlQuery, paramMap, new RowMapper<TdsDetails>() {

				@Override
				public TdsDetails mapRow(ResultSet rs, int rowNum) throws SQLException {
					TdsDetails tdsDetails = new TdsDetails();
					tdsDetails.setMainGlCd(rs.getString("maingl_cd"));
					tdsDetails.setSubGlCd(rs.getString("subgl_cd"));
					tdsDetails.setAccountHead(rs.getString("account_head"));
					tdsDetails.setSectionCd(rs.getString("tds_section"));
					tdsDetails.setSectionName(rs.getString("tds_section_name"));

					tdsDetails.setPvJvNo(rs.getString("pv_jv_no"));
					tdsDetails.setGlTxnType(rs.getString("gl_txn_type"));
					tdsDetails.setPvJvDate(rs.getDate("pv_jv_date").toLocalDate());
					tdsDetails.setPaidTo(rs.getString("paid_to"));
					tdsDetails.setPayToType(rs.getString("pay_to_type"));
					tdsDetails.setPymtPartyCd(rs.getString("pymt_party_cd"));
					try {
						tdsDetails.setPanNo(getPan(tdsDetails.getPayToType(), tdsDetails.getPymtPartyCd()));
					} catch (ServiceNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					tdsDetails.setTotalBillAmt(BigDecimal.valueOf(rs.getDouble("total_bill_amt")));
					tdsDetails.setTaxableAmt(BigDecimal.valueOf(rs.getDouble("taxable_amt")));
					tdsDetails.setNonTaxableAmt(BigDecimal.valueOf(rs.getDouble("non_taxable_amt")));
					tdsDetails.setTdsRate(BigDecimal.valueOf(rs.getDouble("tax_rate")));
					// tdsDetails.setTdsPayable(BigDecimal.valueOf(rs.getDouble("tds_payable")));
					tdsDetails.setTdsPaid(BigDecimal.valueOf(rs.getDouble("tds_paid")));
					// tdsDetails.setReasonForNonTaxableAmt(rs.getString("reason_for_nontaxable_amt"));
					log.info("tdsDetails out: {}", tdsDetails);

					return tdsDetails;
				}

				private String getPan(String payToType, String pymtPartyCd) throws ServiceNotFoundException {
					log.info("Pay to type : {}", payToType);
					log.info("Pay to code : {}", pymtPartyCd);
					if (pymtPartyCd != null) {
						if (payToType.toLowerCase().equals("adm")) {
							return vendorManagementService.getPanByVendorCode(pymtPartyCd);
						}
					}
					return null;
				}
			});
		} catch (DataAccessException e) {
			throw new DataAccessResourceFailureException("Failed to get GL statement : {}", e);
		} catch (Exception e) {
			throw new RuntimeException("Failed to get GL statement : " + e.getMessage());
		}
	}

	@Override
	public List<GLStmt> getGLCodeStatementbyAllLocation(GLCodeStmtIn glCodeStmtIn) {
		log.info("Inside GlTxnDaoImpl#getGLCodeStatementbyAllLocation (Obj) : {}", glCodeStmtIn);

		Map<String, Object> paramMap = new HashMap<>();
		paramMap.put("mainGlCd", glCodeStmtIn.getMainglCd());
		paramMap.put("subGlCd", glCodeStmtIn.getSubglCd());
		paramMap.put("fromDt", glCodeStmtIn.getFromDt());
		paramMap.put("toDt", glCodeStmtIn.getToDt());

		paramMap.forEach((key, value) -> {
			if (value == null || StringUtils.isBlank(value.toString())) {
				paramMap.put(key, "");
			}
		});

		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("select h.gl_txn_no , h.txn_dt, d.dr_cr_flg , d.gl_txn_type , d.txn_amt , d.txn_rmk  "
				+ "				from cs.ecgc_cs_gl_txn_hdr h join cs.ecgc_cs_gl_txn_dtl d on "
				+ "				 d.gl_txn_type = h.gl_txn_type and d.gl_txn_no = h.gl_txn_no where d.maingl_cd = :mainGlCd and d.subgl_cd = :subGlCd "
				+ "				 AND txn_dt between :fromDt and :toDt order by h.txn_dt asc ,h.gl_txn_no  asc");

		String sqlQuery = queryBuilder.toString();

		log.info("Generated SQL Query : {}", sqlQuery);

		try {
			return namedParameterJdbcTemplate.query(sqlQuery, paramMap, new RowMapper<GLStmt>() {

				@Override
				public GLStmt mapRow(ResultSet rs, int rowNum) throws SQLException {
					GLStmt glStmt = new GLStmt();
					if (rs.getDate("txn_dt") != null)
						glStmt.setTxnDate(rs.getDate("txn_dt").toLocalDate());
					glStmt.setTxnNo(rs.getString("gl_txn_no"));
					glStmt.setTxnType(rs.getString("gl_txn_type"));
					if (rs.getString("dr_cr_flg").equalsIgnoreCase("CR")) {
						glStmt.setTxnCrAmt(BigDecimal.valueOf(rs.getDouble("txn_amt")));
						glStmt.setTxnDrAmt(BigDecimal.ZERO);
					} else if (rs.getString("dr_cr_flg").equalsIgnoreCase("DR")) {
						glStmt.setTxnDrAmt(BigDecimal.valueOf(rs.getDouble("txn_amt")));
						glStmt.setTxnCrAmt(BigDecimal.ZERO);
					}
					glStmt.setRemark(rs.getString("txn_rmk"));
					return glStmt;
				}
			});
		} catch (DataAccessException e) {
			throw new DataAccessResourceFailureException("Failed to get GL statement");
		}
	}

	@Override
	public List<GLStmt> getSubBfListwiseGLTxnStatement(GlStmtIn glStmtIn) {
		log.info("Inside GlTxnDaoImpl#getSubBfListwiseGLTxnStatement (Obj): {}", glStmtIn);

		MapSqlParameterSource paramMap = new MapSqlParameterSource();
		paramMap.addValue("logicalLoc", glStmtIn.getLogicallocCd());
		paramMap.addValue("mainGlCd", glStmtIn.getMainglCd());
		paramMap.addValue("subGlCd", glStmtIn.getSubglCd());
		paramMap.addValue("subBifCdList", glStmtIn.getSubBfCdList());
		// paramMap.addValue("subBifurcationLevel", glStmtIn.getSubBfLevelName());
		paramMap.addValue("fromDt", glStmtIn.getFromDt());
		paramMap.addValue("toDt", glStmtIn.getToDt());
		log.info("Parameters : {}", paramMap);

		try {
			return namedParameterJdbcTemplate.query(GlTxnSqlQueries.GET_GL_RANGE_STMT_SUB_BIFURCATION_LIST_WISE,
					paramMap, new RowMapper<GLStmt>() {

						@Override
						public GLStmt mapRow(ResultSet rs, int rowNum) throws SQLException {
							GLStmt glStmt = new GLStmt();
							if (rs.getDate("txn_dt") != null)
								glStmt.setTxnDate(rs.getDate("txn_dt").toLocalDate());
							glStmt.setTxnNo(rs.getString("gl_txn_no"));
							glStmt.setTxnType(rs.getString("gl_txn_type"));
							if (rs.getString("dr_cr_flg").equalsIgnoreCase("CR")) {
								glStmt.setTxnCrAmt(BigDecimal.valueOf(rs.getDouble("txn_amt")));
								glStmt.setTxnDrAmt(BigDecimal.ZERO);
							} else if (rs.getString("dr_cr_flg").equalsIgnoreCase("DR")) {
								glStmt.setTxnDrAmt(BigDecimal.valueOf(rs.getDouble("txn_amt")));
								glStmt.setTxnCrAmt(BigDecimal.ZERO);
							}
							glStmt.setRemark(rs.getString("txn_remarks"));
							glStmt.setSubBfCode(rs.getString("sub_bifurcation"));
							glStmt.setSubBfName(rs.getString("bifurcation_value"));
							return glStmt;
						}
					});
		} catch (DataAccessException e) {
			throw new DataAccessResourceFailureException("Failed to get GL statement");
		}
	}

	@Override
	public TcodeLevelStmtOut getTcodeLevelGLStatement(GlStmtIn glStmtIn) {
		log.info("Inside GlTxnDaoImpl#getTcodeLevelGLStatement.. :{}", glStmtIn);

			
			TcodeLevelquery level1 = new TcodeLevelquery();
			
			return level1.tLevel1(glStmtIn);

	}

	
	class TcodeLevelquery{
		
		private int levelCnt = 0;
		
		
		public TcodeLevelStmtOut tLevel1(GlStmtIn glStmtIn) {
			
			log.info("T Code Level 1");
			Map<String, Object> paramMap = new HashMap<>();
			paramMap.put("logicalLoc", glStmtIn.getLogicallocCd());
			paramMap.put("mainGlCd", glStmtIn.getMainglCd());
			paramMap.put("subGlCd", glStmtIn.getSubglCd());
			paramMap.put("fromDt", glStmtIn.getFromDt());
			paramMap.put("toDt", glStmtIn.getToDt());
			paramMap.put("t1", glStmtIn.getT1());
			paramMap.put("t2", glStmtIn.getT2());
			paramMap.put("t3", glStmtIn.getT3());
			paramMap.put("t4", glStmtIn.getT4());
			paramMap.put("t5", glStmtIn.getT5());
			paramMap.put("t6", glStmtIn.getT6());
			paramMap.put("t7", glStmtIn.getT7());
			paramMap.put("t8", glStmtIn.getT8());
			paramMap.put("t9", glStmtIn.getT9());
			paramMap.put("t10", glStmtIn.getT10());
			paramMap.put("t11", glStmtIn.getT11());
			paramMap.put("t12", glStmtIn.getT12());
			paramMap.put("t13", glStmtIn.getT13());
			paramMap.put("t14", glStmtIn.getT14());
			paramMap.put("t15", glStmtIn.getT15());
			paramMap.put("t16", glStmtIn.getT16());
			paramMap.put("t17", glStmtIn.getT17());
			paramMap.put("t18", glStmtIn.getT18());
			paramMap.put("t19", glStmtIn.getT19());
			paramMap.put("t20", glStmtIn.getT20());
			paramMap.put("t21", glStmtIn.getT21());
			paramMap.put("t22", glStmtIn.getT22());
			paramMap.put("t23", glStmtIn.getT23());
			paramMap.put("t24", glStmtIn.getT24());
			paramMap.put("t25", glStmtIn.getT25());
			paramMap.put("t26", glStmtIn.getT26());
			paramMap.put("t27", glStmtIn.getT27());
			paramMap.put("t28", glStmtIn.getT28());
			paramMap.put("t29", glStmtIn.getT29());
			paramMap.put("t30", glStmtIn.getT30());
			paramMap.put("t31", glStmtIn.getT31());
			paramMap.put("t32", glStmtIn.getT32());
			paramMap.put("t33", glStmtIn.getT33());
			paramMap.put("t34", glStmtIn.getT34());
			paramMap.put("t35", glStmtIn.getT35());
			paramMap.put("t36", glStmtIn.getT36());

			paramMap.forEach((key, value) -> {
				if (value == null || StringUtils.isBlank(value.toString())) {
					paramMap.put(key, "");
				}
			});



			List<String> applicableTcodes = new ArrayList<>();

			String regex = "^t\\d{1,2}$";
			paramMap.forEach((key, value) -> {
				if (value != "" && key.matches(regex)) {
					applicableTcodes.add(key);
				}
			});

			log.info("list of applicable tcodes is {}", applicableTcodes);
			
			StringBuilder queryBuilder = new StringBuilder();
			
			StringBuilder applicableTcodesString = new StringBuilder();
			
			StringBuilder selectString = new StringBuilder();
			
			StringBuilder tcodeGroupString = new StringBuilder();
			Map<Integer, List<String>> levelsMap = glStmtIn.getLevels();
			
		
			String l5 = "";
			String l4 = "";
			String l3 = "";
			String l2 = "";
			String l1 = "";
			
			if(levelsMap.containsKey(1)) {
				levelCnt = 1;
				List<String> tList = levelsMap.get(1);
				l5 = tList.get(0);
				
				tcodeGroupString.append(" group by d."+l5+", d.gl_txn_no ) order by 1, 2;");		
				selectString.append("COALESCE("+l5+", 'NA') AS level_5,"
						+ "	COALESCE("+l5+", 'NA') AS level_4,"
						+ "	COALESCE("+l5+", 'NA') AS level_3,"
						+ "	COALESCE("+l5+", 'NA') AS level_2,"
						+ "	COALESCE("+l5+", 'NA') AS final_level,");
				
			}else if(levelsMap.containsKey(2)) {
				levelCnt = 2;
				List<String> tList = levelsMap.get(2);
				l5 = tList.get(0);
				l4 = tList.get(1);
				
				tcodeGroupString.append(" group by d."+l5+", d."+l4+", d.gl_txn_no ) order by 1, 2 ;");					
		
				selectString.append("COALESCE("+l5+", 'NA') AS level_5,"
						+ "	COALESCE("+l5+", 'NA') AS level_4,"
						+ "	COALESCE("+l5+", 'NA') AS level_3,"
						+ "	COALESCE("+l5+", 'NA') AS level_2,"
						+ "	COALESCE("+l4+", 'NA') AS final_level,");
				
			}else if(levelsMap.containsKey(3)) {
				levelCnt = 3;
				List<String> tList = levelsMap.get(3);
				l5 = tList.get(0);
				l4 = tList.get(1);
				l3 = tList.get(2);
				
				tcodeGroupString.append(" group by d."+l5+", d."+l4+", d."+l3+", d.gl_txn_no ) order by 1, 2, 3 ;");			
				selectString.append("COALESCE("+l5+", 'NA') AS level_5,"
						+ "	COALESCE("+l5+", 'NA') AS level_4,"
						+ "	COALESCE("+l5+", 'NA') AS level_3,"
						+ "	COALESCE("+l4+", 'NA') AS level_2,"
						+ "	COALESCE("+l3+", 'NA') AS final_level,");
				
			}else if(levelsMap.containsKey(4)) {
				levelCnt = 4;
				List<String> tList = levelsMap.get(4);
				l5 = tList.get(0);
				l4 = tList.get(1);
				l3 = tList.get(2);
				l2 = tList.get(3);
				
				tcodeGroupString.append(" group by d."+l5+", d."+l4+", d."+l3+", d."+l2+", d.gl_txn_no ) order by 1, 2, 3, 4 ;");			
				selectString.append("COALESCE("+l5+", 'NA') AS level_5,"
						+ "	COALESCE("+l5+", 'NA') AS level_4,"
						+ "	COALESCE("+l4+", 'NA') AS level_3,"
						+ "	COALESCE("+l3+", 'NA') AS level_2,"
						+ "	COALESCE("+l2+", 'NA') AS final_level,");
				
			}else if(levelsMap.containsKey(5)) {
				levelCnt = 5;
				List<String> tList = levelsMap.get(5);
				l5 = tList.get(0);
				l4 = tList.get(1);
				l3 = tList.get(2);
				l2 = tList.get(3);
				l1 = tList.get(4);
				
				tcodeGroupString.append(" group by d."+l5+", d."+l4+", d."+l3+", d."+l2+",d."+l1+", d.gl_txn_no ) order by 1, 2, 3, 4, 5 ;");		
				
				selectString.append("COALESCE("+l5+", 'NA') AS level_5,"
						+ "	COALESCE("+l4+", 'NA') AS level_4,"
						+ "	COALESCE("+l3+", 'NA') AS level_3,"
						+ "	COALESCE("+l2+", 'NA') AS level_2,"
						+ "	COALESCE("+l1+", 'NA') AS final_level,");
				
			}
			
			applicableTcodesString.append(" AND ");
				for (int i = 0; i < applicableTcodes.size(); i++) {
					if (i > 0) {
						applicableTcodesString.append(" AND ");
					}
					applicableTcodesString.append("d.").append(applicableTcodes.get(i)).append(" = ").append(":").append(applicableTcodes.get(i));
				}
	
			
			queryBuilder.append("select ")
					.append(selectString)
					.append("" 
					+ " h.txn_dt , "
					+ "    concat(d.gl_txn_type, ' ', d.gl_txn_no) as transaction_no, "
					+ "    d.txn_remarks , "
					+ "    (case when upper(d.dr_cr_flg) = 'DR' then d.txn_amt else 0  end ) as dr_amt, "
					+ "    (case when upper(d.dr_cr_flg) = 'CR' then d.txn_amt else 0  end ) as cr_amt "
					+ "from "
					+ "    accounts.ecgc_acct_gl_txn_dtl d "
					+ "inner join "
					+ "    accounts.ecgc_acct_gl_txn_hdr h "
					+ "on "
					+ "    d.logical_loc_cd = h.logical_loc_cd and "
					+ "    d.gl_txn_type = h.gl_txn_type and "
					+ "    d.gl_txn_no = h.gl_txn_no "
					+ "where "
					+ "        (h.txn_dt between :fromDt and :toDt) "
					+ "        and "
					+ "        h.logical_loc_cd = :logicalLoc   "
					+ "        and "
					+ "        maingl_cd = :mainGlCd  and  subgl_cd = :subGlCd ")
					.append(applicableTcodesString)
					.append(""
					+ "        and  d.gl_txn_no in ( "
					+ "                    select "
					+ "                    d.gl_txn_no "
					+ "                    FROM "
					+ "                    accounts.ecgc_acct_gl_txn_dtl d "
					+ "                    inner join "
					+ "                    accounts.ecgc_acct_gl_txn_hdr h "
					+ "                    on "
					+ "                    d.logical_loc_cd = h.logical_loc_cd and "
					+ "                    d.gl_txn_type = h.gl_txn_type and "
					+ "                    d.gl_txn_no = h.gl_txn_no "
					+ "                    where "
					+ "                    (h.txn_dt between :fromDt and :toDt) "
					+ "                    and "
					+ "                    h.logical_loc_cd = :logicalLoc "
					+ "                    and "
					+ "                    maingl_cd = :mainGlCd  and  subgl_cd = :subGlCd ")
											.append(applicableTcodesString)
											.append(tcodeGroupString);
			
			
			String tLevel1Query = queryBuilder.toString();
			log.info("Generated SQL Query : {}", tLevel1Query);
			
			TcodeLevelStmtOut tcodeLevelReport = namedParameterJdbcTemplate.query(tLevel1Query, paramMap, rs -> {
				try {
	                HierarchyBuilder builder = new HierarchyBuilder();
	                System.err.println("RS : "+ rs);
	                return builder.buildHierarchy(rs, levelCnt);
	            } catch (SQLException e) {
	                throw new RuntimeException("Failed to build hierarchy", e);
	            } catch (Exception e) {
	            	throw new RuntimeException("Exception Caused to build hierarchy", e);
	            }
			});//namedparam
			
			log.info("TCode Hierarchy Obj : {}", tcodeLevelReport);
			
			
			return tcodeLevelReport;
		}
	}
}


class HierarchyBuilder {
	 
    public TcodeLevelStmtOut buildHierarchy(ResultSet rs, int levelCnt) throws SQLException {
        TcodeLevelStmtOut root = new TcodeLevelStmtOut("root");
 
        while (rs.next()) {
        	
            try {
				String level5 = rs.getString("level_5");
				if(null == level5) {level5 = "NA";};
				String level4 = rs.getString("level_4");
				if(null == level4) {level4 = "NA";};
				String level3 = rs.getString("level_3");
				if(null == level3) {level3 = "NA";};
				String level2 = rs.getString("level_2");
				if(null == level2) {level2 = "NA";};
				String finalLevel = rs.getString("final_level");
				if(null == finalLevel) {finalLevel = "NA";};
				TcodeTransactions tcodeTransactions = new TcodeTransactions();
				tcodeTransactions.setTxnDt(rs.getDate("txn_dt").toLocalDate());
				tcodeTransactions.setTransactionNo(rs.getString("transaction_no"));
				tcodeTransactions.setTxnRemarks(rs.getString("txn_remarks"));
				tcodeTransactions.setDrAmt(rs.getBigDecimal("dr_amt"));
				tcodeTransactions.setCrAmt(rs.getBigDecimal("cr_amt"));
 
				TcodeLevelStmtOut currentLevel = root;
				
				currentLevel = getOrCreateSubLevel(currentLevel, level5);
				currentLevel = getOrCreateSubLevel(currentLevel, level4);
				currentLevel = getOrCreateSubLevel(currentLevel, level3);
				currentLevel = getOrCreateSubLevel(currentLevel, level2);
				currentLevel = getOrCreateSubLevel(currentLevel, finalLevel);
				
 
				currentLevel.getTransactions().add(tcodeTransactions);
			} catch (Exception e) {
				Log.error(e);
				e.printStackTrace();
			}
        }
 
        return root;
    }
 
    private TcodeLevelStmtOut getOrCreateSubLevel(TcodeLevelStmtOut currentLevel, String subLevelName) {
        for (TcodeLevelStmtOut subLevel : currentLevel.getSubLevels()) {
            if (subLevel.getName().equals(subLevelName)) {
                return subLevel;
            }
        }
 
        TcodeLevelStmtOut newSubLevel = new TcodeLevelStmtOut(subLevelName);
        currentLevel.getSubLevels().add(newSubLevel);
        return newSubLevel;
    }
}

