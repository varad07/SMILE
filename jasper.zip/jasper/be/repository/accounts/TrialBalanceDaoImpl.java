package in.ecgc.smile.erp.reporting.jasper.be.repository.accounts;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcOperations;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.TrialBalance;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.TrialBalanceIn;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.TrialBalanceReport;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.TrialBalanceTxnDtl;
import in.ecgc.smile.erp.reporting.jasper.be.utils.FORMATS;
import in.ecgc.smile.erp.reporting.jasper.be.utils.accounts.TrialBalanceSqlQueries;

@Repository
@Transactional
public class TrialBalanceDaoImpl implements TrialBalanceDao {

	// private static final Logger log =
	// LoggerFactory.getLogger(TrialBalanceDaoImpl.class);

	@Autowired
	private ObjectMapper objectMapper; // Autowire the ObjectMapper

	private NamedParameterJdbcOperations namedParameterJdbcOperations;
	@SuppressWarnings("unused")
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	@Autowired
	public TrialBalanceDaoImpl(DataSource dataSource) {
		namedParameterJdbcOperations = new NamedParameterJdbcTemplate(dataSource);
		namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(dataSource);
	}

	private static final Logger log = LoggerFactory.getLogger(TrialBalanceDaoImpl.class);

	@Override
	public TrialBalanceReport getTrialBalacneAllLoc(String inputDate, Boolean isNil) {
		Map<String, Object> paraMap = new HashMap<>();
		paraMap.put("input_date", LocalDate.parse(inputDate, FORMATS.DATE_FORMATS));
		TrialBalanceReport trialBalanceAllLoc = new TrialBalanceReport();

		List<TrialBalanceTxnDtl> trialBal = new ArrayList<TrialBalanceTxnDtl>();

		String query = null;

		if (isNil) {
			query = TrialBalanceSqlQueries.GET_TRIAL_BALANCE_ALL_LOC;
		} else {
			query = TrialBalanceSqlQueries.GET_TRIAL_BALANCE_ALL_LOC_NOT_NIL;
		}

		trialBal = namedParameterJdbcTemplate.query(query, paraMap, new RowMapper<TrialBalanceTxnDtl>() {

			@Override
			public TrialBalanceTxnDtl mapRow(ResultSet rs, int rowNum) throws SQLException {
				TrialBalanceTxnDtl trialBalanceAllLocDtl = new TrialBalanceTxnDtl();

				trialBalanceAllLocDtl.setInputDate(LocalDate.parse(inputDate, FORMATS.DATE_FORMATS));
				trialBalanceAllLocDtl.setMainglCd(rs.getString("maingl_cd"));
				trialBalanceAllLocDtl.setSubGlCd(rs.getString("subgl_cd"));
				trialBalanceAllLocDtl.setGlName(rs.getString("gl_name"));
				trialBalanceAllLocDtl.setGlType(rs.getString("gl_type"));
				trialBalanceAllLocDtl.setDrAmount(rs.getBigDecimal("dr_amount"));
				trialBalanceAllLocDtl.setCrAmount(rs.getBigDecimal("cr_amount"));
				return trialBalanceAllLocDtl;
			}
		});

		List<String> glTypeList = new ArrayList<>();
		glTypeList.add("ASST");
		glTypeList.add("LIAB");
		glTypeList.add("INCM");
		glTypeList.add("EXPD");

		for (String glType : glTypeList) {
			Map<String, Object> paraMap2 = new HashMap<>();
			paraMap2.put("glType", glType);
			paraMap2.put("input_date", LocalDate.parse(inputDate, FORMATS.DATE_FORMATS));

			namedParameterJdbcTemplate.query(TrialBalanceSqlQueries.GET_TRIAL_BALANCE_ALL_LOC_DR_CR_AMOUNT, paraMap2,
					new RowMapper<Map<String, BigDecimal>>() {

						@Override
						public Map<String, BigDecimal> mapRow(ResultSet rs, int rowNum) throws SQLException {

							Map<String, BigDecimal> amountMap = new HashMap<String, BigDecimal>();

							amountMap.put("crAmount", rs.getBigDecimal("total_cr"));
							amountMap.put("drAmount", rs.getBigDecimal("total_dr"));

							if (glType.equals("ASST")) {
								trialBalanceAllLoc.setAsstCrAmount(amountMap.get("crAmount"));
								trialBalanceAllLoc.setAsstDrAmount(amountMap.get("drAmount"));
							} else if (glType.equals("LIAB")) {
								trialBalanceAllLoc.setLiabCrAmount(amountMap.get("crAmount"));
								trialBalanceAllLoc.setLiabDrAmount(amountMap.get("drAmount"));
							} else if (glType.equals("INCM")) {
								trialBalanceAllLoc.setIncmCrAmount(amountMap.get("crAmount"));
								trialBalanceAllLoc.setIncmDrAmount(amountMap.get("drAmount"));
							} else if (glType.equals("EXPD")) {
								trialBalanceAllLoc.setExpdCrAmount(amountMap.get("crAmount"));
								trialBalanceAllLoc.setExpdDrAmount(amountMap.get("drAmount"));
							}

							return amountMap;
						}
					});

		} // for

		BigDecimal totalCr = trialBalanceAllLoc.getAsstCrAmount().add(trialBalanceAllLoc.getLiabCrAmount())
				.add(trialBalanceAllLoc.getExpdCrAmount()).add(trialBalanceAllLoc.getIncmCrAmount());
		BigDecimal totalDr = trialBalanceAllLoc.getAsstDrAmount().add(trialBalanceAllLoc.getLiabDrAmount())
				.add(trialBalanceAllLoc.getExpdDrAmount()).add(trialBalanceAllLoc.getIncmDrAmount());

		trialBalanceAllLoc.setTotalCrAmount(totalCr);
		trialBalanceAllLoc.setTotalDrAmount(totalDr);

		trialBalanceAllLoc.setTrialBalanceAllLocDtlList(trialBal);
		return trialBalanceAllLoc;
	}

	@Override
	public Integer getCountOfTrialBalacneAllLoc(String inputDate) {

		System.out.println("inside getCountOfTrialBalacneByLoc");

		Map<String, Object> paraMap = new HashMap<>();

		paraMap.put("input_date", LocalDate.parse(inputDate, FORMATS.DATE_FORMATS));

		System.out.println("Param Map : " + paraMap);

		Integer count = namedParameterJdbcTemplate.queryForObject(
				TrialBalanceSqlQueries.GET_TRIAL_BALANCE_ALL_LOC_COUNT, paraMap, new RowMapper<Integer>() {

					@Override
					public Integer mapRow(ResultSet rs, int rowNum) throws SQLException {
						return rs.getInt("count");
					}
				});
		System.out.println("Count of getCountOfTrialBalacneByLoc : " + count);
		return count;

	}

	@Override
	public TrialBalanceReport getTrialBalacneByLoc(String inputDate, String logicalLocation, Boolean isNil) {
		Map<String, Object> paraMap = new HashMap<>();

		paraMap.put("logical_loc_cd", logicalLocation);
		paraMap.put("input_date", LocalDate.parse(inputDate, FORMATS.DATE_FORMATS));

		System.out.println("Param Map : " + paraMap);

		TrialBalanceReport trialBalanceAllLoc = new TrialBalanceReport();

		List<TrialBalanceTxnDtl> trialBal = new ArrayList<TrialBalanceTxnDtl>();

		String query = null;

		if (isNil) {
			query = TrialBalanceSqlQueries.GET_TRIAL_BALANCE_LOC_WISE;
		} else {
			query = TrialBalanceSqlQueries.GET_TRIAL_BALANCE_LOC_WISE_NOT_NIL;
		}

		trialBal = namedParameterJdbcTemplate.query(query, paraMap, new RowMapper<TrialBalanceTxnDtl>() {

			@Override
			public TrialBalanceTxnDtl mapRow(ResultSet rs, int rowNum) throws SQLException {
				TrialBalanceTxnDtl trialBalanceAllLocDtl = new TrialBalanceTxnDtl();

				trialBalanceAllLocDtl.setInputDate(LocalDate.parse(inputDate, FORMATS.DATE_FORMATS));
				trialBalanceAllLocDtl.setMainglCd(rs.getString("maingl_cd"));
				trialBalanceAllLocDtl.setSubGlCd(rs.getString("subgl_cd"));
				trialBalanceAllLocDtl.setGlName(rs.getString("gl_name"));
				trialBalanceAllLocDtl.setGlType(rs.getString("gl_type"));
				trialBalanceAllLocDtl.setDrAmount(rs.getBigDecimal("dr_amount"));
				trialBalanceAllLocDtl.setCrAmount(rs.getBigDecimal("cr_amount"));
				return trialBalanceAllLocDtl;
			}
		});

		List<String> glTypeList = new ArrayList<>();
		glTypeList.add("ASST");
		glTypeList.add("LIAB");
		glTypeList.add("INCM");
		glTypeList.add("EXPD");

		for (String glType : glTypeList) {
			Map<String, Object> paraMap2 = new HashMap<>();
			paraMap2.put("glType", glType);
			paraMap2.put("logical_loc_cd", logicalLocation);
			paraMap2.put("input_date", LocalDate.parse(inputDate, FORMATS.DATE_FORMATS));

			namedParameterJdbcTemplate.query(TrialBalanceSqlQueries.GET_TRIAL_BALANCE_LOC_DR_CR_AMOUNT, paraMap2,
					new RowMapper<Map<String, BigDecimal>>() {

						@Override
						public Map<String, BigDecimal> mapRow(ResultSet rs, int rowNum) throws SQLException {

							Map<String, BigDecimal> amountMap = new HashMap<String, BigDecimal>();

							amountMap.put("crAmount", rs.getBigDecimal("total_cr"));
							amountMap.put("drAmount", rs.getBigDecimal("total_dr"));

							if (glType.equals("ASST")) {
								trialBalanceAllLoc.setAsstCrAmount(amountMap.get("crAmount"));
								trialBalanceAllLoc.setAsstDrAmount(amountMap.get("drAmount"));
							} else if (glType.equals("LIAB")) {
								trialBalanceAllLoc.setLiabCrAmount(amountMap.get("crAmount"));
								trialBalanceAllLoc.setLiabDrAmount(amountMap.get("drAmount"));
							} else if (glType.equals("INCM")) {
								trialBalanceAllLoc.setIncmCrAmount(amountMap.get("crAmount"));
								trialBalanceAllLoc.setIncmDrAmount(amountMap.get("drAmount"));
							} else if (glType.equals("EXPD")) {
								trialBalanceAllLoc.setExpdCrAmount(amountMap.get("crAmount"));
								trialBalanceAllLoc.setExpdDrAmount(amountMap.get("drAmount"));
							}

							return amountMap;
						}
					});

		} // for

		BigDecimal totalCr = trialBalanceAllLoc.getAsstCrAmount().add(trialBalanceAllLoc.getLiabCrAmount())
				.add(trialBalanceAllLoc.getExpdCrAmount()).add(trialBalanceAllLoc.getIncmCrAmount());
		BigDecimal totalDr = trialBalanceAllLoc.getAsstDrAmount().add(trialBalanceAllLoc.getLiabDrAmount())
				.add(trialBalanceAllLoc.getExpdDrAmount()).add(trialBalanceAllLoc.getIncmDrAmount());

		trialBalanceAllLoc.setTotalCrAmount(totalCr);
		trialBalanceAllLoc.setTotalDrAmount(totalDr);

		trialBalanceAllLoc.setTrialBalanceAllLocDtlList(trialBal);
		return trialBalanceAllLoc;
	}

	@Override
	public Integer getCountOfTrialBalacneByLoc(String inputDate, String logicalLocation) {

		System.out.println("inside getCountOfTrialBalacneByLoc");

		Map<String, Object> paraMap = new HashMap<>();

		paraMap.put("logical_loc_cd", logicalLocation);
		paraMap.put("input_date", LocalDate.parse(inputDate, FORMATS.DATE_FORMATS));

		System.out.println("Param Map : " + paraMap);

		Integer count = namedParameterJdbcTemplate.queryForObject(
				TrialBalanceSqlQueries.GET_TRIAL_BALANCE_LOC_WISE_COUNT, paraMap, new RowMapper<Integer>() {

					@Override
					public Integer mapRow(ResultSet rs, int rowNum) throws SQLException {
						return rs.getInt("count");
					}
				});
		System.out.println("Count of getCountOfTrialBalacneByLoc : " + count);
		return count;

	}

	@Override
	public TrialBalance getByLogicalLoc(String logicalLocCd, String balanceDate, String mainglCd, String subglCd,
			String glName, String glType) {
		// log.info("inside TrialBalanceDaoImpl - getByLogicalLoc ");
		TrialBalance trialBalance = new TrialBalance();
		Map<String, Object> paraMap = new HashMap<>();
		paraMap.put("mainglCd", mainglCd);
		paraMap.put("subglCd", subglCd);
		paraMap.put("logicallocCd", logicalLocCd);

		try {
			LocalDate lcdt = LocalDate.parse(balanceDate, FORMATS.DATE_FORMATS);
			paraMap.put("balancedt", lcdt);
		} catch (DateTimeParseException e) {
			throw new RuntimeException("Date Format is Incorrect");
		}

		try {
			// use this query ACCT_R02_A report GET_TRIAL_BAL_BY_LOGLOC
			// use this query for suyash's CS report GET_CS_TRIAL_BAL_BY_GL
			trialBalance = namedParameterJdbcOperations.queryForObject(TrialBalanceSqlQueries.GET_CS_TRIAL_BAL_BY_GL,
					paraMap, new RowMapper<TrialBalance>() {

						@Override
						public TrialBalance mapRow(ResultSet rs, int rowNum) throws SQLException {
							TrialBalance balance = new TrialBalance();
							balance.setLogicalLocCd(logicalLocCd);
							if (rs.getBigDecimal("total_dr_amount") != null) {
								balance.setDrAmount(
										rs.getBigDecimal("total_dr_amount").setScale(2, BigDecimal.ROUND_HALF_UP));
							} else {

								balance.setDrAmount(BigDecimal.valueOf(0.00).setScale(2, BigDecimal.ROUND_HALF_UP));
							}
							if (rs.getBigDecimal("total_cr_amount") != null) {
								balance.setCrAmount(
										rs.getBigDecimal("total_cr_amount").setScale(2, BigDecimal.ROUND_HALF_UP));
							} else {
								balance.setCrAmount(BigDecimal.valueOf(0.00).setScale(2, BigDecimal.ROUND_HALF_UP));
							}
							balance.setMainGlCd(mainglCd);
							balance.setSubGlCd(subglCd);
							balance.setGlName(glName);
							balance.setGltype(glType);

							// log.info("Trial Balance : {}",balance);

							return balance;
						}
					});
		} catch (EmptyResultDataAccessException e) {

			// log.info("Exception caused in getByLogicalLoc: {}", e.getMessage());

			trialBalance.setLogicalLocCd(logicalLocCd);
			trialBalance.setDrAmount(BigDecimal.valueOf(0.00).setScale(2, BigDecimal.ROUND_HALF_UP));
			trialBalance.setCrAmount(BigDecimal.valueOf(0.00).setScale(2, BigDecimal.ROUND_HALF_UP));
			trialBalance.setMainGlCd(mainglCd);
			trialBalance.setSubGlCd(subglCd);
			trialBalance.setGlName(glName);
			trialBalance.setGltype(glType);

		}
		return trialBalance;
	}

	@Override
	public TrialBalance getByTcodewise(TrialBalanceIn trialBalanceIn) {
		log.info("Inside TrialBalanceDaoImpl#getByTcodewise");

		String trialBalJson = "";
		try {
			String JSONStr = objectMapper.writeValueAsString(trialBalanceIn);
			log.info("Object To JSON String : {}", JSONStr);

			JsonNode jsonNode = objectMapper.readTree(JSONStr);

			// Create a new object to store non-null values
			ObjectNode filteredObject = objectMapper.createObjectNode();

			// Iterate through the fields of the input JSON
			jsonNode.fields().forEachRemaining(entry -> {
				// Check if the field value is not null
				log.info("entry val is : {}", entry.getValue());

				if (!entry.getValue().isNull() || entry.getValue().toString() != "") {
					// Add the non-null field to the filtered object
					filteredObject.set(entry.getKey(), entry.getValue());
				}
			});

			List<String> fieldsToRemove = new ArrayList<>();
			// Collect fields to remove
			Iterator<Map.Entry<String, JsonNode>> fields = filteredObject.fields();
			while (fields.hasNext()) {
				Map.Entry<String, JsonNode> entry = fields.next();
				JsonNode value = entry.getValue();
				if (value.isNull() || (value.isTextual() && value.asText().isEmpty())) {
					fieldsToRemove.add(entry.getKey());
				}
			}
			// Remove collected fields
			fieldsToRemove.forEach(filteredObject::remove);

			log.info("Json Object : {}", filteredObject);

			// Convert the filtered object to a JSON string
			trialBalJson = filteredObject.toString();

		} catch (JsonProcessingException e1) {
			e1.printStackTrace();
		}

		log.info("FINAL Input JSON String : {}", trialBalJson);

		SqlParameterSource parameters = new MapSqlParameterSource().addValue("inp_tb_json", trialBalJson);
		TrialBalance trialBalance = new TrialBalance();
		try {
			trialBalance = namedParameterJdbcTemplate.queryForObject(TrialBalanceSqlQueries.GET_TRIAL_BAL_BY_TCODE_WISE,
					parameters, new RowMapper<TrialBalance>() {

						@Override
						public TrialBalance mapRow(ResultSet rs, int rowNum) throws SQLException {
							TrialBalance tBalance = new TrialBalance();
							if (rs.getBigDecimal("total_dr_amount") != null) {
								tBalance.setDrAmount(
										rs.getBigDecimal("total_dr_amount").setScale(2, BigDecimal.ROUND_HALF_UP));
							} else {
								tBalance.setDrAmount(BigDecimal.valueOf(0.00).setScale(2, BigDecimal.ROUND_HALF_UP));
							}
							if (rs.getBigDecimal("total_cr_amount") != null) {
								tBalance.setCrAmount(
										rs.getBigDecimal("total_cr_amount").setScale(2, BigDecimal.ROUND_HALF_UP));
							} else {
								tBalance.setCrAmount(BigDecimal.valueOf(0.00).setScale(2, BigDecimal.ROUND_HALF_UP));
							}
							tBalance.setMainGlCd(trialBalanceIn.getMaingl_cd());
							tBalance.setSubGlCd(trialBalanceIn.getSubgl_cd());
							tBalance.setBalDate(trialBalanceIn.getDate());
							tBalance.setLogicalLocCd(trialBalanceIn.getLogical_loc_cd());
							return tBalance;
						}
					});
		} catch (Exception e) {
			trialBalance.setDrAmount(BigDecimal.valueOf(0.00).setScale(2, BigDecimal.ROUND_HALF_UP));
			trialBalance.setCrAmount(BigDecimal.valueOf(0.00).setScale(2, BigDecimal.ROUND_HALF_UP));
			trialBalance.setMainGlCd(trialBalanceIn.getMaingl_cd());
			trialBalance.setSubGlCd(trialBalanceIn.getSubgl_cd());
			trialBalance.setGlName("");
			trialBalance.setGltype("");
			trialBalance.setBalDate(trialBalanceIn.getDate());
			trialBalance.setLogicalLocCd(trialBalanceIn.getLogical_loc_cd());
		}
		return trialBalance;
	}

	@Override
	public Integer generateTrialBalanceAllLocByDate(String inputDate) {
		Map<String, Object> paraMap = new HashMap<>();

		try {
			paraMap.put("input_date", LocalDate.parse(inputDate, FORMATS.DATE_FORMATS));
		} catch (DateTimeParseException e) {
			throw new RuntimeException("Date Format is Incorrect");
		}

		try {
			return namedParameterJdbcTemplate.queryForObject(TrialBalanceSqlQueries.GETERATE_TRIAL_BALANCE_ALL_LOC,
					paraMap, new RowMapper<Integer>() {
						@Override
						public Integer mapRow(ResultSet rs, int rowNum) throws SQLException {
							return rs.getInt(1);
						}
					});
		} catch (EmptyResultDataAccessException e) {
			throw new RuntimeException("Failed to Generate Trial Balance For Given Date : " + inputDate
					+ " ; Exeception caused due to : " + e.getMessage());

		}
	}

	@Override
	public Integer generateTrialBalanceLocWiseByDate(String inputDate, String logicalLocation) {
		Map<String, Object> paraMap = new HashMap<>();

		try {
			paraMap.put("input_date", LocalDate.parse(inputDate, FORMATS.DATE_FORMATS));
		} catch (DateTimeParseException e) {
			throw new RuntimeException("Date Format is Incorrect");
		}

		try {
			return namedParameterJdbcTemplate.queryForObject(TrialBalanceSqlQueries.GETERATE_TRIAL_BALANCE_LOC_WISE,
					paraMap, new RowMapper<Integer>() {
						@Override
						public Integer mapRow(ResultSet rs, int rowNum) throws SQLException {
							return rs.getInt(0);
						}
					});
		} catch (EmptyResultDataAccessException e) {
			throw new RuntimeException("Failed to Generate Trial Balance For Given Date : " + inputDate
					+ "  ; Exeception caused due to : " + e.getMessage());

		}
	}

	@Override
	public Integer generateTrialBalanceByLocDate(String inputDate, String logicalLocation) {
		Map<String, Object> paraMap = new HashMap<>();

		try {
			paraMap.put("input_date", LocalDate.parse(inputDate, FORMATS.DATE_FORMATS));
			paraMap.put("logical_location", logicalLocation);
		} catch (DateTimeParseException e) {
			throw new RuntimeException("Date Format is Incorrect");
		}

		try {
			return namedParameterJdbcTemplate.queryForObject(TrialBalanceSqlQueries.GETERATE_TRIAL_BALANCE_LOC_WISE,
					paraMap, new RowMapper<Integer>() {
						@Override
						public Integer mapRow(ResultSet rs, int rowNum) throws SQLException {
							return rs.getInt(1);
						}
					});
		} catch (EmptyResultDataAccessException e) {
			throw new RuntimeException("Failed to Generate Trial Balance For Given Date : " + inputDate
					+ " ; Exeception caused due to : " + e.getMessage());

		}
	}

	@Override
	public List<String> getEcgcBranchCodeList() {
		// log.info("Calling method getEcgcBranchCodeList :");
		HashMap<String, Object> paramMap = new HashMap<>();
		// paramMap.put(UWConstants.IN_PROP_SYS_ID, inPropSysId);
		return namedParameterJdbcOperations.queryForList(TrialBalanceSqlQueries.GET_ECGC_BRANCH_CODE_LIST, paramMap,
				String.class);
	}

	@Override
	public List<String> getAllStateMap() {
		// log.info("Calling method getAllStateMap :");
		HashMap<String, Object> paramMap = new HashMap<>();
		return namedParameterJdbcOperations.queryForList(TrialBalanceSqlQueries.GET_STATE_LIST, paramMap, String.class);
	}

	@Override
	public TrialBalanceReport getTrialBalacneByState(String inputDate, String state, Boolean isNil) {
		Map<String, Object> paraMap = new HashMap<>();

		paraMap.put("state", state);
		paraMap.put("input_date", LocalDate.parse(inputDate, FORMATS.DATE_FORMATS));

		System.out.println("Param Map : " + paraMap);

		TrialBalanceReport trialBalanceAllLoc = new TrialBalanceReport();

		List<TrialBalanceTxnDtl> trialBal = new ArrayList<TrialBalanceTxnDtl>();

		String query = null;

		if (isNil) {
			query = TrialBalanceSqlQueries.GET_TRIAL_BALANCE_STATE_WISE;
		} else {
			query = TrialBalanceSqlQueries.GET_TRIAL_BALANCE_STATE_WISE_NOT_NIL;
		}

		trialBal = namedParameterJdbcTemplate.query(query, paraMap, new RowMapper<TrialBalanceTxnDtl>() {

			@Override
			public TrialBalanceTxnDtl mapRow(ResultSet rs, int rowNum) throws SQLException {
				TrialBalanceTxnDtl trialBalanceAllLocDtl = new TrialBalanceTxnDtl();

				trialBalanceAllLocDtl.setInputDate(LocalDate.parse(inputDate, FORMATS.DATE_FORMATS));
				trialBalanceAllLocDtl.setMainglCd(rs.getString("maingl_cd"));
				trialBalanceAllLocDtl.setSubGlCd(rs.getString("subgl_cd"));
				trialBalanceAllLocDtl.setGlName(rs.getString("gl_name"));
				trialBalanceAllLocDtl.setGlType(rs.getString("gl_type"));
				trialBalanceAllLocDtl.setDrAmount(rs.getBigDecimal("dr_amount"));
				trialBalanceAllLocDtl.setCrAmount(rs.getBigDecimal("cr_amount"));
				return trialBalanceAllLocDtl;
			}
		});

		List<String> glTypeList = new ArrayList<>();
		glTypeList.add("ASST");
		glTypeList.add("LIAB");
		glTypeList.add("INCM");
		glTypeList.add("EXPD");

		for (String glType : glTypeList) {
			Map<String, Object> paraMap2 = new HashMap<>();
			paraMap2.put("glType", glType);
			paraMap2.put("state", state);
			paraMap2.put("input_date", LocalDate.parse(inputDate, FORMATS.DATE_FORMATS));

			namedParameterJdbcTemplate.query(TrialBalanceSqlQueries.GET_TRIAL_BALANCE_STATE_DR_CR_AMOUNT, paraMap2,
					new RowMapper<Map<String, BigDecimal>>() {

						@Override
						public Map<String, BigDecimal> mapRow(ResultSet rs, int rowNum) throws SQLException {

							Map<String, BigDecimal> amountMap = new HashMap<String, BigDecimal>();

							amountMap.put("crAmount", rs.getBigDecimal("total_cr"));
							amountMap.put("drAmount", rs.getBigDecimal("total_dr"));

							if (glType.equals("ASST")) {
								trialBalanceAllLoc.setAsstCrAmount(amountMap.get("crAmount"));
								trialBalanceAllLoc.setAsstDrAmount(amountMap.get("drAmount"));
							} else if (glType.equals("LIAB")) {
								trialBalanceAllLoc.setLiabCrAmount(amountMap.get("crAmount"));
								trialBalanceAllLoc.setLiabDrAmount(amountMap.get("drAmount"));
							} else if (glType.equals("INCM")) {
								trialBalanceAllLoc.setIncmCrAmount(amountMap.get("crAmount"));
								trialBalanceAllLoc.setIncmDrAmount(amountMap.get("drAmount"));
							} else if (glType.equals("EXPD")) {
								trialBalanceAllLoc.setExpdCrAmount(amountMap.get("crAmount"));
								trialBalanceAllLoc.setExpdDrAmount(amountMap.get("drAmount"));
							}

							return amountMap;
						}
					});

		} // for

		BigDecimal totalCr = trialBalanceAllLoc.getAsstCrAmount().add(trialBalanceAllLoc.getLiabCrAmount())
				.add(trialBalanceAllLoc.getExpdCrAmount()).add(trialBalanceAllLoc.getIncmCrAmount());
		BigDecimal totalDr = trialBalanceAllLoc.getAsstDrAmount().add(trialBalanceAllLoc.getLiabDrAmount())
				.add(trialBalanceAllLoc.getExpdDrAmount()).add(trialBalanceAllLoc.getIncmDrAmount());

		trialBalanceAllLoc.setTotalCrAmount(totalCr);
		trialBalanceAllLoc.setTotalDrAmount(totalDr);

		trialBalanceAllLoc.setTrialBalanceAllLocDtlList(trialBal);
		return trialBalanceAllLoc;
	}

	@Override
	public Integer generateTrialBalacneByState(String inputDate, String state) {
		Map<String, Object> paraMap = new HashMap<>();

		try {
			paraMap.put("input_date", LocalDate.parse(inputDate, FORMATS.DATE_FORMATS));
			paraMap.put("state", state);
		} catch (DateTimeParseException e) {
			throw new RuntimeException("Date Format is Incorrect");
		}

		try {
			return namedParameterJdbcTemplate.queryForObject(TrialBalanceSqlQueries.GETERATE_TRIAL_BALANCE_STATE_WISE,
					paraMap, new RowMapper<Integer>() {
						@Override
						public Integer mapRow(ResultSet rs, int rowNum) throws SQLException {
							return rs.getInt(1);
						}
					});
		} catch (EmptyResultDataAccessException e) {
			throw new RuntimeException("Failed to Generate Trial Balance For Given Date : " + inputDate
					+ " ; Exeception caused due to : " + e.getMessage());

		}
	}

	@Override
	public List<String> getAllRegionMap() {
		HashMap<String, Object> paramMap = new HashMap<>();
		return namedParameterJdbcOperations.queryForList(TrialBalanceSqlQueries.GET_REGION_LIST, paramMap,
				String.class);
	}

	@Override
	public TrialBalanceReport getTrialBalacneByRegion(String inputDate, String region, Boolean isNil) {
		Map<String, Object> paraMap = new HashMap<>();

		paraMap.put("region", region);
		paraMap.put("input_date", LocalDate.parse(inputDate, FORMATS.DATE_FORMATS));

		System.out.println("Param Map : " + paraMap);

		TrialBalanceReport trialBalanceAllLoc = new TrialBalanceReport();

		List<TrialBalanceTxnDtl> trialBal = new ArrayList<TrialBalanceTxnDtl>();

		String query = null;

		if (isNil) {
			query = TrialBalanceSqlQueries.GET_TRIAL_BALANCE_REGION_WISE;
		} else {
			query = TrialBalanceSqlQueries.GET_TRIAL_BALANCE_REGION_WISE_NOT_NIL;
		}

		trialBal = namedParameterJdbcTemplate.query(query, paraMap, new RowMapper<TrialBalanceTxnDtl>() {

			@Override
			public TrialBalanceTxnDtl mapRow(ResultSet rs, int rowNum) throws SQLException {
				TrialBalanceTxnDtl trialBalanceAllLocDtl = new TrialBalanceTxnDtl();

				trialBalanceAllLocDtl.setInputDate(LocalDate.parse(inputDate, FORMATS.DATE_FORMATS));
				trialBalanceAllLocDtl.setMainglCd(rs.getString("maingl_cd"));
				trialBalanceAllLocDtl.setSubGlCd(rs.getString("subgl_cd"));
				trialBalanceAllLocDtl.setGlName(rs.getString("gl_name"));
				trialBalanceAllLocDtl.setGlType(rs.getString("gl_type"));
				trialBalanceAllLocDtl.setDrAmount(rs.getBigDecimal("dr_amount"));
				trialBalanceAllLocDtl.setCrAmount(rs.getBigDecimal("cr_amount"));
				return trialBalanceAllLocDtl;
			}
		});

		List<String> glTypeList = new ArrayList<>();
		glTypeList.add("ASST");
		glTypeList.add("LIAB");
		glTypeList.add("INCM");
		glTypeList.add("EXPD");

		for (String glType : glTypeList) {
			Map<String, Object> paraMap2 = new HashMap<>();
			paraMap2.put("glType", glType);
			paraMap2.put("region", region);
			paraMap2.put("input_date", LocalDate.parse(inputDate, FORMATS.DATE_FORMATS));

			namedParameterJdbcTemplate.query(TrialBalanceSqlQueries.GET_TRIAL_BALANCE_REGION_DR_CR_AMOUNT, paraMap2,
					new RowMapper<Map<String, BigDecimal>>() {

						@Override
						public Map<String, BigDecimal> mapRow(ResultSet rs, int rowNum) throws SQLException {

							Map<String, BigDecimal> amountMap = new HashMap<String, BigDecimal>();

							amountMap.put("crAmount", rs.getBigDecimal("total_cr"));
							amountMap.put("drAmount", rs.getBigDecimal("total_dr"));

							if (glType.equals("ASST")) {
								trialBalanceAllLoc.setAsstCrAmount(amountMap.get("crAmount"));
								trialBalanceAllLoc.setAsstDrAmount(amountMap.get("drAmount"));
							} else if (glType.equals("LIAB")) {
								trialBalanceAllLoc.setLiabCrAmount(amountMap.get("crAmount"));
								trialBalanceAllLoc.setLiabDrAmount(amountMap.get("drAmount"));
							} else if (glType.equals("INCM")) {
								trialBalanceAllLoc.setIncmCrAmount(amountMap.get("crAmount"));
								trialBalanceAllLoc.setIncmDrAmount(amountMap.get("drAmount"));
							} else if (glType.equals("EXPD")) {
								trialBalanceAllLoc.setExpdCrAmount(amountMap.get("crAmount"));
								trialBalanceAllLoc.setExpdDrAmount(amountMap.get("drAmount"));
							}

							return amountMap;
						}
					});

		} // for

		BigDecimal totalCr = trialBalanceAllLoc.getAsstCrAmount().add(trialBalanceAllLoc.getLiabCrAmount())
				.add(trialBalanceAllLoc.getExpdCrAmount()).add(trialBalanceAllLoc.getIncmCrAmount());
		BigDecimal totalDr = trialBalanceAllLoc.getAsstDrAmount().add(trialBalanceAllLoc.getLiabDrAmount())
				.add(trialBalanceAllLoc.getExpdDrAmount()).add(trialBalanceAllLoc.getIncmDrAmount());

		trialBalanceAllLoc.setTotalCrAmount(totalCr);
		trialBalanceAllLoc.setTotalDrAmount(totalDr);

		trialBalanceAllLoc.setTrialBalanceAllLocDtlList(trialBal);
		return trialBalanceAllLoc;
	}

	@Override
	public Integer generateTrialBalacneByRegion(String inputDate, String region) {
		Map<String, Object> paraMap = new HashMap<>();

		try {
			paraMap.put("input_date", LocalDate.parse(inputDate, FORMATS.DATE_FORMATS));
			paraMap.put("region", region);
		} catch (DateTimeParseException e) {
			throw new RuntimeException("Date Format is Incorrect");
		}

		try {
			return namedParameterJdbcTemplate.queryForObject(TrialBalanceSqlQueries.GETERATE_TRIAL_BALANCE_REGION_WISE,
					paraMap, new RowMapper<Integer>() {
						@Override
						public Integer mapRow(ResultSet rs, int rowNum) throws SQLException {
							return rs.getInt(1);
						}
					});
		} catch (EmptyResultDataAccessException e) {
			throw new RuntimeException("Failed to Generate Trial Balance For Given Date : " + inputDate
					+ " ; Exeception caused due to : " + e.getMessage());

		}
	}

	@Override
	public TrialBalance getBySubBfwise(TrialBalanceIn trialBalanceIn) {
		// log.info("Inside TrialBalanceDaoImpl#getByTcodewise");

		String trialBalJson = "";
		try {
			String JSONStr = objectMapper.writeValueAsString(trialBalanceIn);
			// log.info("Object To JSON String : {}", JSONStr);

			JsonNode jsonNode = objectMapper.readTree(JSONStr);

			// Create a new object to store non-null values
			ObjectNode filteredObject = objectMapper.createObjectNode();

			// Iterate through the fields of the input JSON
			jsonNode.fields().forEachRemaining(entry -> {
				// Check if the field value is not null

				log.info("entry val is : {}", entry.getValue());

				if (!entry.getValue().isNull() || entry.getValue().toString() != "") {
					// Add the non-null field to the filtered object
					filteredObject.set(entry.getKey(), entry.getValue());
				}
			});

			List<String> fieldsToRemove = new ArrayList<>();
			// Collect fields to remove
			Iterator<Map.Entry<String, JsonNode>> fields = filteredObject.fields();
			while (fields.hasNext()) {
				Map.Entry<String, JsonNode> entry = fields.next();
				JsonNode value = entry.getValue();
				if (value.isNull() || (value.isTextual() && value.asText().isEmpty())) {
					fieldsToRemove.add(entry.getKey());
				}
			}
			// Remove collected fields
			fieldsToRemove.forEach(filteredObject::remove);

			log.info("Json Object : {}", filteredObject);

			// Convert the filtered object to a JSON string
			trialBalJson = filteredObject.toString();

		} catch (JsonProcessingException e1) {
			e1.printStackTrace();
		}

		System.out.println("Input JSON String : " + trialBalJson);

		SqlParameterSource parameters = new MapSqlParameterSource().addValue("inp_tb_json", trialBalJson);
		TrialBalance trialBalance = new TrialBalance();
		try {
			trialBalance = namedParameterJdbcTemplate.queryForObject(
					TrialBalanceSqlQueries.GET_TRIAL_BAL_BY_TCODE_SUBBF_WISE, parameters,
					new RowMapper<TrialBalance>() {

						@Override
						public TrialBalance mapRow(ResultSet rs, int rowNum) throws SQLException {
							TrialBalance tBalance = new TrialBalance();
							if (rs.getBigDecimal("total_dr_amount") != null) {
								tBalance.setDrAmount(
										rs.getBigDecimal("total_dr_amount").setScale(2, BigDecimal.ROUND_HALF_UP));
							} else {
								tBalance.setDrAmount(BigDecimal.valueOf(0.00).setScale(2, BigDecimal.ROUND_HALF_UP));
							}
							if (rs.getBigDecimal("total_cr_amount") != null) {
								tBalance.setCrAmount(
										rs.getBigDecimal("total_cr_amount").setScale(2, BigDecimal.ROUND_HALF_UP));
							} else {
								tBalance.setCrAmount(BigDecimal.valueOf(0.00).setScale(2, BigDecimal.ROUND_HALF_UP));
							}
							tBalance.setMainGlCd(trialBalanceIn.getMaingl_cd());
							tBalance.setSubGlCd(trialBalanceIn.getSubgl_cd());
							tBalance.setBalDate(trialBalanceIn.getDate());
							tBalance.setLogicalLocCd(trialBalanceIn.getLogical_loc_cd());
							return tBalance;
						}
					});
		} catch (Exception e) {
			trialBalance.setDrAmount(BigDecimal.valueOf(0.00).setScale(2, BigDecimal.ROUND_HALF_UP));
			trialBalance.setCrAmount(BigDecimal.valueOf(0.00).setScale(2, BigDecimal.ROUND_HALF_UP));
			trialBalance.setMainGlCd(trialBalanceIn.getMaingl_cd());
			trialBalance.setSubGlCd(trialBalanceIn.getSubgl_cd());
			trialBalance.setGlName("");
			trialBalance.setGltype("");
			trialBalance.setBalDate(trialBalanceIn.getDate());
			trialBalance.setLogicalLocCd(trialBalanceIn.getLogical_loc_cd());
		}
		return trialBalance;
	}

	public TrialBalanceReport getTrialBalacneByGlCode(String mainglCd, String subGlCd, String inputDate,
			Boolean isNil) {
		Map<String, Object> paraMap = new HashMap<>();

		paraMap.put("mainglCd", mainglCd);
		paraMap.put("subGlCd", subGlCd);
		paraMap.put("input_date", LocalDate.parse(inputDate, FORMATS.DATE_FORMATS));

		System.out.println("Param Map : " + paraMap);

		Integer generateTrialBalacneByGlCode = this.generateTrialBalacneByGlCode(mainglCd, subGlCd, inputDate);

		List<TrialBalanceTxnDtl> trialBal = new ArrayList<TrialBalanceTxnDtl>();
		TrialBalanceReport trialBalanceAllLoc = new TrialBalanceReport();

		if (generateTrialBalacneByGlCode > 0) {

			String query = null;

			if (isNil) {
				query = TrialBalanceSqlQueries.GET_TRIAL_BALANCE_GL_WISE;
			} else {
				query = TrialBalanceSqlQueries.GET_TRIAL_BALANCE_GL_WISE_NOT_NIL;
			}

			trialBal = namedParameterJdbcTemplate.query(query, paraMap, new RowMapper<TrialBalanceTxnDtl>() {

				@Override
				public TrialBalanceTxnDtl mapRow(ResultSet rs, int rowNum) throws SQLException {
					TrialBalanceTxnDtl trialBalanceAllLocDtl = new TrialBalanceTxnDtl();

					trialBalanceAllLocDtl.setInputDate(LocalDate.parse(inputDate, FORMATS.DATE_FORMATS));
					trialBalanceAllLocDtl.setMainglCd(rs.getString("mainglcd"));
					trialBalanceAllLocDtl.setSubGlCd(rs.getString("subglcd"));
					trialBalanceAllLocDtl.setGlName(rs.getString("gl_name"));
					trialBalanceAllLocDtl.setGlType(rs.getString("gl_type"));
					trialBalanceAllLocDtl.setDrAmount(rs.getBigDecimal("dr_amount"));
					trialBalanceAllLocDtl.setCrAmount(rs.getBigDecimal("cr_amount"));
					trialBalanceAllLocDtl.setLogicalLocation(rs.getString("logical_loc_cd"));
					return trialBalanceAllLocDtl;
				}
			});

			trialBalanceAllLoc.setTrialBalanceAllLocDtlList(trialBal);
		}
		return trialBalanceAllLoc;
	}

	@Override
	public Integer generateTrialBalacneByGlCode(String mainglCd, String subGlCd, String inputDate) {
		Map<String, Object> paraMap = new HashMap<>();

		try {
			paraMap.put("mainglCd", mainglCd);
			paraMap.put("subGlCd", subGlCd);
			paraMap.put("inputDate", LocalDate.parse(inputDate, FORMATS.DATE_FORMATS));
		} catch (DateTimeParseException e) {
			throw new RuntimeException("Date Format is Incorrect");
		}

		try {
			return namedParameterJdbcTemplate.queryForObject(TrialBalanceSqlQueries.GETERATE_TRIAL_BALANCE_GL_WISE,
					paraMap, new RowMapper<Integer>() {
						@Override
						public Integer mapRow(ResultSet rs, int rowNum) throws SQLException {
							return rs.getInt(1);
						}
					});
		} catch (EmptyResultDataAccessException e) {
			throw new RuntimeException("Failed to Generate Trial Balance For Given Date : " + inputDate
					+ " ; Exeception caused due to : " + e.getMessage());

		}
	}

	public TrialBalance getByLogicalLocGLsubBfCd(String logicalLocCd, String balanceDate, String mainglCd,
			String subglCd, String subBfCd, String glName, String glType) {
		log.info("inside TrialBalanceDaoImpl - getByLogicalLocGLsubBfCd :{},{},{},{},{},{},{}", logicalLocCd,
				balanceDate, mainglCd, subglCd, subBfCd, glName, glType);
		TrialBalance trialBalance = new TrialBalance();
		Map<String, Object> paraMap = new HashMap<>();
		paraMap.put("mainglCd", mainglCd);
		paraMap.put("subglCd", subglCd);
		paraMap.put("logicallocCd", logicalLocCd);
		paraMap.put("subbfCd", subBfCd);

		try {
			LocalDate lcdt = LocalDate.parse(balanceDate, FORMATS.DATE_FORMATS);
			paraMap.put("balancedt", lcdt);
		} catch (DateTimeParseException e) {
			throw new RuntimeException("Date Format is Incorrect");
		}

		try {

			trialBalance = namedParameterJdbcOperations.queryForObject(
					TrialBalanceSqlQueries.GET_TRIAL_BAL_BY_LOGLOC_SUBBF_WISE, paraMap, new RowMapper<TrialBalance>() {
						@Override
						public TrialBalance mapRow(ResultSet rs, int rowNum) throws SQLException {
							TrialBalance balance = new TrialBalance();
							balance.setLogicalLocCd(logicalLocCd);
							if (rs.getBigDecimal("total_dr_amount") != null) {
								balance.setDrAmount(
										rs.getBigDecimal("total_dr_amount").setScale(2, BigDecimal.ROUND_HALF_UP));
							} else {

								balance.setDrAmount(BigDecimal.valueOf(0.00).setScale(2, BigDecimal.ROUND_HALF_UP));
							}
							if (rs.getBigDecimal("total_cr_amount") != null) {
								balance.setCrAmount(
										rs.getBigDecimal("total_cr_amount").setScale(2, BigDecimal.ROUND_HALF_UP));
							} else {
								balance.setCrAmount(BigDecimal.valueOf(0.00).setScale(2, BigDecimal.ROUND_HALF_UP));
							}
							balance.setMainGlCd(mainglCd);
							balance.setSubGlCd(subglCd);
							balance.setGlName(glName);
							balance.setGltype(glType);

							// log.info("Trial Balance : {}",balance);

							return balance;
						}

					});
		} catch (EmptyResultDataAccessException e) {

			// log.info("Exception caused in getByLogicalLoc: {}", e.getMessage());

			trialBalance.setLogicalLocCd(logicalLocCd);
			trialBalance.setDrAmount(BigDecimal.valueOf(0.00).setScale(2, BigDecimal.ROUND_HALF_UP));
			trialBalance.setCrAmount(BigDecimal.valueOf(0.00).setScale(2, BigDecimal.ROUND_HALF_UP));
			trialBalance.setMainGlCd(mainglCd);
			trialBalance.setSubGlCd(subglCd);
			trialBalance.setGlName(glName);
			trialBalance.setGltype(glType);

		}
		return trialBalance;

	}

	@Override
	public TrialBalance getGlRangeByLogicalLoc(String locationCode, String balanceDate, String mainglCd, String subglCd,
			String glName, String glType) {

		log.info("inside TrialBalanceDaoImpl - getByLogicalLoc ");
		TrialBalance trialBalance = new TrialBalance();
		Map<String, Object> paraMap = new HashMap<>();
		paraMap.put("mainglCd", mainglCd);
		paraMap.put("subglCd", subglCd);
		paraMap.put("logicallocCd", locationCode);

		try {
			LocalDate lcdt = LocalDate.parse(balanceDate, FORMATS.DATE_FORMATS);
			paraMap.put("balancedt", lcdt);
		} catch (DateTimeParseException e) {
			throw new RuntimeException("Date Format is Incorrect");
		}

		try {
			trialBalance = namedParameterJdbcOperations.queryForObject(TrialBalanceSqlQueries.GET_TRIAL_BAL_BY_LOGLOC,
					paraMap, new RowMapper<TrialBalance>() {

						@Override
						public TrialBalance mapRow(ResultSet rs, int rowNum) throws SQLException {
							TrialBalance balance = new TrialBalance();
							balance.setLogicalLocCd(locationCode);
							if (rs.getBigDecimal("total_dr_amount") != null) {
								balance.setDrAmount(
										rs.getBigDecimal("total_dr_amount").setScale(2, BigDecimal.ROUND_HALF_UP));
							} else {

								balance.setDrAmount(BigDecimal.valueOf(0.00).setScale(2, BigDecimal.ROUND_HALF_UP));
							}
							if (rs.getBigDecimal("total_cr_amount") != null) {
								balance.setCrAmount(
										rs.getBigDecimal("total_cr_amount").setScale(2, BigDecimal.ROUND_HALF_UP));
							} else {
								balance.setCrAmount(BigDecimal.valueOf(0.00).setScale(2, BigDecimal.ROUND_HALF_UP));
							}
							balance.setMainGlCd(mainglCd);
							balance.setSubGlCd(subglCd);
							balance.setGlName(glName);
							balance.setGltype(glType);

							log.info("Trial Balance in DAO: {}", balance);

							return balance;
						}
					});
		} catch (EmptyResultDataAccessException e) {

			log.error("Exception caused in getByLogicalLoc: {}", e.getMessage());

			trialBalance.setLogicalLocCd(locationCode);
			trialBalance.setDrAmount(BigDecimal.valueOf(0.00).setScale(2, BigDecimal.ROUND_HALF_UP));
			trialBalance.setCrAmount(BigDecimal.valueOf(0.00).setScale(2, BigDecimal.ROUND_HALF_UP));
			trialBalance.setMainGlCd(mainglCd);
			trialBalance.setSubGlCd(subglCd);
			trialBalance.setGlName(glName);
			trialBalance.setGltype(glType);

		}
		return trialBalance;
	}

	@Override
	public TrialBalance getByLogicalLocGLsubBfCdList(String logicalLocCd, String balanceDate, String mainglCd,
			String subglCd, List<String> subBfCdList, String glName, String glType) {
		log.info("inside TrialBalanceDaoImpl - getByLogicalLocGLsubBfCd :{},{},{},{},{},{},{}", logicalLocCd,
				balanceDate, mainglCd, subglCd, subBfCdList, glName, glType);
		TrialBalance trialBalance = new TrialBalance();

		MapSqlParameterSource paraMap = new MapSqlParameterSource();
		paraMap.addValue("mainglCd", mainglCd);
		paraMap.addValue("subglCd", subglCd);
		paraMap.addValue("logicallocCd", logicalLocCd);
		paraMap.addValue("subbfCdList", subBfCdList.toArray(new String[0]));

		try {
			LocalDate lcdt = LocalDate.parse(balanceDate, FORMATS.DATE_FORMATS);
			paraMap.addValue("balancedt", lcdt);
		} catch (DateTimeParseException e) {
			throw new RuntimeException("Date Format is Incorrect");
		}

		log.info("Final ParamMap : {}", paraMap);

		try {

			trialBalance = namedParameterJdbcOperations.queryForObject(
					TrialBalanceSqlQueries.GET_TRIAL_BAL_BY_LOGLOC_SUBBF_LIST_WISE, paraMap,
					new RowMapper<TrialBalance>() {
						@Override
						public TrialBalance mapRow(ResultSet rs, int rowNum) throws SQLException {
							TrialBalance balance = new TrialBalance();
							balance.setLogicalLocCd(logicalLocCd);
							if (rs.getBigDecimal("total_dr_amount") != null) {
								balance.setDrAmount(
										rs.getBigDecimal("total_dr_amount").setScale(2, BigDecimal.ROUND_HALF_UP));
							} else {

								balance.setDrAmount(BigDecimal.valueOf(0.00).setScale(2, BigDecimal.ROUND_HALF_UP));
							}
							if (rs.getBigDecimal("total_cr_amount") != null) {
								balance.setCrAmount(
										rs.getBigDecimal("total_cr_amount").setScale(2, BigDecimal.ROUND_HALF_UP));
							} else {
								balance.setCrAmount(BigDecimal.valueOf(0.00).setScale(2, BigDecimal.ROUND_HALF_UP));
							}
							balance.setMainGlCd(mainglCd);
							balance.setSubGlCd(subglCd);
							balance.setGlName(glName);
							balance.setGltype(glType);

							// log.info("Trial Balance : {}",balance);

							return balance;
						}

					});
		} catch (EmptyResultDataAccessException e) {

			// log.info("Exception caused in getByLogicalLoc: {}", e.getMessage());

			trialBalance.setLogicalLocCd(logicalLocCd);
			trialBalance.setDrAmount(BigDecimal.valueOf(0.00).setScale(2, BigDecimal.ROUND_HALF_UP));
			trialBalance.setCrAmount(BigDecimal.valueOf(0.00).setScale(2, BigDecimal.ROUND_HALF_UP));
			trialBalance.setMainGlCd(mainglCd);
			trialBalance.setSubGlCd(subglCd);
			trialBalance.setGlName(glName);
			trialBalance.setGltype(glType);

		}
		return trialBalance;

	}

}
