package in.ecgc.smile.erp.reporting.jasper.be.repository.accounts;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import in.ecgc.smile.erp.reporting.jasper.be.exceptions.ReportGenerationException;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.TrialBalanceDtl;
import in.ecgc.smile.erp.reporting.jasper.be.utils.accounts.ScheduleQueries;

@Repository
public class ScheduleDaoImpl implements ScheduleDao {

	// Sl4j logger
	private static Logger log = LoggerFactory.getLogger(ScheduleDaoImpl.class);

	//template class for JDBC Operations
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	//dataSource Connection
	public ScheduleDaoImpl(DataSource dataSource) {
		namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(dataSource);
	}

	// check for input date in trail balance table
	@Override
	public int checkForInputDt(LocalDate date) {

		log.debug("ScheduleDaoImpl-->checkForInputDt()");

		Map<String, Object> paramMap = new HashMap<>();
		paramMap.put("inputDate", date);

		int result = 0;
		try {
			result = namedParameterJdbcTemplate.queryForObject(ScheduleQueries.CHECK_FOR_DATE, paramMap, Integer.class);

		} catch (Exception e) {
			log.error("Input date error");
			log.error(e.getMessage());
			throw new ReportGenerationException("Report generation error", "DATA_ACCESS_EXCEPTION");
		}

		return result;
	}

	// Getting current input date trial balance
	@Override
	public TrialBalanceDtl getScheduleWiseBalance(String scheduleCd, String scheduleItemCd,LocalDate date) {

		log.debug("ScheduleDaoImpl-->getScheduleWiseBalance()");

		Map<String, Object> paramMap = new HashMap<>();
		paramMap.put("scheduleCd", scheduleCd);
		paramMap.put("scheduleItemCd", scheduleItemCd);
		paramMap.put("inputDate", date);

		TrialBalanceDtl tb = new TrialBalanceDtl();

		try {
			tb = namedParameterJdbcTemplate.queryForObject(ScheduleQueries.GET_SCHEDULE_BALANCE, paramMap,
					new RowMapper<TrialBalanceDtl>() {

						@Override
						public TrialBalanceDtl mapRow(ResultSet rs, int rowNum) throws SQLException {
							TrialBalanceDtl tb = new TrialBalanceDtl();
							tb.setCrAmount(rs.getBigDecimal("cr_amount"));
							if (tb.getCrAmount() == null) {
								tb.setCrAmount(BigDecimal.ZERO);
							}
							tb.setDrAmount(rs.getBigDecimal("dr_amount"));
							if (tb.getDrAmount() == null) {
								tb.setDrAmount(BigDecimal.ZERO);
							}
							return tb;
						}
					});
		} catch (DataAccessException e) {
			log.error("Getting current date  Trail balance schedule code and schedule item code wise error");
			log.error(e.getMessage());
			throw new ReportGenerationException("Report generation error", "DATA_ACCESS_EXCEPTION");
		} catch (Exception e) {
			log.error("Getting current date Trail balance schedule code and schedule item code wise error");
			log.error(e.getMessage());
			throw new ReportGenerationException("Report generation error", "DATA_ACCESS_EXCEPTION");
		}

		return tb;
	}

	// Getting previous input date trial balance
	@Override
	public TrialBalanceDtl getScheduleWiseBalancePrv(String scheduleCd, String scheduleItemCd,LocalDate date) {

		log.debug("ScheduleDaoImpl-->getScheduleWiseBalancePrv()");

		Map<String, Object> paramMap = new HashMap<>();
		paramMap.put("scheduleCd", scheduleCd);
		paramMap.put("scheduleItemCd", scheduleItemCd);
		paramMap.put("inputDate", date);

		TrialBalanceDtl tb = new TrialBalanceDtl();

		try {
			tb = namedParameterJdbcTemplate.queryForObject(ScheduleQueries.GET_SCHEDULE_BALANCE_PRV, paramMap,
					new RowMapper<TrialBalanceDtl>() {

						@Override
						public TrialBalanceDtl mapRow(ResultSet rs, int rowNum) throws SQLException {
							TrialBalanceDtl tb = new TrialBalanceDtl();
							tb.setCrAmount(rs.getBigDecimal("cr_amount"));
							if (tb.getCrAmount() == null) {
								tb.setCrAmount(BigDecimal.ZERO);
							}
							tb.setDrAmount(rs.getBigDecimal("dr_amount"));
							if (tb.getDrAmount() == null) {
								tb.setDrAmount(BigDecimal.ZERO);
							}
							return tb;
						}
					});
		} catch (DataAccessException e) {
			log.error("Getting previous date Trail balance schedule code and schedule item code wise error");
			log.error(e.getMessage());
			throw new ReportGenerationException("Report generation error", "DATA_ACCESS_EXCEPTION");
		} catch (Exception e) {
			log.error("Getting previous date Trail balance schedule code and schedule item code wise error");
			log.error(e.getMessage());
			throw new ReportGenerationException("Report generation error", "DATA_ACCESS_EXCEPTION");
		}

		return tb;
	}

	// Generating current input date trial balance
	@Override
	public int generateTb(LocalDate date) {
		log.debug("ScheduleDaoImpl-->generateTb()");

		Map<String, Object> paramMap = new HashMap<>();
		paramMap.put("inputDate", date);

		int result = 0;
		try {
			result = namedParameterJdbcTemplate.queryForObject(ScheduleQueries.GENERATE_CUR_TB, paramMap,
					Integer.class);

		} catch (Exception e) {
			log.error("Generating current date Trail balance schedule code and schedule item code wise error");
			log.error(e.getMessage());
			throw new ReportGenerationException("Report generation error", "DATA_ACCESS_EXCEPTION");
		}

		return result;
	}

	// Generating previous input date trial balance
	@Override
	public int generateTbPrv(LocalDate prvDt) {
		log.debug("ScheduleDaoImpl-->generateTbPrv()");
		Map<String, Object> paramMap = new HashMap<>();
		paramMap.put("inputDate", prvDt);

		int result = 0;
		try {
			result = namedParameterJdbcTemplate.queryForObject(ScheduleQueries.GENERATE_PR_TB, paramMap, Integer.class);

		} catch (Exception e) {
			log.error("Generating previous date Trail balance schedule code and schedule item code wise error");
			log.error(e.getMessage());
			throw new ReportGenerationException("Report generation error", "DATA_ACCESS_EXCEPTION");

		}

		return result;
	}

}
