package in.ecgc.smile.erp.reporting.jasper.be.repository.accounts;

import java.util.List;

import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.TrialBalance;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.TrialBalanceIn;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.TrialBalanceReport;

public interface TrialBalanceDao {
	
	
	public TrialBalanceReport getTrialBalacneAllLoc(String inputDate, Boolean isNil);
	public Integer getCountOfTrialBalacneAllLoc(String inputDate);
	
	public TrialBalanceReport getTrialBalacneByLoc(String inputDate, String logicalLocation, Boolean isNil);
	public Integer getCountOfTrialBalacneByLoc(String inputDate, String logicalLocation);
	
	
	
	
	public Integer generateTrialBalanceAllLocByDate(String inputDate);
	
	public TrialBalance  getByTcodewise(TrialBalanceIn trialBalanceIn);
	
	public TrialBalance getByLogicalLocGLsubBfCd(String logicalLocCd, String balanceDate, String mainglCd, String subglCd,String subBfCd,
			String glName, String glType);
	
	public TrialBalance getByLogicalLocGLsubBfCdList(String logicalLocCd, String balanceDate, String mainglCd, String subglCd,List<String> subBfCd,
			String glName, String glType);

	public TrialBalance getByLogicalLoc(String logicalLocation, String balanceDate, String mainglCd, String subglCd,
			String glName, String glType);

	public Integer generateTrialBalanceLocWiseByDate(String inputDate, String logicalLocation);
	
	public Integer generateTrialBalanceByLocDate(String inputDate, String logicalLocation);
	
	public List<String> getEcgcBranchCodeList();
	public List<String> getAllStateMap();
	public TrialBalanceReport getTrialBalacneByState(String inputDate, String state, Boolean isNil);
	public Integer generateTrialBalacneByState(String inputDate, String state);
	public List<String> getAllRegionMap();
	public TrialBalanceReport getTrialBalacneByRegion(String inputDate, String region, Boolean isNil);
	public Integer generateTrialBalacneByRegion(String inputDate, String region);
	public TrialBalance getBySubBfwise(TrialBalanceIn trialBalanceIn); 
	public TrialBalanceReport getTrialBalacneByGlCode(String mainglCd, String subGlCd, String inputDate, Boolean isNil);
	public Integer generateTrialBalacneByGlCode(String mainglCd, String subGlCd, String inputDate);
	public TrialBalance getGlRangeByLogicalLoc(String logicalLocation, String balanceDate, String mainglCd, String subglCd,
			String glName, String glType); 

}
