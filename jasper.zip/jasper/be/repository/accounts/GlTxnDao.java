package in.ecgc.smile.erp.reporting.jasper.be.repository.accounts;

import java.time.LocalDate;
import java.util.List;

import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.EntityGL;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.GLCodeStmtIn;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.GLRangeStmt;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.GLStmt;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.GlStmtIn;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.TdsDetails;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.TrialBalance;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.TcodeLevel.TcodeLevelStmtOut;

public interface GlTxnDao {

	public List<GLStmt> getTCodewiseGLTxnStatement(GlStmtIn glStmtIn);

	/*
	 * List<GLStmt> getTransactionTypewiseGLTxnStatement(String logicallocCd, String
	 * txnType, LocalDate fromDt, LocalDate toDt);
	 */

	public List<GLStmt> getTransactionTypewiseGLTxnStatement(String logicallocCd, String txnType, String fromDt,
			String toDt);

	public List<GLRangeStmt> getGLcodewiseTxnStatement(String mainGlCd, String subGlCd, String logicalLocCd,
			LocalDate fromDate, LocalDate toDate, TrialBalance openingTrialBal);

	public List<EntityGL> getGLRangeList(String fromMainGlCd, String fromSubGlCd, String toMainGlCd, String toSubGlCd);

	public List<String> getGLRangeLocationList(String fromMainGlCd, String fromSubGlCd, String toMainGlCd,
			String toSubGlCd, String fromDt, String toDt);

	public List<GLStmt> getGLCodeStatementbyLoc(GLCodeStmtIn glCodeStmtIn);

	public List<GLStmt> getSubBfwiseGLTxnStatement(GlStmtIn glStmtIn);

	public List<GLStmt> getSubBfListwiseGLTxnStatement(GlStmtIn glStmtIn);

	public List<GLStmt> getTcodeAndSubBfwiseGLTxnStatement(GlStmtIn glStmtIn);

	public List<TdsDetails> getdetailsOfAmtPaidUnderTDSForYear(String logicallocCd, String fiscalYear);

	public List<GLStmt> getGLCodeStatementbyAllLocation(GLCodeStmtIn glCodeStmtIn);

	public List<GLStmt> getGLlocGLsubBfCd(GlStmtIn glStmt);

	public TcodeLevelStmtOut getTcodeLevelGLStatement(GlStmtIn glStmtIn);

}
