package in.ecgc.smile.erp.reporting.jasper.be.repository.accounts;

import java.time.LocalDate;

import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.TrialBalanceDtl;

public interface ScheduleDao {

	int checkForInputDt(LocalDate date);
	
	public TrialBalanceDtl getScheduleWiseBalance(String scheduleCd, String scheduleItemCd,LocalDate date);
	
	TrialBalanceDtl getScheduleWiseBalancePrv(String scheduleCd, String scheduleItemCd,LocalDate date);

	int generateTb(LocalDate date);

	int generateTbPrv(LocalDate prvDt);

}
