package in.ecgc.smile.erp.reporting.jasper.be.repository.accounts;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcOperations;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.EntityGL;
import in.ecgc.smile.erp.reporting.jasper.be.utils.accounts.EntityGLSqlQueries;

@Repository
@Transactional

public class EntityGLMasterDaoImpl implements EntityGLMasterDao {
	
	private static final Logger log = LoggerFactory.getLogger(EntityGLMasterDaoImpl.class);

	private NamedParameterJdbcOperations namedParameterJdbcOperations;
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	@Autowired
	public EntityGLMasterDaoImpl(DataSource dataSource) {

		namedParameterJdbcOperations = new NamedParameterJdbcTemplate(dataSource);
		namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(dataSource);
	}

//	private static final Logger log = LoggerFactory.getLogger(EntityGLMasterDaoImpl.class);

	/**
	 * View all GL codes
	 *
	 * DAO implementation to list all GL codes present in the database Table
	 * :acct_entity_gl_mst returns list of model EntityGL
	 * {@link in.ecgc.smile.erp.reporting.jasper.be.model.accounts.accounts.model.EntityGL}
	 */

	
	public EntityGL findGLByGLCode(String mainGLCode, String subGLCode) {
		log.info("Inside EntityGLMasterDaoImpl#findGLByGLCode");
		Map<String, String> paramMap = new HashMap<>();
		paramMap.put("mainCode", mainGLCode);
		paramMap.put("subCode", subGLCode);
		EntityGL entityGL = new EntityGL();
		try {
//			RowMapper<EntityGL> rowMapper = EntityGLSqlQueries::mapRow;
			entityGL = namedParameterJdbcOperations.queryForObject(EntityGLSqlQueries.GET_ENTITY_GL, paramMap,
					new RowMapper<EntityGL>() {

						@Override
						public EntityGL mapRow(ResultSet rs, int rowNum) throws SQLException {
							EntityGL entityGL = new EntityGL();
							// entityGL.setEntityGlCd(rs.getInt("entity_gl_cd"));
							entityGL.setMainglCd(rs.getString("maingl_cd"));
							entityGL.setSubglCd(rs.getString("subgl_cd"));
							entityGL.setGlName(rs.getString("gl_name"));
							entityGL.setEntityGlCd(rs.getString("entity_cd"));
							if (rs.getString("gl_is_group") != null)
								entityGL.setGlIsGroup(rs.getString("gl_is_group").charAt(0));
							entityGL.setGlType(rs.getString("gl_type"));
							entityGL.setGlSubtype(rs.getString("gl_subtype"));
							entityGL.setBalInd(rs.getString("bal_ind"));
							if (rs.getString("zero_bal_flag") != null)
								entityGL.setZeroBalFlg(rs.getString("zero_bal_flag").charAt(0));
							if (rs.getString("active") != null)
								entityGL.setActive(rs.getString("active").charAt(0));
							entityGL.setPlLevel(rs.getString("pl_level"));
							entityGL.setCashaccount(rs.getInt("cashaccount"));
							entityGL.setCashFlow(rs.getInt("cashflow"));
							entityGL.setLogicalLocCd(rs.getString("logical_loc_cd"));
							entityGL.setMetaRemarks(rs.getString("meta_remarks"));
							entityGL.setCreatedBy(rs.getString("created_by"));
							entityGL.setCreatedDt(rs.getObject("created_dt", LocalDate.class));
							entityGL.setLastUpdatedBy(rs.getString("last_updated_by"));
							entityGL.setLastUpdatedDt(rs.getObject("last_updated_dt", LocalDate.class));
							entityGL.setOldCd(rs.getString("old_cd"));
							if (rs.getString("t1") != null)
								entityGL.setT1(rs.getString("t1").charAt(0));
							if (rs.getString("t2") != null)
								entityGL.setT2(rs.getString("t2").charAt(0));
							if (rs.getString("t3") != null)
								entityGL.setT3(rs.getString("t3").charAt(0));
							if (rs.getString("t4") != null)
								entityGL.setT4(rs.getString("t4").charAt(0));
							if (rs.getString("t5") != null)
								entityGL.setT5(rs.getString("t5").charAt(0));
							if (rs.getString("t6") != null)
								entityGL.setT6(rs.getString("t6").charAt(0));
							if (rs.getString("t7") != null)
								entityGL.setT7(rs.getString("t7").charAt(0));
							if (rs.getString("t8") != null)
								entityGL.setT8(rs.getString("t8").charAt(0));
							if (rs.getString("t9") != null)
								entityGL.setT9(rs.getString("t9").charAt(0));
							if (rs.getString("t10") != null)
								entityGL.setT10(rs.getString("t10").charAt(0));
							if (rs.getString("t11") != null)
								entityGL.setT11(rs.getString("t11").charAt(0));
							if (rs.getString("t12") != null)
								entityGL.setT12(rs.getString("t12").charAt(0));
							if (rs.getString("t13") != null)
								entityGL.setT13(rs.getString("t13").charAt(0));
							if(rs.getString("t14") != null)
								entityGL.setT14(rs.getString("t14").charAt(0));
							if (rs.getString("t15") != null)
								entityGL.setT15(rs.getString("t15").charAt(0));
							if (rs.getString("t16") != null)
								entityGL.setT16(rs.getString("t16").charAt(0));
							if (rs.getString("t17") != null)
								entityGL.setT17(rs.getString("t17").charAt(0));
							if (rs.getString("t18") != null)
								entityGL.setT18(rs.getString("t18").charAt(0));
							if (rs.getString("t19") != null)
								entityGL.setT19(rs.getString("t19").charAt(0));
							if (rs.getString("t20") != null)
								entityGL.setT20(rs.getString("t20").charAt(0));
							if (rs.getString("t21") != null)
								entityGL.setT21(rs.getString("t21").charAt(0));
							if (rs.getString("t22") != null)
								entityGL.setT22(rs.getString("t22").charAt(0));
							if (rs.getString("t23") != null)
								entityGL.setT23(rs.getString("t23").charAt(0));
							if (rs.getString("t24") != null)
								entityGL.setT24(rs.getString("t24").charAt(0));
							if (rs.getString("t25") != null)
								entityGL.setT25(rs.getString("t25").charAt(0));
							if (rs.getString("t26") != null)
								entityGL.setT26(rs.getString("t26").charAt(0));
							if (rs.getString("t27") != null)
								entityGL.setT27(rs.getString("t27").charAt(0));
							if (rs.getString("t28") != null)
								entityGL.setT28(rs.getString("t28").charAt(0));
							if (rs.getString("t29") != null)
								entityGL.setT29(rs.getString("t29").charAt(0));
							if (rs.getString("t30") != null)
								entityGL.setT30(rs.getString("t30").charAt(0));
							if (rs.getString("t31") != null)
								entityGL.setT31(rs.getString("t31").charAt(0));
							if (rs.getString("t32") != null)
								entityGL.setT32(rs.getString("t32").charAt(0));
							if (rs.getString("t33") != null)
								entityGL.setT33(rs.getString("t33").charAt(0));
							if (rs.getString("t34") != null)
								entityGL.setT34(rs.getString("t34").charAt(0));
							if (rs.getString("t35") != null)
								entityGL.setT35(rs.getString("t35").charAt(0));
							if (rs.getString("t36") != null)
								entityGL.setT36(rs.getString("t36").charAt(0));
							if (rs.getString("t37") != null)
								entityGL.setT37(rs.getString("t37").charAt(0));
							if (rs.getString("t38") != null)
								entityGL.setT38(rs.getString("t38").charAt(0));
							if (rs.getString("t39") != null)
								entityGL.setT39(rs.getString("t39").charAt(0));
							if (rs.getString("t40") != null)
								entityGL.setT40(rs.getString("t40").charAt(0));

							
							entityGL.setIrdaCd(rs.getString("irda_cd"));
							if (rs.getString("irda_bap_cd") != null)
								entityGL.setIrdaBpaCd(rs.getString("irda_bap_cd"));
							if (rs.getString("schedule6") != null)
								entityGL.setSchedule6(rs.getString("schedule6"));
							if (rs.getString("financial_form_name") != null)
								entityGL.setFinancialFormName(rs.getString("financial_form_name"));
							if (rs.getString("sub_bifurcation_level") != null)
								entityGL.setSubBifurcationLevel(rs.getString("sub_bifurcation_level"));
							entityGL.setBalInd(rs.getString("bal_ind"));
							entityGL.setScheduleItemCd(rs.getString("schedule_item_code"));
							entityGL.setScheduleCd(rs.getString("schedule_code"));
							entityGL.setpFeeFlg(rs.getBoolean("p_fee_flg"));
							log.info("Entity gl is :{}", entityGL);
							return entityGL;
						}
					});
			return entityGL;
		} catch (Exception e) {
			log.error("exception in EntityGLMasterDaoImpl#findGLByGLCode : {}", e);
			throw new RuntimeException("No GL code details found for GL Code for MainGl : " + mainGLCode+ " and SubGl : " + subGLCode + "");
		}
		
	}

	@Override
	public EntityGL findGLByBankGLCode(String mainGLCode, String subGLCode) {
		log.info("Inside EntityGLMasterDaoImpl#findGLByGLCode");
		Map<String, String> paramMap = new HashMap<>();
		paramMap.put("mainCode", mainGLCode);
		paramMap.put("subCode", subGLCode);
		EntityGL entityGL = new EntityGL();
		try {
//			RowMapper<EntityGL> rowMapper = EntityGLSqlQueries::mapRow;
			entityGL = namedParameterJdbcOperations.queryForObject(EntityGLSqlQueries.GET_ENTITY_BANK_GL, paramMap,
					new RowMapper<EntityGL>() {

						@Override
						public EntityGL mapRow(ResultSet rs, int rowNum) throws SQLException {
							EntityGL entityGL = new EntityGL();
							// entityGL.setEntityGlCd(rs.getInt("entity_gl_cd"));
							entityGL.setMainglCd(rs.getString("maingl_cd"));
							entityGL.setSubglCd(rs.getString("subgl_cd"));
							entityGL.setGlName(rs.getString("gl_name"));
							entityGL.setEntityGlCd(rs.getString("entity_cd"));
							if (rs.getString("gl_is_group") != null)
								entityGL.setGlIsGroup(rs.getString("gl_is_group").charAt(0));
							entityGL.setGlType(rs.getString("gl_type"));
							entityGL.setGlSubtype(rs.getString("gl_subtype"));
							entityGL.setBalInd(rs.getString("bal_ind"));
							if (rs.getString("zero_bal_flag") != null)
								entityGL.setZeroBalFlg(rs.getString("zero_bal_flag").charAt(0));
							if (rs.getString("active") != null)
								entityGL.setActive(rs.getString("active").charAt(0));
							entityGL.setPlLevel(rs.getString("pl_level"));
							entityGL.setMetaRemarks(rs.getString("meta_remarks"));
							entityGL.setCreatedBy(rs.getString("created_by"));
							entityGL.setCreatedDt(rs.getObject("created_dt", LocalDate.class));
							entityGL.setLastUpdatedBy(rs.getString("last_updated_by"));
							entityGL.setLastUpdatedDt(rs.getObject("last_updated_dt", LocalDate.class));
							entityGL.setOldCd(rs.getString("old_cd"));
							
							
							
							log.info("Entity gl is :{}", entityGL);
							return entityGL;
						}
					});
			return entityGL;
		} catch (Exception e) {
			log.error("exception in EntityGLMasterDaoImpl#findGLByGLCode : {}", e);
			throw new RuntimeException("No GL code details found for GL Code for MainGl : " + mainGLCode+ " and SubGl : " + subGLCode + "");
		}
	}



}


