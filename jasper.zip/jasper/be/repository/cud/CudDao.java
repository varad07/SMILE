package in.ecgc.smile.erp.reporting.jasper.be.repository.cud;

import java.util.List;

import in.ecgc.smile.erp.reporting.jasper.be.model.cud.CUDR09;
import in.ecgc.smile.erp.reporting.jasper.be.model.cud.CUDR10;

public interface CudDao {

	List<CUDR09> getListCudR09(String fromDate, String toDate);

	List<CUDR10> getListCudR10(String fromDate, String toDate);

}
