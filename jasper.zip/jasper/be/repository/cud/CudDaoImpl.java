package in.ecgc.smile.erp.reporting.jasper.be.repository.cud;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcOperations;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import org.springframework.stereotype.Repository;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import in.ecgc.smile.erp.reporting.jasper.be.model.cud.CUDR09;
import in.ecgc.smile.erp.reporting.jasper.be.model.cud.CUDR10;
import in.ecgc.smile.erp.reporting.jasper.be.utils.cud.CudQueries;

@Repository
public class CudDaoImpl implements CudDao {

	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	private JdbcOperations jdbcOperations;
	private static final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(CudDaoImpl.class);

	public CudDaoImpl(DataSource dataSource) {
		super();
		jdbcOperations = new JdbcTemplate(dataSource);
		namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(dataSource);
	}

	@Override
	public List<CUDR09> getListCudR09(String fromDate, String toDate) {
		String sql = CudQueries.GET_CUDR09;

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

		Date fromDt = null;
		Date toDt = null;

		try {
			fromDt = sdf.parse(fromDate);
			toDt = sdf.parse(toDate);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		MapSqlParameterSource param = new MapSqlParameterSource();
		param.addValue("fromDate", fromDt);
		param.addValue("toDate", toDt);

		List<CUDR09> result;
		try {
			result = namedParameterJdbcTemplate.query(sql, param, new CUDR09ModelRowMapper());
			if (result != null) {
				return result;
			} else {
				return null;
			}
		} catch (DataAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<CUDR10> getListCudR10(String fromDate, String toDate) {
	
		String sql = CudQueries.GET_CUDR10;

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

		Date fromDt = null;
		Date toDt = null;

		try {
			fromDt = sdf.parse(fromDate);
			toDt = sdf.parse(toDate);
		} catch (ParseException e) {
			logger.error("Exception occurred CUDR_10 DaoImpl {}",e.getMessage());
		}

		MapSqlParameterSource param = new MapSqlParameterSource();
		param.addValue("fromDate", fromDt);
		param.addValue("toDate", toDt);

		List<CUDR10> result;
		try {
			result = namedParameterJdbcTemplate.query(sql, param, new CUDR10ModelRowMapper());
			if (result != null) {
				return result;
			} else {
				return null;
			}
		} catch (DataAccessException e) {
			logger.error("Exception occurred CUDR_10 DaoImpl {}",e.getMessage());
		}
		return null;
	}

}

class CUDR09ModelRowMapper implements RowMapper<CUDR09> {

	@Override
	public CUDR09 mapRow(ResultSet rs, int rowNum) throws SQLException {
		CUDR09 cudR09 = new CUDR09();

		cudR09.setRegionCd(rs.getString("regionCd"));
		cudR09.setCountry(rs.getString("country"));
		cudR09.setCommodity(rs.getString("commodity"));
		cudR09.setBranch(rs.getString("branch"));
		cudR09.setPolicyType(rs.getString("policyType"));
		cudR09.setRiskValue(rs.getBigDecimal("riskValue"));
		cudR09.setPremiumAdjusted(rs.getBigDecimal("premiumAdjusted"));

		return cudR09;
	}

}

class CUDR10ModelRowMapper implements RowMapper<CUDR10> {

	@Override
	public CUDR10 mapRow(ResultSet rs, int rowNum) throws SQLException {
		CUDR10 cudR10 = new CUDR10();

		cudR10.setProductId(rs.getString("productId"));
		cudR10.setPolicyNo(rs.getString("policyNo"));
		cudR10.setBranch(rs.getString("branch"));
		cudR10.setRegionName(rs.getString("regionName"));
		cudR10.setFinancialYear(rs.getString("financialYear"));
		cudR10.setYearMonth(rs.getString("yearMonth"));
		cudR10.setTotalRv(rs.getBigDecimal("totalRv"));
		cudR10.setTotalPremAdj(rs.getBigDecimal("totalPremAdj"));

		return cudR10;
	}

}
