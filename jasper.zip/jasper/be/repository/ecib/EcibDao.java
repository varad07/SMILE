package in.ecgc.smile.erp.reporting.jasper.be.repository.ecib;

import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.web.bind.annotation.PathVariable;

import in.ecgc.smile.erp.reporting.jasper.be.model.ecib.EcibInUR04;
import in.ecgc.smile.erp.reporting.jasper.be.model.ecib.EcibInUR16;
import in.ecgc.smile.erp.reporting.jasper.be.model.ecib.EcibRoxbo11;
import in.ecgc.smile.erp.reporting.jasper.be.model.ecib.EcibRoxbo12;
import in.ecgc.smile.erp.reporting.jasper.be.model.ecib.EcibWtUR63;
import in.ecgc.smile.erp.reporting.jasper.be.model.ecib.EcibWtUR64;

public interface EcibDao {

	List<EcibRoxbo11> getListOfCoverTypeExporterMoreThan100Cr(int FromYear, int FromMonth, int ToYear, int ToMonth);
	
	List<EcibInUR04> getListOfInCoverIssueRegister(String fromDate, String toDate, String coverType);

	List<EcibRoxbo12> getListOfExporterMoreThan100Cr(int FromYear, int FromMonth, int ToYear, int ToMonth);
	
	List<EcibInUR16> getListEcibCoverAdjustedDeclaration(int fromYear, int fromMonth, int toYear, int toMonth);
	
	List<EcibWtUR63> getListBankwiseRvPremiumReport(int fromYear, int fromMonth, int toYear, int toMonth);
	
	List<EcibWtUR63> getListEcibTypewise(int fromYear, int fromMonth, int toYear, int toMonth);
	
	List<EcibWtUR63> getListBankwise(int fromYear, int fromMonth, int toYear, int toMonth);
	
	List<EcibWtUR64> getListEcgcBranchwisePremiumEarned(int fromYear, int fromMonth, int toYear, int toMonth);

	List<EcibWtUR64> getListEcibTypewise1(int fromYear, int fromMonth, int toYear, int toMonth);
	
	List<EcibWtUR64> getListBankwise1(int fromYear, int fromMonth, int toYear, int toMonth);

	public List<String> getAllPolicyTypes()throws DataAccessException;

	public List<String> getyear() throws DataAccessException;
	
	public List<String> getmonth() throws DataAccessException;

}
