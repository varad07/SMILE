package in.ecgc.smile.erp.reporting.jasper.be.repository.ecib;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcOperations;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import in.ecgc.smile.erp.reporting.jasper.be.model.ecib.EcibInUR04;
import in.ecgc.smile.erp.reporting.jasper.be.model.ecib.EcibInUR16;
import in.ecgc.smile.erp.reporting.jasper.be.model.ecib.EcibRoxbo11;
import in.ecgc.smile.erp.reporting.jasper.be.model.ecib.EcibRoxbo12;
import in.ecgc.smile.erp.reporting.jasper.be.model.ecib.EcibWtUR63;
import in.ecgc.smile.erp.reporting.jasper.be.model.ecib.EcibWtUR64;
import in.ecgc.smile.erp.reporting.jasper.be.utils.bud.BudQueries;
import in.ecgc.smile.erp.reporting.jasper.be.utils.ecib.EcibQueries;

@Repository
public class EcibDaoImpl implements EcibDao{
	
	
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	private JdbcOperations jdbcOperations;
	private static final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(EcibDaoImpl.class);
	
	public EcibDaoImpl(DataSource dataSource) {
		super();
		jdbcOperations = new JdbcTemplate(dataSource);
		namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(dataSource);
	}

	

	@Override
	public List<EcibRoxbo11> getListOfCoverTypeExporterMoreThan100Cr(int FromYear, int FromMonth, int ToYear,
			int ToMonth) {
		
    String sql = EcibQueries.GET_ECIB_ROXBO_R11;
		
/* SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd"); */
		
/*
 * Integer fromYr = null; Integer fromMonth = null; Integer toYr = null; Integer
 * toMonth = null;
 * 
 * try { fromYr = sdf.parse(fromDate); toDt = sdf.parse(toDate); } catch
 * (ParseException e) { // TODO Auto-generated catch block e.printStackTrace();
 * }
 */
		
		MapSqlParameterSource param = new MapSqlParameterSource();
		param.addValue("FromYear", FromYear);
		param.addValue("FromMonth", FromMonth);
		param.addValue("ToYear", ToYear);
		param.addValue("ToMonth", ToMonth);
		
		List<EcibRoxbo11> result;
		try {
			result = namedParameterJdbcTemplate.query(sql, param, new EcibRoxbo11ModelRowMapper());
			if(result!=null) {
				return result;
			}
			else {
				return null;
			}
		} catch (DataAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<EcibInUR04> getListOfInCoverIssueRegister(String fromDate, String toDate, String coverType) {
		// TODO Auto-generated method stub
		
		
	String sql = EcibQueries.GET_ECIB_IN_U_R04;
	
	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	
	Date fromDt = null;
	Date toDt = null;
	
	try {
		fromDt = sdf.parse(fromDate);
		toDt = sdf.parse(toDate);
	} catch (ParseException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		
	
	MapSqlParameterSource param = new MapSqlParameterSource();
	param.addValue("fromDate", fromDt);
	param.addValue("toDate", toDt);
	param.addValue("coverType", coverType);

	List<EcibInUR04> result;
	try {
		result = namedParameterJdbcTemplate.query(sql, param, new EcibInUR04ModelRowMapper());
		if(result!=null) {
			return result;
		}
		else {
			return null;
		}
	} catch (DataAccessException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	// TODO Auto-generated method stub
	return null;
	
			}
	
	



	@Override
	public List<EcibRoxbo12> getListOfExporterMoreThan100Cr(int FromYear, int FromMonth, int ToYear, int ToMonth) {
		String sql = EcibQueries.GET_ECIB_ROXBO_R12;
		
		
				
				MapSqlParameterSource param = new MapSqlParameterSource();
				param.addValue("FromYear", FromYear);
				param.addValue("FromMonth", FromMonth);
				param.addValue("ToYear", ToYear);
				param.addValue("ToMonth", ToMonth);
				
				List<EcibRoxbo12> result;
				try {
					result = namedParameterJdbcTemplate.query(sql, param, new EcibRoxbo12ModelRowMapper());
					if(result!=null) {
						return result;
					}
					else {
						return null;
					}
				} catch (DataAccessException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				// TODO Auto-generated method stub
				return null;
	}
	
	
	@Override
	public List<EcibInUR16> getListEcibCoverAdjustedDeclaration(int fromYear, int fromMonth, int toYear,
			int toMonth) {
		
             String sql = EcibQueries.GET_ECIB_IN_U_R16;
		
		
		MapSqlParameterSource param = new MapSqlParameterSource();
		param.addValue("fromYear", fromYear);
		param.addValue("fromMonth", fromMonth);
		param.addValue("toYear", toYear);
		param.addValue("toMonth", toMonth);
		
		List<EcibInUR16> result;
		try {
			result = namedParameterJdbcTemplate.query(sql, param, new EcibInUR16ModelRowMapper());
			if(result!=null) {
				return result;
			}
			else {
				return null;
			}
		} catch (DataAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// TODO Auto-generated method stub
		return null;
	}
	
	
	@Override
	public List<EcibWtUR63> getListBankwiseRvPremiumReport(int fromYear, int fromMonth, int toYear,
			int toMonth) {
		
             String sql = EcibQueries.GET_ECIB_WT_U_R63;
		
		
		MapSqlParameterSource param = new MapSqlParameterSource();
		param.addValue("fromYear", fromYear);
		param.addValue("fromMonth", fromMonth);
		param.addValue("toYear", toYear);
		param.addValue("toMonth", toMonth);
		
		List<EcibWtUR63> result;
		try {
			result = namedParameterJdbcTemplate.query(sql, param, new EcibWtUR63ModelRowMapper());
			if(result!=null) {
				return result;
			}
			else {
				return null;
			}
		} catch (DataAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// TODO Auto-generated method stub
		return null;
	}
	
	
	@Override
	public List<EcibWtUR63> getListEcibTypewise(int fromYear, int fromMonth, int toYear,
			int toMonth) {
		
             String sql = EcibQueries.GET_ECIB_TYPEWISE;
		
		
		MapSqlParameterSource param = new MapSqlParameterSource();
		param.addValue("fromYear", fromYear);
		param.addValue("fromMonth", fromMonth);
		param.addValue("toYear", toYear);
		param.addValue("toMonth", toMonth);
		
		List<EcibWtUR63> result;
		try {
			result = namedParameterJdbcTemplate.query(sql, param, new EcibWtUR63ModelRowMapper1());
			if(result!=null) {
				return result;
			}
			else {
				return null;
			}
		} catch (DataAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
		// TODO Auto-generated method stub
		return null;
	}
	
	
	@Override
	public List<EcibWtUR63> getListBankwise(int fromYear, int fromMonth, int toYear,
			int toMonth) {
		
             String sql = EcibQueries.GET_ECIB_BANKWISE;
		
		
		MapSqlParameterSource param = new MapSqlParameterSource();
		param.addValue("fromYear", fromYear);
		param.addValue("fromMonth", fromMonth);
		param.addValue("toYear", toYear);
		param.addValue("toMonth", toMonth);
		
		List<EcibWtUR63> result;
		try {
			result = namedParameterJdbcTemplate.query(sql, param, new EcibWtUR63ModelRowMapper2());
			if(result!=null) {
				return result;
			}
			else {
				return null;
			}
		} catch (DataAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.info("heree");
		}
		// TODO Auto-generated method stub
		return null;
	}
	
	
	@Override
	public List<EcibWtUR64> getListEcgcBranchwisePremiumEarned(int fromYear, int fromMonth, int toYear,
			int toMonth) {
		
             String sql = EcibQueries.GET_ECIB_WT_U_R64;
		
		
		MapSqlParameterSource param = new MapSqlParameterSource();
		param.addValue("fromYear", fromYear);
		param.addValue("fromMonth", fromMonth);
		param.addValue("toYear", toYear);
		param.addValue("toMonth", toMonth);
		
		List<EcibWtUR64> result;
		try {
			result = namedParameterJdbcTemplate.query(sql, param, new EcibWtUR64ModelRowMapper());
			if(result!=null) {
				return result;
			}
			else {
				return null;
			}
		} catch (DataAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public List<EcibWtUR64> getListEcibTypewise1(int fromYear, int fromMonth, int toYear,
			int toMonth) {
		
             String sql = EcibQueries.GET_ECIB_TYPEWISE1;
		
		
		MapSqlParameterSource param = new MapSqlParameterSource();
		param.addValue("fromYear", fromYear);
		param.addValue("fromMonth", fromMonth);
		param.addValue("toYear", toYear);
		param.addValue("toMonth", toMonth);
		
		List<EcibWtUR64> result;
		try {
			result = namedParameterJdbcTemplate.query(sql, param, new EcibWtUR64ModelRowMapper1());
			if(result!=null) {
				return result;
			}
			else {
				return null;
			}
		} catch (DataAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
		// TODO Auto-generated method stub
		return null;
	}
	
	
	@Override
	public List<EcibWtUR64> getListBankwise1(int fromYear, int fromMonth, int toYear,
			int toMonth) {
		
             String sql = EcibQueries.GET_ECIB_BANKWISE1;
		
		
		MapSqlParameterSource param = new MapSqlParameterSource();
		param.addValue("fromYear", fromYear);
		param.addValue("fromMonth", fromMonth);
		param.addValue("toYear", toYear);
		param.addValue("toMonth", toMonth);
		
		List<EcibWtUR64> result;
		try {
			result = namedParameterJdbcTemplate.query(sql, param, new EcibWtUR64ModelRowMapper2());
			if(result!=null) {
				return result;
			}
			else {
				return null;
			}
		} catch (DataAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.info("heree");
		}
		// TODO Auto-generated method stub
		return null;
	}
	

	class EcibRoxbo11ModelRowMapper implements RowMapper<EcibRoxbo11> {
		
		@Override
		public EcibRoxbo11 mapRow(ResultSet rs, int rowNum) throws SQLException {
			EcibRoxbo11 ecibRoxbo11 = new EcibRoxbo11();
			
			ecibRoxbo11.setBank_code(rs.getString("Bank_code"));
			ecibRoxbo11.setCover_type(rs.getString("cover_type"));
			ecibRoxbo11.setExpoter_code(rs.getString("expoter_code"));
			ecibRoxbo11.setCalculated_adp(rs.getBigDecimal("calculated_adp"));
			ecibRoxbo11.setCalculated_adp_inr(rs.getString("calculated_adp_inr"));
			ecibRoxbo11.setMonth(rs.getBigDecimal("month"));
			ecibRoxbo11.setYear(rs.getBigDecimal("year"));
			
		
			return ecibRoxbo11;
		}	
		
	
	}
	
			
			class EcibInUR04ModelRowMapper implements RowMapper<EcibInUR04> {
				
				@Override
				public EcibInUR04 mapRow(ResultSet rs, int rowNum) throws SQLException {
					EcibInUR04 ecibInUR04 = new EcibInUR04();
					
					ecibInUR04.setCoverNumber(rs.getString("coverNumber"));
					ecibInUR04.setFreshRenewal(rs.getString("freshRenewal"));
					ecibInUR04.setBankBranchName(rs.getString("bankBranchName"));
					ecibInUR04.setExporterName(rs.getString("exporterName"));
					ecibInUR04.setEcibCoverValue(rs.getBigDecimal("ecibCoverValue"));
					ecibInUR04.setCoverPeriod(rs.getString("coverPeriod"));
					ecibInUR04.setPercentageOfCover(rs.getBigDecimal("percentageOfCover"));
					ecibInUR04.setPremiumRate(rs.getBigDecimal("premiumRate"));
					ecibInUR04.setLcCoverForShipOnly(rs.getBoolean("lcCoverForShipOnly"));
					ecibInUR04.setLcCoverShipAssociate(rs.getBoolean("lcCoverShipAssociate"));
					ecibInUR04.setNursingEcibCover(rs.getBoolean("nursingEcibCover"));
					ecibInUR04.setBalAsDpInAcc(rs.getBigDecimal("balAsDpInAcc"));
					ecibInUR04.setRemarks(rs.getString("remarks"));
					
					return ecibInUR04;
				}	
				
	}
	
			
		
		class EcibRoxbo12ModelRowMapper implements RowMapper<EcibRoxbo12> {
			
			@Override
			public EcibRoxbo12 mapRow(ResultSet rs, int rowNum) throws SQLException {
				EcibRoxbo12 ecibRoxbo12 = new EcibRoxbo12();
				
				ecibRoxbo12.setExpoter_code(rs.getString("expoter_code"));
				ecibRoxbo12.setCalculated_adp(rs.getBigDecimal("calculated_adp"));
				ecibRoxbo12.setCalculated_adp_inr(rs.getString("calculated_adp_inr"));
				ecibRoxbo12.setMonth(rs.getBigDecimal("month"));
				ecibRoxbo12.setYear(rs.getBigDecimal("year"));
					
				return ecibRoxbo12;
		
		}
		}
			
			 class EcibInUR16ModelRowMapper implements RowMapper<EcibInUR16> {
				
				@Override
				public  EcibInUR16 mapRow(ResultSet rs, int rowNum) throws SQLException {
					EcibInUR16 ecibInUR16 = new EcibInUR16();
					
					ecibInUR16.setCoverNumber(rs.getString("coverNumber"));  
					ecibInUR16.setCoverType(rs.getString("coverType"));
					ecibInUR16.setBankName(rs.getString("bankName"));
					ecibInUR16.setBankBranchName(rs.getString("bankBranchName"));
					ecibInUR16.setExporterName(rs.getString("exporterName"));
					ecibInUR16.setRiskValue(rs.getBigDecimal("riskValue"));
					ecibInUR16.setPremiumAdjusted(rs.getBigDecimal("premiumAdjusted"));
					ecibInUR16.setYear(rs.getInt("year"));
					ecibInUR16.setMonth(rs.getInt("month"));
					
					
				return ecibInUR16;
	
			}	

		}
			 
			 
			 class EcibWtUR63ModelRowMapper implements RowMapper<EcibWtUR63> {
					
					@Override
					public  EcibWtUR63 mapRow(ResultSet rs, int rowNum) throws SQLException {
						EcibWtUR63 ecibWtUR63 = new EcibWtUR63();
						
						ecibWtUR63.setEcibType(rs.getString("ecibType"));
						ecibWtUR63.setBankName(rs.getString("bankName"));
						ecibWtUR63.setRiskValue(rs.getBigDecimal("riskValue"));
						ecibWtUR63.setPremiumEarned(rs.getBigDecimal("premiumEarned"));
						
						
					return ecibWtUR63;
		
				}	
					
				
			}	
			 
			 
			 class EcibWtUR63ModelRowMapper1 implements RowMapper<EcibWtUR63> {
					
					@Override
					public  EcibWtUR63 mapRow(ResultSet rs, int rowNum) throws SQLException {
						EcibWtUR63 ecibWtUR63 = new EcibWtUR63();
						
						ecibWtUR63.setEcibType(rs.getString("ecibType"));
						ecibWtUR63.setRiskValue(rs.getBigDecimal("riskValue"));
						ecibWtUR63.setPremiumEarned(rs.getBigDecimal("premiumEarned"));
						
						
					return ecibWtUR63;
		
				}	
					
				
			}
			 
			 class EcibWtUR63ModelRowMapper2 implements RowMapper<EcibWtUR63> {
					
					@Override
					public  EcibWtUR63 mapRow(ResultSet rs, int rowNum) throws SQLException {
						EcibWtUR63 ecibWtUR63 = new EcibWtUR63();
						
						
						ecibWtUR63.setBankName(rs.getString("bankName"));
						ecibWtUR63.setRiskValue(rs.getBigDecimal("riskValue"));
						ecibWtUR63.setPremiumEarned(rs.getBigDecimal("premiumEarned"));
						
						
					return ecibWtUR63;
		
				}	
					
				
			}

			 class EcibWtUR64ModelRowMapper implements RowMapper<EcibWtUR64> {
					
					@Override
					public  EcibWtUR64 mapRow(ResultSet rs, int rowNum) throws SQLException {
						EcibWtUR64 ecibWtUR64 = new EcibWtUR64();
						
						ecibWtUR64.setEcibType(rs.getString("ecibType"));
						ecibWtUR64.setEcgcBranchName(rs.getString("ecgcBranchName"));
						ecibWtUR64.setRiskValue(rs.getBigDecimal("riskValue"));
						ecibWtUR64.setPremiumEarned(rs.getBigDecimal("premiumEarned"));
						
						
					return ecibWtUR64;
		
				}	
					
				
			}
			 
			 class EcibWtUR64ModelRowMapper1 implements RowMapper<EcibWtUR64> {
					
					@Override
					public  EcibWtUR64 mapRow(ResultSet rs, int rowNum) throws SQLException {
						EcibWtUR64 ecibWtUR64 = new EcibWtUR64();
						
						ecibWtUR64.setEcibType(rs.getString("ecibType"));
						ecibWtUR64.setRiskValue(rs.getBigDecimal("riskValue"));
						ecibWtUR64.setPremiumEarned(rs.getBigDecimal("premiumEarned"));
						
						
					return ecibWtUR64;
		
				}	
					
				
			}
			 
			 class EcibWtUR64ModelRowMapper2 implements RowMapper<EcibWtUR64> {
					
					@Override
					public  EcibWtUR64 mapRow(ResultSet rs, int rowNum) throws SQLException {
						EcibWtUR64 ecibWtUR64 = new EcibWtUR64();
						
						
						ecibWtUR64.setBankName(rs.getString("bankName"));
						ecibWtUR64.setRiskValue(rs.getBigDecimal("riskValue"));
						ecibWtUR64.setPremiumEarned(rs.getBigDecimal("premiumEarned"));
						
						
					return ecibWtUR64;
		
				}	
						
			}

			@Override
			public List<String> getAllPolicyTypes() throws DataAccessException {
				final String query = EcibQueries.GET_ALL_COVER_TYPES;

				try {
					return namedParameterJdbcTemplate.queryForList(query, new MapSqlParameterSource(), String.class);
				} catch (DataAccessException e) {
					e.printStackTrace();
					throw e;
				}
			}



			@Override
			public List<String> getyear() throws DataAccessException {
				final String query = EcibQueries.GET_YEAR;

				try {
					return namedParameterJdbcTemplate.queryForList(query, new MapSqlParameterSource(), String.class);
				} catch (DataAccessException e) {
					e.printStackTrace();
					throw e;
				}
			}



			@Override
			public List<String> getmonth() throws DataAccessException {
				final String query = EcibQueries.GET_MONTH;

				try {
					return namedParameterJdbcTemplate.queryForList(query, new MapSqlParameterSource(), String.class);
				} catch (DataAccessException e) {
					e.printStackTrace();
					throw e;
				}
			}
			 		
}		
