package in.ecgc.smile.erp.reporting.jasper.be.repository.bud;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import in.ecgc.smile.erp.reporting.jasper.be.model.bud.BudR02;
import in.ecgc.smile.erp.reporting.jasper.be.model.bud.BudR04_1;
import in.ecgc.smile.erp.reporting.jasper.be.model.bud.BudR04_2;
import in.ecgc.smile.erp.reporting.jasper.be.model.bud.BudR09;
import in.ecgc.smile.erp.reporting.jasper.be.model.bud.BudR16;
import in.ecgc.smile.erp.reporting.jasper.be.model.bud.BudR17;
import in.ecgc.smile.erp.reporting.jasper.be.model.bud.BudR18;
import in.ecgc.smile.erp.reporting.jasper.be.model.bud.BudR20;
import in.ecgc.smile.erp.reporting.jasper.be.model.bud.BudR21;
import in.ecgc.smile.erp.reporting.jasper.be.model.bud.BudR23;
import in.ecgc.smile.erp.reporting.jasper.be.model.bud.BudR40;
import in.ecgc.smile.erp.reporting.jasper.be.model.bud.BudR48_1;
import in.ecgc.smile.erp.reporting.jasper.be.model.bud.BudR48_2;
import in.ecgc.smile.erp.reporting.jasper.be.model.bud.BudR49;
import in.ecgc.smile.erp.reporting.jasper.be.model.bud.BudR49_1;
import in.ecgc.smile.erp.reporting.jasper.be.utils.bud.BudQueries;
import in.ecgc.smile.erp.reporting.jasper.be.utils.bud.BudQuery;

@Repository
public class BudDaoImpl implements BudDao {

	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	private static final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(BudDaoImpl.class);

	public BudDaoImpl(DataSource dataSource) {
		super();
		namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(dataSource);
	}

	@Override
	public List<BudR21> getListBudR21(String lastUpdatedDateFrom, String lastUpdatedDateTo) {
		// TODO Auto-generated method stub

		String sql = BudQueries.GET_BUDR21;

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

		Date fromDt = null;
		Date toDt = null;

		try {
			fromDt = sdf.parse(lastUpdatedDateFrom);
			toDt = sdf.parse(lastUpdatedDateTo);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		MapSqlParameterSource param = new MapSqlParameterSource();
		param.addValue("last_updated_date_from", fromDt);
		param.addValue("last_updated_date_to", toDt);

		List<BudR21> result;
		try {

			result = namedParameterJdbcTemplate.query(sql, param, new BudR21RowMapper());
			if (result != null) {
				return result;
			} else {
				return null;
			}
		} catch (DataAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	class BudR21RowMapper implements RowMapper<BudR21> {
		@Override
		public BudR21 mapRow(ResultSet rs, int rowNum) throws SQLException {
			BudR21 budR21 = new BudR21();

			budR21.setTerms_of_Payment(rs.getString("terms_of_Payment"));
			budR21.setCountry(rs.getString("country"));
			budR21.setCell_No(rs.getString("cell_No"));
			budR21.setClaim_Paid(rs.getBigDecimal("claim_Paid"));

			return budR21;
		}
	}

	@Override
	public List<BudR49> getListBudR49(String fromDate, String toDate) {
		// TODO Auto-generated method stub

		String sql = BudQueries.GET_BUDR49;
		String sql1 = BudQueries.GET_BUDR49_1;

		logger.info("In Dao ::>> from date ::  " + fromDate + ",  to date ::  " + toDate);

		String fromDt = null;
		String toDt = null;
		try {
			// The input date
			LocalDate fromDate1 = LocalDate.parse(fromDate);
			LocalDate toDate1 = LocalDate.parse(toDate);

			// Create a DateTimeFormatter with the desired format
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");

			// Format the date to a string
			fromDt = fromDate1.format(formatter);
			toDt = toDate1.format(formatter);

		} catch (Exception e) {
			logger.info("In Dao ::>> Error");
		}

		logger.info("In Dao ::>> fromDt ::  " + fromDt + ",  toDate ::  " + toDt);

		MapSqlParameterSource param = new MapSqlParameterSource();
		param.addValue("date_from", fromDt);
		param.addValue("date_to", toDt);

		List<BudR49> result;
		List<BudR49_1> result1;
		try {

			result = namedParameterJdbcTemplate.query(sql, param, new BudR49RowMapper());
			result1 = namedParameterJdbcTemplate.query(sql1, param, new BudR49_1RowMapper());

			logger.info("result ::>>  " + result + ",  result1 ::  " + result1);
			logger.info("sql ::>>  " + sql + ",  sql1 ::  " + sql1);

			if (result != null) {
				return result;
			} else {
				return null;
			}
		} catch (DataAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<BudR49_1> getListBudR49_1(String fromDate, String toDate) {
		// TODO Auto-generated method stub

		String sql = BudQueries.GET_BUDR49_1;

		logger.info("In Dao ::>> from date ::  " + fromDate + ",  to date ::  " + toDate);

		String fromDt = null;
		String toDt = null;
		try {
			// The input date
			LocalDate fromDate1 = LocalDate.parse(fromDate);
			LocalDate toDate1 = LocalDate.parse(toDate);

			// Create a DateTimeFormatter with the desired format
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");

			// Format the date to a string
			fromDt = fromDate1.format(formatter);
			toDt = toDate1.format(formatter);

		} catch (Exception e) {
			logger.info("In Dao ::>> Error");
		}

		logger.info("In Dao ::>> fromDt ::  " + fromDt + ",  toDate ::  " + toDt);

		MapSqlParameterSource param = new MapSqlParameterSource();
		param.addValue("date_from", fromDt);
		param.addValue("date_to", toDt);

		List<BudR49_1> result;
		try {

			result = namedParameterJdbcTemplate.query(sql, param, new BudR49_1RowMapper());

			logger.info("result ::>>  " + result + ",  result1 ::  " + result);
			// logger.info("mergedList ::>> " + mergedList);

			if (result != null) {
				return result;
			} else {
				return null;
			}
		} catch (DataAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<BudR02> getListBudR02(String fromDate, String toDate) {
		// TODO Auto-generated method stub

		String sql = BudQueries.GET_BUDR02;

		logger.info("In Dao ::>> from date ::  " + fromDate + ",  to date ::  " + toDate);

		String fromDt = null;
		String toDt = null;
		try {
			// The input date
			LocalDate fromDate1 = LocalDate.parse(fromDate);
			LocalDate toDate1 = LocalDate.parse(toDate);

			// Create a DateTimeFormatter with the desired format
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");

			// Format the date to a string
			fromDt = fromDate1.format(formatter);
			toDt = toDate1.format(formatter);

		} catch (Exception e) {
			logger.info("In Dao ::>> Error");
		}

		logger.info("In Dao ::>> fromDt ::  " + fromDt + ",  toDate ::  " + toDt);

		MapSqlParameterSource param = new MapSqlParameterSource();
		param.addValue("date_from", fromDt);
		param.addValue("date_to", toDt);

		List<BudR02> result;
		try {
			result = namedParameterJdbcTemplate.query(sql, param, new BudR02RowMapper());
			if (result != null) {
				return result;
			} else {
				return null;
			}
		} catch (DataAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<BudR16> getListBudR16(String fromDate, String toDate) {
		// TODO Auto-generated method stub

		String sql = BudQueries.GET_BUDR16;

		logger.info("In Dao ::>> from date ::  " + fromDate + ",  to date ::  " + toDate);

		// String fromDt = null;
		// String toDt = null;
		// try{
		// // The input date
		// LocalDate fromDate1 = LocalDate.parse(fromDate);
		// LocalDate toDate1 = LocalDate.parse(toDate);
		//
		// // Create a DateTimeFormatter with the desired format
		// DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		//
		// // Format the date to a string
		// fromDt = fromDate1.format(formatter);
		// toDt = toDate1.format(formatter);
		//
		// }catch(Exception e) {
		// logger.info("In Dao ::>> Error" );
		// }

		MapSqlParameterSource param = new MapSqlParameterSource();
		param.addValue("date_from", fromDate);
		param.addValue("date_to", toDate);

		List<BudR16> result;
		try {
			result = namedParameterJdbcTemplate.query(sql, param, new BudR16RowMapper());
			logger.info("sql  ::: >>> " + sql);
			if (result != null) {
				return result;
			} else {
				return null;
			}
		} catch (DataAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<BudR17> getListBudR17(String fromDate, String toDate) {
		// TODO Auto-generated method stub

		String sql = BudQueries.GET_BUDR17;

		logger.info("In Dao ::>> from date ::  " + fromDate + ",  to date ::  " + toDate);

		// String fromDt = null;
		// String toDt = null;
		// try{
		// // The input date
		// LocalDate fromDate1 = LocalDate.parse(fromDate);
		// LocalDate toDate1 = LocalDate.parse(toDate);
		//
		// // Create a DateTimeFormatter with the desired format
		// DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		//
		// // Format the date to a string
		// fromDt = fromDate1.format(formatter);
		// toDt = toDate1.format(formatter);
		//
		// }catch(Exception e) {
		// logger.info("In Dao ::>> Error" );
		// }
		//
		// logger.info("In Dao ::>> fromDt :: " + fromDt + ", toDate :: " + toDt);

		MapSqlParameterSource param = new MapSqlParameterSource();
		param.addValue("date_from", fromDate);
		param.addValue("date_to", toDate);

		List<BudR17> result;
		try {
			result = namedParameterJdbcTemplate.query(sql, param, new BudR17RowMapper());
			logger.info("result ::  " + result);
			if (result != null) {
				return result;
			} else {
				return null;
			}
		} catch (DataAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<BudR18> getListBudR18(String fromDate, String toDate) {
		// TODO Auto-generated method stub

		String sql = BudQueries.GET_BUDR18;

		logger.info("In Dao ::>> from date ::  " + fromDate + ",  to date ::  " + toDate);

		String fromDt = null;
		String toDt = null;
		try {
			// The input date
			LocalDate fromDate1 = LocalDate.parse(fromDate);
			LocalDate toDate1 = LocalDate.parse(toDate);

			// Create a DateTimeFormatter with the desired format
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");

			// Format the date to a string
			fromDt = fromDate1.format(formatter);
			toDt = toDate1.format(formatter);

		} catch (Exception e) {
			logger.info("In Dao ::>> Error");
		}

		logger.info("In Dao ::>> fromDt ::  " + fromDt + ",  toDt ::  " + toDt);

		MapSqlParameterSource param = new MapSqlParameterSource();
		param.addValue("date_from", fromDt);
		param.addValue("date_to", toDt);

		List<BudR18> result;
		try {
			result = namedParameterJdbcTemplate.query(sql, param, new BudR18RowMapper());
			if (result != null) {
				logger.info("result" + result);
				return result;
			} else {
				logger.info("Result is null");
				return null;
			}
		} catch (DataAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return null;
	}

	@Override
	public List<BudR18> getListBudR18_1(String fromDate, String toDate) {
		// TODO Auto-generated method stub

		String sql = BudQueries.GET_BUDR18_1;

		logger.info("In Dao ::>> from date ::  " + fromDate + ",  to date ::  " + toDate);

		String fromDt = null;
		String toDt = null;
		try {
			// The input date
			LocalDate fromDate1 = LocalDate.parse(fromDate);
			LocalDate toDate1 = LocalDate.parse(toDate);

			// Create a DateTimeFormatter with the desired format
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");

			// Format the date to a string
			fromDt = fromDate1.format(formatter);
			toDt = toDate1.format(formatter);

		} catch (Exception e) {
			logger.info("In Dao ::>> Error");
		}

		logger.info("In Dao ::>> fromDt ::  " + fromDt + ",  toDt ::  " + toDt);

		MapSqlParameterSource param = new MapSqlParameterSource();
		param.addValue("date_from", fromDt);
		param.addValue("date_to", toDt);

		List<BudR18> result;
		try {
			result = namedParameterJdbcTemplate.query(sql, param, new BudR18RowMapper1());
			logger.info("result_1" + result);
			if (result != null) {
				return result;
			} else {
				logger.info("Result is null");
				return null;
			}
		} catch (DataAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return null;
	}

	@Override
	public List<BudR20> getListBudR20(String fromDate, String toDate) {
		// TODO Auto-generated method stub

		String sql = BudQueries.GET_BUDR20;

		logger.info("In Dao ::>> from date ::  " + fromDate + ",  to date ::  " + toDate);

		// String fromDt = null;
		// String toDt = null;
		// try{
		// // The input date
		// LocalDate fromDate1 = LocalDate.parse(fromDate);
		// LocalDate toDate1 = LocalDate.parse(toDate);
		//
		// // Create a DateTimeFormatter with the desired format
		// DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		//
		// // Format the date to a string
		// fromDt = fromDate1.format(formatter);
		// toDt = toDate1.format(formatter);

		// }catch(Exception e) {
		// logger.info("In Dao ::>> Error" );
		// }

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

		Date fromDt = null;
		Date toDt = null;

		try {
			fromDt = sdf.parse(fromDate);
			toDt = sdf.parse(toDate);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		logger.info("In Dao ::>> fromDt ::  " + fromDt + ",  toDt ::  " + toDt);

		MapSqlParameterSource param = new MapSqlParameterSource();
		param.addValue("date_from", fromDt);
		param.addValue("date_to", toDt);

		List<BudR20> result;
		try {
			result = namedParameterJdbcTemplate.query(sql, param, new BudR20RowMapper());
			if (result != null) {
				// logger.info("result"+ result);
				return result;
			} else {
				logger.info("Result is null");
				return null;
			}
		} catch (DataAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return null;
	}

	@Override
	public List<BudR20> getListBudR20_1(String fromDate, String toDate) {
		// TODO Auto-generated method stub

		String sql = BudQueries.GET_BUDR20_1;

		logger.info("Query :" + sql);

		logger.info("In Dao ::>> from date ::  " + fromDate + ",  to date ::  " + toDate);

		// String fromDt = null;
		// String toDt = null;
		// try{
		// // The input date
		// LocalDate fromDate1 = LocalDate.parse(fromDate);
		// LocalDate toDate1 = LocalDate.parse(toDate);
		//
		// // Create a DateTimeFormatter with the desired format
		// DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		//
		// // Format the date to a string
		// fromDt = fromDate1.format(formatter);
		// toDt = toDate1.format(formatter);
		//
		// }catch(Exception e) {
		// logger.info("In Dao ::>> Error" );
		// }

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

		Date fromDt = null;
		Date toDt = null;

		try {
			fromDt = sdf.parse(fromDate);
			toDt = sdf.parse(toDate);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		logger.info("In Dao ::>> fromDt ::  " + fromDt + ",  toDt ::  " + toDt);

		MapSqlParameterSource param = new MapSqlParameterSource();
		param.addValue("date_from", fromDt);
		param.addValue("date_to", toDt);

		List<BudR20> result;
		try {
			result = namedParameterJdbcTemplate.query(sql, param, new BudR20RowMapper1());
			// logger.info("result_1"+ result);
			if (result != null) {
				return result;
			} else {
				logger.info("Result is null");
				return null;
			}
		} catch (DataAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return null;
	}

	public List<BudR23> getListBudR23(String fromDate, String toDate, String claType) {
		// TODO Auto-generated method stub

		String sql = BudQueries.GET_BUDR23;

		logger.info(
				"In Dao ::>> from date ::  " + fromDate + ",  to date ::  " + toDate + ",  claType1 ::  " + claType);

		String[] parts = claType.split("_");

		String claType1 = "";
		String claType2 = "";

		for (int i = 0; i < parts.length; i++) {
			if (i == 0) {
				claType1 = parts[i];
				logger.info(" i ::  " + i);
			}
			if (i == 1) {
				claType2 = parts[i];
				logger.info(" i ::  " + i);
			}
			logger.info(" parts ::  " + parts[i] + ", [" + i + "]");
		}

		logger.info(" claType1 ::  " + claType1 + ", claType2 ::  " + claType2);

		String fromDt = null;
		String toDt = null;
		try {
			// The input date
			LocalDate fromDate1 = LocalDate.parse(fromDate);
			LocalDate toDate1 = LocalDate.parse(toDate);

			// Create a DateTimeFormatter with the desired format
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

			// Format the date to a string
			fromDt = fromDate1.format(formatter);
			toDt = toDate1.format(formatter);

		} catch (Exception e) {
			logger.info("In Dao ::>> Error");
		}

		logger.info("In Dao ::>> fromDt ::  " + fromDt + ",  toDt ::  " + toDt);

		// logger.info("sql >>>>> " + sql);

		MapSqlParameterSource param = new MapSqlParameterSource();
		param.addValue("fromDt", fromDt);
		param.addValue("toDt", toDt);
		param.addValue("claType1", claType1);
		param.addValue("claType2", claType2);

		List<BudR23> result;
		try {
			result = namedParameterJdbcTemplate.query(sql, param, new BudR23RowMapper());
			if (result != null) {
				return result;
			} else {
				return null;
			}
		} catch (DataAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<BudR09> getListBudR09(String fromDate, String toDate, String reportStatus) {
		// TODO Auto-generated method stub

		String sql = BudQueries.GET_BUDR09_a;
		String sql1 = BudQueries.GET_BUDR09_b;

		logger.info("In Dao ::>> from date ::  " + fromDate + ",  to date ::  " + toDate + ",  reportStatus ::  "
				+ reportStatus);

		String fromDt = null;
		String toDt = null;
		try {
			// The input date
			LocalDate fromDate1 = LocalDate.parse(fromDate);
			LocalDate toDate1 = LocalDate.parse(toDate);

			// Create a DateTimeFormatter with the desired format
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

			// Format the date to a string
			fromDt = fromDate1.format(formatter);
			toDt = toDate1.format(formatter);

		} catch (Exception e) {
			logger.info("In Dao ::>> Error");
		}

		logger.info("In Dao ::>> frDt ::  " + fromDt + ",  toDt ::  " + toDt + ",  reportStatus ::  " + reportStatus);

		MapSqlParameterSource param = new MapSqlParameterSource();
		param.addValue("date_from", fromDt);
		param.addValue("date_to", toDt);
		param.addValue("reportStatus", reportStatus);

		List<BudR09> result;
		try {
			if (reportStatus.equals("RECD_BYR")) {
				result = namedParameterJdbcTemplate.query(sql1, param, new BudR09RowMapper());
				if (result != null) {
					// logger.info("result :: " + result);
					return result;
				} else {
					return null;
				}
			} else {
				result = namedParameterJdbcTemplate.query(sql, param, new BudR09RowMapper());
				if (result != null) {
					// logger.info("result :: " + result);
					return result;
				} else {
					return null;
				}
			}

		} catch (DataAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<BudR40> getListBudR40(String fromDate, String toDate) {
		String sql = BudQueries.GET_BUDR40_QUERY;
		String procedure1 = BudQueries.GET_BUDR40_CALL;

		logger.info("In Dao ::>> from date ::  " + fromDate + ",  to date ::  " + toDate);

		String fromDt = null;
		String toDt = null;
		try {
			// The input date
			LocalDate fromDate1 = LocalDate.parse(fromDate);
			LocalDate toDate1 = LocalDate.parse(toDate);

			// Create a DateTimeFormatter with the desired format
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");

			// Format the date to a string
			fromDt = fromDate1.format(formatter);
			toDt = toDate1.format(formatter);

		} catch (Exception e) {
			logger.info("In Dao ::>> Error");
		}

		logger.info("In Dao ::>> frDt ::  " + fromDt + ",  toDt ::  " + toDt);

		MapSqlParameterSource param = new MapSqlParameterSource();
		param.addValue("date_from", fromDt);
		param.addValue("date_to", toDt);

		try {

			// Call the stored procedure without expecting results
			namedParameterJdbcTemplate.update(procedure1, param);

			// Execute the SQL query
			List<BudR40> result = namedParameterJdbcTemplate.query(sql, param, new BudR40RowMapper());

			// Check if the result is not null or empty
			if (result != null && !result.isEmpty()) {
				logger.info("Result: " + result);
				return result;
			} else {
				return Collections.emptyList(); // Return an empty list if no results
			}
		} catch (DataAccessException e) {
			e.printStackTrace(); // Log or handle the exception appropriately
			return Collections.emptyList(); // Return an empty list in case of an exception
		}
	}

	@Override
	public List<BudR48_1> getListBudR48_1(String fromDate, String toDate, String reportStatus) {
		// TODO Auto-generated method stub

		String sql = BudQueries.GET_BUDR48_1;

		logger.info("In Dao ::>> from date ::  " + fromDate + ",  to date ::  " + toDate + "reportStatus :: "
				+ reportStatus);

		String fromDt = null;
		String toDt = null;
		try {
			// The input date
			LocalDate fromDate1 = LocalDate.parse(fromDate);
			LocalDate toDate1 = LocalDate.parse(toDate);

			// Create a DateTimeFormatter with the desired format
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

			// Format the date to a string
			fromDt = fromDate1.format(formatter);
			toDt = toDate1.format(formatter);

		} catch (Exception e) {
			logger.info("In Dao ::>> Error");
		}

		logger.info("In Dao ::>> fromDt ::  " + fromDt + ",  toDate ::  " + toDt);

		MapSqlParameterSource param = new MapSqlParameterSource();
		param.addValue("date_from", fromDt);
		param.addValue("date_to", toDt);
		param.addValue("report_status", reportStatus);

		List<BudR48_1> result;
		try {

			result = namedParameterJdbcTemplate.query(sql, param, new BudR48_1RowMapper());

			logger.info("result ::>>  " + result);

			if (result != null) {
				return result;
			} else {
				return null;
			}
		} catch (DataAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<BudR48_2> getListBudR48_2(String fromDate, String toDate, String reportStatus) {
		// TODO Auto-generated method stub

		String sql = BudQueries.GET_BUDR48_2;

		logger.info("In Dao ::>> from date ::  " + fromDate + ",  to date ::  " + toDate + "reportStatus :: "
				+ reportStatus);

		String fromDt = null;
		String toDt = null;
		try {
			// The input date
			LocalDate fromDate1 = LocalDate.parse(fromDate);
			LocalDate toDate1 = LocalDate.parse(toDate);

			// Create a DateTimeFormatter with the desired format
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");

			// Format the date to a string
			fromDt = fromDate1.format(formatter);
			toDt = toDate1.format(formatter);

		} catch (Exception e) {
			logger.info("In Dao ::>> Error");
		}

		logger.info("In Dao ::>> fromDt ::  " + fromDt + ",  toDate ::  " + toDt);

		MapSqlParameterSource param = new MapSqlParameterSource();
		param.addValue("date_from", fromDt);
		param.addValue("date_to", toDt);
		param.addValue("report_status", reportStatus);

		List<BudR48_2> result;
		try {

			result = namedParameterJdbcTemplate.query(sql, param, new BudR48_2RowMapper());

			logger.info("result ::>>  " + result);

			if (result != null) {
				return result;
			} else {
				return null;
			}
		} catch (DataAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	// ------------- RowMappers

	class BudR49RowMapper implements RowMapper<BudR49> {
		@Override
		public BudR49 mapRow(ResultSet rs, int rowNum) throws SQLException {
			BudR49 budR49 = new BudR49();

			budR49.setBranch(rs.getString("branch"));
			budR49.setPolicy_no(rs.getString("policy_no"));
			budR49.setExporter_name(rs.getString("exporter_name"));
			budR49.setBuyer_code(rs.getString("buyer_code"));
			budR49.setBuyer_name(rs.getString("buyer_name"));
			budR49.setCountry(rs.getString("country"));
			budR49.setCell_code(rs.getString("cell_code"));
			budR49.setBuyer_in_default(rs.getString("buyer_in_default"));
			budR49.setOl_status(rs.getString("ol_status"));
			budR49.setClaim_date(rs.getString("claim_date"));
			budR49.setClaim_status(rs.getString("claim_status"));
			budR49.setClaimed_amount(rs.getDouble("claimed_amount"));
			budR49.setClaim_paid_amount(rs.getDouble("claim_paid_amount"));
			budR49.setReason(rs.getString("reason"));

			return budR49;
		}
	}

	class BudR49_1RowMapper implements RowMapper<BudR49_1> {
		@Override
		public BudR49_1 mapRow(ResultSet rs, int rowNum) throws SQLException {
			BudR49_1 budR49 = new BudR49_1();

			budR49.setBranch(rs.getString("branch"));
			budR49.setGurantee_number(rs.getString("gurantee_number"));
			budR49.setClaim_no(rs.getString("claim_no"));
			budR49.setExporter_name(rs.getString("exporter_name"));
			budR49.setBuyer_code(rs.getString("buyer_code"));
			budR49.setBuyer_name(rs.getString("buyer_name"));
			budR49.setCountry(rs.getString("country"));
			budR49.setCell_code(rs.getString("cell_code"));
			budR49.setOl_status(rs.getString("ol_status"));
			budR49.setClm_pref_date(rs.getString("clm_pref_date"));
			budR49.setClm_decision_date(rs.getString("clm_decision_date"));
			budR49.setClaim_status(rs.getString("claim_status"));
			budR49.setClm_paid_amount(rs.getInt("clm_paid_amount"));
			budR49.setClm_pref_amt(rs.getInt("clm_pref_amt"));
			budR49.setRecovered_amt(rs.getInt("recovered_amt"));
			budR49.setClaim_reason(rs.getString("claim_reason"));

			return budR49;
		}
	}

	class BudR02RowMapper implements RowMapper<BudR02> {
		@Override
		public BudR02 mapRow(ResultSet rs, int rowNum) throws SQLException {
			BudR02 budR02 = new BudR02();

			budR02.setCla_no(rs.getString("cla_no"));
			budR02.setBuyer_code(rs.getString("buyer_code"));
			budR02.setBuyer_name(rs.getString("buyer_name"));
			budR02.setPolicy_no(rs.getString("policy_no"));
			budR02.setPolicy_holders_name(rs.getString("policy_holders_name"));
			budR02.setCla_belongs_to(rs.getString("cla_belongs_to"));
			budR02.setCancelled_at(rs.getString("cancelled_at"));
			budR02.setUser_id(rs.getString("user_id"));
			budR02.setCancellation_date(rs.getString("cancellation_date"));
			budR02.setLetter_generated_on(rs.getString("letter_generated_on"));
			budR02.setLetter_generated_by(rs.getString("letter_generated_by"));
			budR02.setLetter_generated_by_user_name(rs.getString("letter_generated_by_user_name"));
			budR02.setLetter_generated_at(rs.getString("letter_generated_at"));
			budR02.setCancellation_reason(rs.getString("cancellation_reason"));
			budR02.setCell_code(rs.getString("cell_code"));
			budR02.setCountry(rs.getString("country"));
			budR02.setCla_type(rs.getString("cla_type"));

			return budR02;
		}
	}

	class BudR16RowMapper implements RowMapper<BudR16> {
		@Override
		public BudR16 mapRow(ResultSet rs, int rowNum) throws SQLException {
			BudR16 budR16 = new BudR16();

			budR16.setCommodity_name(rs.getString("commodity_name"));
			budR16.setClaim_preferred_amount(rs.getDouble("claim_preferred_amount"));
			budR16.setClaim_paid_amount(rs.getDouble("claim_paid_amount"));
			budR16.setClaim_paid_date(rs.getString("claim_paid_date"));
			budR16.setClaim_no(rs.getString("claim_no"));
			budR16.setPremium_received(rs.getInt("premium_received"));
			budR16.setClaim_premiuim_ratio(rs.getInt("claim_premiuim_ratio"));

			return budR16;
		}
	}

	class BudR17RowMapper implements RowMapper<BudR17> {
		@Override
		public BudR17 mapRow(ResultSet rs, int rowNum) throws SQLException {
			BudR17 budR17 = new BudR17();

			budR17.setCountry_name(rs.getString("country_name"));
			budR17.setClaim_preferred_amount(rs.getDouble("claim_preferred_amount"));
			budR17.setClaim_paid_amount(rs.getDouble("claim_paid_amount"));
			budR17.setClaim_paid_date(rs.getString("claim_paid_date"));
			budR17.setBud_cell_cd(rs.getString("bud_cell_cd"));
			budR17.setClaim_no(rs.getString("claim_no"));
			budR17.setPremium_received(rs.getBigDecimal("premium_received"));
			budR17.setClaim_premiuim_ratio(rs.getBigDecimal("claim_premiuim_ratio"));

			return budR17;
		}
	}

	class BudR18RowMapper implements RowMapper<BudR18> {
		@Override
		public BudR18 mapRow(ResultSet rs, int rowNum) throws SQLException {
			BudR18 budR18 = new BudR18();

			budR18.setCountry_name(rs.getString("country_name"));
			budR18.setCell_no(rs.getString("cell_no"));
			budR18.setTotal_cla_received(rs.getBigDecimal("total_cla_received"));
			budR18.setCla_approved(rs.getBigDecimal("cla_approved"));
			budR18.setCla_pending(rs.getBigDecimal("cla_pending"));
			budR18.setAverage_decision_days(rs.getBigDecimal("average_decision_days"));

			return budR18;
		}
	}

	class BudR18RowMapper1 implements RowMapper<BudR18> {
		@Override
		public BudR18 mapRow(ResultSet rs, int rowNum) throws SQLException {
			BudR18 budR18 = new BudR18();

			budR18.setCell_no(rs.getString("cell_no"));
			budR18.setTotal_cla_received(rs.getBigDecimal("total_cla_received"));
			budR18.setCla_approved(rs.getBigDecimal("cla_approved"));
			budR18.setCla_pending(rs.getBigDecimal("cla_pending"));
			budR18.setAverage_decision_days(rs.getBigDecimal("average_decision_days"));

			return budR18;
		}
	}

	class BudR20RowMapper implements RowMapper<BudR20> {
		@Override
		public BudR20 mapRow(ResultSet rs, int rowNum) throws SQLException {
			BudR20 budR20 = new BudR20();

			budR20.setBuyer_name(rs.getString("buyer_name"));
			budR20.setBuyer_code(rs.getString("buyer_code"));
			budR20.setCell_no(rs.getString("cell_no"));
			budR20.setBranch(rs.getString("branch"));
			budR20.setPolicy_holder_name(rs.getString("policy_holder_name"));
			budR20.setAmount_of_limit_approved(rs.getBigDecimal("amount_of_limit_approved"));
			budR20.setTerms_of_payement(rs.getString("terms_of_payement"));
			budR20.setCla_approval_date(rs.getString("cla_approval_date"));
			budR20.setClaim_pref_amt(rs.getBigDecimal("claim_pref_amt"));
			budR20.setClaim_paid_amt(rs.getBigDecimal("claim_paid_amt"));
			budR20.setClaim_paid_date(rs.getString("claim_paid_date"));
			budR20.setReason(rs.getString("reason"));

			return budR20;
		}
	}

	class BudR20RowMapper1 implements RowMapper<BudR20> {
		@Override
		public BudR20 mapRow(ResultSet rs, int rowNum) throws SQLException {
			BudR20 budR20 = new BudR20();

			budR20.setCountry(rs.getString("country"));
			budR20.setClaim_paid_amt(rs.getBigDecimal("claim_paid_amt"));
			budR20.setAmount_of_regular_limit_approved(rs.getBigDecimal("amount_of_regular_limit_approved"));

			return budR20;
		}
	}

	class BudR23RowMapper implements RowMapper<BudR23> {
		@Override
		public BudR23 mapRow(ResultSet rs, int rowNum) throws SQLException {
			BudR23 budR23 = new BudR23();

			budR23.setRn(rs.getInt("rn"));
			budR23.setCla_no(rs.getString("cla_no"));
			budR23.setCla_type(rs.getString("cla_type"));
			budR23.setLogicalloc_cd(rs.getString("logicalloc_cd"));
			budR23.setPolicy_no(rs.getString("policy_no"));
			budR23.setBuyer_bank_cd(rs.getString("buyer_bank_cd"));
			budR23.setBuyer_bank_name(rs.getString("buyer_bank_name"));
			budR23.setBuyer_bank_country(rs.getString("buyer_bank_country"));
			budR23.setOfn_decision(rs.getString("ofn_decision"));
			budR23.setIwd_dt(rs.getString("iwd_dt"));
			budR23.setCla_entry_dt(rs.getString("cla_entry_dt"));
			budR23.setCla_decision_dt(rs.getString("cla_decision_dt"));
			budR23.setOl_decision_dt(rs.getString("ol_decision_dt"));
			budR23.setIn_process(rs.getString("in_process"));
			budR23.setReport_rec_date(rs.getString("report_rec_date"));
			budR23.setReport_req_date(rs.getString("report_req_date"));
			budR23.setReport_status(rs.getString("report_status"));
			budR23.setOl_decision_date(rs.getString("ol_decision_date"));
			budR23.setDisposal_day(rs.getInt("disposal_day"));

			return budR23;
		}
	}

	class BudR09RowMapper implements RowMapper<BudR09> {
		@Override
		public BudR09 mapRow(ResultSet rs, int rowNum) throws SQLException {
			BudR09 budR09 = new BudR09();

			budR09.setBuyer_code(rs.getString("buyer_code"));
			budR09.setBuyer_country(rs.getString("buyer_country"));
			budR09.setRequest_no(rs.getString("request_no"));
			budR09.setReport_status(rs.getString("report_status"));
			budR09.setRequest_dt(rs.getString("request_dt"));
			budR09.setRequest_received_dt(rs.getString("request_received_dt"));
			budR09.setOl_desc_dt(rs.getString("ol_desc_dt"));
			budR09.setOl_last_trans_dt(rs.getString("ol_last_trans_dt"));
			budR09.setCell_no(rs.getString("cell_no"));
			budR09.setDay_diff(rs.getString("day_diff"));

			return budR09;
		}
	}

	class BudR40RowMapper implements RowMapper<BudR40> {
		@Override
		public BudR40 mapRow(ResultSet rs, int rowNum) throws SQLException {
			BudR40 budR40 = new BudR40();

			budR40.setBuyer_cd(rs.getString("buyer_cd"));
			budR40.setBuyer_name(rs.getString("buyer_name"));
			budR40.setBuyer_country(rs.getString("buyer_country"));

			return budR40;
		}
	}

	class BudR48_1RowMapper implements RowMapper<BudR48_1> {
		@Override
		public BudR48_1 mapRow(ResultSet rs, int rowNum) throws SQLException {
			BudR48_1 budR48_1 = new BudR48_1();

			budR48_1.setLogicalloc_cd(rs.getString("logicalloc_cd"));
			budR48_1.setPol_num(rs.getString("pol_num"));
			budR48_1.setPolicy_type(rs.getString("policy_type"));
			budR48_1.setExporter_name(rs.getString("exporter_name"));
			budR48_1.setBuyer_code(rs.getString("buyer_code"));
			budR48_1.setBuyer_name(rs.getString("buyer_name"));
			budR48_1.setCountry(rs.getString("country"));
			budR48_1.setShip_date(rs.getString("ship_date"));
			budR48_1.setDefault_status(rs.getString("default_status"));
			budR48_1.setDefault_received_date(rs.getString("default_received_date"));
			budR48_1.setDefault_from_date(rs.getString("default_from_date"));
			budR48_1.setCell_code(rs.getString("cell_code"));
			budR48_1.setOl_status(rs.getString("ol_status"));
			budR48_1.setByr_default_list(rs.getString("byr_default_list"));
			budR48_1.setBalance(rs.getString("balance"));
			budR48_1.setTotal_overall_limit(rs.getString("total_overall_limit"));
			budR48_1.setTotal_sanctioned_limit(rs.getString("total_sanctioned_limit"));

			return budR48_1;
		}
	}

	class BudR48_2RowMapper implements RowMapper<BudR48_2> {
		@Override
		public BudR48_2 mapRow(ResultSet rs, int rowNum) throws SQLException {
			BudR48_2 budR48_2 = new BudR48_2();

			budR48_2.setBranch(rs.getString("branch"));
			budR48_2.setRod_no(rs.getString("rod_no"));
			budR48_2.setRod_entry_no(rs.getString("rod_entry_no"));
			budR48_2.setRod_status(rs.getString("rod_status"));
			budR48_2.setCover_no(rs.getString("cover_no"));
			budR48_2.setExporter_code(rs.getString("exporter_code"));
			budR48_2.setExporter_name(rs.getString("exporter_name"));
			budR48_2.setBank_code(rs.getString("bank_code"));
			budR48_2.setBank_name(rs.getString("bank_name"));
			budR48_2.setBuyer_code(rs.getString("buyer_code"));
			budR48_2.setBuyer_name(rs.getString("buyer_name"));
			budR48_2.setCountry(rs.getString("country"));
			budR48_2.setBuyer_in_default(rs.getString("buyer_in_default"));
			budR48_2.setOl_status(rs.getString("ol_status"));
			budR48_2.setLimit_reported(rs.getString("limit_reported"));
			budR48_2.setTotal_outstanding(rs.getString("total_outstanding"));
			budR48_2.setTotal_overall_limit(rs.getString("total_overall_limit"));
			budR48_2.setTotal_sanctioned_limit(rs.getString("total_sanctioned_limit"));

			return budR48_2;
		}
	}

	class BudR04_1RowMapper implements RowMapper<BudR04_1> {
		@Override
		public BudR04_1 mapRow(ResultSet rs, int rowNum) throws SQLException {
			BudR04_1 budR04_1 = new BudR04_1();

			budR04_1.setBranch(rs.getString("branch"));
			budR04_1.setCell_no(rs.getString("cell_no"));
			budR04_1.setCla_no(rs.getString("cla_no"));
			budR04_1.setCla_type(rs.getString("cla_type"));
			budR04_1.setCla_recd_dt_iwd_dt(rs.getString("cla_recd_dt_iwd_dt"));
			budR04_1.setPolicy_number(rs.getString("policy_number"));
			budR04_1.setPolicy_holder_name(rs.getString("policy_holder_name"));
			budR04_1.setBuyer_code(rs.getString("buyer_code"));
			budR04_1.setBuyer_name(rs.getString("buyer_name"));
			budR04_1.setOl_fixed(rs.getString("ol_fixed"));
			budR04_1.setTerms_of_payment(rs.getString("terms_of_payment"));
			budR04_1.setLimit_sought_in_lacs(rs.getString("limit_sought_in_lacs"));
			budR04_1.setExisting_limit_in_lacs(rs.getString("existing_limit_in_lacs"));
			budR04_1.setExisting_limit_payment_terms(rs.getString("existing_limit_payment_terms"));
			budR04_1.setDp_balance_in_lacs(rs.getString("dp_balance_in_lacs"));
			budR04_1.setDa_balance_in_lacs(rs.getString("da_balance_in_lacs"));
			budR04_1.setTotal_ol_in_lacs(rs.getString("total_ol_in_lacs"));
			budR04_1.setOl_dec_status(rs.getString("ol_dec_status"));
			budR04_1.setOl_last_trans_date(rs.getString("ol_last_trans_date"));
			budR04_1.setCla_entry_dt(rs.getString("cla_entry_dt"));
			budR04_1.setRequest_no(rs.getString("request_no"));
			budR04_1.setRequest_date(rs.getString("request_date"));
			budR04_1.setStatus(rs.getString("status"));
			budR04_1.setReport_received_date(rs.getString("report_received_date"));
			budR04_1.setBuyer_in_default(rs.getString("buyer_in_default"));
			budR04_1.setPrevious_report_date(rs.getString("previous_report_date"));
			budR04_1.setReport_status(rs.getString("report_status"));
			budR04_1.setCommodity_description(rs.getString("commodity_description"));

			return budR04_1;
		}
	}

	class BudR04_2RowMapper implements RowMapper<BudR04_2> {
		@Override
		public BudR04_2 mapRow(ResultSet rs, int rowNum) throws SQLException {
			BudR04_2 budR04_2 = new BudR04_2();

			budR04_2.setLogicalloc_cd(rs.getString("logicalloc_cd"));
			budR04_2.setA(rs.getString("a"));
			budR04_2.setB(rs.getString("b"));
			budR04_2.setC(rs.getString("c"));
			budR04_2.setTotal_sum(rs.getString("total_sum"));

			return budR04_2;
		}
	}

	@Override
	public List<String> getAllBudCellCodes() throws DataAccessException {
		final String query = BudQueries.GET_ALL_CELL_CODES;

		try {
			return namedParameterJdbcTemplate.queryForList(query, new MapSqlParameterSource(), String.class);
		} catch (DataAccessException e) {
			e.printStackTrace();
			throw e;
		}

	}

	public List<Map<String, String>> getAllCla144Policies(final Map<String, String> queryParams, final String query)
			throws DataAccessException {

		try {
			return namedParameterJdbcTemplate.query(query, queryParams, rs -> {
				List<Map<String, String>> list = new ArrayList<>();
				boolean forPolicy = queryParams.get("for").equalsIgnoreCase("%policy%");

				while (rs.next()) {
					HashMap<String, String> m = new HashMap<>();
					if (forPolicy) {
						m.put("policyNo", rs.getString("policy_no"));
						m.put("exporterName", rs.getString("ph_name"));
					} else {
						m.put("buyerCode", rs.getString("buyer_cd"));
						m.put("buyerName", rs.getString("buyer_name"));
						m.put("buyerCountry", rs.getString("buyer_ctry"));
					}
					list.add(m);

				}
				return list;
			});
		} catch (DataAccessException e) {
			e.printStackTrace();
			throw e;
		}
	}

	@Override
	public List<Map<String, Object>> getAllActiveApprovedLimits(String coverCatId, String logicalLocationCode) {
		final String query = BudQuery.BUD_R59_A_01.getQuery();

		try {

			return namedParameterJdbcTemplate.queryForList(query,
					new MapSqlParameterSource().addValue("coverCatId", coverCatId).addValue("logicalLocationCode",
							logicalLocationCode));
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

	}

	@Override
	public List<Map<String, Object>> getAllActiveApprovedLimitsBuyer(String coverCatId, String logicalLocationCode) {
		final String query = BudQuery.BUD_R59_A_02.getQuery();

		try {

			return namedParameterJdbcTemplate.queryForList(query,
					new MapSqlParameterSource().addValue("coverCatId", coverCatId).addValue("logicalLocationCode",
							logicalLocationCode));
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

	}

	@Override
	public List<Map<String, Object>> getActiveApprovedLimitsBuyer(String coverCatId, String logicalLocationCode,
			String countryName) {
		final String query = BudQuery.BUD_R59_A_03.getQuery();

		try {
			return namedParameterJdbcTemplate.queryForList(query, new MapSqlParameterSource()
					.addValue("coverCatId", coverCatId).addValue("logicalLocationCode", logicalLocationCode)
					.addValue("buyerCountryName", countryName.toUpperCase()));

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	@Override
	public List<Map<String, Object>> getAllActiveApprovedLimitsBank(String coverCatId, String logicalLocationCode) {
		final String query = BudQuery.BUD_R59_A_04.getQuery();

		try {

			return namedParameterJdbcTemplate.queryForList(query,
					new MapSqlParameterSource().addValue("coverCatId", coverCatId).addValue("logicalLocationCode",
							logicalLocationCode));
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

	}

	@Override
	public List<Map<String, Object>> getActiveApprovedLimitsBank(String coverCatId, String logicalLocationCode,
			String countryName) {
		final String query = BudQuery.BUD_R59_A_05.getQuery();

		try {
			return namedParameterJdbcTemplate.queryForList(query, new MapSqlParameterSource()
					.addValue("coverCatId", coverCatId).addValue("logicalLocationCode", logicalLocationCode)
					.addValue("bankCountryName", countryName.toUpperCase()));

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

}
