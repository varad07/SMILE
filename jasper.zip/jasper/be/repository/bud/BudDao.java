package in.ecgc.smile.erp.reporting.jasper.be.repository.bud;

import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;

import in.ecgc.smile.erp.reporting.jasper.be.model.bud.BudR02;
import in.ecgc.smile.erp.reporting.jasper.be.model.bud.BudR09;
import in.ecgc.smile.erp.reporting.jasper.be.model.bud.BudR16;
import in.ecgc.smile.erp.reporting.jasper.be.model.bud.BudR17;
import in.ecgc.smile.erp.reporting.jasper.be.model.bud.BudR18;
import in.ecgc.smile.erp.reporting.jasper.be.model.bud.BudR20;
import in.ecgc.smile.erp.reporting.jasper.be.model.bud.BudR21;
import in.ecgc.smile.erp.reporting.jasper.be.model.bud.BudR23;
import in.ecgc.smile.erp.reporting.jasper.be.model.bud.BudR40;
import in.ecgc.smile.erp.reporting.jasper.be.model.bud.BudR48_1;
import in.ecgc.smile.erp.reporting.jasper.be.model.bud.BudR48_2;
import in.ecgc.smile.erp.reporting.jasper.be.model.bud.BudR49;
import in.ecgc.smile.erp.reporting.jasper.be.model.bud.BudR49_1;

public interface BudDao {

	List<BudR21> getListBudR21(String lastUpdatedDateFrom, String lastUpdatedDateTo);

	List<BudR49> getListBudR49(String fromDate, String toDate);

	List<BudR49_1> getListBudR49_1(String fromDate, String toDate);

	List<BudR02> getListBudR02(String fromDate, String toDate);

	List<BudR16> getListBudR16(String fromDate, String toDate);

	List<BudR17> getListBudR17(String fromDate, String toDate);

	List<BudR18> getListBudR18(String fromDate, String toDate);

	List<BudR18> getListBudR18_1(String fromDate, String toDate);

	List<BudR20> getListBudR20(String fromDate, String toDate);

	List<BudR20> getListBudR20_1(String fromDate, String toDate);

	List<BudR23> getListBudR23(String fromDate, String toDate, String claType);

	List<BudR09> getListBudR09(String fromDate, String toDate, String reportStatus);

	List<BudR40> getListBudR40(String fromDate, String toDate);

	List<BudR48_1> getListBudR48_1(String fromDate, String toDate, String reportStatus);

	List<BudR48_2> getListBudR48_2(String fromDate, String toDate, String reportStatus);

	public List<String> getAllBudCellCodes() throws DataAccessException;

	public List<Map<String, String>> getAllCla144Policies(final Map<String, String> queryParams, String query)
			throws DataAccessException;

	public List<Map<String, Object>> getAllActiveApprovedLimits(String coverCatId, String logicalLocationCode);

	public List<Map<String, Object>> getAllActiveApprovedLimitsBank(String coverCatId, String logicalLocationCode);

	public List<Map<String, Object>> getAllActiveApprovedLimitsBuyer(String coverCatId, String logicalLocationCode);

	public List<Map<String, Object>> getActiveApprovedLimitsBank(String coverCatId, String logicalLocationCode,
			String countryName);

	public List<Map<String, Object>> getActiveApprovedLimitsBuyer(String coverCatId, String logicalLocationCode,
			String countryName);

}
