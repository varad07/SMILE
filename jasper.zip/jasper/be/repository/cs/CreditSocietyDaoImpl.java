package in.ecgc.smile.erp.reporting.jasper.be.repository.cs;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataAccessResourceFailureException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcOperations;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.databind.ObjectMapper;

import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.EntityGL;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.GLStmt;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.TrialBalance;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.TrialBalanceReport;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.TrialBalanceTxnDtl;
import in.ecgc.smile.erp.reporting.jasper.be.model.cs.Employee;
import in.ecgc.smile.erp.reporting.jasper.be.model.cs.PLStmt;
import in.ecgc.smile.erp.reporting.jasper.be.model.cs.PlWiseSummary;
import in.ecgc.smile.erp.reporting.jasper.be.repository.accounts.GlTxnDaoImpl;
import in.ecgc.smile.erp.reporting.jasper.be.utils.FORMATS;
import in.ecgc.smile.erp.reporting.jasper.be.utils.accounts.TrialBalanceSqlQueries;
import in.ecgc.smile.erp.reporting.jasper.be.utils.cs.CreditSocietySqlQueries;

@Repository
@Transactional
public class CreditSocietyDaoImpl implements CreditSocietyDao {

	@Autowired
	private ObjectMapper objectMapper; // Autowire the ObjectMapper

	private NamedParameterJdbcOperations namedParameterJdbcOperations;
	@SuppressWarnings("unused")
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	@Autowired
	public CreditSocietyDaoImpl(DataSource dataSource) {
		namedParameterJdbcOperations = new NamedParameterJdbcTemplate(dataSource);
		namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(dataSource);
	}
	
	private static final Logger log = LoggerFactory.getLogger(GlTxnDaoImpl.class);


	@Override
	public TrialBalanceReport getTrialBalacneAllLoc(String inputDate, Boolean isNil) {
		Map<String, Object> paraMap = new HashMap<>();
		paraMap.put("input_date", LocalDate.parse(inputDate, FORMATS.DATE_FORMATS));
		TrialBalanceReport trialBalanceAllLoc = new TrialBalanceReport();

		List<TrialBalanceTxnDtl> trialBal = new ArrayList<TrialBalanceTxnDtl>();

		String query = null;

		if (isNil) {
			query = CreditSocietySqlQueries.GET_CS_TRIAL_BALANCE_ALL_LOC;
		} else {
			query = CreditSocietySqlQueries.GET_CS_TRIAL_BALANCE_ALL_LOC_NOT_NIL;
		}

		trialBal = namedParameterJdbcTemplate.query(query, paraMap, new RowMapper<TrialBalanceTxnDtl>() {

			@Override
			public TrialBalanceTxnDtl mapRow(ResultSet rs, int rowNum) throws SQLException {
				TrialBalanceTxnDtl trialBalanceAllLocDtl = new TrialBalanceTxnDtl();

				trialBalanceAllLocDtl.setInputDate(LocalDate.parse(inputDate, FORMATS.DATE_FORMATS));
				trialBalanceAllLocDtl.setMainglCd(rs.getString("maingl_cd"));
				trialBalanceAllLocDtl.setSubGlCd(rs.getString("subgl_cd"));
				trialBalanceAllLocDtl.setGlName(rs.getString("gl_name"));
				trialBalanceAllLocDtl.setGlType(rs.getString("gl_type"));
				trialBalanceAllLocDtl.setDrAmount(rs.getBigDecimal("dr_amount"));
				trialBalanceAllLocDtl.setCrAmount(rs.getBigDecimal("cr_amount"));
				return trialBalanceAllLocDtl;
			}
		});

		List<String> glTypeList = new ArrayList<>();
		glTypeList.add("ASST");
		glTypeList.add("LIAB");
		glTypeList.add("INCM");
		glTypeList.add("EXPD");

		for (String glType : glTypeList) {
			Map<String, Object> paraMap2 = new HashMap<>();
			paraMap2.put("glType", glType);
			paraMap2.put("input_date", LocalDate.parse(inputDate, FORMATS.DATE_FORMATS));

			namedParameterJdbcTemplate.query(CreditSocietySqlQueries.GET_CS_TRIAL_BALANCE_ALL_LOC_DR_CR_AMOUNT,
					paraMap2, new RowMapper<Map<String, BigDecimal>>() {

						@Override
						public Map<String, BigDecimal> mapRow(ResultSet rs, int rowNum) throws SQLException {

							Map<String, BigDecimal> amountMap = new HashMap<String, BigDecimal>();

							amountMap.put("crAmount", rs.getBigDecimal("total_cr"));
							amountMap.put("drAmount", rs.getBigDecimal("total_dr"));

							if (glType.equals("ASST")) {
								trialBalanceAllLoc.setAsstCrAmount(amountMap.get("crAmount"));
								trialBalanceAllLoc.setAsstDrAmount(amountMap.get("drAmount"));
							} else if (glType.equals("LIAB")) {
								trialBalanceAllLoc.setLiabCrAmount(amountMap.get("crAmount"));
								trialBalanceAllLoc.setLiabDrAmount(amountMap.get("drAmount"));
							} else if (glType.equals("INCM")) {
								trialBalanceAllLoc.setIncmCrAmount(amountMap.get("crAmount"));
								trialBalanceAllLoc.setIncmDrAmount(amountMap.get("drAmount"));
							} else if (glType.equals("EXPD")) {
								trialBalanceAllLoc.setExpdCrAmount(amountMap.get("crAmount"));
								trialBalanceAllLoc.setExpdDrAmount(amountMap.get("drAmount"));
							}

							return amountMap;
						}
					});

		} // for

		BigDecimal totalCr = trialBalanceAllLoc.getAsstCrAmount().add(trialBalanceAllLoc.getLiabCrAmount())
				.add(trialBalanceAllLoc.getExpdCrAmount()).add(trialBalanceAllLoc.getIncmCrAmount());
		BigDecimal totalDr = trialBalanceAllLoc.getAsstDrAmount().add(trialBalanceAllLoc.getLiabDrAmount())
				.add(trialBalanceAllLoc.getExpdDrAmount()).add(trialBalanceAllLoc.getIncmDrAmount());

		trialBalanceAllLoc.setTotalCrAmount(totalCr);
		trialBalanceAllLoc.setTotalDrAmount(totalDr);

		trialBalanceAllLoc.setTrialBalanceAllLocDtlList(trialBal);
		return trialBalanceAllLoc;
	}

	@Override
	public Integer generateTrialBalanceAllLocByDate(String inputDate) {
		Map<String, Object> paraMap = new HashMap<>();

		try {
			paraMap.put("input_date", LocalDate.parse(inputDate, FORMATS.DATE_FORMATS));
		} catch (DateTimeParseException e) {
			throw new RuntimeException("Date Format is Incorrect");
		}

		try {
			return namedParameterJdbcTemplate.queryForObject(CreditSocietySqlQueries.GETERATE_CS_TRIAL_BALANCE_ALL_LOC,
					paraMap, new RowMapper<Integer>() {
						@Override
						public Integer mapRow(ResultSet rs, int rowNum) throws SQLException {
							return rs.getInt(1);
						}
					});
		} catch (EmptyResultDataAccessException e) {
			throw new RuntimeException("Failed to Generate CS Trial Balance For Given Date : " + inputDate
					+ " ; Exeception caused due to : " + e.getMessage());

		}
	}

	@Override
	public Integer generateBankReconciliation(String inputDate, Boolean isNil) {
		Map<String, Object> paraMap = new HashMap<>();

		try {
			paraMap.put("input_date", LocalDate.parse(inputDate, FORMATS.DATE_FORMATS));
		} catch (DateTimeParseException e) {
			throw new RuntimeException("Date Format is Incorrect");
		}

		try {
			return namedParameterJdbcTemplate.queryForObject(CreditSocietySqlQueries.GETERATE_CS_BANK_RECONCILIATION,
					paraMap, new RowMapper<Integer>() {
						@Override
						public Integer mapRow(ResultSet rs, int rowNum) throws SQLException {
							return rs.getInt(1);
						}
					});
		} catch (EmptyResultDataAccessException e) {
			throw new RuntimeException("Failed to Generate CS BANK RECONCILIATION For Given Date : " + inputDate
					+ " ; Exeception caused due to : " + e.getMessage());

		}
	}

	@Override
	public TrialBalanceReport getBankReconciliation(String inputDate, Boolean isNil) {
		Map<String, Object> paraMap = new HashMap<>();
		paraMap.put("input_date", LocalDate.parse(inputDate, FORMATS.DATE_FORMATS));
		TrialBalanceReport trialBalanceAllLoc = new TrialBalanceReport();

		List<TrialBalanceTxnDtl> trialBal = new ArrayList<TrialBalanceTxnDtl>();

		String query = null;

		if (isNil) {
			query = CreditSocietySqlQueries.GET_CS_BANK_RECONCILIATION;
		} else {
			query = CreditSocietySqlQueries.GET_CS_BANK_RECONCILIATION_NOT_NIL;
		}

		trialBal = namedParameterJdbcTemplate.query(query, paraMap, new RowMapper<TrialBalanceTxnDtl>() {

			@Override
			public TrialBalanceTxnDtl mapRow(ResultSet rs, int rowNum) throws SQLException {
				TrialBalanceTxnDtl trialBalanceAllLocDtl = new TrialBalanceTxnDtl();

				trialBalanceAllLocDtl.setInputDate(LocalDate.parse(inputDate, FORMATS.DATE_FORMATS));
				trialBalanceAllLocDtl.setMainglCd(rs.getString("mainglcd"));
				trialBalanceAllLocDtl.setSubGlCd(rs.getString("subglcd"));
				trialBalanceAllLocDtl.setGlName(rs.getString("gl_name"));
				trialBalanceAllLocDtl.setGlType(rs.getString("gl_type"));
				trialBalanceAllLocDtl.setDrAmount(rs.getBigDecimal("dr_amount"));
				trialBalanceAllLocDtl.setCrAmount(rs.getBigDecimal("cr_amount"));
				trialBalanceAllLocDtl.setLogicalLocation(rs.getString("logical_loc_cd"));
				return trialBalanceAllLocDtl;
			}
		});

		List<String> glTypeList = new ArrayList<>();
		glTypeList.add("ASST");
		

		for (String glType : glTypeList) {
			Map<String, Object> paraMap2 = new HashMap<>();
			paraMap2.put("glType", glType);
			paraMap2.put("input_date", LocalDate.parse(inputDate, FORMATS.DATE_FORMATS));

			namedParameterJdbcTemplate.query(CreditSocietySqlQueries.GET_CS_BANK_RECONCILIATION_DR_CR_AMOUNT, paraMap2,
					new RowMapper<Map<String, BigDecimal>>() {

						@Override
						public Map<String, BigDecimal> mapRow(ResultSet rs, int rowNum) throws SQLException {

							Map<String, BigDecimal> amountMap = new HashMap<String, BigDecimal>();

							amountMap.put("crAmount", rs.getBigDecimal("total_cr"));
							amountMap.put("drAmount", rs.getBigDecimal("total_dr"));

							if (glType.equals("ASST")) {
								trialBalanceAllLoc.setAsstCrAmount(amountMap.get("crAmount"));
								trialBalanceAllLoc.setAsstDrAmount(amountMap.get("drAmount"));
							}

							return amountMap;
						}
					});

		} // for
		try {
			BigDecimal totalCr = trialBalanceAllLoc.getAsstCrAmount();

			BigDecimal totalDr = trialBalanceAllLoc.getAsstDrAmount();

			trialBalanceAllLoc.setTotalCrAmount(totalCr);
			trialBalanceAllLoc.setTotalDrAmount(totalDr);

			trialBalanceAllLoc.setTrialBalanceAllLocDtlList(trialBal);
			return trialBalanceAllLoc;
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println(e.getMessage());
		}
		return trialBalanceAllLoc;
	}

	@Override
	public TrialBalance getByLogicalLoc(String balanceDate, String mainglCd, String subglCd, String glName,
			String glType) {
		TrialBalance trialBalance = new TrialBalance();
		Map<String, Object> paraMap = new HashMap<>();
		paraMap.put("mainglCd", mainglCd);
		paraMap.put("subglCd", subglCd);

		try {
			LocalDate lcdt = LocalDate.parse(balanceDate, FORMATS.DATE_FORMATS);
			paraMap.put("balancedt", lcdt);
		} catch (DateTimeParseException e) {
			throw new RuntimeException("Date Format is Incorrect");
		}

		try {
			trialBalance = namedParameterJdbcOperations.queryForObject(TrialBalanceSqlQueries.GET_CS_TRIAL_BAL_BY_GL,
					paraMap, new RowMapper<TrialBalance>() {

						@Override
						public TrialBalance mapRow(ResultSet rs, int rowNum) throws SQLException {
							TrialBalance balance = new TrialBalance();
							
							if (rs.getBigDecimal("total_dr_amount") != null) {
								balance.setDrAmount(
										rs.getBigDecimal("total_dr_amount").setScale(2, BigDecimal.ROUND_HALF_UP));
							} else {

								balance.setDrAmount(BigDecimal.valueOf(0.00).setScale(2, BigDecimal.ROUND_HALF_UP));
							}
							if (rs.getBigDecimal("total_cr_amount") != null) {
								balance.setCrAmount(
										rs.getBigDecimal("total_cr_amount").setScale(2, BigDecimal.ROUND_HALF_UP));
							} else {
								balance.setCrAmount(BigDecimal.valueOf(0.00).setScale(2, BigDecimal.ROUND_HALF_UP));
							}
							balance.setMainGlCd(mainglCd);
							balance.setSubGlCd(subglCd);
							balance.setGlName(glName);
							balance.setGltype(glType);

							// log.info("Trial Balance : {}",balance);

							return balance;
						}
					});
		} catch (EmptyResultDataAccessException e) {

			// log.info("Exception caused in getByLogicalLoc: {}", e.getMessage());

			trialBalance.setDrAmount(BigDecimal.valueOf(0.00).setScale(2, BigDecimal.ROUND_HALF_UP));
			trialBalance.setCrAmount(BigDecimal.valueOf(0.00).setScale(2, BigDecimal.ROUND_HALF_UP));
			trialBalance.setMainGlCd(mainglCd);
			trialBalance.setSubGlCd(subglCd);
			trialBalance.setGlName(glName);
			trialBalance.setGltype(glType);

		}
		return trialBalance;
	}
	
	
	

	@Override

	public List<EntityGL>  getAllGlCodes() {

	try {

			return namedParameterJdbcTemplate.query(CreditSocietySqlQueries.GET_ALL_GL_CODES,

					new RowMapper<EntityGL>() {
 
						@Override

						public EntityGL mapRow(ResultSet rs, int rowNum) throws SQLException {

							EntityGL entitygl = new EntityGL();
							entitygl.setMainglCd(rs.getString("maingl_cd"));
					        entitygl.setSubglCd(rs.getString("subgl_cd"));
					   	return entitygl;

						}

			});

		} catch (Exception e) {
System.out.println("ERROR: DAO Module {}\", e.getMessage()");

			throw e;

		}

	}

	@Override
	public List<Employee> getAllEmployeePl(String mainGlCd, String subGlCd) {
		Employee emp = new Employee();
		Map<String, Object> paraMap = new HashMap<>();
		paraMap.put("mainGlCd", mainGlCd);
		paraMap.put("subGlCd", subGlCd);

	


	try {
		return namedParameterJdbcOperations.query(CreditSocietySqlQueries.GET_PL_CODES,
				paraMap, new RowMapper<Employee>() {

			@Override

					public Employee mapRow(ResultSet rs, int rowNum) throws SQLException {

						Employee emp = new Employee();
						emp.setEmpNo(rs.getInt("emp_no"));
                        emp.setEmpAlias(rs.getString("emp_alias"));
                        emp.setRankId(rs.getString("rank_cd"));
						
						return emp;

					}

				});

		
			} catch (Exception e) {
System.out.println("inside dao impl");

				throw e;

			}

		}

	@Override
	public List<PLStmt> getGLCodeStatementbyLoc(PlWiseSummary plwiseSummary) {
		log.info("Inside GlTxnDaoImpl#getGLCodeStatementbyLoc (Obj):{}", plwiseSummary);

		Map<String, Object> paramMap = new HashMap<>();
		//paramMap.put("logicalLoc", glCodeStmtIn.getLogicallocCd());
		paramMap.put("mainGlCd", plwiseSummary.getMainglCd());
		paramMap.put("subGlCd", plwiseSummary.getSubglCd());
		paramMap.put("plCd", plwiseSummary.getPlCd());
		paramMap.put("fromDt", plwiseSummary.getFromDt());
		paramMap.put("toDt", plwiseSummary.getToDt());

		paramMap.forEach((key, value) -> {
			if (value == null || StringUtils.isBlank(value.toString())) {
				paramMap.put(key, "");
			}
		});

		

		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("select * from cs.ecgc_cs_gl_txn_dtl d \r\n"
				+ "inner join cs.ecgc_cs_gl_txn_hdr h  \r\n"
				+ "on d.gl_txn_no = h.gl_txn_no and d.logicalloc_cd  = h.logicalloc_cd  and d.gl_txn_type = h.gl_txn_type \r\n"
				+ "where d.maingl_cd = :mainGlCd and d.subgl_cd = :subGlCd and d.personal_ledger_cd = :plCd \r\n"
				+ "and h.txn_dt >= :fromDt and h.txn_dt = :toDt ");

		


		String sqlQuery = queryBuilder.toString();

		log.info("Generated SQL Query : {}", sqlQuery);

		try {
			return namedParameterJdbcTemplate.query(sqlQuery, paramMap, new RowMapper<PLStmt>() {

				@Override
				public PLStmt mapRow(ResultSet rs, int rowNum) throws SQLException {
					PLStmt glStmt = new PLStmt();
					if (rs.getDate("txn_dt") != null)
						glStmt.setTxnDate(rs.getDate("txn_dt").toLocalDate());
					glStmt.setTxnNo(rs.getString("gl_txn_no"));
					glStmt.setTxnType(rs.getString("gl_txn_type"));
					if (rs.getString("dr_cr_flg").equalsIgnoreCase("CR")) {
						glStmt.setTxnCrAmt(BigDecimal.valueOf(rs.getDouble("txn_amt")));
						glStmt.setTxnDrAmt(BigDecimal.ZERO);
					} else if (rs.getString("dr_cr_flg").equalsIgnoreCase("DR")) {
						glStmt.setTxnDrAmt(BigDecimal.valueOf(rs.getDouble("txn_amt")));
						glStmt.setTxnCrAmt(BigDecimal.ZERO);
					}
					//glStmt.setRemark(rs.getString("txn_remarks"));
					return glStmt;
				}
			});
		} catch (DataAccessException e) {
			log.error("Exception caused due to : {}", e.getMessage());
			throw new DataAccessResourceFailureException("Failed to get PL statement");
		}
	}

	@Override
	public TrialBalance getGlRangeByDate(String inputDate, String mainglCd, String subglCd, String plCd) {
		TrialBalance trialBalance = new TrialBalance();
		Map<String, Object> paraMap = new HashMap<>();
		paraMap.put("mainglCd", mainglCd);
		paraMap.put("subglCd", subglCd);
		paraMap.put("plCd", plCd);

		try {
			LocalDate lcdt = LocalDate.parse(inputDate, FORMATS.DATE_FORMATS);
			paraMap.put("inputDate", lcdt);
		} catch (DateTimeParseException e) {
			throw new RuntimeException("Date Format is Incorrect");
		}

		try {
			trialBalance = namedParameterJdbcOperations.queryForObject(CreditSocietySqlQueries.GET_TRIAL_BAL_BY_PL,
					paraMap, new RowMapper<TrialBalance>() {

						@Override
						public TrialBalance mapRow(ResultSet rs, int rowNum) throws SQLException {
							TrialBalance balance = new TrialBalance();
							if (rs.getBigDecimal("total_dr_amount") != null) {
								balance.setDrAmount(
										rs.getBigDecimal("total_dr_amount").setScale(2, BigDecimal.ROUND_HALF_UP));
							} else {

								balance.setDrAmount(BigDecimal.valueOf(0.00).setScale(2, BigDecimal.ROUND_HALF_UP));
							}
							if (rs.getBigDecimal("total_cr_amount") != null) {
								balance.setCrAmount(
										rs.getBigDecimal("total_cr_amount").setScale(2, BigDecimal.ROUND_HALF_UP));
							} else {
								balance.setCrAmount(BigDecimal.valueOf(0.00).setScale(2, BigDecimal.ROUND_HALF_UP));
							}
							balance.setMainGlCd(mainglCd);
							balance.setSubGlCd(subglCd);
							balance.setPlCd(plCd);
							

							log.info("Trial Balance in DAO: {}",balance);

							return balance;
						}
					});
		} catch (EmptyResultDataAccessException e) {

			log.error("Exception caused in getByDate: {}", e.getMessage());
			
			trialBalance.setDrAmount(BigDecimal.valueOf(0.00).setScale(2, BigDecimal.ROUND_HALF_UP));
			trialBalance.setCrAmount(BigDecimal.valueOf(0.00).setScale(2, BigDecimal.ROUND_HALF_UP));
			trialBalance.setMainGlCd(mainglCd);
			trialBalance.setSubGlCd(subglCd);
			trialBalance.setPlCd(plCd);

		}
		return trialBalance;
	}

	@Override
	public TrialBalance getGlRangeByDateGL(String mainglCd, String subglCd,String inputDate) {
		TrialBalance trialBalance = new TrialBalance();
		Map<String, Object> paraMap = new HashMap<>();
		paraMap.put("mainglCd", mainglCd);
		paraMap.put("subglCd", subglCd);

		try {
			LocalDate lcdt = LocalDate.parse(inputDate, FORMATS.DATE_FORMATS);
			paraMap.put("balancedt", lcdt);
		} catch (DateTimeParseException e) {
			throw new RuntimeException("Date Format is Incorrect");
		}

		try {
			trialBalance = namedParameterJdbcOperations.queryForObject(CreditSocietySqlQueries.GET_CS_TRIAL_BAL_BY_GL,
					paraMap, new RowMapper<TrialBalance>() {

						@Override
						public TrialBalance mapRow(ResultSet rs, int rowNum) throws SQLException {
							TrialBalance balance = new TrialBalance();
							if (rs.getBigDecimal("total_dr_amount") != null) {
								balance.setDrAmount(
										rs.getBigDecimal("total_dr_amount").setScale(2, BigDecimal.ROUND_HALF_UP));
							} else {

								balance.setDrAmount(BigDecimal.valueOf(0.00).setScale(2, BigDecimal.ROUND_HALF_UP));
							}
							if (rs.getBigDecimal("total_cr_amount") != null) {
								balance.setCrAmount(
										rs.getBigDecimal("total_cr_amount").setScale(2, BigDecimal.ROUND_HALF_UP));
							} else {
								balance.setCrAmount(BigDecimal.valueOf(0.00).setScale(2, BigDecimal.ROUND_HALF_UP));
							}
							balance.setMainGlCd(mainglCd);
							balance.setSubGlCd(subglCd);
							

							log.info("Trial Balance in DAO: {}",balance);

							return balance;
						}
					});
		} catch (EmptyResultDataAccessException e) {

			log.error("Exception caused in getByDate: {}", e.getMessage());
			
			trialBalance.setDrAmount(BigDecimal.valueOf(0.00).setScale(2, BigDecimal.ROUND_HALF_UP));
			trialBalance.setCrAmount(BigDecimal.valueOf(0.00).setScale(2, BigDecimal.ROUND_HALF_UP));
			trialBalance.setMainGlCd(mainglCd);
			trialBalance.setSubGlCd(subglCd);

		}
		return trialBalance;
	}

	@Override
	public List<PLStmt> getGLCodeStatementForCashBankBook(PlWiseSummary plwiseSummary) {
		log.info("Inside CreditSocietyDaoImpl#getGLCodeStatementForCashBankBook (Obj):{}", plwiseSummary);

		Map<String, Object> paramMap = new HashMap<>();
		paramMap.put("mainGlCd", plwiseSummary.getMainglCd());
		paramMap.put("subGlCd", plwiseSummary.getSubglCd());
		paramMap.put("fromDt", plwiseSummary.getFromDt());
		paramMap.put("toDt", plwiseSummary.getToDt());

		paramMap.forEach((key, value) -> {
			if (value == null || StringUtils.isBlank(value.toString())) {
				paramMap.put(key, "");
			}
		});

		

		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("select * from cs.ecgc_cs_gl_txn_dtl d \r\n"
				+ "inner join cs.ecgc_cs_gl_txn_hdr h  \r\n"
				+ "on d.gl_txn_no = h.gl_txn_no and d.logicalloc_cd  = h.logicalloc_cd  and d.gl_txn_type = h.gl_txn_type \r\n"
				+ "where d.maingl_cd = '1000' and d.subgl_cd = '004' \r\n"
				+ "and h.txn_dt >= :fromDt and h.txn_dt <= :toDt ");

		


		String sqlQuery = queryBuilder.toString();

		log.info("Generated SQL Query : {}", sqlQuery);

		try {
			return namedParameterJdbcTemplate.query(sqlQuery, paramMap, new RowMapper<PLStmt>() {

				@Override
				public PLStmt mapRow(ResultSet rs, int rowNum) throws SQLException {
					PLStmt glStmt = new PLStmt();
					if (rs.getDate("txn_dt") != null)
						glStmt.setTxnDate(rs.getDate("txn_dt").toLocalDate());
					glStmt.setTxnNo(rs.getString("gl_txn_no"));
					glStmt.setTxnType(rs.getString("gl_txn_type"));
					if (rs.getString("dr_cr_flg").equalsIgnoreCase("CR")) {
						glStmt.setTxnCrAmt(BigDecimal.valueOf(rs.getDouble("txn_amt")));
						glStmt.setTxnDrAmt(BigDecimal.ZERO);
					} else if (rs.getString("dr_cr_flg").equalsIgnoreCase("DR")) {
						glStmt.setTxnDrAmt(BigDecimal.valueOf(rs.getDouble("txn_amt")));
						glStmt.setTxnCrAmt(BigDecimal.ZERO);
					}
					//glStmt.setRemark(rs.getString("txn_remarks"));
					return glStmt;
				}
			});
		} catch (DataAccessException e) {
			log.error("Exception caused due to : {}", e.getMessage());
			throw new DataAccessResourceFailureException("Failed to get GL statement");
		}
	}	
	
	

}
