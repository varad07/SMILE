package in.ecgc.smile.erp.reporting.jasper.be.repository.cs;

import java.util.List;

import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.EntityGL;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.TrialBalance;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.TrialBalanceReport;
import in.ecgc.smile.erp.reporting.jasper.be.model.cs.Employee;
import in.ecgc.smile.erp.reporting.jasper.be.model.cs.PLStmt;
import in.ecgc.smile.erp.reporting.jasper.be.model.cs.PlWiseSummary;

public interface CreditSocietyDao {

	public Integer generateTrialBalanceAllLocByDate(String inputDate);

	public TrialBalanceReport getTrialBalacneAllLoc(String inputDate, Boolean isNil);

	public Integer generateBankReconciliation(String inputDate, Boolean isNil);

	public TrialBalanceReport getBankReconciliation(String inputDate, Boolean isNil);
	
	public TrialBalance getByLogicalLoc(String balanceDate, String mainglCd, String subglCd,
			String glName, String glType);

	public List<EntityGL> getAllGlCodes();

	public List<Employee> getAllEmployeePl(String mainGlCd, String subGlCd);

	public List<PLStmt> getGLCodeStatementbyLoc(PlWiseSummary plwiseSummary);

	public TrialBalance getGlRangeByDate(String inputDate, String mainglCd, String subglCd, String plCd);

	public TrialBalance getGlRangeByDateGL(String mainglCd, String subglCd,String inputDate);

	public List<PLStmt> getGLCodeStatementForCashBankBook(PlWiseSummary plwiseSummary);


}
