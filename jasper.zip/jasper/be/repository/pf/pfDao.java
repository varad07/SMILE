package in.ecgc.smile.erp.reporting.jasper.be.repository.pf;

import java.util.List;

import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.TrialBalanceReport;
import in.ecgc.smile.erp.reporting.jasper.be.model.pf.Pf_r02;
import in.ecgc.smile.erp.reporting.jasper.be.model.pf.Pf_r07;

public interface pfDao {

	public List<Pf_r02> getListPf_r02(String personal_ledger_code);

	public List<Pf_r07> getActuarialValuationReport_r07();

	public Integer generateTrialBalanceByDate(String inputDate);

	public TrialBalanceReport getpfTrialBalacneAllLoc(String inputDate, Boolean isNil);
	
}
