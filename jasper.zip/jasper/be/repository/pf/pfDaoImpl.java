package in.ecgc.smile.erp.reporting.jasper.be.repository.pf;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcOperations;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.TrialBalanceReport;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.TrialBalanceTxnDtl;
import in.ecgc.smile.erp.reporting.jasper.be.model.mktg.FormIXAgencyOrgStmt;
import in.ecgc.smile.erp.reporting.jasper.be.model.pf.Pf_r02;
import in.ecgc.smile.erp.reporting.jasper.be.model.pf.Pf_r07;
import in.ecgc.smile.erp.reporting.jasper.be.utils.FORMATS;
import in.ecgc.smile.erp.reporting.jasper.be.utils.accounts.TrialBalanceSqlQueries;
import in.ecgc.smile.erp.reporting.jasper.be.utils.pf.PfQueries;

@Repository
public class pfDaoImpl implements pfDao {

	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	private JdbcOperations jdbcOperations;
	private static final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(pfDaoImpl.class);

	public pfDaoImpl(DataSource dataSource) {
		super();
		jdbcOperations = new JdbcTemplate(dataSource);
		namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(dataSource);
	}

	@Override
	public List<Pf_r02> getListPf_r02(String personal_ledger_code) throws DataAccessException {

		String sql = PfQueries.PF_R02;
		System.out.println("sql,code" + sql + personal_ledger_code);

		MapSqlParameterSource param = new MapSqlParameterSource();
		param.addValue("personal_ledger_cd", personal_ledger_code);

		List<Pf_r02> result;
		try {
			result = namedParameterJdbcTemplate.query(sql, param, new pf_r02_RowMapper());
			if (result != null) {
				return result;
			} else {
				return null;
			}
		} catch (DataAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}

		/*
		 * String sql =
		 * "select * from accounts_pf.ecgc_pf_gl_br_bal_yr where maingl_cd='3870'";
		 * //PfQueries.PF_R02; System.out.println("sql,code"+sql+personal_ledger_code);
		 * 
		 * 
		 * 
		 * MapSqlParameterSource param = new MapSqlParameterSource();
		 * param.addValue("personal_ledger_cd", personal_ledger_code);
		 * 
		 * List<Pf_r02> result; try { List<Map<String, Object>> list
		 * =namedParameterJdbcTemplate.queryForList(sql, param);
		 * //namedParameterJdbcTemplate.query(sql, param, );
		 * 
		 * System.out.println("data"+list);
		 * 
		 * return null;
		 * 
		 * } catch (DataAccessException e) { // TODO Auto-generated catch block
		 * e.printStackTrace(); return null; }
		 */

	}

	class pf_r02_RowMapper implements RowMapper<Pf_r02> {
		@Override
		public Pf_r02 mapRow(ResultSet rs, int rowNum) throws SQLException {
			Pf_r02 Pf_r02 = new Pf_r02();

			// Pf_r02.setPersonal_ledger_code(rs.getString("personal_ledger_code"));
			Pf_r02.setPersonal_ledger_cd(rs.getString("personal_ledger_cd"));
			Pf_r02.setBalance(rs.getBigDecimal("balance"));
			Pf_r02.setGl_code(rs.getString("GL_code"));
			Pf_r02.setGl_name(rs.getString("gl_name"));
			Pf_r02.setMaingl_cd(rs.getString("maingl_cd"));
			Pf_r02.setSubgl_cd(rs.getString("subgl_cd"));

			return Pf_r02;
		}
	}

	@Override
	public List<Pf_r07> getActuarialValuationReport_r07() {
		String sql = PfQueries.PF_R07;

		List<Pf_r07> result;
		try {
			result = namedParameterJdbcTemplate.query(sql, new pf_r07_RowMapper());
			if (result != null) {
				return result;
			} else {
				return null;
			}
		} catch (DataAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}

	}

	class pf_r07_RowMapper implements RowMapper<Pf_r07> {
		@Override
		public Pf_r07 mapRow(ResultSet rs, int rowNum) throws SQLException {
			Pf_r07 pf_r07 = new Pf_r07();

			// Pf_r02.setPersonal_ledger_code(rs.getString("personal_ledger_code"));
			pf_r07.setJoin_date(rs.getString("join_date"));
			pf_r07.setPan_eff_frm_dt(rs.getString("pan_eff_frm_dt"));
			pf_r07.setPl_code(rs.getString("pl_code"));
			pf_r07.setEmp_firstname(rs.getString("emp_firstname"));
			pf_r07.setBalance(rs.getDouble("balance"));
			pf_r07.setGl_code(rs.getString("gl_code"));
			pf_r07.setGl_name(rs.getString("gl_name"));

			return pf_r07;
		}
	}

	@Override
	public Integer generateTrialBalanceByDate(String inputDate) {
		Map<String, Object> paraMap = new HashMap<>();

		try {
			paraMap.put("input_date", LocalDate.parse(inputDate, FORMATS.DATE_FORMATS));
		} catch (DateTimeParseException e) {
			throw new RuntimeException("Date Format is Incorrect");
		}

		try {
			return namedParameterJdbcTemplate.queryForObject(TrialBalanceSqlQueries.GETERATE_PF_TRIAL_BALANCE_ALL_LOC,
					paraMap, new RowMapper<Integer>() {
						@Override
						public Integer mapRow(ResultSet rs, int rowNum) throws SQLException {
							return rs.getInt(1);
						}
					});
		} catch (EmptyResultDataAccessException e) {
			throw new RuntimeException("Failed to Generate PF Trial Balance For Given Date : " + inputDate
					+ " ; Exeception caused due to : " + e.getMessage());

		}
	}

	@Override
	public TrialBalanceReport getpfTrialBalacneAllLoc(String inputDate, Boolean isNil) {
		Map<String, Object> paraMap = new HashMap<>();
		paraMap.put("input_date", LocalDate.parse(inputDate, FORMATS.DATE_FORMATS));
		TrialBalanceReport trialBalanceAllLoc = new TrialBalanceReport();

		List<TrialBalanceTxnDtl> trialBal = new ArrayList<TrialBalanceTxnDtl>();

		String query = null;

		if (isNil) {
			query = TrialBalanceSqlQueries.GET_PF_TRIAL_BALANCE_ALL_LOC;
		} else {
			query = TrialBalanceSqlQueries.GET_PF_TRIAL_BALANCE_ALL_LOC_NOT_NIL;
		}

		trialBal = namedParameterJdbcTemplate.query(query, paraMap, new RowMapper<TrialBalanceTxnDtl>() {

			@Override
			public TrialBalanceTxnDtl mapRow(ResultSet rs, int rowNum) throws SQLException {
				TrialBalanceTxnDtl trialBalanceAllLocDtl = new TrialBalanceTxnDtl();

				trialBalanceAllLocDtl.setInputDate(LocalDate.parse(inputDate, FORMATS.DATE_FORMATS));
				trialBalanceAllLocDtl.setMainglCd(rs.getString("maingl_cd"));
				trialBalanceAllLocDtl.setSubGlCd(rs.getString("subgl_cd"));
				trialBalanceAllLocDtl.setGlName(rs.getString("gl_name"));
				trialBalanceAllLocDtl.setGlType(rs.getString("gl_type"));
				trialBalanceAllLocDtl.setDrAmount(rs.getBigDecimal("dr_amount"));
				trialBalanceAllLocDtl.setCrAmount(rs.getBigDecimal("cr_amount"));
				return trialBalanceAllLocDtl;
			}
		});

		List<String> glTypeList = new ArrayList<>();
		glTypeList.add("ASST");
		glTypeList.add("LIAB");
		glTypeList.add("INCM");
		glTypeList.add("EXPD");

		for (String glType : glTypeList) {
			Map<String, Object> paraMap2 = new HashMap<>();
			paraMap2.put("glType", glType);
			paraMap2.put("input_date", LocalDate.parse(inputDate, FORMATS.DATE_FORMATS));

			namedParameterJdbcTemplate.query(TrialBalanceSqlQueries.GET_PF_TRIAL_BALANCE_ALL_LOC_DR_CR_AMOUNT, paraMap2,
					new RowMapper<Map<String, BigDecimal>>() {

						@Override
						public Map<String, BigDecimal> mapRow(ResultSet rs, int rowNum) throws SQLException {

							Map<String, BigDecimal> amountMap = new HashMap<String, BigDecimal>();

							amountMap.put("crAmount", rs.getBigDecimal("total_cr"));
							amountMap.put("drAmount", rs.getBigDecimal("total_dr"));

							if (glType.equals("ASST")) {
								trialBalanceAllLoc.setAsstCrAmount(amountMap.get("crAmount"));
								trialBalanceAllLoc.setAsstDrAmount(amountMap.get("drAmount"));
							} else if (glType.equals("LIAB")) {
								trialBalanceAllLoc.setLiabCrAmount(amountMap.get("crAmount"));
								trialBalanceAllLoc.setLiabDrAmount(amountMap.get("drAmount"));
							} else if (glType.equals("INCM")) {
								trialBalanceAllLoc.setIncmCrAmount(amountMap.get("crAmount"));
								trialBalanceAllLoc.setIncmDrAmount(amountMap.get("drAmount"));
							} else if (glType.equals("EXPD")) {
								trialBalanceAllLoc.setExpdCrAmount(amountMap.get("crAmount"));
								trialBalanceAllLoc.setExpdDrAmount(amountMap.get("drAmount"));
							}

							return amountMap;
						}
					});

		} // for

		BigDecimal totalCr = trialBalanceAllLoc.getAsstCrAmount().add(trialBalanceAllLoc.getLiabCrAmount())
				.add(trialBalanceAllLoc.getExpdCrAmount()).add(trialBalanceAllLoc.getIncmCrAmount());
		BigDecimal totalDr = trialBalanceAllLoc.getAsstDrAmount().add(trialBalanceAllLoc.getLiabDrAmount())
				.add(trialBalanceAllLoc.getExpdDrAmount()).add(trialBalanceAllLoc.getIncmDrAmount());

		trialBalanceAllLoc.setTotalCrAmount(totalCr);
		trialBalanceAllLoc.setTotalDrAmount(totalDr);

		trialBalanceAllLoc.setTrialBalanceAllLocDtlList(trialBal);
		return trialBalanceAllLoc;
	}

}
