package in.ecgc.smile.erp.reporting.jasper.be.repository.common;

import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;

public interface CommonMasterDao {
    public List<Map<String,Object>> getAllLogicalLocCd() throws DataAccessException;

    public List<Map<String,Object>> getAllCountryName() throws DataAccessException;

}
