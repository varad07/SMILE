package in.ecgc.smile.erp.reporting.jasper.be.repository.common;

import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class CommonMasterDaoImpl implements CommonMasterDao {

    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
    private final Logger logger = org.slf4j.LoggerFactory.getLogger(this.getClass());

    public CommonMasterDaoImpl(DataSource dataSource) {
        super();
        namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(dataSource);
    }

    public List<Map<String,Object>> getAllLogicalLocCd() throws DataAccessException {
        final String query = "select distinct  office_id,office_name from org_struct.ecgc_hrd_office_mst where status ='A' and office_type_id_fk in ('BO','RO','HO') order by office_id asc";

        try {
            return namedParameterJdbcTemplate.queryForList(query, new MapSqlParameterSource());
        } catch (DataAccessException e) {
            e.printStackTrace();
            throw e;
        }

    }

    public List<Map<String,Object>> getAllCountryName() throws DataAccessException {
        final String query = "select distinct country_id, country_name from country.ecgc_cud_country_mst order by country_name asc;";

        try {
            return namedParameterJdbcTemplate.queryForList(query, new MapSqlParameterSource());
        } catch (DataAccessException e) {
            e.printStackTrace();
            throw e;
        }

    }

}
