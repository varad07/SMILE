package in.ecgc.smile.erp.reporting.jasper.be.repository.common;

import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;

import in.ecgc.smile.erp.reporting.jasper.be.model.reports.Report;
import in.ecgc.smile.erp.reporting.jasper.be.utils.Pair;
import in.ecgc.smile.erp.reporting.jasper.be.utils.queries.DaoQueryInterface;

public interface ReportMetaDataDao {
    public <T extends Enum<T> & DaoQueryInterface> Pair<Report, Exception> getReportForReportId(String reportId,
            MapSqlParameterSource paramMap,
            Class<T> queryClass);

}
