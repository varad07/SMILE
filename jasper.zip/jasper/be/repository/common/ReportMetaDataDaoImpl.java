package in.ecgc.smile.erp.reporting.jasper.be.repository.common;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;
import org.springframework.context.NoSuchMessageException;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import in.ecgc.smile.erp.reporting.jasper.be.model.reports.Report;
import in.ecgc.smile.erp.reporting.jasper.be.model.reports.ReportTable;
import in.ecgc.smile.erp.reporting.jasper.be.model.reports.ReportTable.SummaryType;
import in.ecgc.smile.erp.reporting.jasper.be.utils.Pair;
import in.ecgc.smile.erp.reporting.jasper.be.utils.queries.DaoQueryInterface;

@Repository
public class ReportMetaDataDaoImpl implements ReportMetaDataDao {

    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    private final Logger logger = org.slf4j.LoggerFactory.getLogger(this.getClass());

    @Autowired
    @Qualifier("reportMessageSource")
    MessageSource messageSource;

    public ReportMetaDataDaoImpl(DataSource dataSource) {
        super();
        namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(dataSource);
    }

    public <T extends Enum<T> & DaoQueryInterface> Pair<Report, Exception> getReportForReportId(String reportId,
            MapSqlParameterSource paramMap,
            Class<T> queryClass) {
        try {
            Map<String, Object> values = new HashMap<>(paramMap.getValues());

            for (Entry<String, Object> es : values.entrySet()) {
                if (String.valueOf(es.getValue()).equalsIgnoreCase("ALL")) {
                    values.replace(es.getKey(), "%%");
                }
            }

            values.put("claType", Arrays.asList(String.valueOf(values.get("claType")).split(",")));

            Report report = getReport(reportId.trim().toUpperCase(), values, queryClass);

            return new Pair<>(report, null);
        } catch (IllegalArgumentException | NullPointerException | DataAccessException e) {
            e.printStackTrace();
            logger.error("Error  in getReportForReportId with message {}", e.getMessage());
            return new Pair<>(null, e);
        }

    }

    private <T extends Enum<T> & DaoQueryInterface> Report getReport(String reportId, Map<String, Object> paramMap,
            Class<T> queryClass)
            throws DataAccessException, NullPointerException {

        Report report = getReportMetaData(reportId);

        for (ReportTable reportTable : report.getTables()) {
            logger.info("Executing query for Report Id {}", reportTable.getId());
            reportTable
                    .setData(namedParameterJdbcTemplate.query(
                            DaoQueryInterface.getValueOf(queryClass, reportTable.getId()),
                            paramMap,
                            (ResultSetExtractor<List<Map<String, Object>>>) rs -> extractData(rs, reportTable)));
            try {
                if (reportTable.isHasSummary()) {
                    reportTable.setSummary(
                            reportTable.getSummaryType().apply(reportTable.getData(), reportTable.getSummaryKeys()));
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return report;

    }

    private Report getReportMetaData(String reportId) throws DataAccessException, NullPointerException {
        logger.info("Fetching Reports for ReportId {}", reportId);
        Report report = new Report();

        String query = "select report_id,report_title from reporting.jasper_reportmetadata where report_id like :reportId order by report_id;";
        MapSqlParameterSource paramMap = new MapSqlParameterSource().addValue("reportId", reportId.concat("%"));

        List<String> reportIds = namedParameterJdbcTemplate.query(query, paramMap, rs -> {
            ArrayList<String> r = new ArrayList<>();
            while (rs.next()) {
                r.add(rs.getString("report_id"));
                report.setTitle(rs.getString("report_title"));
            }
            return r;
        });

        if (reportIds == null || reportIds.isEmpty()) {
            logger.error("ReportMetaDataDao getReportMetaData.No metadata/record found for Report ID : {}", reportId);
            throw new NullPointerException(String.format("No metadata/record found for Report ID : %s", reportId));
        }

        for (String ri : reportIds) {
            report.getTables().add(getReportTableMetaData(ri.trim().toUpperCase()));
        }

        return report;

    }

    private List<Map<String, Object>> extractData(ResultSet rs, ReportTable reportTable) throws SQLException {
        List<Map<String, Object>> rows = new ArrayList<>();
        ResultSetMetaData metaData = rs.getMetaData();

        Map<String, Object> columns = getColNameList(reportTable.getId(), metaData);
        if (!rs.isBeforeFirst()) {
            rows.add(columns);
        } else {
            while (rs.next()) {
                Iterator<Entry<String, Object>> iterator = columns.entrySet().stream().iterator();
                Map<String, Object> map = new LinkedHashMap<>(columns);
                int i = 1;
                while (iterator.hasNext()) {
                    Entry<String, Object> entry = iterator.next();
                    map.put(entry.getKey(), rs.getObject(i++));
                }
                rows.add(map);
            }
        }

        return rows;
    }

    private ReportTable getReportTableMetaData(String reportId) throws RuntimeException, NullPointerException {
        logger.info("Fetching Jasper Metadata for Report Id : {}", reportId);

        String query = "select report_id,table_title,has_summary,summary_function,summary_cols from reporting.jasper_reportmetadata where report_id = :reportId ;";
        MapSqlParameterSource paramMap = new MapSqlParameterSource().addValue("reportId", reportId);

        return namedParameterJdbcTemplate.query(query, paramMap, rs -> {
            ReportTable reportTable = new ReportTable();
            while (rs.next()) {
                reportTable.setId(rs.getString("report_id"))
                        .setTableTitle(rs.getString("table_title"))
                        .setHasSummary(rs.getBoolean("has_summary"));

                if (reportTable.isHasSummary()) {
                    String sc = rs.getString("summary_cols");
                    reportTable.setSummaryType(SummaryType.getType(rs.getString("summary_function")))
                            .setSummaryKeys(sc == null ? Collections.emptyList() : Arrays.asList(sc.split(",")));
                }
            }
            return reportTable;
        });
    }

    private Map<String, Object> getColNameList(String id, ResultSetMetaData metaData) throws SQLException {
        int columnCount = metaData.getColumnCount();

        Map<String, Object> map = new LinkedHashMap<>();
        for (int i = 1; i <= columnCount; i++) {
            String key = metaData.getColumnLabel(i);
            try {
                String temp = messageSource.getMessage((id + "." + metaData.getColumnLabel(i)).toUpperCase(),
                        null, null).trim();
                map.put(temp == null || temp.isEmpty() ? key : temp, null);

            } catch (NoSuchMessageException e) {
                logger.error("No Such Message Exception {}", e.getLocalizedMessage());
                map.put(key, null);
            }

        }

        return Collections.unmodifiableMap(map);
    }

}
