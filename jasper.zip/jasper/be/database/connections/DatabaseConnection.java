package in.ecgc.smile.erp.reporting.jasper.be.database.connections;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class DatabaseConnection {
	
	@Value("${spring.datasource.url}")
	private String databaseURL;

	@Value("${spring.datasource.username}")
	private String databaseUser;

	@Value("${spring.datasource.password}")
	private String databasePwd;

	public Connection connect() throws SQLException {
		return DriverManager.getConnection(databaseURL, databaseUser, databasePwd);
	}
}
