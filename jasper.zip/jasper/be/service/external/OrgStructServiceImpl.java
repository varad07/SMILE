package in.ecgc.smile.erp.reporting.jasper.be.service.external;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.collections4.map.HashedMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.BranchMaster;
import in.ecgc.smile.erp.reporting.jasper.be.model.external.ParentOfficeMaster;
import in.ecgc.smile.erp.reporting.jasper.be.proxy.OrgStructClient;

@Service
public class OrgStructServiceImpl implements OrgStructService {

	@Autowired
	OrgStructClient orgStructClient;

	private static final Logger log = LoggerFactory.getLogger(OrgStructServiceImpl.class);

	@Override
	public Map<String, String> getParentOfficeDetailsMap() {
		log.info("inside OrgStructServiceImpl#getParentOfficeDetailsMap");

		try {

			List<ParentOfficeMaster> officelocations = orgStructClient.getParentOfficeDetails();

			log.info("Count of Office location received from org struct is : {}", officelocations.size());

			Map<String, String> officeMap = new HashedMap<>();

			officeMap = officelocations.stream()

					.collect(Collectors.toMap(ParentOfficeMaster::getParentOfficeId,
							ParentOfficeMaster::getParentOfficeName));

			officeMap = officeMap.entrySet().stream().sorted(Map.Entry.comparingByKey()).collect(Collectors

					.toMap(Map.Entry::getKey, Map.Entry::getValue, (oldValue, newValue) -> oldValue,
							LinkedHashMap::new));

			log.info("Count of Parent Office location after eleminating departments : {}", officeMap.size());

			return officeMap;

		} catch (ResponseStatusException ex) { // Exception can be handled here or in Controller

			log.error("Got error {}" + ex.getReason());

		}

		catch (Exception e) {

			log.error("Failed to List of Logical Locations :: {}", e);

		}

		return null;

	}

	@Override
	public BranchMaster getBranchDtlsByOfficeId(String logicalLocation) {
		log.info("inside OrgStructServiceImpl#getBranchDtlsByOfficeId");

		try {

			return orgStructClient.getBranchDtlsByOfficeId(logicalLocation);

		} catch (ResponseStatusException ex) { // Exception can be handled here or in Controller

			log.error("Got error {}" + ex.getReason());
		} catch (Exception e) {
			log.error("Failed to Branch By Logical Location :: {}", e);
		}
		return null;
	}
}
