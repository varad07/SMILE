package in.ecgc.smile.erp.reporting.jasper.be.service.external;

import java.util.Map;

import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.BranchMaster;

public interface OrgStructService {

	Map<String, String> getParentOfficeDetailsMap();
	
	BranchMaster getBranchDtlsByOfficeId(String logicalLocation);

}
