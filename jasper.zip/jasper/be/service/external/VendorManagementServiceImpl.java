package in.ecgc.smile.erp.reporting.jasper.be.service.external;

import java.util.List;

import javax.management.ServiceNotFoundException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import in.ecgc.smile.erp.reporting.jasper.be.exceptions.ErrorResponse;
import in.ecgc.smile.erp.reporting.jasper.be.model.external.VendorManagement;
import in.ecgc.smile.erp.reporting.jasper.be.proxy.VendorMgmtClient;

@Service
public class VendorManagementServiceImpl implements VendorManagementService {

	private static final Logger log = LoggerFactory.getLogger(VendorManagementServiceImpl.class);

	@Autowired
	private VendorMgmtClient vendorMgmtClient;

	@Override
	public List<VendorManagement> getAllVendors() throws ServiceNotFoundException {
		log.info("--- getAllVendors() method called ---");
		// List<VendorManagement> vendorList=null;
		try {

			List<VendorManagement> list = vendorMgmtClient.getAllVendor();

			return list;

		} catch (ResponseStatusException ex) { // Exception can be handled here or in Controller
			log.error("Got error: {} ", ex.getReason());
			try {
				// Extract ErrorResponse from Exception
				ErrorResponse errorResponse = new ObjectMapper()
						.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
						.readValue(ex.getReason(), ErrorResponse.class);
				log.error("Error: {} ", errorResponse);
				throw ex;
			} catch (JsonProcessingException e) {
				log.error("Exception while json processing ", e);
			}
		} catch (Exception e) {
			log.error("Failed to List of Vendor :: {}", e);
			throw new ServiceNotFoundException("Vendor service is down. Please Try After Some Time! ");
		}

		return null;
	}

	@Override
	public String getPanByVendorCode(String vendorCode) throws ServiceNotFoundException {
		log.info("--- getVendorById() method called ---");
		// List<VendorManagement> vendorList=null;
		try {

			VendorManagement vendorByVendorCode = vendorMgmtClient.getPanByVendorCode(vendorCode);
			log.info("Vendor Detail : {}", vendorByVendorCode);
			return vendorByVendorCode.getPan();

		} catch (ResponseStatusException ex) { // Exception can be handled here or in Controller
			log.error("Got error: {} ", ex.getReason());
			try {
				// Extract ErrorResponse from Exception
				ErrorResponse errorResponse = new ObjectMapper()
						.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
						.readValue(ex.getReason(), ErrorResponse.class);
				log.error("Error: {} ", errorResponse);
				throw ex;
			} catch (JsonProcessingException e) {
				log.error("Exception while json processing ", e);
			}
		} catch (Exception e) {
			log.error("Failed to List of Vendor :: {}", e);
			throw new ServiceNotFoundException("Vendor service is down. Please Try After Some Time! ");
		}

		return null;
	}

}
