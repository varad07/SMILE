package in.ecgc.smile.erp.reporting.jasper.be.service.external;

import java.util.List;

import javax.management.ServiceNotFoundException;

import in.ecgc.smile.erp.reporting.jasper.be.model.external.VendorManagement;

public interface VendorManagementService {

	List<VendorManagement> getAllVendors() throws ServiceNotFoundException;

	public String getPanByVendorCode(String vendorCode) throws ServiceNotFoundException;
}
