package in.ecgc.smile.erp.reporting.jasper.be.service.accounts;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.EntityGL;
import in.ecgc.smile.erp.reporting.jasper.be.repository.accounts.EntityGLMasterDao;

@Service
public class EntityGLMasterServiceImpl implements EntityGLMasterService {
	// private static final Logger log =
	// LoggerFactory.getLogger(EntityGLMasterServiceImpl.class);
	
	private static final Logger log = LoggerFactory.getLogger(EntityGLMasterServiceImpl.class);

	@Autowired
	EntityGLMasterDao entityGLMasterDao;
	/**
	 * Find GL code details by entityGLCode
	 *
	 * service implementation to find details of GL code
	 *
	 */
	@Override
	public EntityGL findGLByGLCode(String mainGLCode, String subGLCode) {
		log.info("Inside EntityGLMasterServiceImpl#findGLByGLCode");
		return entityGLMasterDao.findGLByGLCode(mainGLCode, subGLCode);
	}
	@Override
	public EntityGL findGLByBankGLCode(String mainGLCode, String subGLCode) {
		log.info("Inside EntityGLMasterServiceImpl#findGLByGLCode");
		return entityGLMasterDao.findGLByBankGLCode(mainGLCode, subGLCode);
	}
	
}
