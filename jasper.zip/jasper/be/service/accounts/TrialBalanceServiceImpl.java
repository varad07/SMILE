package in.ecgc.smile.erp.reporting.jasper.be.service.accounts;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.constraints.NotBlank;

import org.jfree.util.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.ConsTrialBal;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.TrialBalance;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.TrialBalanceReport;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.TrialBalanceTxnDtl;
import in.ecgc.smile.erp.reporting.jasper.be.repository.accounts.TrialBalanceDao;
import in.ecgc.smile.erp.reporting.jasper.be.utils.FORMATS;

@Service
public class TrialBalanceServiceImpl implements TrialBalanceService {

	@Autowired
	TrialBalanceDao trialBalanceDao;

	@Override
	public TrialBalanceReport getTrialBalacneAllLoc(String inputDate, Boolean isNil) {
		// Integer count = trialBalanceDao.getCountOfTrialBalacneAllLoc(inputDate);

		// if(count>0) {
		// System.err.println("Trial Balance Already Present");
		// return trialBalanceDao.getTrialBalacneAllLoc(inputDate, isNil);
		// }else {
		// System.err.println("Trial Balance Not Present");
		Integer txnCount = trialBalanceDao.generateTrialBalanceAllLocByDate(inputDate);
		System.err.println("Trial Balance Count : " + txnCount);

		return trialBalanceDao.getTrialBalacneAllLoc(inputDate, isNil);
		// }

	}

	@Override
	public TrialBalanceReport getTrialBalacneByLoc(String inputDate, String logicalLocation, Boolean isNil) {

		// Integer count = trialBalanceDao.getCountOfTrialBalacneByLoc(inputDate,
		// logicalLocation);

		// if(count>0) {
		// System.err.println("Trial Balance Already Present");
		// return trialBalanceDao.getTrialBalacneByLoc(inputDate, logicalLocation,
		// isNil);
		// }else {
		// System.err.println("Trial Balance Not Present");
		Integer txnCount = trialBalanceDao.generateTrialBalanceByLocDate(inputDate, logicalLocation);
		System.err.println("Trial Balance Count : " + txnCount);

		return trialBalanceDao.getTrialBalacneByLoc(inputDate, logicalLocation, isNil);
		// }

	}

	@Override
	public TrialBalance getTrialBalanceByGLCodeLocation(@NotBlank String logicalLocCd, String balanceDate,
			@NotBlank String mainglCd, @NotBlank String subglCd) {

		return trialBalanceDao.getByLogicalLoc(logicalLocCd, balanceDate, mainglCd, subglCd, "", "");
	}

	@Override
	public Integer generateTrialBalanceByDate(String inputDate) {
		return trialBalanceDao.generateTrialBalanceAllLocByDate(inputDate);
	}

	@Override
	public Integer generateTrialBalanceLocWiseByDate(String inputDate, String logicalLocation) {
		return trialBalanceDao.generateTrialBalanceLocWiseByDate(inputDate, logicalLocation);
	}

	@Override
	public List<String> getEcgcBranchCodeList() {
		return trialBalanceDao.getEcgcBranchCodeList();
	}

	@Override
	public List<String> getAllStateMap() {
		return trialBalanceDao.getAllStateMap();
	}

	@Override
	public TrialBalanceReport getTrialBalacneByState(String inputDate, String state, Boolean isNil) {

		Integer txnCount = trialBalanceDao.generateTrialBalacneByState(inputDate, state);

		return trialBalanceDao.getTrialBalacneByState(inputDate, state, isNil);
	}

	@Override
	public Integer generateTrialBalacneByState(String inputDate, String state) {
		return trialBalanceDao.generateTrialBalacneByState(inputDate, state);
	}

	@Override
	public List<String> getAllRegionMap() {
		return trialBalanceDao.getAllRegionMap();
	}

	@Override
	public TrialBalanceReport getTrialBalacneByRegion(String inputDate, String region, Boolean isNil) {

		Integer txnCount = trialBalanceDao.generateTrialBalacneByRegion(inputDate, region);

		return trialBalanceDao.getTrialBalacneByRegion(inputDate, region, isNil);
	}

	@Override
	public Integer generateTrialBalacneByRegion(String inputDate, String region) {
		return trialBalanceDao.generateTrialBalacneByRegion(inputDate, region);
	}

	@Override
	public TrialBalanceReport getTrialBalacneByGlCode(String mainglCd, String subGlCd, String inputDate,
			Boolean isNil) {
		Log.info("inside TrialBalanceServiceImpl#getTrialBalacneByGlCode");
		return trialBalanceDao.getTrialBalacneByGlCode(mainglCd, subGlCd, inputDate, isNil);
	}

	@Override
	public Integer generateTrialBalacneByGlCode(String mainglCd, String subGlCd, String inputDate) {
		Log.info("inside TrialBalanceServiceImpl#generateTrialBalacneByGlCode");
		return trialBalanceDao.generateTrialBalacneByGlCode(mainglCd, subGlCd, inputDate);
	}

	@Override
	public TrialBalance getByLogicalLoc(String logicalLocation, String balanceDate, String mainglCd, String subglCd,
			String glName, String glType) {
		// Log.info("inside TrialBalanceServiceImpl#getByLogicalLoc : {}, {}, {},
		// {}",logicalLocation, balanceDate, mainglCd, subglCd);
		return trialBalanceDao.getByLogicalLoc(logicalLocation, balanceDate, mainglCd, subglCd, "", "");
	}

	@Override
	public Map<String, List<ConsTrialBal>> getConsolidateTrialBalance(String areaType, String area, String inputDate) {

		Map<String, List<ConsTrialBal>> consTBMap = new HashMap<String, List<ConsTrialBal>>();

		if (areaType.equalsIgnoreCase("State")) {

			List<String> logicalLocList = new ArrayList<String>();

			// Get Logical Location List For Input State

			logicalLocList.add("HOLOG06");
			logicalLocList.add("WROLOG01");
			logicalLocList.add("NAGPURLOG1");
			logicalLocList.add("MUMBAILOG5");
			logicalLocList.add("MUMBAILOG6");
			logicalLocList.add("MUMBAILOG7");
//			logicalLocList.add("HOLOG01");
//			logicalLocList.add("HOLOG02");
//			logicalLocList.add("HOLOG04");
//			logicalLocList.add("HOLOG03");
//			logicalLocList.add("LEBLOG01");
//			logicalLocList.add("PUNELOG01");
//			logicalLocList.add("MUMBAILOG1");
//			logicalLocList.add("BBBLOG01");
//			logicalLocList.add("THANELOG01");
//			logicalLocList.add("MSOUTHLOG1");
//			logicalLocList.add("PEBLOG01");
//			logicalLocList.add("HOLOG05");

			List<ConsTrialBal> consTbList = new ArrayList<ConsTrialBal>();

			for (String logicalLocationCd : logicalLocList) {
				trialBalanceDao.generateTrialBalanceByLocDate(inputDate, logicalLocationCd);

				TrialBalanceReport trialBalacneByLoc = trialBalanceDao.getTrialBalacneByLoc(inputDate,
						logicalLocationCd, false);

				for (TrialBalanceTxnDtl tbDtl : trialBalacneByLoc.getTrialBalanceTxnDtlList()) {
					ConsTrialBal consTB = new ConsTrialBal();
					consTB.setBranchName(logicalLocationCd);
					consTB.setMainGlCd(tbDtl.getMainglCd());
					consTB.setSubGlCd(tbDtl.getSubGlCd());
					consTB.setGlName(tbDtl.getGlName());
					consTB.setGlType(tbDtl.getGlType());
					consTB.setCrAmt(tbDtl.getCrAmount());
					consTB.setDrAmt(tbDtl.getDrAmount());
					consTB.setInputDate(LocalDate.parse(inputDate, FORMATS.DATE_FORMATS));

					consTbList.add(consTB);

				}
				consTBMap.put(logicalLocationCd, consTbList);
			}
		}

		return consTBMap;
	}

}
