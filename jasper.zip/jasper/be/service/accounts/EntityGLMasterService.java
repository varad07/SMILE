package in.ecgc.smile.erp.reporting.jasper.be.service.accounts;

import java.util.List;

import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.EntityGL;

/**
 * GL master create operation Service Interface
 *
 * @version 1.0 22-April-2020
 * @author Sanjali Kesarkar
 */
public interface EntityGLMasterService {

	
	public EntityGL findGLByGLCode(String mainGLCode, String subGLCode);

	public EntityGL findGLByBankGLCode(String mainGLCode, String subGLCode);

}