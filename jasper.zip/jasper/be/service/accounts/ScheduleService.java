package in.ecgc.smile.erp.reporting.jasper.be.service.accounts;

import java.math.BigDecimal;
import java.time.LocalDate;

import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.Schedule1;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.Schedule11;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.Schedule12;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.Schedule13;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.Schedule14;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.Schedule15;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.Schedule2;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.Schedule3;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.Schedule4;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.Schedule5;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.Schedule5A;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.Schedule6;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.Schedule7;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.Schedule8;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.Schedule9;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.TrialBalanceDtl;

public interface ScheduleService {

	Schedule1 getSchedule1(LocalDate date);

	TrialBalanceDtl getTrialBalanceDtl(String scheduleCd, String scheduleItemCd,LocalDate date);
	
	TrialBalanceDtl getTrialBalanceDtlPrv(String scheduleCd, String scheduleItemCd,LocalDate date);

	Schedule2 getSchedule2(LocalDate date);

	Schedule7 getSchedule7(LocalDate date);

	Schedule15 getSchedule15(LocalDate date);

	Schedule5 getSchedule5(LocalDate date, BigDecimal authCapital, BigDecimal authPreCapital);

	Schedule5A getSchedule5A(LocalDate date);

	Schedule9 getSchedule9(LocalDate date);

	Schedule11 getSchedule11(LocalDate date);

	Schedule14 getSchedule14(LocalDate date);

	Schedule13 getSchedule13(LocalDate date);

	Schedule12 getSchedule12(LocalDate date);

	Schedule8 getSchedule8(LocalDate date, Schedule8 schedule8);

	Schedule3 getSchedule3(LocalDate date);

	Schedule6 getSchedule6(LocalDate date);

	Schedule4 getSchedule4(LocalDate date);

	
	
	

	

}
