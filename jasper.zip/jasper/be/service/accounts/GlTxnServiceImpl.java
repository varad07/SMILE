package in.ecgc.smile.erp.reporting.jasper.be.service.accounts;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.EntityGL;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.GLCodeStmtIn;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.GLCodeStmtOut;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.GLRangeStmt;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.GLRangeStmtDtl;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.GLRangeStmtIn;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.GLRangeStmtOut;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.GLStmt;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.GLStmtOut;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.GlStmtIn;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.TdsDetails;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.TrialBalance;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.TrialBalanceIn;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.TcodeLevel.TcodeLevelStmtOut;
import in.ecgc.smile.erp.reporting.jasper.be.model.external.BankBranch;
import in.ecgc.smile.erp.reporting.jasper.be.proxy.BankBranchFeignClient;
import in.ecgc.smile.erp.reporting.jasper.be.proxy.OrgStructClient;
import in.ecgc.smile.erp.reporting.jasper.be.repository.accounts.GlTxnDao;
import in.ecgc.smile.erp.reporting.jasper.be.repository.accounts.TrialBalanceDao;
import in.ecgc.smile.erp.reporting.jasper.be.service.external.OrgStructService;

@Service
public class GlTxnServiceImpl implements GlTxnService {

	private static final Logger log = LoggerFactory.getLogger(GlTxnServiceImpl.class);

	@Autowired
	GlTxnDao txnDao;

	@Autowired
	TrialBalanceService trialBalanceService;

	@Autowired
	TrialBalanceDao trialBalanceDao;

	@Autowired
	BankBranchFeignClient bankBranchFeignClient;

	@Autowired
	EntityGLMasterService entityGlMstService;

	@Autowired(required = true)
	OrgStructService orgStructService;

	@Autowired
	OrgStructClient orgStructClient;

	private Integer counter;

	private Integer glTxnNo;

	public Integer getGlTxnNo() {
		return glTxnNo;
	}

	public void setGlTxnNo(Integer glTxnNo) {
		this.glTxnNo = glTxnNo;
	}

	public Integer getCounter() {
		return counter;
	}

	public void setCounter(Integer counter) {
		this.counter = counter;
	}

	@Override
	public GLStmtOut getTcodewiseGLTxnStatement(GlStmtIn glStmtIn) {
		log.info("Inside GlTxnServiceImpl#getTcodewiseGLTxnStatement_x :{}", glStmtIn);
		GLStmtOut glStmtOut = new GLStmtOut();

		TrialBalanceIn trialBalanceIn = new TrialBalanceIn();
		trialBalanceIn.setLogical_loc_cd(glStmtIn.getLogicallocCd());
		trialBalanceIn.setMaingl_cd(glStmtIn.getMainglCd());
		trialBalanceIn.setSubgl_cd(glStmtIn.getSubglCd());
		trialBalanceIn.setT1(glStmtIn.getT1());
		trialBalanceIn.setT2(glStmtIn.getT2());
		trialBalanceIn.setT3(glStmtIn.getT3());
		trialBalanceIn.setT4(glStmtIn.getT4());
		trialBalanceIn.setT5(glStmtIn.getT5());
		trialBalanceIn.setT6(glStmtIn.getT6());
		trialBalanceIn.setT7(glStmtIn.getT7());
		trialBalanceIn.setT8(glStmtIn.getT8());
		trialBalanceIn.setT9(glStmtIn.getT9());
		trialBalanceIn.setT10(glStmtIn.getT10());
		trialBalanceIn.setT11(glStmtIn.getT11());
		trialBalanceIn.setT12(glStmtIn.getT12());
		trialBalanceIn.setT13(glStmtIn.getT13());
		trialBalanceIn.setT14(glStmtIn.getT14());
		trialBalanceIn.setT15(glStmtIn.getT15());
		trialBalanceIn.setT16(glStmtIn.getT16());
		trialBalanceIn.setT17(glStmtIn.getT17());
		trialBalanceIn.setT18(glStmtIn.getT18());
		trialBalanceIn.setT19(glStmtIn.getT19());
		trialBalanceIn.setT20(glStmtIn.getT20());
		trialBalanceIn.setT21(glStmtIn.getT21());
		trialBalanceIn.setT22(glStmtIn.getT22());
		trialBalanceIn.setT23(glStmtIn.getT23());
		trialBalanceIn.setT24(glStmtIn.getT24());
		trialBalanceIn.setT25(glStmtIn.getT25());
		trialBalanceIn.setT26(glStmtIn.getT26());
		trialBalanceIn.setT27(glStmtIn.getT27());
		trialBalanceIn.setT28(glStmtIn.getT28());
		trialBalanceIn.setT29(glStmtIn.getT29());
		trialBalanceIn.setT30(glStmtIn.getT30());
		trialBalanceIn.setT31(glStmtIn.getT31());
		trialBalanceIn.setT32(glStmtIn.getT32());
		trialBalanceIn.setT33(glStmtIn.getT33());
		trialBalanceIn.setT34(glStmtIn.getT34());
		trialBalanceIn.setT35(glStmtIn.getT35());
		trialBalanceIn.setT36(glStmtIn.getT36());

		if (glStmtIn.getFromDt().getDayOfMonth() == 1 && glStmtIn.getFromDt().getMonthValue() == 4) {
			trialBalanceIn.setDate(glStmtIn.getFromDt()); // From Date
		} else {
			trialBalanceIn.setDate(glStmtIn.getFromDt().minusDays(1)); // From Date
		}

		// log.info("fromdt trialBalanceIn : {}", trialBalanceIn);
		TrialBalance fromDtBal = trialBalanceDao.getByTcodewise(trialBalanceIn);
		glStmtOut.setOpeningCrBal(fromDtBal.getCrAmount());
		glStmtOut.setOpeningDrBal(fromDtBal.getDrAmount());
		log.info("OpeningCrBal & OpeningDrBal: {} {}", fromDtBal.getCrAmount(), fromDtBal.getDrAmount());

		// log.info("todt trialBalanceIn : {}", trialBalanceIn);
		trialBalanceIn.setDate(glStmtIn.getToDt()); // To date
		TrialBalance toDtBal = trialBalanceDao.getByTcodewise(trialBalanceIn);
		glStmtOut.setClosingCrBal(toDtBal.getCrAmount());
		glStmtOut.setClosingDrBal(toDtBal.getDrAmount());
		log.info("ClosingCrBal & ClosingDrBal: {} {}", toDtBal.getCrAmount(), toDtBal.getDrAmount());

		List<GLStmt> glTxnStatement = txnDao.getTCodewiseGLTxnStatement(glStmtIn);

		String balanceType = "";
		String negativeBalanceType = "";

		String glType = entityGlMstService.findGLByGLCode(glStmtIn.getMainglCd(), glStmtIn.getSubglCd()).getGlType();

		BigDecimal balance = BigDecimal.ZERO;

		if (fromDtBal.getDrAmount().compareTo(fromDtBal.getCrAmount()) == 1) {
			balance = fromDtBal.getDrAmount();
			balanceType = "DR";
			negativeBalanceType = "CR";

		} else if (fromDtBal.getCrAmount().compareTo(fromDtBal.getDrAmount()) == 1) {
			balance = fromDtBal.getCrAmount();
			balanceType = "CR";
			negativeBalanceType = "DR";
		} else if (!glType.isEmpty() || glType != null) {
			if (glType.equalsIgnoreCase("ASST") || glType.equalsIgnoreCase("INCM")) {
				balanceType = "DR";
				negativeBalanceType = "CR";
			} else {
				balanceType = "CR";
				negativeBalanceType = "DR";
			}
		}

		if (balanceType.equalsIgnoreCase("CR")) {
			for (GLStmt glStmt : glTxnStatement) {
				if (glStmt.getTxnCrAmt().compareTo(glStmt.getTxnDrAmt()) == 1) {
					balance = glStmt.getTxnCrAmt().add(balance);
					glStmt.setBalance(balance.abs());
					if (balance.compareTo(BigDecimal.ZERO) < 0) {
						glStmt.setBalanceType(negativeBalanceType);
					} else {
						glStmt.setBalanceType(balanceType);
					}

				} else {
					balance = balance.subtract(glStmt.getTxnDrAmt());
					if (balance.compareTo(BigDecimal.ZERO) == -1) {
						glStmt.setBalanceType(negativeBalanceType);
					} else {
						glStmt.setBalanceType(balanceType);
					}
					glStmt.setBalance(balance.abs());
				}
			}
		} else {
			for (GLStmt glStmt : glTxnStatement) {
				if (glStmt.getTxnDrAmt().compareTo(glStmt.getTxnCrAmt()) == 1) {
					balance = glStmt.getTxnDrAmt().add(balance);
					glStmt.setBalance(balance.abs());
					if (balance.compareTo(BigDecimal.ZERO) < 0) {
						glStmt.setBalanceType(negativeBalanceType);
					} else {
						glStmt.setBalanceType(balanceType);
					}

				} else {
					balance = balance.subtract(glStmt.getTxnCrAmt());
					if (balance.compareTo(BigDecimal.ZERO) == -1) {
						glStmt.setBalanceType(negativeBalanceType);
					} else {
						glStmt.setBalanceType(balanceType);
					}
					glStmt.setBalance(balance.abs());
				}

			}
		}
		glStmtOut.setGlStmt(glTxnStatement);

		return glStmtOut;
	}

	@Override
	public TcodeLevelStmtOut getTcodeLevelGLStatement(GlStmtIn glStmtIn) {
		log.info("Inside GlTxnServiceImpl#getTcodeLevelGLStatement :{}", glStmtIn);
		GLStmtOut glStmtOut = new GLStmtOut();

		TrialBalanceIn trialBalanceIn = new TrialBalanceIn();
		trialBalanceIn.setLogical_loc_cd(glStmtIn.getLogicallocCd());
		trialBalanceIn.setMaingl_cd(glStmtIn.getMainglCd());
		trialBalanceIn.setSubgl_cd(glStmtIn.getSubglCd());
		trialBalanceIn.setT1(glStmtIn.getT1());
		trialBalanceIn.setT2(glStmtIn.getT2());
		trialBalanceIn.setT3(glStmtIn.getT3());
		trialBalanceIn.setT4(glStmtIn.getT4());
		trialBalanceIn.setT5(glStmtIn.getT5());
		trialBalanceIn.setT6(glStmtIn.getT6());
		trialBalanceIn.setT7(glStmtIn.getT7());
		trialBalanceIn.setT8(glStmtIn.getT8());
		trialBalanceIn.setT9(glStmtIn.getT9());
		trialBalanceIn.setT10(glStmtIn.getT10());
		trialBalanceIn.setT11(glStmtIn.getT11());
		trialBalanceIn.setT12(glStmtIn.getT12());
		trialBalanceIn.setT13(glStmtIn.getT13());
		trialBalanceIn.setT14(glStmtIn.getT14());
		trialBalanceIn.setT15(glStmtIn.getT15());
		trialBalanceIn.setT16(glStmtIn.getT16());
		trialBalanceIn.setT17(glStmtIn.getT17());
		trialBalanceIn.setT18(glStmtIn.getT18());
		trialBalanceIn.setT19(glStmtIn.getT19());
		trialBalanceIn.setT20(glStmtIn.getT20());
		trialBalanceIn.setT21(glStmtIn.getT21());
		trialBalanceIn.setT22(glStmtIn.getT22());
		trialBalanceIn.setT23(glStmtIn.getT23());
		trialBalanceIn.setT24(glStmtIn.getT24());
		trialBalanceIn.setT25(glStmtIn.getT25());
		trialBalanceIn.setT26(glStmtIn.getT26());
		trialBalanceIn.setT27(glStmtIn.getT27());
		trialBalanceIn.setT28(glStmtIn.getT28());
		trialBalanceIn.setT29(glStmtIn.getT29());
		trialBalanceIn.setT30(glStmtIn.getT30());
		trialBalanceIn.setT31(glStmtIn.getT31());
		trialBalanceIn.setT32(glStmtIn.getT32());
		trialBalanceIn.setT33(glStmtIn.getT33());
		trialBalanceIn.setT34(glStmtIn.getT34());
		trialBalanceIn.setT35(glStmtIn.getT35());
		trialBalanceIn.setT36(glStmtIn.getT36());

		if (glStmtIn.getFromDt().getDayOfMonth() == 1 && glStmtIn.getFromDt().getMonthValue() == 4) {
			trialBalanceIn.setDate(glStmtIn.getFromDt()); // From Date
		} else {
			trialBalanceIn.setDate(glStmtIn.getFromDt().minusDays(1)); // From Date
		}

		// log.info("fromdt trialBalanceIn : {}", trialBalanceIn);
		TrialBalance fromDtBal = trialBalanceDao.getByTcodewise(trialBalanceIn);
		glStmtOut.setOpeningCrBal(fromDtBal.getCrAmount());
		glStmtOut.setOpeningDrBal(fromDtBal.getDrAmount());
		log.info("OpeningCrBal & OpeningDrBal: {} {}", fromDtBal.getCrAmount(), fromDtBal.getDrAmount());

		// log.info("todt trialBalanceIn : {}", trialBalanceIn);
		trialBalanceIn.setDate(glStmtIn.getToDt()); // To date
		TrialBalance toDtBal = trialBalanceDao.getByTcodewise(trialBalanceIn);
		glStmtOut.setClosingCrBal(toDtBal.getCrAmount());
		glStmtOut.setClosingDrBal(toDtBal.getDrAmount());
		log.info("ClosingCrBal & ClosingDrBal: {} {}", toDtBal.getCrAmount(), toDtBal.getDrAmount());

		return txnDao.getTcodeLevelGLStatement(glStmtIn);
	}

	
	
	
	
	@Override
	public GLCodeStmtOut getGLCodeStatementbyLoc(GLCodeStmtIn glCodeStmtIn) {
		log.info("Inside GlTxnServiceImpl#getGLCodeStatementbyLoc (Obj) : {}", glCodeStmtIn);

		GLCodeStmtOut glCodeStmtOut = new GLCodeStmtOut();
		TrialBalance fromDtBal = new TrialBalance();

		if (glCodeStmtIn.getFromDt().getDayOfMonth() == 1 && glCodeStmtIn.getFromDt().getMonthValue() == 4) {
			fromDtBal = trialBalanceDao.getGlRangeByLogicalLoc(glCodeStmtIn.getLogicallocCd(),
					glCodeStmtIn.getFromDt().toString(), glCodeStmtIn.getMainglCd(), glCodeStmtIn.getSubglCd(), "", "");// From
																														// Date
		} else {
			fromDtBal = trialBalanceDao.getGlRangeByLogicalLoc(glCodeStmtIn.getLogicallocCd(),
					glCodeStmtIn.getFromDt().minusDays(1).toString(), glCodeStmtIn.getMainglCd(),
					glCodeStmtIn.getSubglCd(), "", ""); // To
			// Change
		}
		glCodeStmtOut.setOpeningCrBal(fromDtBal.getCrAmount());
		glCodeStmtOut.setOpeningDrBal(fromDtBal.getDrAmount());

		TrialBalance toDtBal = trialBalanceDao.getGlRangeByLogicalLoc(glCodeStmtIn.getLogicallocCd(),
				glCodeStmtIn.getToDt().toString(), glCodeStmtIn.getMainglCd(), glCodeStmtIn.getSubglCd(), "", ""); // To
																													// Change

		glCodeStmtOut.setClosingCrBal(toDtBal.getCrAmount());
		glCodeStmtOut.setClosingDrBal(toDtBal.getDrAmount());

		List<GLStmt> glCodeTxnStatement = txnDao.getGLCodeStatementbyLoc(glCodeStmtIn);

		String balanceType = "";
		String negativeBalanceType = "";

		String glType = entityGlMstService.findGLByGLCode(glCodeStmtIn.getMainglCd(), glCodeStmtIn.getSubglCd())
				.getGlType();

		BigDecimal balance = BigDecimal.ZERO;
		if (fromDtBal.getDrAmount().compareTo(fromDtBal.getCrAmount()) == 1) {
			balance = fromDtBal.getDrAmount();
			balanceType = "DR";
			negativeBalanceType = "CR";

		} else if (fromDtBal.getCrAmount().compareTo(fromDtBal.getDrAmount()) == 1) {
			balance = fromDtBal.getCrAmount();
			balanceType = "CR";
			negativeBalanceType = "DR";
		} else if (!glType.isEmpty() || glType != null) {
			if (glType.equalsIgnoreCase("ASST") || glType.equalsIgnoreCase("INCM")) {
				balanceType = "DR";
				negativeBalanceType = "CR";
			} else {
				balanceType = "CR";
				negativeBalanceType = "DR";
			}
		}

		if (balanceType.equalsIgnoreCase("CR")) {
			for (GLStmt glStmt : glCodeTxnStatement) {
				if (glStmt.getTxnCrAmt().compareTo(glStmt.getTxnDrAmt()) == 1) {
					balance = glStmt.getTxnCrAmt().add(balance);
					glStmt.setBalance(balance.abs());
					if (balance.compareTo(BigDecimal.ZERO) < 0) {
						glStmt.setBalanceType(negativeBalanceType);
					} else {
						glStmt.setBalanceType(balanceType);
					}

				} else {
					balance = balance.subtract(glStmt.getTxnDrAmt());
					if (balance.compareTo(BigDecimal.ZERO) == -1) {
						glStmt.setBalanceType(negativeBalanceType);
					} else {
						glStmt.setBalanceType(balanceType);
					}
					glStmt.setBalance(balance.abs());
				}

			}
		} else {
			for (GLStmt glStmt : glCodeTxnStatement) {
				if (glStmt.getTxnDrAmt().compareTo(glStmt.getTxnCrAmt()) == 1) {
					balance = glStmt.getTxnDrAmt().add(balance);
					glStmt.setBalance(balance.abs());
					if (balance.compareTo(BigDecimal.ZERO) < 0) {
						glStmt.setBalanceType(negativeBalanceType);
					} else {
						glStmt.setBalanceType(balanceType);
					}

				} else {
					balance = balance.subtract(glStmt.getTxnCrAmt());
					if (balance.compareTo(BigDecimal.ZERO) == -1) {
						glStmt.setBalanceType(negativeBalanceType);
					} else {
						glStmt.setBalanceType(balanceType);
					}
					glStmt.setBalance(balance.abs());
				}

			}
		}

		glCodeStmtOut.setGlStmt(glCodeTxnStatement);

		return glCodeStmtOut;

	}

	@Override
	public List<GLStmt> getGLTransactionTypeWiseStatement(String logicallocCd, String txnType, String fromDt,
			String toDt) {
		log.info("Inside GlTxnServiceImpl#getGLTransactionTypeWiseStatement (Obj) : {} {} {} {}", logicallocCd, txnType,
				fromDt, toDt);
		List<GLStmt> glTxnStatement = txnDao.getTransactionTypewiseGLTxnStatement(logicallocCd, txnType, fromDt, toDt);

		for (GLStmt glStmt : glTxnStatement) {
		}
		return glTxnStatement;
	}

	@Override
	public List<GLRangeStmtOut> getGLRangewiseTxnStatement(GLRangeStmtIn glRangeStmtIn) {
		log.info("Inside GlTxnServiceImpl#getGLRangewiseTxnStatement (Obj) : {}", glRangeStmtIn);

		if (glRangeStmtIn.getLogicallocCd().equalsIgnoreCase("ALL")) {

			List<GLRangeStmtOut> glRangeStmtOutList = new ArrayList<>();

			// 1 : Get GL Range List
			List<EntityGL> glRangeList = txnDao.getGLRangeList(glRangeStmtIn.getFromMainglCd(),
					glRangeStmtIn.getFromSubglCd(), glRangeStmtIn.getToMainglCd(), glRangeStmtIn.getToSubglCd());

			List<String> locationList = new ArrayList<String>();

			try {
				locationList = txnDao.getGLRangeLocationList(glRangeStmtIn.getFromMainglCd(),
						glRangeStmtIn.getFromSubglCd(), glRangeStmtIn.getToMainglCd(), glRangeStmtIn.getToSubglCd(),
						glRangeStmtIn.getFromDt().toString(), glRangeStmtIn.getToDt().toString());
				// log.info("Office list map : {}", officeList);

			} catch (Exception e) {

			}
			for (String location : locationList) {

				log.info("1st value of the location " + location);

				String branch = orgStructService.getBranchDtlsByOfficeId(location).getBranchName();

				List<GLRangeStmtDtl> glRangeStmtDtlList = new ArrayList<>();

				GLRangeStmtOut glRangeStmtOut = new GLRangeStmtOut();
				glRangeStmtOut.setLogicalLocCd(location);
				glRangeStmtOut.setBranch(branch);
				// 2 : Iterate over each GL and get statement

				for (EntityGL glCd : glRangeList) {

					log.info("GL Code : {}",
							glCd.getMainglCd().concat(" ").concat(glCd.getSubglCd()).concat(glCd.getGlType()));

					// TrialBalance fromDtBal = new TrialBalance();
					TrialBalance openingTrialBal = new TrialBalance();
					if (glRangeStmtIn.getFromDt().getDayOfMonth() == 1
							&& glRangeStmtIn.getFromDt().getMonthValue() == 4) {
						openingTrialBal = trialBalanceDao.getGlRangeByLogicalLoc(location,
								glRangeStmtIn.getFromDt().toString(), glCd.getMainglCd(), glCd.getSubglCd(),
								glCd.getGlName(), glCd.getGlType());
					} else {
						openingTrialBal = trialBalanceDao.getGlRangeByLogicalLoc(location,
								glRangeStmtIn.getFromDt().minusDays(1).toString(), glCd.getMainglCd(),
								glCd.getSubglCd(), glCd.getGlName(), glCd.getGlType()); // To Change
					}

					TrialBalance closingTrialBal = trialBalanceDao.getGlRangeByLogicalLoc(location,
							glRangeStmtIn.getToDt().toString(), glCd.getMainglCd(), glCd.getSubglCd(), glCd.getGlName(),
							glCd.getGlType());

					openingTrialBal.setGltype(glCd.getGlType());
					closingTrialBal.setGltype(glCd.getGlType());

					GLRangeStmtDtl glStmtDtl = new GLRangeStmtDtl();

					glStmtDtl.setMainGlCd(glCd.getMainglCd());
					glStmtDtl.setSubGlCd(glCd.getSubglCd());
					glStmtDtl.setFromDt(glRangeStmtIn.getFromDt());
					glStmtDtl.setToDt(glRangeStmtIn.getToDt());

					if (openingTrialBal.getCrAmount().compareTo(openingTrialBal.getDrAmount()) > 0) {
						glStmtDtl.setOpeningBal(openingTrialBal.getCrAmount());
						glStmtDtl.setOpeningFlag("CR");
					} else if (openingTrialBal.getDrAmount().compareTo(openingTrialBal.getCrAmount()) > 0) {
						glStmtDtl.setOpeningBal(openingTrialBal.getDrAmount());
						glStmtDtl.setOpeningFlag("DR");
					} else {
						if (openingTrialBal.getGltype().equalsIgnoreCase("ASST")
								|| openingTrialBal.getGltype().equalsIgnoreCase("INCM")) {
							glStmtDtl.setOpeningBal(openingTrialBal.getDrAmount());
							glStmtDtl.setOpeningFlag("DR");
						} else if (openingTrialBal.getGltype().equalsIgnoreCase("LIAB")
								|| openingTrialBal.getGltype().equalsIgnoreCase("EXPD")) {
							glStmtDtl.setOpeningBal(openingTrialBal.getCrAmount());
							glStmtDtl.setOpeningFlag("CR");
						}
					}

					if (closingTrialBal.getCrAmount().compareTo(closingTrialBal.getDrAmount()) > 0) {
						glStmtDtl.setClosingBal(closingTrialBal.getCrAmount());
						glStmtDtl.setClosingFlag("CR");
					} else if (closingTrialBal.getDrAmount().compareTo(closingTrialBal.getCrAmount()) > 0) {
						glStmtDtl.setClosingBal(closingTrialBal.getDrAmount());
						glStmtDtl.setClosingFlag("DR");
					} else {
						if (closingTrialBal.getGltype().equalsIgnoreCase("ASST")
								|| closingTrialBal.getGltype().equalsIgnoreCase("INCM")) {
							glStmtDtl.setClosingBal(closingTrialBal.getDrAmount());
							glStmtDtl.setClosingFlag("DR");
						} else if (closingTrialBal.getGltype().equalsIgnoreCase("LIAB")
								|| closingTrialBal.getGltype().equalsIgnoreCase("EXPD")) {
							glStmtDtl.setClosingBal(closingTrialBal.getCrAmount());
							glStmtDtl.setClosingFlag("CR");
						}

					}

					// glStmtDtl.setClosingBal(closingTrialBal.getCrAmount());

					List<GLRangeStmt> gLcodewiseTxnStatement = txnDao.getGLcodewiseTxnStatement(glCd.getMainglCd(),
							glCd.getSubglCd(), location, glRangeStmtIn.getFromDt(), glRangeStmtIn.getToDt(),
							openingTrialBal);

					glStmtDtl.setGlName(glCd.getGlName());

					glStmtDtl.setGlrangeStmt(gLcodewiseTxnStatement);

					glRangeStmtDtlList.add(glStmtDtl);
				}

				glRangeStmtOut.setGlRangeStmtDtls(glRangeStmtDtlList);

				glRangeStmtOutList.add(glRangeStmtOut);
			}

			return glRangeStmtOutList;

		} else {

			List<GLRangeStmtOut> glRangeStmtOutList = new ArrayList<>();

			// 1 : Get GL Range List
			List<EntityGL> glRangeList = txnDao.getGLRangeList(glRangeStmtIn.getFromMainglCd(),
					glRangeStmtIn.getFromSubglCd(), glRangeStmtIn.getToMainglCd(), glRangeStmtIn.getToSubglCd());

			List<String> locationList = new ArrayList<>();
			locationList.add(glRangeStmtIn.getLogicallocCd());

			for (String location : locationList) {

				String branch = orgStructService.getBranchDtlsByOfficeId(location).getBranchName();

				log.info("2nd value of the location " + location);
				List<GLRangeStmtDtl> glRangeStmtDtlList = new ArrayList<>();

				GLRangeStmtOut glRangeStmtOut = new GLRangeStmtOut();
				glRangeStmtOut.setLogicalLocCd(location);
				glRangeStmtOut.setBranch(branch);
				// 2 : Iterate over each GL and get statement

				for (EntityGL glCd : glRangeList) {

					log.info("GL Code : {}",
							glCd.getMainglCd().concat(" ").concat(glCd.getSubglCd()).concat(glCd.getGlType()));

					TrialBalance openingTrialBal = new TrialBalance();
					if (glRangeStmtIn.getFromDt().getDayOfMonth() == 1
							&& glRangeStmtIn.getFromDt().getMonthValue() == 4) {
						openingTrialBal = trialBalanceDao.getGlRangeByLogicalLoc(location,
								glRangeStmtIn.getFromDt().toString(), glCd.getMainglCd(), glCd.getSubglCd(),
								glCd.getGlName(), glCd.getGlType());
					} else {
						openingTrialBal = trialBalanceDao.getGlRangeByLogicalLoc(location,
								glRangeStmtIn.getFromDt().minusDays(1).toString(), glCd.getMainglCd(),
								glCd.getSubglCd(), glCd.getGlName(), glCd.getGlType()); // To Change
					}

					/*
					 * TrialBalance openingTrialBal =
					 * trialBalanceDao.getGlRangeByLogicalLoc(location,
					 * glRangeStmtIn.getFromDt().minusDays(1).toString(), glCd.getMainglCd(),
					 * glCd.getSubglCd(), glCd.getGlName(), glCd.getGlType());
					 */
					TrialBalance closingTrialBal = trialBalanceDao.getGlRangeByLogicalLoc(location,
							glRangeStmtIn.getToDt().toString(), glCd.getMainglCd(), glCd.getSubglCd(), glCd.getGlName(),
							glCd.getGlType());

					openingTrialBal.setGltype(glCd.getGlType());
					closingTrialBal.setGltype(glCd.getGlType());

					GLRangeStmtDtl glStmtDtl = new GLRangeStmtDtl();

					glStmtDtl.setMainGlCd(glCd.getMainglCd());
					glStmtDtl.setSubGlCd(glCd.getSubglCd());
					glStmtDtl.setFromDt(glRangeStmtIn.getFromDt());
					glStmtDtl.setToDt(glRangeStmtIn.getToDt());

					if (openingTrialBal.getCrAmount().compareTo(openingTrialBal.getDrAmount()) > 0) {
						glStmtDtl.setOpeningBal(openingTrialBal.getCrAmount());
						glStmtDtl.setOpeningFlag("CR");
					} else if (openingTrialBal.getDrAmount().compareTo(openingTrialBal.getCrAmount()) > 0) {
						glStmtDtl.setOpeningBal(openingTrialBal.getDrAmount());
						glStmtDtl.setOpeningFlag("DR");
					} else {
						if (openingTrialBal.getGltype().equalsIgnoreCase("ASST")
								|| openingTrialBal.getGltype().equalsIgnoreCase("INCM")) {
							glStmtDtl.setOpeningBal(openingTrialBal.getDrAmount());
							glStmtDtl.setOpeningFlag("DR");
						} else if (openingTrialBal.getGltype().equalsIgnoreCase("LIAB")
								|| openingTrialBal.getGltype().equalsIgnoreCase("EXPD")) {
							glStmtDtl.setOpeningBal(openingTrialBal.getCrAmount());
							glStmtDtl.setOpeningFlag("CR");
						}
					}

					if (closingTrialBal.getCrAmount().compareTo(closingTrialBal.getDrAmount()) > 0) {
						glStmtDtl.setClosingBal(closingTrialBal.getCrAmount());
						glStmtDtl.setClosingFlag("CR");
					} else if (closingTrialBal.getDrAmount().compareTo(closingTrialBal.getCrAmount()) > 0) {
						glStmtDtl.setClosingBal(closingTrialBal.getDrAmount());
						glStmtDtl.setClosingFlag("DR");
					} else {
						if (closingTrialBal.getGltype().equalsIgnoreCase("ASST")
								|| closingTrialBal.getGltype().equalsIgnoreCase("INCM")) {
							glStmtDtl.setClosingBal(closingTrialBal.getDrAmount());
							glStmtDtl.setClosingFlag("DR");
						} else if (openingTrialBal.getGltype().equalsIgnoreCase("LIAB")
								|| openingTrialBal.getGltype().equalsIgnoreCase("EXPD")) {
							glStmtDtl.setClosingBal(closingTrialBal.getCrAmount());
							glStmtDtl.setClosingFlag("CR");
						}

					}

					// glStmtDtl.setClosingBal(closingTrialBal.getCrAmount());

					List<GLRangeStmt> gLcodewiseTxnStatement = txnDao.getGLcodewiseTxnStatement(glCd.getMainglCd(),
							glCd.getSubglCd(), location, glRangeStmtIn.getFromDt(), glRangeStmtIn.getToDt(),
							openingTrialBal);

					glStmtDtl.setGlName(glCd.getGlName());

					glStmtDtl.setGlrangeStmt(gLcodewiseTxnStatement);

					glRangeStmtDtlList.add(glStmtDtl);
				}

				glRangeStmtOut.setGlRangeStmtDtls(glRangeStmtDtlList);

				glRangeStmtOutList.add(glRangeStmtOut);
			}

			return glRangeStmtOutList;

		}

	}

	@Override
	public GLStmtOut getSubBfwiseGLTxnStatement(GlStmtIn glStmtIn) {
		log.info("Inside GlTxnServiceImpl#getSubBfwiseGLTxnStatement");
		GLStmtOut glStmtOut = new GLStmtOut();

		/*
		 * TrialBalanceIn trialBalanceIn = new TrialBalanceIn();
		 * trialBalanceIn.setLogical_loc_cd(glStmtIn.getLogicallocCd());
		 * trialBalanceIn.setMaingl_cd(glStmtIn.getMainglCd());
		 * trialBalanceIn.setSubgl_cd(glStmtIn.getSubglCd());
		 * trialBalanceIn.setSubBfCd(glStmtIn.getSubBfCd());
		 * trialBalanceIn.setSubBfNameCd(glStmtIn.getSubBfNameCd());
		 * 
		 * trialBalanceIn.setDate(glStmtIn.getFromDt().minusDays(1)); // From Date
		 * 
		 * // This to be replaced // TrialBalance fromDtBal =
		 * trialBalanceDao.getBySubBfwise(trialBalanceIn);
		 * 
		 */
		TrialBalance fromDtBal = new TrialBalance();
		if (glStmtIn.getFromDt().getDayOfMonth() == 1 && glStmtIn.getFromDt().getMonthValue() == 4) {
			log.info("Day 1 and Month 4");
			fromDtBal = trialBalanceDao.getByLogicalLocGLsubBfCdList(glStmtIn.getLogicallocCd(),
					glStmtIn.getFromDt().toString(), glStmtIn.getMainglCd(), glStmtIn.getSubglCd(),
					glStmtIn.getSubBfCdList(), "", "");
		} else {
			log.info("Other Date");
			fromDtBal = trialBalanceDao.getByLogicalLocGLsubBfCdList(glStmtIn.getLogicallocCd(),
					glStmtIn.getFromDt().minusDays(1).toString(), glStmtIn.getMainglCd(), glStmtIn.getSubglCd(),
					glStmtIn.getSubBfCdList(), "", ""); // To Change
		}

		/*
		 * TrialBalance fromDtBal =
		 * trialBalanceDao.getByLogicalLocGLsubBfCdList(glStmtIn.getLogicallocCd(),
		 * glStmtIn.getFromDt().minusDays(1).toString(), glStmtIn.getMainglCd(),
		 * glStmtIn.getSubglCd(), glStmtIn.getSubBfCdList(), "", "");
		 */

		log.info("from date TB : {}", fromDtBal);

		glStmtOut.setOpeningCrBal(fromDtBal.getCrAmount());
		glStmtOut.setOpeningDrBal(fromDtBal.getDrAmount());

		// trialBalanceIn.setDate(glStmtIn.getToDt()); // To date

		// This to be replaced
		// TrialBalance toDtBal = trialBalanceDao.getBySubBfwise(trialBalanceIn);

		TrialBalance toDtBal = trialBalanceDao.getByLogicalLocGLsubBfCdList(glStmtIn.getLogicallocCd(),
				glStmtIn.getToDt().toString(), glStmtIn.getMainglCd(), glStmtIn.getSubglCd(), glStmtIn.getSubBfCdList(),
				"", "");
		log.info("to date TB : {}", toDtBal);

		glStmtOut.setClosingCrBal(toDtBal.getCrAmount());
		glStmtOut.setClosingDrBal(toDtBal.getDrAmount());

		List<GLStmt> glTxnStatement = txnDao.getSubBfListwiseGLTxnStatement(glStmtIn);

		log.info("Gl Stmt count : {}{}", glTxnStatement, glTxnStatement.size());

		// String balanceType = null;
		String balanceType = "";
		String negativeBalanceType = "";

		String glType = entityGlMstService.findGLByGLCode(glStmtIn.getMainglCd(), glStmtIn.getSubglCd()).getGlType();

		/*
		 * if (!glType.isEmpty() || glType != null) { if
		 * (glType.equalsIgnoreCase("ASST") || glType.equalsIgnoreCase("EXPD") ||
		 * glType.equalsIgnoreCase("EXP")) { balanceType = "DR"; } else { balanceType =
		 * "CR"; } }
		 */

		BigDecimal balance = BigDecimal.ZERO;
		if (fromDtBal.getDrAmount().compareTo(fromDtBal.getCrAmount()) == 1) {
			balance = fromDtBal.getDrAmount();
			balanceType = "DR";
			negativeBalanceType = "CR";
		} else if (fromDtBal.getCrAmount().compareTo(fromDtBal.getDrAmount()) == 1) {
			balance = fromDtBal.getCrAmount();
			balanceType = "CR";
			negativeBalanceType = "DR";
		} else if (!glType.isEmpty() || glType != null) {
			if (glType.equalsIgnoreCase("ASST") || glType.equalsIgnoreCase("INCM")) {
				balanceType = "DR";
				negativeBalanceType = "CR";
			} else {
				balanceType = "CR";
				negativeBalanceType = "DR";
			}
		}

		if (balanceType.equalsIgnoreCase("CR")) {
			for (GLStmt glStmt : glTxnStatement) {
				if (glStmt.getTxnCrAmt().compareTo(glStmt.getTxnDrAmt()) == 1) {
					balance = glStmt.getTxnCrAmt().add(balance);
					glStmt.setBalance(balance.abs());
					if (balance.compareTo(BigDecimal.ZERO) < 0) {
						glStmt.setBalanceType(negativeBalanceType);
					} else {
						glStmt.setBalanceType(balanceType);
					}

				} else {
					balance = balance.subtract(glStmt.getTxnDrAmt());
					if (balance.compareTo(BigDecimal.ZERO) == -1) {
						glStmt.setBalanceType(negativeBalanceType);
					} else {
						glStmt.setBalanceType(balanceType);
					}
					glStmt.setBalance(balance.abs());
				}
			}

		} else {
			for (GLStmt glStmt : glTxnStatement) {
				if (glStmt.getTxnDrAmt().compareTo(glStmt.getTxnCrAmt()) == 1) {
					balance = glStmt.getTxnDrAmt().add(balance);
					glStmt.setBalance(balance.abs());
					if (balance.compareTo(BigDecimal.ZERO) < 0) {
						glStmt.setBalanceType(negativeBalanceType);
					} else {
						glStmt.setBalanceType(balanceType);
					}

				} else {
					balance = balance.subtract(glStmt.getTxnCrAmt());
					if (balance.compareTo(BigDecimal.ZERO) == -1) {
						glStmt.setBalanceType(negativeBalanceType);
					} else {
						glStmt.setBalanceType(balanceType);
					}
					glStmt.setBalance(balance.abs());
				}
			}
		}
		glStmtOut.setGlStmt(glTxnStatement);

		return glStmtOut;
	}

	@Override
	public GLStmtOut getTcodeAndSubBfwiseGLTxnStatement(GlStmtIn glStmtIn) {
		log.info("Inside GlTxnServiceImpl#getSubBfwiseGLTxnStatement glStmtIn (obj):{}", glStmtIn);
		GLStmtOut glStmtOut = new GLStmtOut();

		TrialBalanceIn trialBalanceIn = new TrialBalanceIn();
		trialBalanceIn.setLogical_loc_cd(glStmtIn.getLogicallocCd());
		trialBalanceIn.setMaingl_cd(glStmtIn.getMainglCd());
		trialBalanceIn.setSubgl_cd(glStmtIn.getSubglCd());
		trialBalanceIn.setSubBfCd(glStmtIn.getSubBfCd());
		trialBalanceIn.setSubBfNameCd(glStmtIn.getSubBfNameCd());
		trialBalanceIn.setT1(glStmtIn.getT1());
		trialBalanceIn.setT2(glStmtIn.getT2());
		trialBalanceIn.setT3(glStmtIn.getT3());
		trialBalanceIn.setT4(glStmtIn.getT4());
		trialBalanceIn.setT5(glStmtIn.getT5());
		trialBalanceIn.setT6(glStmtIn.getT6());
		trialBalanceIn.setT7(glStmtIn.getT7());
		trialBalanceIn.setT8(glStmtIn.getT8());
		trialBalanceIn.setT9(glStmtIn.getT9());
		trialBalanceIn.setT10(glStmtIn.getT10());
		trialBalanceIn.setT11(glStmtIn.getT11());
		trialBalanceIn.setT12(glStmtIn.getT12());
		trialBalanceIn.setT13(glStmtIn.getT13());
		trialBalanceIn.setT14(glStmtIn.getT14());
		trialBalanceIn.setT15(glStmtIn.getT15());
		trialBalanceIn.setT16(glStmtIn.getT16());
		trialBalanceIn.setT17(glStmtIn.getT17());
		trialBalanceIn.setT18(glStmtIn.getT18());
		trialBalanceIn.setT19(glStmtIn.getT19());
		trialBalanceIn.setT20(glStmtIn.getT20());
		trialBalanceIn.setT21(glStmtIn.getT21());
		trialBalanceIn.setT22(glStmtIn.getT22());
		trialBalanceIn.setT23(glStmtIn.getT23());
		trialBalanceIn.setT24(glStmtIn.getT24());
		trialBalanceIn.setT25(glStmtIn.getT25());
		trialBalanceIn.setT26(glStmtIn.getT26());
		trialBalanceIn.setT27(glStmtIn.getT27());
		trialBalanceIn.setT28(glStmtIn.getT28());
		trialBalanceIn.setT29(glStmtIn.getT29());
		trialBalanceIn.setT30(glStmtIn.getT30());
		trialBalanceIn.setT31(glStmtIn.getT31());
		trialBalanceIn.setT32(glStmtIn.getT32());
		trialBalanceIn.setT33(glStmtIn.getT33());
		trialBalanceIn.setT34(glStmtIn.getT34());
		trialBalanceIn.setT35(glStmtIn.getT35());
		trialBalanceIn.setT36(glStmtIn.getT36());

		String fromDt = glStmtIn.getFromDt().minusDays(1).toString(); // From Date

		List<GLStmt> glTxnStatement = txnDao.getTcodeAndSubBfwiseGLTxnStatement(glStmtIn);

		TrialBalance fromDtBal = new TrialBalance();
		if (glStmtIn.getFromDt().getDayOfMonth() == 1 && glStmtIn.getFromDt().getMonthValue() == 4) {
			fromDtBal = trialBalanceDao.getByLogicalLocGLsubBfCd(glStmtIn.getLogicallocCd(), fromDt,
					glStmtIn.getMainglCd(), glStmtIn.getSubglCd(), glStmtIn.getSubBfCd(), "", "");
		} else {
			fromDtBal = trialBalanceDao.getByLogicalLocGLsubBfCd(glStmtIn.getLogicallocCd(), fromDt,
					glStmtIn.getMainglCd(), glStmtIn.getSubglCd(), glStmtIn.getSubBfCd(), "", ""); // To Change
		}

		// TrialBalance fromDtBal =
		// trialBalanceDao.getByLogicalLocGLsubBfCd(glStmtIn.getLogicallocCd(), fromDt,
		// glStmtIn.getMainglCd(), glStmtIn.getSubglCd(), glStmtIn.getSubBfCd(), "",
		// "");

		glStmtOut.setOpeningCrBal(fromDtBal.getCrAmount());
		glStmtOut.setOpeningDrBal(fromDtBal.getDrAmount());

		String toDt = glStmtIn.getToDt().toString(); // To date

		TrialBalance toDtBal = trialBalanceDao.getByLogicalLocGLsubBfCd(glStmtIn.getLogicallocCd(), toDt,
				glStmtIn.getMainglCd(), glStmtIn.getSubglCd(), glStmtIn.getSubBfCd(), "", "");

		glStmtOut.setClosingCrBal(toDtBal.getCrAmount());
		glStmtOut.setClosingDrBal(toDtBal.getDrAmount());

		String balanceType = null;
		String glType = entityGlMstService.findGLByGLCode(glStmtIn.getMainglCd(), glStmtIn.getSubglCd()).getGlType();

		if (!glType.isEmpty() || glType != null) {
			if (glType.equalsIgnoreCase("ASST") || glType.equalsIgnoreCase("EXPD") || glType.equalsIgnoreCase("EXP")) {
				balanceType = "DR";
			} else {
				balanceType = "CR";
			}
		}

		BigDecimal balance = BigDecimal.ZERO;
		if (fromDtBal.getDrAmount().compareTo(fromDtBal.getCrAmount()) == 1) {
			balance = fromDtBal.getDrAmount();
		} else if (fromDtBal.getCrAmount().compareTo(fromDtBal.getDrAmount()) == 1) {
			balance = fromDtBal.getCrAmount();
		}

		if (balanceType.equalsIgnoreCase("CR")) {
			for (GLStmt glStmt : glTxnStatement) {
				if (glStmt.getTxnCrAmt().compareTo(glStmt.getTxnDrAmt()) == 1) {
					balance = glStmt.getTxnCrAmt().add(balance);
					glStmt.setBalance(balance.abs());
					if (balance.compareTo(BigDecimal.ZERO) < 0) {
						glStmt.setBalanceType("DR");
					} else {
						glStmt.setBalanceType("CR");
					}

				} else {
					balance = balance.subtract(glStmt.getTxnDrAmt());
					if (balance.compareTo(BigDecimal.ZERO) == -1) {
						glStmt.setBalanceType("DR");
					} else {
						glStmt.setBalanceType("CR");
					}
					glStmt.setBalance(balance.abs());
				}

			}
		} else {
			for (GLStmt glStmt : glTxnStatement) {
				if (glStmt.getTxnDrAmt().compareTo(glStmt.getTxnCrAmt()) == 1) {
					balance = glStmt.getTxnDrAmt().add(balance);
					glStmt.setBalance(balance.abs());
					if (balance.compareTo(BigDecimal.ZERO) < 0) {
						glStmt.setBalanceType("CR");
					} else {
						glStmt.setBalanceType("DR");
					}

				} else {
					balance = balance.subtract(glStmt.getTxnCrAmt());
					if (balance.compareTo(BigDecimal.ZERO) == -1) {
						glStmt.setBalanceType("CR");
					} else {
						glStmt.setBalanceType("DR");
					}
					glStmt.setBalance(balance.abs());
				}

			}
		}
		glStmtOut.setGlStmt(glTxnStatement);

		return glStmtOut;
	}

	@Override
	public List<TdsDetails> getdetailsOfAmtPaidUnderTDSForYear(String logicallocCd, String fiscalYear) {
		log.info("Inside GlTxnServiceImpl#getdetailsOfAmtPaidUnderTDSForYear");
		List<TdsDetails> tdsDetails = txnDao.getdetailsOfAmtPaidUnderTDSForYear(logicallocCd, fiscalYear);
		return tdsDetails;
	}

	@Override
	public String findBankByLogicalLocation(String logicalLocCode) {
		log.info("findBankByLogicalLocation is here: {}", logicalLocCode);

		BankBranch bankByLogicalLocation = bankBranchFeignClient.findBankByLogicalLocation(logicalLocCode);
		log.info("bankByLogicalLocation is here  : {}", bankByLogicalLocation);

		return bankByLogicalLocation.getTanNo();
	}
}
