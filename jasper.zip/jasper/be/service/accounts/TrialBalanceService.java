package in.ecgc.smile.erp.reporting.jasper.be.service.accounts;

import java.util.List;
import java.util.Map;

import javax.validation.constraints.NotBlank;

import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.ConsTrialBal;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.TrialBalance;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.TrialBalanceReport;

public interface TrialBalanceService {

	
	public TrialBalanceReport getTrialBalacneAllLoc(String inputDate, Boolean isNil);
	
	public TrialBalanceReport getTrialBalacneByLoc(String inputDate, String logicalLocation, Boolean isNil);
	
	public TrialBalance getByLogicalLoc(String logicalLocation, String balanceDate, String mainglCd, String subglCd,
			String glName, String glType);
	
	public Integer generateTrialBalanceLocWiseByDate(String inputDate,String logicalLocation);
	
	public TrialBalance getTrialBalanceByGLCodeLocation(@NotBlank String logicalLocCd,  String balanceDate, @NotBlank String mainglCd, @NotBlank String subglCd);
	
	public Integer generateTrialBalanceByDate(String inputDate);
	public List<String> getEcgcBranchCodeList();

	public List<String> getAllStateMap();

	public TrialBalanceReport getTrialBalacneByState(String inputDate, String state, Boolean isNil);

	public Integer generateTrialBalacneByState(String inputDate, String state);

	public List<String> getAllRegionMap();

	public TrialBalanceReport getTrialBalacneByRegion(String inputDate, String region, Boolean isNil);

	public Integer generateTrialBalacneByRegion(String inputDate, String region);

	public TrialBalanceReport getTrialBalacneByGlCode(String mainglCd, String subGlCd, String inputDate, Boolean isNil);

	public Integer generateTrialBalacneByGlCode(String mainglCd, String subGlCd, String inputDate);

	public Map<String, List<ConsTrialBal>> getConsolidateTrialBalance(String areaType,  String area, String inputDate);

	
}
