package in.ecgc.smile.erp.reporting.jasper.be.service.accounts;


import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.Schedule1;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.Schedule11;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.Schedule12;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.Schedule13;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.Schedule14;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.Schedule15;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.Schedule2;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.Schedule3;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.Schedule4;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.Schedule5;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.Schedule5A;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.Schedule6;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.Schedule7;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.Schedule8;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.Schedule8A;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.Schedule9;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.TrialBalanceDtl;
import in.ecgc.smile.erp.reporting.jasper.be.repository.accounts.ScheduleDao;
import in.ecgc.smile.erp.sys.auth.be.service.UserInfoService;
import in.ecgc.smile.erp.util.CurrencyFormat;

@Service
public class ScheduleServiceImpl implements ScheduleService {

	private static Logger log = LoggerFactory.getLogger(ScheduleServiceImpl.class);

	@Autowired
	private ScheduleDao scheduleDao;

	@Autowired
	private UserInfoService userInfoService;

	@Override
	public TrialBalanceDtl getTrialBalanceDtl(String scheduleCd, String scheduleItemCd, LocalDate date) {
		return scheduleDao.getScheduleWiseBalance(scheduleCd, scheduleItemCd, date);
	}

	@Override
	public TrialBalanceDtl getTrialBalanceDtlPrv(String scheduleCd, String scheduleItemCd, LocalDate date) {
		return scheduleDao.getScheduleWiseBalancePrv(scheduleCd, scheduleItemCd, date);
	}

	public String amtFormatter(BigDecimal input) {

		if (input.compareTo(BigDecimal.ZERO) < 0) {
			input = input.abs();
			return "(" + new CurrencyFormat().indianCurrencyFormat(input) + ")";
		}

		if (input.compareTo(BigDecimal.ZERO) == 0)
			return "-";

		return new CurrencyFormat().indianCurrencyFormat(input);
	}
	
	//----------------------------------Schedule 1----------------------------------------------------

	@Override
	public Schedule1 getSchedule1(LocalDate date) {

		log.debug("ScheduleServiceImpl-->getSchedule1()");

		Schedule1 schedule1 = null;
		// if data is present directly take values from trail balance table
		if (scheduleDao.checkForInputDt(date) > 0) {

			schedule1 = getSchedule1Data(date);
			// else generate trail balance and then take values
		} else {

			int curtb = scheduleDao.generateTb(date);

			LocalDate prvDt = date.minusYears(1);

			int prvtb = scheduleDao.generateTbPrv(prvDt);

			if (curtb > 0 && prvtb > 0) {
				schedule1 = getSchedule1Data(date);
			}

		}

		return schedule1;
	}

	public Schedule1 getSchedule1Data(LocalDate date) {
		TrialBalanceDtl trialBalance1dot1Dtl = getTrialBalanceDtl("1", "1.1", date);
		TrialBalanceDtl trialBalance1dot2Dtl = getTrialBalanceDtl("1", "1.2", date);
		TrialBalanceDtl trialBalance1dot3Dtl = getTrialBalanceDtl("1", "1.3", date);
		TrialBalanceDtl trialBalance1dot5Dtl = getTrialBalanceDtl("1", "1.5", date);

		LocalDate prvDt = date.minusYears(1);
		TrialBalanceDtl trialBalance1dot1DtlPrv = getTrialBalanceDtlPrv("1", "1.1", prvDt);
		TrialBalanceDtl trialBalance1dot2DtlPrv = getTrialBalanceDtlPrv("1", "1.2", prvDt);
		TrialBalanceDtl trialBalance1dot3DtlPrv = getTrialBalanceDtlPrv("1", "1.3", prvDt);
		TrialBalanceDtl trialBalance1dot5DtlPrv = getTrialBalanceDtlPrv("1", "1.5", prvDt);

		Schedule1 schedule1 = new Schedule1();

		// set all names of schedule 1
		schedule1.setCreatedBy(userInfoService.getName());
		schedule1.setScheduleName("अर्जित प्रीमियम (शुद्ध)/PREMIUM EARNED (NET)");
		schedule1.setScheduleItem1dot1Name(
				"प्रत्यक्ष व्यापार से प्रीमियम - भारत में/Premium from direct business - In India");
		schedule1.setScheduleItem1dot2Name(
				"जोड़ें: पुनर्बीमा पर प्रीमियम स्वीकार किया गया/Add : Premium on reinsurance accepted");
		schedule1.setScheduleItem1dot3Name(
				"कम: पुनर्बीमा पर प्रीमियम सौंप दिया गया/Less : Premium on reinsurance ceded");
		schedule1.setScheduleItem1dot4Name("शुद्ध प्रीमियम/Net Premium");
		schedule1.setScheduleItem1dot5Name(
				"असमाप्त जोखिमों के लिए रिजर्व में बदलाव के लिए समायोजन/Adjustment for change in reserve for unexpired risks");
		schedule1.setFinalScheduleName("कुल अर्जित प्रीमियम (शुद्ध)/Total Premium Earned (Net)");

		// Schedule 1 and itemcode 1.1
		BigDecimal itemCode1_1 = trialBalance1dot1Dtl.getCrAmount().subtract(trialBalance1dot1Dtl.getDrAmount());
		itemCode1_1 = itemCode1_1.divide(BigDecimal.valueOf(1000), 4);
		itemCode1_1=itemCode1_1.setScale(2,RoundingMode.HALF_UP);

		schedule1.setScheduleItem1dot1Amt(amtFormatter(itemCode1_1));

		// Schedule 1 and itemcode 1.1 prv
		BigDecimal itemCode1_1Prv = trialBalance1dot1DtlPrv.getCrAmount()
				.subtract(trialBalance1dot1DtlPrv.getDrAmount());
		itemCode1_1Prv = itemCode1_1Prv.divide(BigDecimal.valueOf(1000), 4);
		itemCode1_1Prv=itemCode1_1Prv.setScale(2,RoundingMode.HALF_UP);

		schedule1.setScheduleItem1dot1PreAmt(amtFormatter(itemCode1_1Prv));

		// Schedule 1 and itemcode 1.2
		BigDecimal itemCode1_2 = trialBalance1dot2Dtl.getCrAmount().subtract(trialBalance1dot2Dtl.getDrAmount());
		itemCode1_2 = itemCode1_2.divide(BigDecimal.valueOf(1000), 4);
		itemCode1_2=itemCode1_2.setScale(2,RoundingMode.HALF_UP);

		schedule1.setScheduleItem1dot2Amt(amtFormatter(itemCode1_2));

		// Schedule 1 and itemcode 1.2 prv
		BigDecimal itemCode1_2Prv = trialBalance1dot2DtlPrv.getCrAmount()
				.subtract(trialBalance1dot2DtlPrv.getDrAmount());
		itemCode1_2Prv = itemCode1_2Prv.divide(BigDecimal.valueOf(1000), 4);
		itemCode1_2Prv=itemCode1_2Prv.setScale(2,RoundingMode.HALF_UP);

		schedule1.setScheduleItem1dot2PreAmt(amtFormatter(itemCode1_2Prv));

		// Schedule 1 and itemcode 1.3
		BigDecimal itemCode1_3 = trialBalance1dot3Dtl.getDrAmount().subtract(trialBalance1dot3Dtl.getCrAmount());
		itemCode1_3 = itemCode1_3.divide(BigDecimal.valueOf(1000),4);
		itemCode1_3=itemCode1_3.setScale(2,RoundingMode.HALF_UP);

		schedule1.setScheduleItem1dot3Amt(amtFormatter(itemCode1_3));

		// Schedule 1 and itemcode 1.3 prv
		BigDecimal itemCode1_3Prv = trialBalance1dot3DtlPrv.getDrAmount()
				.subtract(trialBalance1dot3DtlPrv.getCrAmount());
		itemCode1_3Prv = itemCode1_3Prv.divide(BigDecimal.valueOf(1000), 4);
		itemCode1_3Prv = itemCode1_3Prv.setScale(2,RoundingMode.HALF_UP );
		schedule1.setScheduleItem1dot3PreAmt(amtFormatter(itemCode1_3Prv));

		// Schedule 1 and itemcode 1.4
		BigDecimal itemCode1_4 = itemCode1_1.subtract(itemCode1_3);
		schedule1.setScheduleItem1dot4Amt(amtFormatter(itemCode1_4));

		// Schedule 1 and itemcode 1.4 prv
		BigDecimal itemCode1_4Prv = itemCode1_1Prv.subtract(itemCode1_3Prv);
		schedule1.setScheduleItem1dot4PreAmt(amtFormatter(itemCode1_4Prv));

		// Schedule 1 and itemcode 1.5
		BigDecimal itemCode1_5 = trialBalance1dot5Dtl.getCrAmount().subtract(trialBalance1dot5Dtl.getDrAmount());
		itemCode1_5 = itemCode1_5.divide(BigDecimal.valueOf(1000), 4);
		itemCode1_5 = itemCode1_5.setScale(2,RoundingMode.HALF_UP);
		schedule1.setScheduleItem1dot5Amt(amtFormatter(itemCode1_5));

		// Schedule 1 and itemcode 1.5 prv
		BigDecimal itemCode1_5Prv = trialBalance1dot5DtlPrv.getCrAmount()
				.subtract(trialBalance1dot5DtlPrv.getDrAmount());
		itemCode1_5Prv = itemCode1_5Prv.divide(BigDecimal.valueOf(1000), 4);
		itemCode1_5Prv = itemCode1_5Prv.setScale(2,RoundingMode.HALF_UP);
		schedule1.setScheduleItem1dot5PreAmt(amtFormatter(itemCode1_5Prv));

		// Schedule 1 and netamt
		BigDecimal finalAmt = itemCode1_4.add(itemCode1_5);
		schedule1.setFinalSchedule1Amt(amtFormatter(finalAmt));

		// Schedule 1 and netamt Prv
		BigDecimal finalAmtPrv = itemCode1_4Prv.add(itemCode1_5Prv);
		schedule1.setFinalSchedule1PreAmt(amtFormatter(finalAmtPrv));

		return schedule1;
	}

	// -------------------------------------------Schedule 2-----------------------------------------------------

	@Override
	public Schedule2 getSchedule2(LocalDate date) {
		log.debug("ScheduleServiceImpl-->getSchedule2()");

		Schedule2 schedule2 = null;
		// if data is present directly take values from trail balance table
		if (scheduleDao.checkForInputDt(date) > 0) {

			schedule2 = getSchedule2Data(date);
			// else generate trail balance and then take values
		} else {

			int curtb = scheduleDao.generateTb(date);

			LocalDate prvDt = date.minusYears(1);

			int prvtb = scheduleDao.generateTbPrv(prvDt);

			if (curtb > 0 && prvtb > 0) {
				schedule2 = getSchedule2Data(date);
			}

		}

		return schedule2;
	}

	public Schedule2 getSchedule2Data(LocalDate date) {

		TrialBalanceDtl trialBalance2dot2Dtl = getTrialBalanceDtl("2", "2.2", date);
		TrialBalanceDtl trialBalance2dot3Dtl = getTrialBalanceDtl("2", "2.3", date);
		TrialBalanceDtl trialBalance2dot4Dtl = getTrialBalanceDtl("2", "2.4", date);
		TrialBalanceDtl trialBalance2dot5dot1Dtl = getTrialBalanceDtl("2", "2.5.1", date);
		TrialBalanceDtl trialBalance2dot5dot2Dtl = getTrialBalanceDtl("2", "2.5.2", date);
		TrialBalanceDtl trialBalance2dot5dot3Dtl = getTrialBalanceDtl("2", "2.5.3", date);
		TrialBalanceDtl trialBalance2dot7Dtl = getTrialBalanceDtl("2", "2.7", date);
		TrialBalanceDtl trialBalance2dot8Dtl = getTrialBalanceDtl("2", "2.8", date);
		TrialBalanceDtl trialBalance2dot10Dtl = getTrialBalanceDtl("2", "2.10", date);
		TrialBalanceDtl trialBalance2dot11Dtl = getTrialBalanceDtl("2", "2.11", date);

		LocalDate prvDt = date.minusYears(1);
		TrialBalanceDtl trialBalance2dot2Prv = getTrialBalanceDtlPrv("2", "2.2", prvDt);
		TrialBalanceDtl trialBalance2dot3Prv = getTrialBalanceDtlPrv("2", "2.3", prvDt);
		TrialBalanceDtl trialBalance2dot4Prv = getTrialBalanceDtlPrv("2", "2.4", prvDt);
		TrialBalanceDtl trialBalance2dot5dot1Prv = getTrialBalanceDtlPrv("2", "2.5.1", prvDt);
		TrialBalanceDtl trialBalance2dot5dot2Prv = getTrialBalanceDtlPrv("2", "2.5.2", prvDt);
		TrialBalanceDtl trialBalance2dot5dot3Prv = getTrialBalanceDtlPrv("2", "2.5.3", prvDt);
		TrialBalanceDtl trialBalance2dot7Prv = getTrialBalanceDtlPrv("2", "2.7", prvDt);
		TrialBalanceDtl trialBalance2dot8Prv = getTrialBalanceDtlPrv("2", "2.8", prvDt);
		TrialBalanceDtl trialBalance2dot10Prv = getTrialBalanceDtlPrv("2", "2.10", prvDt);
		TrialBalanceDtl trialBalance2dot11Prv = getTrialBalanceDtlPrv("2", "2.11", prvDt);

		Schedule2 schedule2 = new Schedule2();

		schedule2.setCreatedBy(userInfoService.getName());
		schedule2.setScheduleItem2dot1Name("दावों का भुगतान किया गया/Claims Paid");
		schedule2.setScheduleItem2dot2Name("प्रत्यक्ष/Direct");
		schedule2.setScheduleItem2dot3Name("जोड़ें : पुनर्बीमा स्वीकृत/Add : Reinsurance accepted");
		schedule2.setScheduleItem2dot4Name("घटाएँ : पुनर्बीमा सौंप दिया गया/Less : Reinsurance ceded ");
		schedule2.setScheduleItem2dot5Name("घटाएँ :/Less :");
		schedule2.setScheduleItem2dot5dot1Name("वर्ष के दौरान पुनर्प्राप्त किया गया/Recovered during the year ");
		schedule2.setScheduleItem2dot5dot2Name(
				"जोड़ें: भुगतान किए गए दावों की वसूली पर प्राप्त ब्याज/Add : Interest received on Recovery of Claims Paid");
		schedule2.setScheduleItem2dot5dot3Name("घटाएँ: पुनर्बीमाकर्ता का हिस्सा/Less : Share of reinsurer");
		schedule2.setScheduleItem2dot6Name("भुगतान किया गया शुद्ध दावा (ए)/Net Claims paid (A)");
		schedule2.setScheduleItem2dot7Name(
				"जोड़ें: वर्ष के अंत में बकाया दावे (पुनर्बीमा को छोड़कर)/Add : Claims Outstanding at the end of the year (net of reinsurance)");
		schedule2.setScheduleItem2dot8Name(
				"वसूली के लिए माइनस प्रावधान (पुनर्बीमा का शुद्ध)/Minus provision for recovery (net of reinsurance)");
		schedule2.setScheduleItem2dot9Name("(बी)/(B)");
		schedule2.setScheduleItem2dot10Name(
				"कम: आरंभ में बकाया दावे (पुनर्बीमा का शुद्ध)/Less : Claims Outstanding at the beginning (net of reinsurance)");
		schedule2.setScheduleItem2dot11Name(
				"वसूली के लिए माइनस प्रावधान (पुनर्बीमा का शुद्ध)/Minus Provision for recovery (net of reinsurance)");
		schedule2.setScheduleItem2dot12Name("(सी)/(C)");
		schedule2.setFinalScheduleName("किए गए कुल दावे (ए + बी - सी)/Total Claims Incurred (A + B - C)");

		// 2.2
		BigDecimal itm2_2 = trialBalance2dot2Dtl.getDrAmount().subtract(trialBalance2dot2Dtl.getCrAmount());
		itm2_2 = itm2_2.divide(BigDecimal.valueOf(1000), 4);
		itm2_2 = itm2_2.setScale(2,RoundingMode.HALF_UP);
		schedule2.setScheduleItem2dot2Amt(amtFormatter(itm2_2));

		BigDecimal itm2_2Prv = trialBalance2dot2Prv.getDrAmount().subtract(trialBalance2dot2Prv.getCrAmount());
		itm2_2Prv = itm2_2Prv.divide(BigDecimal.valueOf(1000), 4);
		itm2_2Prv = itm2_2Prv.setScale(2,RoundingMode.HALF_UP);
		schedule2.setScheduleItem2dot2PreAmt(amtFormatter(itm2_2Prv));

		// 2.3
		schedule2.setScheduleItem2dot3Amt(amtFormatter(BigDecimal.ZERO));
		schedule2.setScheduleItem2dot3PreAmt(amtFormatter(BigDecimal.ZERO));

		// 2.4
		BigDecimal itm2_4 = trialBalance2dot4Dtl.getCrAmount().subtract(trialBalance2dot4Dtl.getDrAmount());
		itm2_4 = itm2_4.divide(BigDecimal.valueOf(1000), 4);
		itm2_4 = itm2_4.setScale(2,RoundingMode.HALF_UP);
		schedule2.setScheduleItem2dot4Amt(amtFormatter(itm2_4));

		BigDecimal itm2_4Prv = trialBalance2dot4Prv.getCrAmount().subtract(trialBalance2dot4Prv.getDrAmount());
		itm2_4Prv = itm2_4Prv.divide(BigDecimal.valueOf(1000), 4);
		itm2_4Prv = itm2_4Prv.setScale(2,RoundingMode.HALF_UP);
		schedule2.setScheduleItem2dot4PreAmt(amtFormatter(itm2_4Prv));

		// 2.5.1
		BigDecimal itm2_5_1 = trialBalance2dot5dot1Dtl.getCrAmount().subtract(trialBalance2dot5dot1Dtl.getDrAmount());
		itm2_5_1 = itm2_5_1.divide(BigDecimal.valueOf(1000), 4);
		itm2_5_1 = itm2_5_1.setScale(2,RoundingMode.HALF_UP);
		schedule2.setScheduleItem2dot5dot1Amt(amtFormatter(itm2_5_1));

		BigDecimal itm2_5_1Prv = trialBalance2dot5dot1Prv.getCrAmount()
				.subtract(trialBalance2dot5dot1Prv.getDrAmount());
		itm2_5_1Prv = itm2_5_1Prv.divide(BigDecimal.valueOf(1000), 4);
		itm2_5_1Prv = itm2_5_1Prv.setScale(2,RoundingMode.HALF_UP);
		schedule2.setScheduleItem2dot5dot1PreAmt(amtFormatter(itm2_5_1Prv));

		// 2.5.2
		BigDecimal itm2_5_2 = trialBalance2dot5dot2Dtl.getCrAmount().subtract(trialBalance2dot5dot2Dtl.getDrAmount());
		itm2_5_2 = itm2_5_2.divide(BigDecimal.valueOf(1000), 4);
		itm2_5_2 = itm2_5_2.setScale(2,RoundingMode.HALF_UP);
		schedule2.setScheduleItem2dot5dot2Amt(amtFormatter(itm2_5_2));

		BigDecimal itm2_5_2Prv = trialBalance2dot5dot2Prv.getCrAmount()
				.subtract(trialBalance2dot5dot2Prv.getDrAmount());
		itm2_5_2Prv = itm2_5_2Prv.divide(BigDecimal.valueOf(1000), 4);
		itm2_5_2Prv = itm2_5_2Prv.setScale(2,RoundingMode.HALF_UP);
		schedule2.setScheduleItem2dot5dot2PreAmt(amtFormatter(itm2_5_2Prv));

		// 2.5.3
		BigDecimal itm2_5_3 = trialBalance2dot5dot3Dtl.getDrAmount().subtract(trialBalance2dot5dot3Dtl.getCrAmount());
		itm2_5_3 = itm2_5_3.divide(BigDecimal.valueOf(1000), 4);
		itm2_5_3 = itm2_5_3.setScale(2,RoundingMode.HALF_UP);
		schedule2.setScheduleItem2dot5dot3Amt(amtFormatter(itm2_5_3));

		BigDecimal itm2_5_3Prv = trialBalance2dot5dot3Prv.getDrAmount()
				.subtract(trialBalance2dot5dot3Prv.getCrAmount());
		itm2_5_3Prv = itm2_5_3Prv.divide(BigDecimal.valueOf(1000), 4);
		itm2_5_3 = itm2_5_3.setScale(2,RoundingMode.HALF_UP);
		schedule2.setScheduleItem2dot5dot3PreAmt(amtFormatter(itm2_5_3Prv));

		// 2.5.4
		BigDecimal itm2_5_4 = itm2_5_1.add(itm2_5_2).subtract(itm2_5_3);
		schedule2.setScheduleItem2dot5dot4Amt(amtFormatter(itm2_5_4));

		BigDecimal itm2_5_4Prv = itm2_5_1Prv.add(itm2_5_2Prv).subtract(itm2_5_3Prv);
		schedule2.setScheduleItem2dot5dot4PreAmt(amtFormatter(itm2_5_4Prv));

		// 2.6
		BigDecimal itm2_6 = itm2_2.subtract(itm2_4).subtract(itm2_5_4);
		schedule2.setScheduleItem2dot6Amt(amtFormatter(itm2_6));

		BigDecimal itm2_6Prv = itm2_2Prv.subtract(itm2_4Prv).subtract(itm2_5_4Prv);
		schedule2.setScheduleItem2dot6PreAmt(amtFormatter(itm2_6Prv));

		// 2.7
		BigDecimal itm2_7 = trialBalance2dot7Dtl.getDrAmount().subtract(trialBalance2dot7Dtl.getCrAmount());
		itm2_7 = itm2_7.divide(BigDecimal.valueOf(1000), 4);
		itm2_7 = itm2_7.setScale(2,RoundingMode.HALF_UP);
		schedule2.setScheduleItem2dot7Amt(amtFormatter(itm2_7));

		BigDecimal itm2_7Prv = trialBalance2dot7Prv.getDrAmount().subtract(trialBalance2dot7Prv.getCrAmount());
		itm2_7Prv = itm2_7Prv.divide(BigDecimal.valueOf(1000), 4);
		itm2_7Prv = itm2_7Prv.setScale(2,RoundingMode.HALF_UP);
		schedule2.setScheduleItem2dot7PreAmt(amtFormatter(itm2_7Prv));

		// 2.8
		BigDecimal itm2_8 = trialBalance2dot8Dtl.getCrAmount().subtract(trialBalance2dot8Dtl.getDrAmount());
		itm2_8 = itm2_8.divide(BigDecimal.valueOf(1000), 4);
		itm2_8 = itm2_8.setScale(2,RoundingMode.HALF_UP);
		schedule2.setScheduleItem2dot8Amt(amtFormatter(itm2_8));

		BigDecimal itm2_8Prv = trialBalance2dot8Prv.getCrAmount().subtract(trialBalance2dot8Prv.getDrAmount());
		itm2_8Prv = itm2_8Prv.divide(BigDecimal.valueOf(1000), 4);
		itm2_8Prv = itm2_8Prv.setScale(2,RoundingMode.HALF_UP);
		schedule2.setScheduleItem2dot8PreAmt(amtFormatter(itm2_8Prv));

		// 2.9
		BigDecimal itm2_9 = itm2_7.subtract(itm2_8);
		schedule2.setScheduleItem2dot9Amt(amtFormatter(itm2_9));

		BigDecimal itm2_9Prv = itm2_7Prv.subtract(itm2_8Prv);
		schedule2.setScheduleItem2dot9PreAmt(amtFormatter(itm2_9Prv));

		// 2.10
		BigDecimal itm2_10 = trialBalance2dot10Dtl.getCrAmount();
		itm2_10 = itm2_10.divide(BigDecimal.valueOf(1000), 4);
		itm2_10 = itm2_10.setScale(2,RoundingMode.HALF_UP);
		schedule2.setScheduleItem2dot10Amt(amtFormatter(itm2_10));

		BigDecimal itm2_10Prv = trialBalance2dot10Prv.getCrAmount();
		itm2_10Prv = itm2_10Prv.divide(BigDecimal.valueOf(1000), 4);
		itm2_10Prv = itm2_10Prv.setScale(2,RoundingMode.HALF_UP);
		schedule2.setScheduleItem2dot10PreAmt(amtFormatter(itm2_10Prv));

		// 2.11
		BigDecimal itm2_11 = trialBalance2dot11Dtl.getDrAmount();
		itm2_11 = itm2_11.divide(BigDecimal.valueOf(1000), 4);
		itm2_11 = itm2_11.setScale(2,RoundingMode.HALF_UP);
		schedule2.setScheduleItem2dot11Amt(amtFormatter(itm2_11));

		BigDecimal itm2_11Prv = trialBalance2dot11Prv.getDrAmount();
		itm2_11Prv = itm2_11Prv.divide(BigDecimal.valueOf(1000), 4);
		itm2_11Prv = itm2_11Prv.setScale(2,RoundingMode.HALF_UP);
		schedule2.setScheduleItem2dot11PreAmt(amtFormatter(itm2_11Prv));

		// 2.12
		BigDecimal itm2_12 = itm2_10.subtract(itm2_11);
		schedule2.setScheduleItem2dot12Amt(amtFormatter(itm2_12));

		BigDecimal itm2_12Prv = itm2_10Prv.subtract(itm2_11Prv);
		schedule2.setScheduleItem2dot12PreAmt(amtFormatter(itm2_12Prv));

		// 2.12
		BigDecimal itm2_13 = itm2_6.add(itm2_9).subtract(itm2_12);
		schedule2.setFinalSchedule2Amt(amtFormatter(itm2_13));

		BigDecimal itm2_13Prv = itm2_6Prv.add(itm2_9Prv).subtract(itm2_12Prv);
		schedule2.setFinalSchedule2PreAmt(amtFormatter(itm2_13Prv));

		return schedule2;

	}

	// -----------------------------------schedule 7---------------------------------------------------------

	@Override
	public Schedule7 getSchedule7(LocalDate date) {
		log.debug("ScheduleServiceImpl-->getSchedule7()");

		Schedule7 schedule7 = null;
		// if data is present directly take values from trail balance table
		if (scheduleDao.checkForInputDt(date) > 0) {

			schedule7 = getSchedule7Data(date);
			// else generate trail balance and then take values
		} else {

			int curtb = scheduleDao.generateTb(date);

			LocalDate prvDt = date.minusYears(1);

			int prvtb = scheduleDao.generateTbPrv(prvDt);

			if (curtb > 0 && prvtb > 0) {
				schedule7 = getSchedule7Data(date);
			}

		}

		return schedule7;
	}

	public Schedule7 getSchedule7Data(LocalDate date) {

		TrialBalanceDtl trialBalance7dot1Dtl = getTrialBalanceDtl("7", "7.1", date);
		TrialBalanceDtl trialBalance7dot2Dtl = getTrialBalanceDtl("7", "7.2", date);
		TrialBalanceDtl trialBalance7dot3Dtl = getTrialBalanceDtl("7", "7.3", date);
		TrialBalanceDtl trialBalance7dot4Dtl = getTrialBalanceDtl("7", "7.4", date);

		LocalDate prvDt = date.minusYears(1);
		TrialBalanceDtl trialBalance7dot1Prv = getTrialBalanceDtlPrv("7", "7.1", prvDt);
		TrialBalanceDtl trialBalance7dot2Prv = getTrialBalanceDtlPrv("7", "7.2", prvDt);
		TrialBalanceDtl trialBalance7dot3Prv = getTrialBalanceDtlPrv("7", "7.3", prvDt);
		TrialBalanceDtl trialBalance7dot4Prv = getTrialBalanceDtlPrv("7", "7.4", prvDt);

		Schedule7 schedule7 = new Schedule7();

		schedule7.setCreatedBy(userInfoService.getName());
		schedule7.setScheduleItem7dot1Name("डिबेंचर/बॉन्ड/Debentures/Bonds");
		schedule7.setScheduleItem7dot2Name(
				"बैंक (असुरक्षित - 12 महीने से कम समय में चुकाने योग्य)/Banks (unsecured - repayable in less than 12 months)");
		schedule7.setScheduleItem7dot3Name("वित्तीय संस्थानों/Financial Institutions");
		schedule7.setScheduleItem7dot4Name("अन्य/Others");
		schedule7.setFinalSchedule7Name("कुल/TOTAL");

		// 7.1
		BigDecimal itm7_1 = BigDecimal.ZERO;
		schedule7.setScheduleItem7dot1Amt(amtFormatter(itm7_1));

		BigDecimal itm7_1Prv = BigDecimal.ZERO;
		schedule7.setScheduleItem7dot1PreAmt(amtFormatter(itm7_1Prv));

		// 7.2
		BigDecimal itm7_2 = trialBalance7dot2Dtl.getCrAmount();
		itm7_2 = itm7_2.divide(BigDecimal.valueOf(1000), 4);
		itm7_2 = itm7_2.setScale(2,RoundingMode.HALF_UP);
		schedule7.setScheduleItem7dot2Amt(amtFormatter(itm7_2));

		BigDecimal itm7_2Prv = trialBalance7dot2Prv.getCrAmount();
		itm7_2Prv = itm7_2Prv.divide(BigDecimal.valueOf(1000), 4);
		itm7_2Prv = itm7_2Prv.setScale(2,RoundingMode.HALF_UP);
		schedule7.setScheduleItem7dot2PreAmt(amtFormatter(itm7_2Prv));

		// 7.3
		BigDecimal itm7_3 = BigDecimal.ZERO;
		schedule7.setScheduleItem7dot3Amt(amtFormatter(itm7_3));

		BigDecimal itm7_3Prv = BigDecimal.ZERO;
		schedule7.setScheduleItem7dot3PreAmt(amtFormatter(itm7_3Prv));

		// 7.4
		BigDecimal itm7_4 = BigDecimal.ZERO;
		schedule7.setScheduleItem7dot4Amt(amtFormatter(itm7_4));

		BigDecimal itm7_4Prv = BigDecimal.ZERO;
		schedule7.setScheduleItem7dot4PreAmt(amtFormatter(itm7_4Prv));

		// 7.5
		BigDecimal itm7_5 = itm7_1.add(itm7_2).add(itm7_3).add(itm7_4);
		schedule7.setFinalSchedule7Amt(amtFormatter(itm7_5));

		BigDecimal itm7_5Prv = itm7_1Prv.add(itm7_2Prv).add(itm7_3Prv).add(itm7_4Prv);
		schedule7.setFinalSchedule7PreAmt(amtFormatter(itm7_5Prv));

		return schedule7;
	}

	// -----------------------------------schedule 15------------------------------------------------

	@Override
	public Schedule15 getSchedule15(LocalDate date) {
		log.debug("ScheduleServiceImpl-->getSchedule15()");

		Schedule15 schedule15 = null;
		// if data is present directly take values from trail balance table
		if (scheduleDao.checkForInputDt(date) > 0) {

			schedule15 = getSchedule15Data(date);
			// else generate trail balance and then take values
		} else {

			int curtb = scheduleDao.generateTb(date);

			LocalDate prvDt = date.minusYears(1);

			int prvtb = scheduleDao.generateTbPrv(prvDt);

			if (curtb > 0 && prvtb > 0) {
				schedule15 = getSchedule15Data(date);
			}

		}

		return schedule15;

	}

	public Schedule15 getSchedule15Data(LocalDate date) {

		TrialBalanceDtl trialBalance15dot1Dtl = getTrialBalanceDtl("15", "15.1", date);
		TrialBalanceDtl trialBalance15dot2Dtl = getTrialBalanceDtl("15", "15.2", date);

		LocalDate prvDt = date.minusYears(1);
		TrialBalanceDtl trialBalance15dot1Prv = getTrialBalanceDtlPrv("15", "15.1", prvDt);
		TrialBalanceDtl trialBalance15dot2Prv = getTrialBalanceDtlPrv("15", "15.2", prvDt);

		Schedule15 schedule15 = new Schedule15();

		schedule15.setCreatedBy(userInfoService.getName());
		schedule15.setScheduleItem15dot1Name(
				"शेयर/डिबेंचर जारी करने में छूट की अनुमति/Discount Allowed in issue of shares/debentures");
		schedule15.setScheduleItem15dot2Name("अन्य/Others");
		schedule15.setFinalSchedule15Name("कुल/TOTAL");

		// 15.1
		BigDecimal itm15_1 = BigDecimal.ZERO;
		schedule15.setScheduleItem15dot1Amt(amtFormatter(itm15_1));

		BigDecimal itm15_1Prv = BigDecimal.ZERO;
		schedule15.setScheduleItem15dot1PreAmt(amtFormatter(itm15_1Prv));

		// 15.2
		BigDecimal itm15_2 = BigDecimal.ZERO;
		schedule15.setScheduleItem15dot2Amt(amtFormatter(itm15_2));

		BigDecimal itm15_2Prv = BigDecimal.ZERO;
		schedule15.setScheduleItem15dot2PreAmt(amtFormatter(itm15_2Prv));

		// 15.3
		BigDecimal itm15_3 = itm15_1.add(itm15_2);
		schedule15.setFinalSchedule15Amt(amtFormatter(itm15_3));

		BigDecimal itm15_3Prv = itm15_1Prv.add(itm15_2Prv);
		schedule15.setFinalSchedule15PreAmt(amtFormatter(itm15_3Prv));

		return schedule15;
	}

	// ----------------------------------------schedule 5--------------------------------------------------------

	@Override
	public Schedule5 getSchedule5(LocalDate date, BigDecimal authCapital, BigDecimal authPreCapital) {
		log.debug("ScheduleServiceImpl-->getSchedule5()");

		Schedule5 schedule5 = null;
		// if data is present directly take values from trail balance table
		if (scheduleDao.checkForInputDt(date) > 0) {

			schedule5 = getSchedule5Data(date, authCapital, authPreCapital);
			// else generate trail balance and then take values
		} else {

			int curtb = scheduleDao.generateTb(date);

			LocalDate prvDt = date.minusYears(1);

			int prvtb = scheduleDao.generateTbPrv(prvDt);

			if (curtb > 0 && prvtb > 0) {
				schedule5 = getSchedule5Data(date, authCapital, authPreCapital);
			}

		}

		return schedule5;
	}

	public Schedule5 getSchedule5Data(LocalDate date, BigDecimal authCapital, BigDecimal authPreCapital) {

		TrialBalanceDtl trialBalance5dot2Dtl = getTrialBalanceDtl("5", "5.2", date);
		TrialBalanceDtl trialBalance5dot3Dtl = getTrialBalanceDtl("5", "5.3", date);
		TrialBalanceDtl trialBalance5dot4Dtl = getTrialBalanceDtl("5", "5.4", date);

		LocalDate prvDt = date.minusYears(1);
		TrialBalanceDtl trialBalance5dot2Prv = getTrialBalanceDtlPrv("5", "5.2", prvDt);
		TrialBalanceDtl trialBalance5dot3Prv = getTrialBalanceDtlPrv("5", "5.3", prvDt);
		TrialBalanceDtl trialBalance5dot4Prv = getTrialBalanceDtlPrv("5", "5.4", prvDt);

		Schedule5 schedule5 = new Schedule5();

		// 5.1
		schedule5.setScheduleItem5dot1Amt(amtFormatter(authCapital));
		schedule5.setScheduleItem5dot1PreAmt(amtFormatter(authPreCapital));

		// 5.2
		BigDecimal itm5_2 = trialBalance5dot2Dtl.getCrAmount();
		itm5_2 = itm5_2.divide(BigDecimal.valueOf(1000), 4);
		itm5_2 = itm5_2.setScale(2,RoundingMode.HALF_UP);
		schedule5.setScheduleItem5dot2Amt(amtFormatter(itm5_2));

		BigDecimal itm5_2Prv = trialBalance5dot2Prv.getCrAmount();
		itm5_2Prv = itm5_2Prv.divide(BigDecimal.valueOf(1000), 4);
		itm5_2Prv = itm5_2Prv.setScale(2,RoundingMode.HALF_UP);
		schedule5.setScheduleItem5dot2PreAmt(amtFormatter(itm5_2Prv));

		// 5.3
		BigDecimal itm5_3 = trialBalance5dot3Dtl.getCrAmount();
		itm5_3 = itm5_3.divide(BigDecimal.valueOf(1000), 4);
		itm5_3 = itm5_3.setScale(2,RoundingMode.HALF_UP);
		schedule5.setScheduleItem5dot3Amt(amtFormatter(itm5_3));

		BigDecimal itm5_3Prv = trialBalance5dot3Prv.getCrAmount();
		itm5_3Prv = itm5_3Prv.divide(BigDecimal.valueOf(1000), 4);
		itm5_3Prv = itm5_3Prv.setScale(2,RoundingMode.HALF_UP);
		schedule5.setScheduleItem5dot3PreAmt(amtFormatter(itm5_3Prv));

		// 5.4s
		BigDecimal itm5_4 = trialBalance5dot4Dtl.getCrAmount();
		itm5_4 = itm5_4.divide(BigDecimal.valueOf(1000), 4);
		itm5_4 = itm5_4.setScale(2,RoundingMode.HALF_UP);
		schedule5.setScheduleItem5dot4Amt(amtFormatter(itm5_4));

		BigDecimal itm5_4Prv = trialBalance5dot4Prv.getCrAmount();
		itm5_4Prv = itm5_4Prv.divide(BigDecimal.valueOf(1000), 4);
		itm5_4Prv = itm5_4Prv.setScale(2,RoundingMode.HALF_UP);
		schedule5.setScheduleItem5dot4PreAmt(amtFormatter(itm5_4Prv));

		// 5.5
		BigDecimal itm5_5 = BigDecimal.ZERO;
		schedule5.setScheduleItem5dot5Amt(amtFormatter(itm5_5));

		BigDecimal itm5_5Prv = BigDecimal.ZERO;
		schedule5.setScheduleItem5dot5PreAmt(amtFormatter(itm5_5Prv));

		// 5.6
		BigDecimal itm5_6 = BigDecimal.ZERO;
		schedule5.setScheduleItem5dot6Amt(amtFormatter(itm5_6));

		BigDecimal itm5_6Prv = BigDecimal.ZERO;
		schedule5.setScheduleItem5dot6PreAmt(amtFormatter(itm5_6Prv));

		// 5.7
		BigDecimal itm5_7 = BigDecimal.ZERO;
		schedule5.setScheduleItem5dot7Amt(amtFormatter(itm5_7));

		BigDecimal itm5_7Prv = BigDecimal.ZERO;
		schedule5.setScheduleItem5dot7PreAmt(amtFormatter(itm5_7Prv));

		// 5.8
		BigDecimal itm5_8 = BigDecimal.ZERO;
		schedule5.setScheduleItem5dot8Amt(amtFormatter(itm5_8));

		BigDecimal itm5_8Prv = BigDecimal.ZERO;
		schedule5.setScheduleItem5dot8PreAmt(amtFormatter(itm5_8Prv));

		BigDecimal itm5final = itm5_2.max(itm5_3).max(itm5_4).max(itm5_5).max(itm5_6).max(itm5_7).max(itm5_8);
		schedule5.setFinalSchedule5Amt(amtFormatter(itm5final));

		BigDecimal itm5finalPrv = itm5_2Prv.max(itm5_3Prv).max(itm5_4Prv).max(itm5_5Prv).max(itm5_6Prv).max(itm5_7Prv)
				.max(itm5_8Prv);
		schedule5.setFinalSchedule5PreAmt(amtFormatter(itm5finalPrv));

		schedule5.setCreatedBy(userInfoService.getName());
		schedule5.setScheduleItem5dot1Name("अधिकृत पूंजी\r\n" + authCapital + " रुपये के इक्विटी शेयर। 100 प्रत्येक\r\n"
				+ "(पिछली अवधि के " + authPreCapital + " इक्विटी शेयर 100 रुपये प्रत्येक)/" + "Authorised Capital\r\n"
				+ " " + authCapital + " Equity Shares of Rs. 100 each\r\n" + "(Previous Period " + authPreCapital
				+ " Equity Shares of Rs. 100 each)\r\n" + "");

		schedule5.setScheduleItem5dot2Name(
				"जारी पूँजी\r\n" + "" + (amtFormatter(itm5_2)) + " इक्विटी शेयर रु. 100 प्रत्येक\r\n"
						+ "(पिछली अवधि के " + (amtFormatter(itm5_2Prv)) + " इक्विटी शेयर प्रत्येक 100 रुपये के)/" + ""
						+ "Issued Capital \r\n" + "" + (amtFormatter(itm5_2)) + " Equity Shares of Rs. 100 each\r\n"
						+ "(Previous Period " + (amtFormatter(itm5_2Prv)) + " Equity Shares of Rs 100 each)\r\n" + "");

		schedule5.setScheduleItem5dot3Name(
				"अभिदत्त पूंजी\r\n" + "" + (amtFormatter(itm5_3)) + " इक्विटी शेयर रु. 100 प्रत्येक\r\n"
						+ "(पिछली अवधि के " + (amtFormatter(itm5_3Prv)) + " इक्विटी शेयर प्रत्येक 100 रुपये के)/"
						+ "Subscribed Capital\r\n" + "" + (amtFormatter(itm5_3)) + " Equity Shares of Rs. 100 each\r\n"
						+ "(Previous Period " + (amtFormatter(itm5_3Prv)) + " Equity Shares of Rs 100 each)\r\n" + "");

		schedule5.setScheduleItem5dot4Name("बुलाया गया और पूंजी का भुगतान किया गया\r\n" + "" + (amtFormatter(itm5_4))
				+ " इक्विटी शेयर रु. 100 प्रत्येक\r\n" + "(पिछली अवधि के " + (amtFormatter(itm5_4Prv))
				+ " इक्विटी शेयर प्रत्येक 100 रुपये के)/" + "Called up & Paid up Capital\r\n" + ""
				+ (amtFormatter(itm5_4)) + " Equity Shares of Rs. 100 each\r\n" + "(Previous Period "
				+ (amtFormatter(itm5_4Prv)) + " Equity Shares of Rs 100 each)\r\n" + "");

		schedule5.setScheduleItem5dot5Name("जोड़ें: जब्त किए गए इक्विटी शेयर (मूल रूप से भुगतान की गई राशि)/"
				+ "Add : Equity Shares forfeited (Amount originally paid up)");

		schedule5.setScheduleItem5dot6Name(
				"कम: वापस खरीदे गए इक्विटी शेयरों का सममूल्य/" + "Less : Par Value of Equity Shares bought back");

		schedule5.setScheduleItem5dot7Name("कम : प्रारंभिक व्यय" + "Less : Preliminary Expenses");

		schedule5.setScheduleItem5dot8Name("कमीशन या दलाली सहित व्यय\r\n" + "शेयरों की अंडरराइटिंग या सदस्यता पर/"
				+ "Expenses including commission or brokerage\r\n" + "on Underwriting or subscription of shares");

		schedule5.setFinalSchedule5Name("कुल/TOTAL");

		return schedule5;
	}

//--------------------------------------------------schedule 5A--------------------------------------------------------------

	@Override
	public Schedule5A getSchedule5A(LocalDate date) {
		log.debug("ScheduleServiceImpl-->getSchedule5()");

		Schedule5A schedule5A = null;
		// if data is present directly take values from trail balance table
		if (scheduleDao.checkForInputDt(date) > 0) {

			schedule5A = getSchedule5AData(date);
			// else generate trail balance and then take values
		} else {

			int curtb = scheduleDao.generateTb(date);

			LocalDate prvDt = date.minusYears(1);

			int prvtb = scheduleDao.generateTbPrv(prvDt);

			if (curtb > 0 && prvtb > 0) {
				schedule5A = getSchedule5AData(date);
			}

		}

		return schedule5A;
	}

	public Schedule5A getSchedule5AData(LocalDate date) {

		TrialBalanceDtl trialBalance5dot4Dtl = getTrialBalanceDtl("5", "5.4", date);

		LocalDate prvDt = date.minusYears(1);
		TrialBalanceDtl trialBalance5dot4Prv = getTrialBalanceDtlPrv("5", "5.4", prvDt);

		Schedule5A schedule5A = new Schedule5A();

		schedule5A.setCreatedBy(userInfoService.getName());
		schedule5A.setScheduleItem5dot1Name("संवर्धक/Promoters");

		schedule5A.setScheduleItem5dot2Name("भारतीय/Indians");

		schedule5A.setScheduleItem5dot3Name(
				"भारत के राष्ट्रपति और उनके नामांकित व्यक्ति/President of India & His Nominees");

		schedule5A.setScheduleItem5dot4Name("विदेश/Foreign");

		schedule5A.setScheduleItem5dot5Name("अन्य/Others");

		schedule5A.setFinalSchedule5Name("कुल/TOTAL");

		// 5.3A
		BigDecimal itm5_3 = trialBalance5dot4Dtl.getCrAmount();
		itm5_3 = itm5_3.divide(BigDecimal.valueOf(100), 4);
		itm5_3 = itm5_3.setScale(2,RoundingMode.HALF_UP);
		schedule5A.setScheduleItem5dot3Amt(amtFormatter(itm5_3));

		BigDecimal itm5_3Prv = trialBalance5dot4Prv.getCrAmount();
		itm5_3Prv = itm5_3Prv.divide(BigDecimal.valueOf(100), 4);
		itm5_3Prv = itm5_3Prv.setScale(2,RoundingMode.HALF_UP);
		schedule5A.setScheduleItem5dot3PreAmt(amtFormatter(itm5_3Prv));

		// 5.4A
		BigDecimal itm5_4 = BigDecimal.ZERO;
		schedule5A.setScheduleItem5dot4Amt(amtFormatter(itm5_4));

		BigDecimal itm5_4Prv = BigDecimal.ZERO;
		schedule5A.setScheduleItem5dot4PreAmt(amtFormatter(itm5_4Prv));

		// 5.5A
		BigDecimal itm5_5 = BigDecimal.ZERO;
		schedule5A.setScheduleItem5dot5Amt(amtFormatter(itm5_5));

		BigDecimal itm5_5Prv = BigDecimal.ZERO;
		schedule5A.setScheduleItem5dot5PreAmt(amtFormatter(itm5_5Prv));

		// final
		BigDecimal itm5Afinal = itm5_3.add(itm5_4).add(itm5_5);
		schedule5A.setFinalSchedule5Amt(amtFormatter(itm5Afinal));

		BigDecimal itm5AfinalPrv = itm5_3Prv.add(itm5_4Prv).add(itm5_5Prv);
		schedule5A.setFinalSchedule5PreAmt(amtFormatter(itm5AfinalPrv));

		return schedule5A;
	}

	// ----------------------------------------------schedule-9------------------------------------------------------
	@Override
	public Schedule9 getSchedule9(LocalDate date) {
		log.debug("ScheduleServiceImpl-->getSchedule9()");

		Schedule9 schedule9 = null;
		// if data is present directly take values from trail balance table
		if (scheduleDao.checkForInputDt(date) > 0) {

			schedule9 = getSchedule9Data(date);
			// else generate trail balance and then take values
		} else {

			int curtb = scheduleDao.generateTb(date);

			LocalDate prvDt = date.minusYears(1);

			int prvtb = scheduleDao.generateTbPrv(prvDt);

			if (curtb > 0 && prvtb > 0) {
				schedule9 = getSchedule9Data(date);
			}

		}

		return schedule9;
	}

	public Schedule9 getSchedule9Data(LocalDate date) {

		TrialBalanceDtl trialBalance9dot5Dtl = getTrialBalanceDtl("9", "9.5", date);

		LocalDate prvDt = date.minusYears(1);

		TrialBalanceDtl trialBalance9dot5Prv = getTrialBalanceDtlPrv("9", "9.5", prvDt);

		Schedule9 schedule9 = new Schedule9();

		schedule9.setCreatedBy(userInfoService.getName());
		schedule9.setScheduleItem9dot1Name("सुरक्षा-वार वर्गीकरण/SECURITY-WISE CLASSIFICATION");
		schedule9.setScheduleItem9dot2Name("सुरक्षित/Secured");
		schedule9.setScheduleItem9dot3Name("(ए) संपत्ति के बंधक पर/(a) On mortagage of property");
		schedule9.setScheduleItem9dot4Name("भारत में/in India");
		schedule9.setScheduleItem9dot5Name("भारत के बाहर/Outside India");
		schedule9.setScheduleItem9dot6Name("कम : संदिग्ध ऋणों के लिए प्रावधान/Less : Provision for doubtful debts");
		schedule9.setScheduleItem9dot8Name(
				"(बी) शेयर, बांड, सरकारी प्रतिभूतियों पर/(b) On Shares, Bonds, Government Securities");
		schedule9.setScheduleItem9dot9Name(
				"(सी) अन्य (असुरक्षित - कर्मचारियों को ऋण)/(c) Others (unsecured - loan to employees)");
		schedule9.setScheduleItem9dot10Name("कुल/TOTAL");
		schedule9.setScheduleItem9dot11Name("उधारकर्ता-वार वर्गीकरण/BORROWER-WISE CLASSIFICATION");
		schedule9.setScheduleItem9dot12Name("(ए) केंद्र और राज्य सरकारें/(a) Central and State Governments");
		schedule9.setScheduleItem9dot13Name("(बी) बैंक और वित्तीय संस्थान/(b) Banks and Financial Institutions");
		schedule9.setScheduleItem9dot14Name("(सी) सहायक कंपनियां/(c) Subsidiaries");
		schedule9.setScheduleItem9dot15Name("(डी) औद्योगिक उपक्रम/(d) Industrial Undertakings");
		schedule9.setScheduleItem9dot16Name("(ई) अन्य (कर्मचारियों को ऋण)/(e) Others (loans to employees)");
		schedule9.setScheduleItem9dot17Name("प्रदर्शन के अनुसार वर्गीकरण/PERFORMANCE-WISE CLASSIFICATION");
		schedule9.setScheduleItem9dot18Name(
				"(ए) ऋण को मानक के रूप में वर्गीकृत किया गया है/(a) Loans classified as standard");
		schedule9.setScheduleItem9dot19Name("भारत में (कर्मचारियों को ऋण)/in India (Loans to employees)");
		schedule9.setScheduleItem9dot20Name("भारत के बाहर/Outside India");
		schedule9.setScheduleItem9dot21Name(
				"(बी) गैर-निष्पादित ऋण कम प्रावधान/(b) Non-performing loans less provisions");
		schedule9.setScheduleItem9dot22Name("भारत में/in India");
		schedule9.setScheduleItem9dot23Name("भारत के बाहर/Outside India");
		schedule9.setScheduleItem9dot24Name("परिपक्वता-वार वर्गीकरण/MATURITY -WISE CLASSIFICATION");
		schedule9.setScheduleItem9dot25Name("(ए) अल्पावधि/(a) Short Term");
		schedule9.setScheduleItem9dot26Name("(बी) दीर्घकालिक/(b) Long Term");
		schedule9.setFinalSchedule9Name("कुल योग/GRAND TOTAL");

		schedule9.setScheduleItem9dot4Amt(amtFormatter(BigDecimal.ZERO));
		schedule9.setScheduleItem9dot4PreAmt(amtFormatter(BigDecimal.ZERO));

		BigDecimal itm9_5 = trialBalance9dot5Dtl.getDrAmount();
		itm9_5 = itm9_5.divide(BigDecimal.valueOf(1000), 2);
		itm9_5 = itm9_5.setScale(2,RoundingMode.HALF_UP);

		BigDecimal itm9_5Prv = trialBalance9dot5Dtl.getDrAmount();
		itm9_5Prv = itm9_5Prv.divide(BigDecimal.valueOf(1000), 2);
		itm9_5Prv = itm9_5Prv.setScale(2,RoundingMode.HALF_UP);

		schedule9.setScheduleItem9dot5Amt(amtFormatter(itm9_5));
		schedule9.setScheduleItem9dot5PreAmt(amtFormatter(itm9_5Prv));

		schedule9.setScheduleItem9dot6Amt(amtFormatter(BigDecimal.ZERO));
		schedule9.setScheduleItem9dot6PreAmt(amtFormatter(BigDecimal.ZERO));

		schedule9.setScheduleItem9dot7Amt(amtFormatter(itm9_5));
		schedule9.setScheduleItem9dot7PreAmt(amtFormatter(itm9_5Prv));

		schedule9.setScheduleItem9dot8Amt(amtFormatter(BigDecimal.ZERO));
		schedule9.setScheduleItem9dot8PreAmt(amtFormatter(BigDecimal.ZERO));

		schedule9.setScheduleItem9dot9Amt(amtFormatter(BigDecimal.ZERO));
		schedule9.setScheduleItem9dot9PreAmt(amtFormatter(BigDecimal.ZERO));

		schedule9.setScheduleItem9dot10Amt(amtFormatter(BigDecimal.ZERO));
		schedule9.setScheduleItem9dot10PreAmt(amtFormatter(BigDecimal.ZERO));

		schedule9.setScheduleItem9dot12Amt(amtFormatter(BigDecimal.ZERO));
		schedule9.setScheduleItem9dot12PreAmt(amtFormatter(BigDecimal.ZERO));

		schedule9.setScheduleItem9dot13Amt(amtFormatter(BigDecimal.ZERO));
		schedule9.setScheduleItem9dot13PreAmt(amtFormatter(BigDecimal.ZERO));

		schedule9.setScheduleItem9dot14Amt(amtFormatter(BigDecimal.ZERO));
		schedule9.setScheduleItem9dot14PreAmt(amtFormatter(BigDecimal.ZERO));

		schedule9.setScheduleItem9dot15Amt(amtFormatter(BigDecimal.ZERO));
		schedule9.setScheduleItem9dot15PreAmt(amtFormatter(BigDecimal.ZERO));

		schedule9.setScheduleItem9dot16Amt(amtFormatter(BigDecimal.ZERO));
		schedule9.setScheduleItem9dot16PreAmt(amtFormatter(BigDecimal.ZERO));

		schedule9.setScheduleItem9dot16Amt(amtFormatter(BigDecimal.ZERO));
		schedule9.setScheduleItem9dot16PreAmt(amtFormatter(BigDecimal.ZERO));

		schedule9.setScheduleItem9dot16Amt(amtFormatter(BigDecimal.ZERO));
		schedule9.setScheduleItem9dot16PreAmt(amtFormatter(BigDecimal.ZERO));

		schedule9.setScheduleItem9dot19Amt(amtFormatter(BigDecimal.ZERO));
		schedule9.setScheduleItem9dot19PreAmt(amtFormatter(BigDecimal.ZERO));

		schedule9.setScheduleItem9dot20Amt(amtFormatter(BigDecimal.ZERO));
		schedule9.setScheduleItem9dot20PreAmt(amtFormatter(BigDecimal.ZERO));

		schedule9.setScheduleItem9dot22Amt(amtFormatter(BigDecimal.ZERO));
		schedule9.setScheduleItem9dot22PreAmt(amtFormatter(BigDecimal.ZERO));

		schedule9.setScheduleItem9dot23Amt(amtFormatter(BigDecimal.ZERO));
		schedule9.setScheduleItem9dot23PreAmt(amtFormatter(BigDecimal.ZERO));

		schedule9.setScheduleItem9dot25Amt(amtFormatter(BigDecimal.ZERO));
		schedule9.setScheduleItem9dot25PreAmt(amtFormatter(BigDecimal.ZERO));

		schedule9.setScheduleItem9dot26Amt(amtFormatter(BigDecimal.ZERO));
		schedule9.setScheduleItem9dot26PreAmt(amtFormatter(BigDecimal.ZERO));

		schedule9.setFinalSchedule9Amt(amtFormatter(BigDecimal.ZERO));
		schedule9.setFinalSchedule9PreAmt(amtFormatter(BigDecimal.ZERO));

		return schedule9;

	}

	// ------------------------------------------schedule 11-----------------------------------------------------

	@Override
	public Schedule11 getSchedule11(LocalDate date) {
		log.debug("ScheduleServiceImpl-->getSchedule9()");

		Schedule11 schedule11 = null;
		// if data is present directly take values from trail balance table
		if (scheduleDao.checkForInputDt(date) > 0) {

			schedule11 = getSchedule11Data(date);
			// else generate trail balance and then take values
		} else {

			int curtb = scheduleDao.generateTb(date);

			LocalDate prvDt = date.minusYears(1);

			int prvtb = scheduleDao.generateTbPrv(prvDt);

			if (curtb > 0 && prvtb > 0) {
				schedule11 = getSchedule11Data(date);
			}

		}

		return schedule11;
	}

	public Schedule11 getSchedule11Data(LocalDate date) {

		TrialBalanceDtl trialBalance11dot1Dtl = getTrialBalanceDtl("11", "11.1", date);
		TrialBalanceDtl trialBalance11dot5Dtl = getTrialBalanceDtl("11", "11.5", date);
		TrialBalanceDtl trialBalance11dot6Dtl = getTrialBalanceDtl("11", "11.6", date);
		TrialBalanceDtl trialBalance11dot10Dtl = getTrialBalanceDtl("11", "11.10", date);
		TrialBalanceDtl trialBalance11dot11Dtl = getTrialBalanceDtl("11", "11.11", date);

		LocalDate prvDt = date.minusYears(1);

		TrialBalanceDtl trialBalance11dot1Prv = getTrialBalanceDtlPrv("11", "11.1", prvDt);
		TrialBalanceDtl trialBalance11dot5Prv = getTrialBalanceDtlPrv("11", "11.5", prvDt);
		TrialBalanceDtl trialBalance11dot6Prv = getTrialBalanceDtlPrv("11", "11.6", prvDt);
		TrialBalanceDtl trialBalance11dot10Prv = getTrialBalanceDtlPrv("11", "11.10", prvDt);
		TrialBalanceDtl trialBalance11dot11Prv = getTrialBalanceDtlPrv("11", "11.11", prvDt);

		Schedule11 schedule11 = new Schedule11();

		schedule11.setCreatedBy(userInfoService.getName());
		schedule11.setScheduleItem11dot1Name(
				"नकद (चेक, ड्राफ्ट और स्टाम्प सहित)/Cash (including cheques, drafts and stamps)");
		schedule11.setScheduleItem11dot2Name("बैंक बैलेंस/Bank Balances");
		schedule11.setScheduleItem11dot3Name("(ए) जमा खाते/(a) Deposit Accounts");
		schedule11.setScheduleItem11dot4Name(
				"  (एए) अल्पावधि (12 महीने के भीतर देय):/(aa) Short Term (due within 12 months):");
		schedule11.setScheduleItem11dot5Name("        बैंकों के साथ/With Banks");
		schedule11.setScheduleItem11dot6Name("        वित्तीय संस्थानों के साथ/With Financial Institutions");
		schedule11.setScheduleItem11dot7Name("  (बीबी) अन्य/(bb) Others");
		schedule11.setScheduleItem11dot10Name("(बी) चालू खाते/(b) Current Accounts");
		schedule11.setScheduleItem11dot11Name(
				"(सी) अन्य - भारतीय रिजर्व बैंक के साथ संतुलन/(c ) Others - Balance with Reserve Bank of India)");
		schedule11.setFinalSchedule11Name("कुल योग/GRAND TOTAL");

		// 11.11
		BigDecimal itm11_11 = trialBalance11dot11Dtl.getDrAmount();
		itm11_11 = itm11_11.divide(BigDecimal.valueOf(1000), 4);
		itm11_11 = itm11_11.setScale(2,RoundingMode.HALF_UP);
		schedule11.setScheduleItem11dot11Amt(amtFormatter(itm11_11));

		BigDecimal itm11_11Prv = trialBalance11dot11Prv.getDrAmount();
		itm11_11Prv = itm11_11Prv.divide(BigDecimal.valueOf(1000), 4);
		itm11_11Prv = itm11_11Prv.setScale(2,RoundingMode.HALF_UP);
		schedule11.setScheduleItem11dot11PreAmt(amtFormatter(itm11_11Prv));

		// 11.10
		BigDecimal itm11_10 = trialBalance11dot10Dtl.getDrAmount().subtract(trialBalance11dot10Dtl.getCrAmount());
		itm11_10 = itm11_10.divide(BigDecimal.valueOf(1000), 4);
		itm11_10 = itm11_10.setScale(2,RoundingMode.HALF_UP);
		itm11_10 = itm11_10.subtract(itm11_11);
		schedule11.setScheduleItem11dot10Amt(amtFormatter(itm11_10));

		BigDecimal itm11_10Prv = trialBalance11dot10Prv.getDrAmount().subtract(trialBalance11dot10Prv.getCrAmount());
		itm11_10Prv = itm11_10Prv.divide(BigDecimal.valueOf(1000), 4);
		itm11_10Prv = itm11_10Prv.setScale(2,RoundingMode.HALF_UP);
		itm11_10Prv = itm11_10Prv.subtract(itm11_11Prv);
		schedule11.setScheduleItem11dot10PreAmt(amtFormatter(itm11_10Prv));

		// 11.9
		schedule11.setScheduleItem11dot9Amt(amtFormatter(BigDecimal.ZERO));
		schedule11.setScheduleItem11dot9PreAmt(amtFormatter(BigDecimal.ZERO));

		// 11.8
		schedule11.setScheduleItem11dot8Amt(amtFormatter(BigDecimal.ZERO));
		schedule11.setScheduleItem11dot8PreAmt(amtFormatter(BigDecimal.ZERO));

		// 11.6
		BigDecimal itm11_6 = trialBalance11dot6Dtl.getDrAmount();
		itm11_6 = itm11_6.divide(BigDecimal.valueOf(1000), 4);
		itm11_6 = itm11_6.setScale(2,RoundingMode.HALF_UP);
		schedule11.setScheduleItem11dot6Amt(amtFormatter(itm11_6));

		BigDecimal itm11_6Prv = trialBalance11dot6Prv.getDrAmount();
		itm11_6Prv = itm11_6Prv.divide(BigDecimal.valueOf(1000), 4);
		itm11_6Prv = itm11_6Prv.setScale(2,RoundingMode.HALF_UP);
		schedule11.setScheduleItem11dot6PreAmt(amtFormatter(itm11_6Prv));

		// 11.5
		BigDecimal itm11_5 = trialBalance11dot5Dtl.getDrAmount().subtract(trialBalance11dot5Dtl.getCrAmount());
		itm11_5 = itm11_5.divide(BigDecimal.valueOf(1000), 4);
		itm11_5 = itm11_5.setScale(2,RoundingMode.HALF_UP);
		itm11_5 = itm11_5.subtract(itm11_6);
		schedule11.setScheduleItem11dot5Amt(amtFormatter(itm11_5));

		BigDecimal itm11_5Prv = trialBalance11dot5Prv.getDrAmount().subtract(trialBalance11dot5Prv.getCrAmount());
		itm11_5Prv = itm11_5Prv.divide(BigDecimal.valueOf(1000), 4);
		itm11_5Prv = itm11_5Prv.setScale(2,RoundingMode.HALF_UP);
		itm11_5Prv = itm11_5Prv.subtract(itm11_6Prv);
		schedule11.setScheduleItem11dot5PreAmt(amtFormatter(itm11_5Prv));

		// 11.1
		BigDecimal itm11_1 = trialBalance11dot1Dtl.getDrAmount().subtract(trialBalance11dot1Dtl.getCrAmount());
		itm11_1 = itm11_1.divide(BigDecimal.valueOf(1000), 4);
		itm11_1 = itm11_1.setScale(2,RoundingMode.HALF_UP);
		schedule11.setScheduleItem11dot1Amt(amtFormatter(itm11_1));

		BigDecimal itm11_1Prv = trialBalance11dot1Prv.getDrAmount().subtract(trialBalance11dot1Prv.getCrAmount());
		itm11_1Prv = itm11_1Prv.divide(BigDecimal.valueOf(1000), 4);
		itm11_1Prv = itm11_1Prv.setScale(2,RoundingMode.HALF_UP);
		schedule11.setScheduleItem11dot1PreAmt(amtFormatter(itm11_1Prv));

		// 11.final
		BigDecimal itm11 = itm11_1.add(itm11_5).add(itm11_6).add(itm11_10).add(itm11_11);
		schedule11.setFinalSchedule11Amt(amtFormatter(itm11));

		BigDecimal itm11Prv = itm11_1Prv.add(itm11_5Prv).add(itm11_6Prv).add(itm11_10Prv).add(itm11_11Prv);
		schedule11.setFinalSchedule11PreAmt(amtFormatter(itm11Prv));

		return schedule11;

	}

	// -----------------------------------------------schedule 14-------------------------------------------------------

	@Override
	public Schedule14 getSchedule14(LocalDate date) {
		log.debug("ScheduleServiceImpl-->getSchedule14()");

		Schedule14 schedule14 = null;
		// if data is present directly take values from trail balance table
		if (scheduleDao.checkForInputDt(date) > 0) {

			schedule14 = getSchedule14Data(date);
			// else generate trail balance and then take values
		} else {

			int curtb = scheduleDao.generateTb(date);

			LocalDate prvDt = date.minusYears(1);

			int prvtb = scheduleDao.generateTbPrv(prvDt);

			if (curtb > 0 && prvtb > 0) {
				schedule14 = getSchedule14Data(date);
			}

		}

		return schedule14;
	}

	public Schedule14 getSchedule14Data(LocalDate date) {

		TrialBalanceDtl trialBalance14dot1Dtl = getTrialBalanceDtl("14", "14.1", date);
		TrialBalanceDtl trialBalance14dot2Dtl = getTrialBalanceDtl("14", "14.2", date);
		TrialBalanceDtl trialBalance14dot3Dtl = getTrialBalanceDtl("14", "14.3", date);
		TrialBalanceDtl trialBalance14dot5Dtl = getTrialBalanceDtl("14", "14.5", date);
		TrialBalanceDtl trialBalance14dot6Dtl = getTrialBalanceDtl("14", "14.6", date);
		TrialBalanceDtl trialBalance14dot7Dtl = getTrialBalanceDtl("14", "14.7", date);
		TrialBalanceDtl trialBalance14dot9Dtl = getTrialBalanceDtl("14", "14.9", date);
		TrialBalanceDtl trialBalance14dot10Dtl = getTrialBalanceDtl("14", "14.10", date);
		TrialBalanceDtl trialBalance14dot11Dtl = getTrialBalanceDtl("14", "14.11", date);
		TrialBalanceDtl trialBalance14dot12Dtl = getTrialBalanceDtl("14", "14.12", date);
		TrialBalanceDtl trialBalance14dot13Dtl = getTrialBalanceDtl("14", "14.13", date);

		LocalDate prvDt = date.minusYears(1);

		TrialBalanceDtl trialBalance14dot1Prv = getTrialBalanceDtlPrv("14", "14.1", prvDt);
		TrialBalanceDtl trialBalance14dot2Prv = getTrialBalanceDtlPrv("14", "14.2", prvDt);
		TrialBalanceDtl trialBalance14dot3Prv = getTrialBalanceDtlPrv("14", "14.3", prvDt);
		TrialBalanceDtl trialBalance14dot5Prv = getTrialBalanceDtlPrv("14", "14.5", prvDt);
		TrialBalanceDtl trialBalance14dot6Prv = getTrialBalanceDtlPrv("14", "14.6", prvDt);
		TrialBalanceDtl trialBalance14dot7Prv = getTrialBalanceDtlPrv("14", "14.7", prvDt);
		TrialBalanceDtl trialBalance14dot9Prv = getTrialBalanceDtlPrv("14", "14.9", prvDt);
		TrialBalanceDtl trialBalance14dot10Prv = getTrialBalanceDtlPrv("14", "14.10", prvDt);
		TrialBalanceDtl trialBalance14dot11Prv = getTrialBalanceDtlPrv("14", "14.11", prvDt);
		TrialBalanceDtl trialBalance14dot12Prv = getTrialBalanceDtlPrv("14", "14.12", prvDt);
		TrialBalanceDtl trialBalance14dot13Prv = getTrialBalanceDtlPrv("14", "14.13", prvDt);

		Schedule14 schedule14 = new Schedule14();

		schedule14.setCreatedBy(userInfoService.getName());
		schedule14.setScheduleItem14dot1Name("असमाप्त जोखिम के लिए आरक्षित/Reserve for Unexpired Risk");
		schedule14.setScheduleItem14dot2Name("प्रीमियम की कमी के लिए रिजर्व/Reserve for Premium Deficiency");
		schedule14.setScheduleItem14dot4Name("कराधान के लिए/For Taxation");
		schedule14.setScheduleItem14dot5Name("- आयकर (अग्रिम कर का शुद्ध)/Income Tax (Net of Advance Tax)");
		schedule14.setScheduleItem14dot7Name("प्रस्तावित लाभांश के लिए/For Proposed Dividends");
		schedule14.setScheduleItem14dot8Name("लाभांश वितरण कर के लिए/For Dividend distribution Tax");
		schedule14.setScheduleItem14dot6Name("सेवानिवृत्ति लाभ के लिए/For Retirement Benefits");
		schedule14.setScheduleItem14dot9Name("- अवकाश नकदीकरण एवं लंबी सेवा/Leave Encashment & Long Service");
		schedule14.setScheduleItem14dot10Name("- ग्रेच्युटी/Gratuity");
		schedule14.setScheduleItem14dot11Name("- पेंशन/Pension");
		schedule14.setScheduleItem14dot12Name("कम कारोबार वाले शेयरों के लिए/For Thinly Traded Shares");
		schedule14.setScheduleItem14dot13Name("निवेश परिसंपत्तियों के लिए/For Investment Assets");

		schedule14.setFinalSchedule14Name("कुल योग/GRAND TOTAL");

		// 14.1
		BigDecimal itm14_1 = trialBalance14dot1Dtl.getCrAmount().subtract(trialBalance14dot1Dtl.getDrAmount());
		itm14_1 = itm14_1.divide(BigDecimal.valueOf(1000), 4);
		itm14_1 = itm14_1.setScale(2,RoundingMode.HALF_UP);
		schedule14.setScheduleItem14dot1Amt(amtFormatter(itm14_1));

		BigDecimal itm14_1Prv = trialBalance14dot1Prv.getCrAmount().subtract(trialBalance14dot1Prv.getDrAmount());
		itm14_1Prv = itm14_1Prv.divide(BigDecimal.valueOf(1000), 4);
		itm14_1Prv = itm14_1Prv.setScale(2,RoundingMode.HALF_UP);
		schedule14.setScheduleItem14dot1PreAmt(amtFormatter(itm14_1Prv));

		// 14.2
		BigDecimal itm14_2 = trialBalance14dot2Dtl.getCrAmount().subtract(trialBalance14dot2Dtl.getDrAmount());
		itm14_2 = itm14_2.divide(BigDecimal.valueOf(1000), 4);
		itm14_2 = itm14_2.setScale(2,RoundingMode.HALF_UP);
		schedule14.setScheduleItem14dot2Amt(amtFormatter(itm14_2));

		BigDecimal itm14_2Prv = trialBalance14dot2Prv.getCrAmount().subtract(trialBalance14dot2Prv.getDrAmount());
		itm14_2Prv = itm14_2Prv.divide(BigDecimal.valueOf(1000), 4);
		itm14_2Prv = itm14_2Prv.setScale(2,RoundingMode.HALF_UP);
		schedule14.setScheduleItem14dot2PreAmt(amtFormatter(itm14_2Prv));

		// 14.5
		BigDecimal itm14_5 = trialBalance14dot5Dtl.getDrAmount().subtract(trialBalance14dot5Dtl.getCrAmount());
		itm14_5 = itm14_5.divide(BigDecimal.valueOf(1000), 4);
		itm14_5 = itm14_5.setScale(2,RoundingMode.HALF_UP);
		itm14_5 = itm14_5.compareTo(BigDecimal.ZERO) < 0 ? itm14_5 : BigDecimal.ZERO;
		schedule14.setScheduleItem14dot5Amt(amtFormatter(itm14_5));

		BigDecimal itm14_5Prv = trialBalance14dot5Prv.getDrAmount().subtract(trialBalance14dot5Prv.getCrAmount());
		itm14_5Prv = itm14_5Prv.divide(BigDecimal.valueOf(1000), 4);
		itm14_5Prv = itm14_5Prv.setScale(2,RoundingMode.HALF_UP);
		itm14_5Prv = itm14_5Prv.compareTo(BigDecimal.ZERO) < 0 ? itm14_5Prv : BigDecimal.ZERO;
		schedule14.setScheduleItem14dot5PreAmt(amtFormatter(itm14_5Prv));

		// 14.7
		BigDecimal itm14_7 = trialBalance14dot7Dtl.getCrAmount();
		itm14_7 = itm14_7.divide(BigDecimal.valueOf(1000), 4);
		itm14_7 = itm14_7.setScale(2,RoundingMode.HALF_UP);
		schedule14.setScheduleItem14dot7Amt(amtFormatter(itm14_7));

		BigDecimal itm14_7Prv = trialBalance14dot7Prv.getCrAmount();
		itm14_7Prv = itm14_7Prv.divide(BigDecimal.valueOf(1000), 4);
		itm14_7Prv = itm14_7Prv.setScale(2,RoundingMode.HALF_UP);
		schedule14.setScheduleItem14dot7PreAmt(amtFormatter(itm14_7Prv));

		// 14.8
		schedule14.setScheduleItem14dot8Amt(amtFormatter(BigDecimal.ZERO));
		schedule14.setScheduleItem14dot8PreAmt(amtFormatter(BigDecimal.ZERO));

		// 14.9
		BigDecimal itm14_9 = trialBalance14dot9Dtl.getCrAmount();
		itm14_9 = itm14_9.divide(BigDecimal.valueOf(1000), 4);
		itm14_9 = itm14_9.setScale(2,RoundingMode.HALF_UP);
		schedule14.setScheduleItem14dot9Amt(amtFormatter(itm14_9));

		BigDecimal itm14_9Prv = trialBalance14dot9Prv.getCrAmount();
		itm14_9Prv = itm14_9Prv.divide(BigDecimal.valueOf(1000), 4);
		itm14_9Prv = itm14_9Prv.setScale(2,RoundingMode.HALF_UP);
		schedule14.setScheduleItem14dot9PreAmt(amtFormatter(itm14_9Prv));

		// 14.10
		BigDecimal itm14_10 = trialBalance14dot10Dtl.getCrAmount();
		itm14_10 = itm14_10.divide(BigDecimal.valueOf(1000), 4);
		itm14_10 = itm14_10.setScale(2,RoundingMode.HALF_UP);
		schedule14.setScheduleItem14dot10Amt(amtFormatter(itm14_10));

		BigDecimal itm14_10Prv = trialBalance14dot10Prv.getCrAmount();
		itm14_10Prv = itm14_10Prv.divide(BigDecimal.valueOf(1000), 4);
		itm14_10Prv = itm14_10Prv.setScale(2,RoundingMode.HALF_UP);
		schedule14.setScheduleItem14dot10PreAmt(amtFormatter(itm14_10Prv));

		// 14.11
		BigDecimal itm14_11 = trialBalance14dot11Dtl.getCrAmount();
		itm14_11 = itm14_11.divide(BigDecimal.valueOf(1000), 4);
		itm14_11 = itm14_11.setScale(2,RoundingMode.HALF_UP);
		schedule14.setScheduleItem14dot11Amt(amtFormatter(itm14_11));

		BigDecimal itm14_11Prv = trialBalance14dot11Prv.getCrAmount();
		itm14_11Prv = itm14_11Prv.divide(BigDecimal.valueOf(1000), 4);
		itm14_11Prv = itm14_11Prv.setScale(2,RoundingMode.HALF_UP);
		schedule14.setScheduleItem14dot11PreAmt(amtFormatter(itm14_11Prv));

		// 14.12
		BigDecimal itm14_12 = trialBalance14dot12Dtl.getCrAmount();
		itm14_12 = itm14_12.divide(BigDecimal.valueOf(1000), 4);
		itm14_12 = itm14_12.setScale(2,RoundingMode.HALF_UP);
		schedule14.setScheduleItem14dot12Amt(amtFormatter(itm14_12));

		BigDecimal itm14_12Prv = trialBalance14dot12Prv.getCrAmount();
		itm14_12Prv = itm14_12Prv.divide(BigDecimal.valueOf(1000), 4);
		itm14_12 = itm14_12.setScale(2,RoundingMode.HALF_UP);
		schedule14.setScheduleItem14dot12PreAmt(amtFormatter(itm14_12Prv));

		// 14.12
		BigDecimal itm14_13 = trialBalance14dot13Dtl.getCrAmount();
		itm14_13 = itm14_13.divide(BigDecimal.valueOf(1000), 4);
		itm14_13 = itm14_13.setScale(2,RoundingMode.HALF_UP);
		schedule14.setScheduleItem14dot13Amt(amtFormatter(itm14_13));

		BigDecimal itm14_13Prv = trialBalance14dot13Prv.getCrAmount();
		itm14_13Prv = itm14_13Prv.divide(BigDecimal.valueOf(1000), 4);
		itm14_13Prv = itm14_13Prv.setScale(2,RoundingMode.HALF_UP);
		schedule14.setScheduleItem14dot13PreAmt(amtFormatter(itm14_13Prv));

		BigDecimal itm14 = itm14_1.add(itm14_2).add(itm14_5).add(itm14_7).add(itm14_9).add(itm14_10).add(itm14_11)
				.add(itm14_12).add(itm14_13);

		schedule14.setFinalSchedule14Amt(amtFormatter(itm14));
		BigDecimal itm14Prv = itm14_1Prv.add(itm14_2Prv).add(itm14_5Prv).add(itm14_7Prv).add(itm14_9Prv)
				.add(itm14_10Prv).add(itm14_11Prv).add(itm14_12Prv).add(itm14_13Prv);
		schedule14.setFinalSchedule14PreAmt(amtFormatter(itm14Prv));

		return schedule14;

	}

	// -------------------------------------------------------schedule 13-----------------------------------------------------

	@Override
	public Schedule13 getSchedule13(LocalDate date) {
		log.debug("ScheduleServiceImpl-->getSchedule13()");

		Schedule13 schedule13 = null;
		// if data is present directly take values from trail balance table
		if (scheduleDao.checkForInputDt(date) > 0) {

			schedule13 = getSchedule13Data(date);
			// else generate trail balance and then take values
		} else {

			int curtb = scheduleDao.generateTb(date);

			LocalDate prvDt = date.minusYears(1);

			int prvtb = scheduleDao.generateTbPrv(prvDt);

			if (curtb > 0 && prvtb > 0) {
				schedule13 = getSchedule13Data(date);
			}

		}

		return schedule13;
	}

	public Schedule13 getSchedule13Data(LocalDate date) {
		TrialBalanceDtl trialBalance13dot2Dtl = getTrialBalanceDtl("13", "13.2", date);
		TrialBalanceDtl trialBalance13dot4Dtl = getTrialBalanceDtl("13", "13.4", date);
		TrialBalanceDtl trialBalance13dot5Dtl = getTrialBalanceDtl("13", "13.5", date);
		TrialBalanceDtl trialBalance13dot6Dtl = getTrialBalanceDtl("13", "13.6", date);
		TrialBalanceDtl trialBalance13dot7Dtl = getTrialBalanceDtl("13", "13.7", date);
		TrialBalanceDtl trialBalance13dot8Dtl = getTrialBalanceDtl("13", "13.8", date);
		TrialBalanceDtl trialBalance13dot10Dtl = getTrialBalanceDtl("13", "13.10", date);
		TrialBalanceDtl trialBalance13dot11Dtl = getTrialBalanceDtl("13", "13.11", date);
		TrialBalanceDtl trialBalance13dot13Dtl = getTrialBalanceDtl("13", "13.13", date);
		TrialBalanceDtl trialBalance13dot14Dtl = getTrialBalanceDtl("13", "13.14", date);
		TrialBalanceDtl trialBalance13dot15Dtl = getTrialBalanceDtl("13", "13.15", date);
		TrialBalanceDtl trialBalance13dot16Dtl = getTrialBalanceDtl("13", "13.16", date);

		LocalDate prvDt = date.minusYears(1);

		TrialBalanceDtl trialBalance13dot2Prv = getTrialBalanceDtlPrv("13", "13.2", prvDt);
		TrialBalanceDtl trialBalance13dot4Prv = getTrialBalanceDtlPrv("13", "13.4", prvDt);
		TrialBalanceDtl trialBalance13dot5Prv = getTrialBalanceDtlPrv("13", "13.5", prvDt);
		TrialBalanceDtl trialBalance13dot6Prv = getTrialBalanceDtlPrv("13", "13.6", prvDt);
		TrialBalanceDtl trialBalance13dot7Prv = getTrialBalanceDtlPrv("13", "13.7", prvDt);
		TrialBalanceDtl trialBalance13dot8Prv = getTrialBalanceDtlPrv("13", "13.8", prvDt);
		TrialBalanceDtl trialBalance13dot10Prv = getTrialBalanceDtlPrv("13", "13.10", prvDt);
		TrialBalanceDtl trialBalance13dot11Prv = getTrialBalanceDtlPrv("13", "13.11", prvDt);
		TrialBalanceDtl trialBalance13dot13Prv = getTrialBalanceDtlPrv("13", "13.13", prvDt);
		TrialBalanceDtl trialBalance13dot14Prv = getTrialBalanceDtlPrv("13", "13.14", prvDt);
		TrialBalanceDtl trialBalance13dot15Prv = getTrialBalanceDtlPrv("13", "13.15", prvDt);
		TrialBalanceDtl trialBalance13dot16Prv = getTrialBalanceDtlPrv("13", "13.16", prvDt);

		Schedule13 schedule13 = new Schedule13();
		// write here

		schedule13.setCreatedBy(userInfoService.getName());
		schedule13.setScheduleItem13dot1Name("एजेंटों का शेष/Agents' Balances");
		schedule13.setScheduleItem13dot2Name("अन्य बीमा कंपनियों को देय शेष/Balances due to other Insurance Companies");
		schedule13.setScheduleItem13dot3Name(
				"पुनर्बीमा पर रखी गई जमा राशि वापस कर दी गई/Deposits held on re-insurance ceded");
		schedule13.setScheduleItem13dot4Name("प्रीमियम अग्रिम रूप से प्राप्त हुआ/Premiums received in advance");
		schedule13.setScheduleItem13dot5Name("अनावंटित प्रीमियम/Unallocated Premium");
		schedule13.setScheduleItem13dot6Name("पॉलिसीधारकों की दावा न की गई राशि/Unclaimed Amount of Policyholders");
		schedule13.setScheduleItem13dot7Name(
				"जोड़ें: पॉलिसीधारकों की दावा न की गई राशि पर अर्जित ब्याज/Add: Interest earned on Unclaimed Amount of Policyholders");
		schedule13.setScheduleItem13dot8Name("विविध लेनदार/Sundry Creditors");
		schedule13
				.setScheduleItem13dot9Name("सहायक कंपनियों/होल्डिंग कंपनी के कारण/Due to subsidiaries/holding company");
		schedule13.setScheduleItem13dot10Name("दावा बकाया है/Claims outstanding");
		schedule13.setScheduleItem13dot11Name("कर्मचारियों के कारण/Due to Employees");
		schedule13.setScheduleItem13dot12Name("अन्य/Others");
		schedule13.setScheduleItem13dot13Name("         - एनईआईए/NEIA");
		schedule13.setScheduleItem13dot14Name("         - फैक्टरिंग/Factoring ");
		schedule13.setScheduleItem13dot15Name("         - मिश्रित/Miscellaneous");
		schedule13.setScheduleItem13dot16Name("         - जीएसटी देनदारी/GST Liability");
		schedule13.setFinalSchedule13Name("कुल/TOTAL");

		// 13.1
		schedule13.setScheduleItem13dot1Amt(amtFormatter(BigDecimal.ZERO));
		schedule13.setScheduleItem13dot1PreAmt(amtFormatter(BigDecimal.ZERO));

		// 13.2
		BigDecimal itm13_2 = trialBalance13dot2Dtl.getCrAmount().subtract(trialBalance13dot2Dtl.getDrAmount());
		itm13_2 = itm13_2.divide(BigDecimal.valueOf(1000), 4);
		itm13_2 = itm13_2.setScale(2,RoundingMode.HALF_UP);
		schedule13.setScheduleItem13dot2Amt(amtFormatter(itm13_2));

		BigDecimal itm13_2Prv = trialBalance13dot2Prv.getCrAmount().subtract(trialBalance13dot2Prv.getDrAmount());
		itm13_2Prv = itm13_2Prv.divide(BigDecimal.valueOf(1000), 4);
		itm13_2Prv = itm13_2Prv.setScale(2,RoundingMode.HALF_UP);
		schedule13.setScheduleItem13dot2PreAmt(amtFormatter(itm13_2Prv));

		// 13.3
		schedule13.setScheduleItem13dot3Amt(amtFormatter(BigDecimal.ZERO));
		schedule13.setScheduleItem13dot3PreAmt(amtFormatter(BigDecimal.ZERO));

		// 13.4
		BigDecimal itm13_4 = trialBalance13dot4Dtl.getCrAmount();
		itm13_4 = itm13_4.divide(BigDecimal.valueOf(1000), 4);
		itm13_4 = itm13_4.setScale(2,RoundingMode.HALF_UP);
		schedule13.setScheduleItem13dot4Amt(amtFormatter(itm13_4));

		BigDecimal itm13_4Prv = trialBalance13dot4Prv.getCrAmount();
		itm13_4Prv = itm13_4Prv.divide(BigDecimal.valueOf(1000), 4);
		itm13_4Prv = itm13_4Prv.setScale(2,RoundingMode.HALF_UP);
		schedule13.setScheduleItem13dot4PreAmt(amtFormatter(itm13_4Prv));

		// 13.5
		BigDecimal itm13_5 = trialBalance13dot5Dtl.getCrAmount().subtract(trialBalance13dot5Dtl.getDrAmount());
		itm13_5 = itm13_5.divide(BigDecimal.valueOf(1000), 4);
		itm13_5 = itm13_5.setScale(2,RoundingMode.HALF_UP);
		schedule13.setScheduleItem13dot5Amt(amtFormatter(itm13_5));

		BigDecimal itm13_5Prv = trialBalance13dot5Prv.getCrAmount().subtract(trialBalance13dot5Prv.getDrAmount());
		itm13_5Prv = itm13_5Prv.divide(BigDecimal.valueOf(1000), 4);
		itm13_5Prv = itm13_5Prv.setScale(2,RoundingMode.HALF_UP);
		schedule13.setScheduleItem13dot5PreAmt(amtFormatter(itm13_5Prv));

		// 13.7
		BigDecimal itm13_7 = trialBalance13dot7Dtl.getCrAmount();
		itm13_7 = itm13_7.divide(BigDecimal.valueOf(1000), 4);
		itm13_7 = itm13_7.setScale(2,RoundingMode.HALF_UP);
		schedule13.setScheduleItem13dot7Amt(amtFormatter(itm13_7));

		BigDecimal itm13_7Prv = trialBalance13dot7Prv.getCrAmount();
		itm13_7Prv = itm13_7Prv.divide(BigDecimal.valueOf(1000), 4);
		itm13_7Prv = itm13_7Prv.setScale(2,RoundingMode.HALF_UP);
		schedule13.setScheduleItem13dot7PreAmt(amtFormatter(itm13_7Prv));

		// 13.6
		BigDecimal itm13_6 = trialBalance13dot6Dtl.getCrAmount().subtract(trialBalance13dot6Dtl.getDrAmount());
		itm13_6 = itm13_6.divide(BigDecimal.valueOf(1000), 4);
		itm13_6 = itm13_6.setScale(2,RoundingMode.HALF_UP);
		itm13_6 = itm13_6.subtract(itm13_7);
		schedule13.setScheduleItem13dot6Amt(amtFormatter(itm13_6));

		BigDecimal itm13_6Prv = trialBalance13dot6Prv.getCrAmount().subtract(trialBalance13dot6Prv.getDrAmount());
		itm13_6Prv = itm13_6Prv.divide(BigDecimal.valueOf(1000), 4);
		itm13_6Prv = itm13_6Prv.setScale(2,RoundingMode.HALF_UP);
		itm13_6Prv = itm13_6Prv.subtract(itm13_7Prv);
		schedule13.setScheduleItem13dot6PreAmt(amtFormatter(itm13_6Prv));

		// sum 13.6 13.7

		BigDecimal itmsum13_6_7 = itm13_6.add(itm13_7);

		schedule13.setSumScheduleItem13dot6and7Amt(amtFormatter(itmsum13_6_7));

		BigDecimal itm13_6_7Prv = itm13_6Prv.add(itm13_7Prv);

		schedule13.setSumScheduleItem13dot6and7PreAmt(amtFormatter(itm13_6_7Prv));

		// 13.8
		BigDecimal itm13_8 = trialBalance13dot8Dtl.getCrAmount().subtract(trialBalance13dot8Dtl.getDrAmount());
		itm13_8 = itm13_8.divide(BigDecimal.valueOf(1000), 4);
		itm13_8 = itm13_8.setScale(2,RoundingMode.HALF_UP);
		schedule13.setScheduleItem13dot8Amt(amtFormatter(itm13_8));

		BigDecimal itm13_8Prv = trialBalance13dot8Prv.getCrAmount().subtract(trialBalance13dot8Prv.getDrAmount());
		itm13_8Prv = itm13_8Prv.divide(BigDecimal.valueOf(1000), 4);
		itm13_8Prv = itm13_8Prv.setScale(2,RoundingMode.HALF_UP);
		schedule13.setScheduleItem13dot8PreAmt(amtFormatter(itm13_8Prv));

		// 13.9
		schedule13.setScheduleItem13dot9Amt(amtFormatter(BigDecimal.ZERO));
		schedule13.setScheduleItem13dot9PreAmt(amtFormatter(BigDecimal.ZERO));

		// 13.10
		BigDecimal itm13_10 = trialBalance13dot10Dtl.getCrAmount().subtract(trialBalance13dot10Dtl.getDrAmount());
		itm13_10 = itm13_10.divide(BigDecimal.valueOf(1000), 4);
		itm13_10 = itm13_10.setScale(2,RoundingMode.HALF_UP);
		schedule13.setScheduleItem13dot10Amt(amtFormatter(itm13_10));

		BigDecimal itm13_10Prv = trialBalance13dot10Prv.getCrAmount().subtract(trialBalance13dot10Prv.getDrAmount());
		itm13_10Prv = itm13_10Prv.divide(BigDecimal.valueOf(1000), 4);
		itm13_10Prv = itm13_10Prv.setScale(2,RoundingMode.HALF_UP);
		schedule13.setScheduleItem13dot10PreAmt(amtFormatter(itm13_10Prv));

		// 13.11
		BigDecimal itm13_11 = trialBalance13dot11Dtl.getCrAmount().subtract(trialBalance13dot11Dtl.getDrAmount());
		itm13_11 = itm13_11.divide(BigDecimal.valueOf(1000), 4);
		itm13_11 = itm13_11.setScale(2,RoundingMode.HALF_UP);
		schedule13.setScheduleItem13dot11Amt(amtFormatter(itm13_11));

		BigDecimal itm13_11Prv = trialBalance13dot11Prv.getCrAmount().subtract(trialBalance13dot11Prv.getDrAmount());
		itm13_11Prv = itm13_11Prv.divide(BigDecimal.valueOf(1000), 4);
		itm13_11Prv = itm13_11Prv.setScale(2,RoundingMode.HALF_UP);
		schedule13.setScheduleItem13dot11PreAmt(amtFormatter(itm13_11Prv));

		// 13.13
		BigDecimal itm13_13 = trialBalance13dot13Dtl.getCrAmount();
		itm13_13 = itm13_13.divide(BigDecimal.valueOf(1000), 4);
		itm13_13 = itm13_13.setScale(2,RoundingMode.HALF_UP);
		schedule13.setScheduleItem13dot13Amt(amtFormatter(itm13_13));

		BigDecimal itm13_13Prv = trialBalance13dot13Prv.getCrAmount();
		itm13_13Prv = itm13_13Prv.divide(BigDecimal.valueOf(1000), 4);
		itm13_13Prv = itm13_13Prv.setScale(2,RoundingMode.HALF_UP);
		schedule13.setScheduleItem13dot13PreAmt(amtFormatter(itm13_13Prv));

		// 13.14
		BigDecimal itm13_14 = trialBalance13dot14Dtl.getCrAmount();
		itm13_14 = itm13_14.divide(BigDecimal.valueOf(1000), 4);
		itm13_14 = itm13_14.setScale(2,RoundingMode.HALF_UP);
		schedule13.setScheduleItem13dot14Amt(amtFormatter(itm13_14));

		BigDecimal itm13_14Prv = trialBalance13dot14Prv.getCrAmount();
		itm13_14Prv = itm13_14Prv.divide(BigDecimal.valueOf(1000), 4);
		itm13_14Prv = itm13_14Prv.setScale(2,RoundingMode.HALF_UP);
		schedule13.setScheduleItem13dot14PreAmt(amtFormatter(itm13_14Prv));

		// 13.15
		BigDecimal itm13_15 = trialBalance13dot15Dtl.getCrAmount().subtract(trialBalance13dot15Dtl.getDrAmount());
		itm13_15 = itm13_15.divide(BigDecimal.valueOf(1000), 4);
		itm13_15 = itm13_15.setScale(2,RoundingMode.HALF_UP);
		schedule13.setScheduleItem13dot15Amt(amtFormatter(itm13_15));

		BigDecimal itm13_15Prv = trialBalance13dot15Prv.getCrAmount().subtract(trialBalance13dot15Prv.getDrAmount());
		itm13_15Prv = itm13_15Prv.divide(BigDecimal.valueOf(1000), 4);
		itm13_15Prv = itm13_15Prv.setScale(2,RoundingMode.HALF_UP);
		schedule13.setScheduleItem13dot15PreAmt(amtFormatter(itm13_15Prv));

		// 13.16
		BigDecimal itm13_16 = trialBalance13dot16Dtl.getCrAmount().subtract(trialBalance13dot16Dtl.getDrAmount());
		itm13_16 = itm13_16.divide(BigDecimal.valueOf(1000), 4);
		itm13_16 = itm13_16.setScale(2,RoundingMode.HALF_UP);
		schedule13.setScheduleItem13dot16Amt(amtFormatter(itm13_16));

		BigDecimal itm13_16Prv = trialBalance13dot16Prv.getCrAmount().subtract(trialBalance13dot16Prv.getDrAmount());
		itm13_16Prv = itm13_16Prv.divide(BigDecimal.valueOf(1000), 4);
		itm13_16Prv = itm13_16Prv.setScale(2,RoundingMode.HALF_UP);
		schedule13.setScheduleItem13dot16PreAmt(amtFormatter(itm13_16Prv));

		// total
		BigDecimal itm13 = itm13_2.add(itm13_4).add(itm13_5).add(itm13_6).add(itm13_7).add(itm13_8).add(itm13_10)
				.add(itm13_11).add(itm13_13).add(itm13_14).add(itm13_15).add(itm13_16);

		schedule13.setFinalSchedule13Amt(amtFormatter(itm13));

		BigDecimal itm13Prv = itm13_2Prv.add(itm13_4Prv).add(itm13_5Prv).add(itm13_6Prv).add(itm13_7Prv).add(itm13_8Prv)
				.add(itm13_10Prv).add(itm13_11Prv).add(itm13_13Prv).add(itm13_14Prv).add(itm13_15Prv).add(itm13_16Prv);
		schedule13.setFinalSchedule13PreAmt(amtFormatter(itm13Prv));

		return schedule13;
	}

	// -------------------------------------------------schedule 12---------------------------------------------------------

	@Override
	public Schedule12 getSchedule12(LocalDate date) {
		log.debug("ScheduleServiceImpl-->getSchedule13()");

		Schedule12 schedule12 = null;
		// if data is present directly take values from trail balance table
		if (scheduleDao.checkForInputDt(date) > 0) {

			schedule12 = getSchedule12Data(date);
			// else generate trail balance and then take values
		} else {

			int curtb = scheduleDao.generateTb(date);

			LocalDate prvDt = date.minusYears(1);

			int prvtb = scheduleDao.generateTbPrv(prvDt);

			if (curtb > 0 && prvtb > 0) {
				schedule12 = getSchedule12Data(date);
			}

		}

		return schedule12;
	}

	public Schedule12 getSchedule12Data(LocalDate date) {
		TrialBalanceDtl trialBalance12dot2Dtl = getTrialBalanceDtl("12", "12.2", date);
		TrialBalanceDtl trialBalance12dot3Dtl = getTrialBalanceDtl("12", "12.3", date);
		TrialBalanceDtl trialBalance12dot5Dtl = getTrialBalanceDtl("12", "12.5", date);
		TrialBalanceDtl trialBalance12dot6Dtl = getTrialBalanceDtl("12", "12.6", date);
		TrialBalanceDtl trialBalance12dot7Dtl = getTrialBalanceDtl("12", "12.7", date);
		TrialBalanceDtl trialBalance12dot10Dtl = getTrialBalanceDtl("12", "12.10", date);
		TrialBalanceDtl trialBalance12dot14Dtl = getTrialBalanceDtl("12", "12.14", date);
		TrialBalanceDtl trialBalance12dot16Dtl = getTrialBalanceDtl("12", "12.16", date);
		TrialBalanceDtl trialBalance12dot18Dtl = getTrialBalanceDtl("12", "12.18", date);
		TrialBalanceDtl trialBalance12dot20Dtl = getTrialBalanceDtl("12", "12.20", date);
		TrialBalanceDtl trialBalance12dot21Dtl = getTrialBalanceDtl("12", "12.21", date);
		TrialBalanceDtl trialBalance12dot26Dtl = getTrialBalanceDtl("12", "12.26", date);
		TrialBalanceDtl trialBalance12dot30Dtl = getTrialBalanceDtl("12", "12.30", date);
		TrialBalanceDtl trialBalance12dot31Dtl = getTrialBalanceDtl("12", "12.31", date);
		TrialBalanceDtl trialBalance12dot33Dtl = getTrialBalanceDtl("12", "12.33", date);
		TrialBalanceDtl trialBalance12dot36Dtl = getTrialBalanceDtl("12", "12.36", date);
		TrialBalanceDtl trialBalance12dot37Dtl = getTrialBalanceDtl("12", "12.37", date);
		TrialBalanceDtl trialBalance12dot38Dtl = getTrialBalanceDtl("12", "12.38", date);

		LocalDate prvDt = date.minusYears(1);

		TrialBalanceDtl trialBalance12dot2Prv = getTrialBalanceDtlPrv("12", "12.2", prvDt);
		TrialBalanceDtl trialBalance12dot3Prv = getTrialBalanceDtlPrv("12", "12.3", prvDt);
		TrialBalanceDtl trialBalance12dot5Prv = getTrialBalanceDtlPrv("12", "12.5", prvDt);
		TrialBalanceDtl trialBalance12dot6Prv = getTrialBalanceDtlPrv("12", "12.6", prvDt);
		TrialBalanceDtl trialBalance12dot7Prv = getTrialBalanceDtlPrv("12", "12.7", prvDt);
		TrialBalanceDtl trialBalance12dot10Prv = getTrialBalanceDtlPrv("12", "12.10", prvDt);
		TrialBalanceDtl trialBalance12dot14Prv = getTrialBalanceDtlPrv("12", "12.14", prvDt);
		TrialBalanceDtl trialBalance12dot16Prv = getTrialBalanceDtlPrv("12", "12.16", prvDt);
		TrialBalanceDtl trialBalance12dot18Prv = getTrialBalanceDtlPrv("12", "12.18", prvDt);
		TrialBalanceDtl trialBalance12dot20Prv = getTrialBalanceDtlPrv("12", "12.20", prvDt);
		TrialBalanceDtl trialBalance12dot21Prv = getTrialBalanceDtlPrv("12", "12.21", prvDt);
		TrialBalanceDtl trialBalance12dot26Prv = getTrialBalanceDtlPrv("12", "12.26", prvDt);
		TrialBalanceDtl trialBalance12dot30Prv = getTrialBalanceDtlPrv("12", "12.30", prvDt);
		TrialBalanceDtl trialBalance12dot31Prv = getTrialBalanceDtlPrv("12", "12.31", prvDt);
		TrialBalanceDtl trialBalance12dot33Prv = getTrialBalanceDtlPrv("12", "12.33", prvDt);
		TrialBalanceDtl trialBalance12dot36Prv = getTrialBalanceDtlPrv("12", "12.36", prvDt);
		TrialBalanceDtl trialBalance12dot37Prv = getTrialBalanceDtlPrv("12", "12.37", prvDt);
		TrialBalanceDtl trialBalance12dot38Prv = getTrialBalanceDtlPrv("12", "12.38", prvDt);

		Schedule12 schedule12 = new Schedule12();
		// write here

		schedule12.setCreatedBy(userInfoService.getName());
		schedule12.setScheduleItem12dot0Name("अग्रिम/ADVANCES");
		schedule12.setScheduleItem12dot1Name(
				"सौंपने वाली कंपनियों के पास जमा सुरक्षित रखें/Reserve deposits with ceding companies");
		schedule12.setScheduleItem12dot2Name("निवेश के लिए आवेदन राशि/Application money for investments");
		schedule12.setScheduleItem12dot3Name("पूर्वभुगतान/Prepayments");
		schedule12.setScheduleItem12dot4Name("निदेशकों को अग्रिम/Advance to Directors");
		schedule12.setScheduleItem12dot5Name(
				"भुगतान किया गया अग्रिम कर और स्रोत पर काटा गया कर (कराधान के प्रावधान का शुद्ध)/Advance Tax paid and taxes deducted at source (Net of provision for taxation)");
		schedule12.setScheduleItem12dot6Name("कर्मचारियों को अग्रिम/Advances to Employees");
		schedule12.setScheduleItem12dot7Name("व्यय के लिए अग्रिम/Advance for Expenses");
		schedule12.setScheduleItem12dot8Name("कुल (ए)/TOTAL (A)");
		schedule12.setScheduleItem12dot9Name("अन्य परिसंपत्तियां/OTHER ASSETS");
		schedule12.setScheduleItem12dot10Name("निवेश पर अर्जित आय/Income accrued on Investments");
		schedule12.setScheduleItem12dot11Name("बकाया प्रीमियम/Outstanding Premiums");
		schedule12.setScheduleItem12dot12Name("एजेंटों का शेष/Agents' Balances");
		schedule12.setScheduleItem12dot13Name("विदेशी एजेंसियाँ शेष/Foreign Agencies Balances");
		schedule12.setScheduleItem12dot14Name(
				"बीमा कारोबार करने वाली अन्य संस्थाओं से देय (पुनर्बीमाकर्ताओं सहित)/Due from other entities carrying on insurance business (including reinsurers)");
		schedule12.setScheduleItem12dot15Name("सहायक कंपनियों/होल्डिंग से देय/Due from subsidiaries/holding");
		schedule12.setScheduleItem12dot16Name("भारतीय रिज़र्व बैंक के पास जमा/Deposit with Reserve Bank of India");
		schedule12.setScheduleItem12dot17Name(
				"(बीमा अधिनियम, 1938 की धारा 7 के अनुसार)/(Pursuant to section 7 of Insurance Act, 1938)s");
		schedule12.setScheduleItem12dot18Name("आवास ऋण पर ब्याज एकत्रित हुआ/Interest accrued on Housing Loan");
		schedule12.setScheduleItem12dot19Name("विविध देयकों/Sundry Debtors");
		schedule12.setScheduleItem12dot20Name("मानक संपत्ति/Standard Asset");
		schedule12.setScheduleItem12dot21Name("कम: मानक संपत्ति के लिए प्रावधान/Less: Provision for Standard Asset");
		schedule12.setScheduleItem12dot22Name("( I )");
		schedule12.setScheduleItem12dot23Name("अस्थायी संपत्ति/Sub - Standard Asset");
		schedule12.setScheduleItem12dot24Name(
				"कम: अस्थायी संपत्ति के लिए प्रावधान/Less : Provision for Sub - Standard Asset");
		schedule12.setScheduleItem12dot25Name("( II )");
		schedule12.setScheduleItem12dot26Name("संदिग्ध संपत्ति/Doubtful Asset");
		schedule12
				.setScheduleItem12dot27Name("कम: संदिग्ध संपत्ति के लिए प्रावधान/Less : Provision for Doubtful Asset");
		schedule12.setScheduleItem12dot28Name("( III )");
		schedule12.setScheduleItem12dot29Name("( I + II + III )");
		schedule12.setScheduleItem12dot30Name("अन्य से उधारी राशि/Amount Recoverable from others");
		schedule12
				.setScheduleItem12dot31Name("कम: संदिग्ध वसूली के लिए प्रावधान/Less: Provision for Doubtful Recovery");
		schedule12.setScheduleItem12dot33Name("विविध जमा/Sundry Deposits");
		schedule12.setScheduleItem12dot34Name("कम: संदिग्ध ऋण के लिए प्रावधान/Less: Provision for Doubtful Debts");
		schedule12.setScheduleItem12dot36Name(
				"पॉलिसीधारक संपत्ति के लिए अस्थायी राशि/Unclaimed Amount for Policyholder Assets");
		schedule12.setScheduleItem12dot37Name(
				"जोड़ें: पॉलिसीधारक परिसंपत्तियों के लिए दावा न की गई राशि पर अर्जित ब्याज/Add: Interest earned on Unclaimed Amount for Policyholder Assets");
		schedule12.setScheduleItem12dot38Name(
				"भारत सरकार के पक्ष में एटीआई सहभागिता/ATI Participation on behalf of Govt. of India");
		schedule12.setScheduleItem12dot39Name("कुल (बी)/TOTAL (B)");
		schedule12.setFinalSchedule12Name("कुल (ए+बी)/TOTAL (A+B)");

		// 12.1
		schedule12.setScheduleItem12dot1Amt(amtFormatter(BigDecimal.ZERO));
		schedule12.setScheduleItem12dot1PreAmt(amtFormatter(BigDecimal.ZERO));

		// 12.2
		BigDecimal itm12_2 = trialBalance12dot2Dtl.getCrAmount().subtract(trialBalance12dot2Dtl.getDrAmount());
		itm12_2 = itm12_2.divide(BigDecimal.valueOf(1000), 4);
		itm12_2 = itm12_2.setScale(2,RoundingMode.HALF_UP);
		schedule12.setScheduleItem12dot2Amt(amtFormatter(itm12_2));

		BigDecimal itm12_2Prv = trialBalance12dot2Prv.getCrAmount().subtract(trialBalance12dot2Prv.getDrAmount());
		itm12_2Prv = itm12_2Prv.divide(BigDecimal.valueOf(1000), 4);
		itm12_2Prv = itm12_2Prv.setScale(2,RoundingMode.HALF_UP);
		schedule12.setScheduleItem12dot2PreAmt(amtFormatter(itm12_2Prv));

		// 12.3
		BigDecimal itm12_3 = trialBalance12dot3Dtl.getDrAmount().subtract(trialBalance12dot3Dtl.getCrAmount());
		itm12_3 = itm12_3.divide(BigDecimal.valueOf(1000), 4);
		itm12_3 = itm12_3.setScale(2,RoundingMode.HALF_UP);
		schedule12.setScheduleItem12dot3Amt(amtFormatter(itm12_3));

		BigDecimal itm12_3Prv = trialBalance12dot3Prv.getDrAmount().subtract(trialBalance12dot3Prv.getCrAmount());
		itm12_3Prv = itm12_3Prv.divide(BigDecimal.valueOf(1000), 4);
		itm12_3Prv = itm12_3Prv.setScale(2,RoundingMode.HALF_UP);
		schedule12.setScheduleItem12dot3PreAmt(amtFormatter(itm12_3Prv));

		// 12.4
		schedule12.setScheduleItem12dot4Amt(amtFormatter(BigDecimal.ZERO));
		schedule12.setScheduleItem12dot4PreAmt(amtFormatter(BigDecimal.ZERO));

		// 12.5
		BigDecimal itm12_5 = trialBalance12dot5Dtl.getDrAmount().subtract(trialBalance12dot5Dtl.getCrAmount());
		itm12_5 = itm12_5.divide(BigDecimal.valueOf(1000), 4);
		itm12_5 = itm12_5.setScale(2,RoundingMode.HALF_UP);
		schedule12.setScheduleItem12dot5Amt(amtFormatter(itm12_5));

		BigDecimal itm12_5Prv = trialBalance12dot5Prv.getDrAmount().subtract(trialBalance12dot5Prv.getCrAmount());
		itm12_5Prv = itm12_5Prv.divide(BigDecimal.valueOf(1000), 4);
		itm12_5Prv = itm12_5Prv.setScale(2,RoundingMode.HALF_UP);
		schedule12.setScheduleItem12dot5PreAmt(amtFormatter(itm12_5Prv));

		// 12.6
		BigDecimal itm12_6 = trialBalance12dot6Dtl.getDrAmount().subtract(trialBalance12dot6Dtl.getCrAmount());
		itm12_6 = itm12_6.divide(BigDecimal.valueOf(1000), 4);
		itm12_6 = itm12_6.setScale(2,RoundingMode.HALF_UP);
		schedule12.setScheduleItem12dot6Amt(amtFormatter(itm12_6));

		BigDecimal itm12_6Prv = trialBalance12dot6Prv.getDrAmount().subtract(trialBalance12dot6Prv.getCrAmount());
		itm12_6Prv = itm12_6Prv.divide(BigDecimal.valueOf(1000), 4);
		itm12_6Prv = itm12_6Prv.setScale(2,RoundingMode.HALF_UP);
		schedule12.setScheduleItem12dot6PreAmt(amtFormatter(itm12_6Prv));

		// 12.7
		BigDecimal itm12_7 = trialBalance12dot7Dtl.getDrAmount().subtract(trialBalance12dot7Dtl.getCrAmount());
		itm12_7 = itm12_7.divide(BigDecimal.valueOf(1000), 4);
		itm12_7 = itm12_7.setScale(2,RoundingMode.HALF_UP);
		schedule12.setScheduleItem12dot7Amt(amtFormatter(itm12_7));

		BigDecimal itm12_7Prv = trialBalance12dot7Prv.getDrAmount().subtract(trialBalance12dot7Prv.getCrAmount());
		itm12_7Prv = itm12_7Prv.divide(BigDecimal.valueOf(1000), 4);
		itm12_7Prv = itm12_7Prv.setScale(2,RoundingMode.HALF_UP);
		schedule12.setScheduleItem12dot7PreAmt(amtFormatter(itm12_7Prv));

		// 12.8
		BigDecimal itm12_8 = itm12_2.add(itm12_3).add(itm12_5).add(itm12_6).add(itm12_7);
		schedule12.setScheduleItem12dot8Amt(amtFormatter(itm12_8));

		BigDecimal itm12_8Prv = itm12_2Prv.add(itm12_3Prv).add(itm12_5Prv).add(itm12_6Prv).add(itm12_7Prv);
		schedule12.setScheduleItem12dot8PreAmt(amtFormatter(itm12_8Prv));

		// 12.10
		BigDecimal itm12_10 = trialBalance12dot10Dtl.getDrAmount();
		itm12_10 = itm12_10.divide(BigDecimal.valueOf(1000), 4);
		itm12_10 = itm12_10.setScale(2,RoundingMode.HALF_UP);
		schedule12.setScheduleItem12dot10Amt(amtFormatter(itm12_10));

		BigDecimal itm12_10Prv = trialBalance12dot10Prv.getDrAmount();
		itm12_10Prv = itm12_10Prv.divide(BigDecimal.valueOf(1000), 4);
		itm12_10Prv = itm12_10Prv.setScale(2,RoundingMode.HALF_UP);
		schedule12.setScheduleItem12dot10PreAmt(amtFormatter(itm12_10Prv));

		// 12.11
		schedule12.setScheduleItem12dot11Amt(amtFormatter(BigDecimal.ZERO));
		schedule12.setScheduleItem12dot11PreAmt(amtFormatter(BigDecimal.ZERO));

		// 12.12
		schedule12.setScheduleItem12dot12Amt(amtFormatter(BigDecimal.ZERO));
		schedule12.setScheduleItem12dot12PreAmt(amtFormatter(BigDecimal.ZERO));

		// 12.13
		schedule12.setScheduleItem12dot13Amt(amtFormatter(BigDecimal.ZERO));
		schedule12.setScheduleItem12dot13PreAmt(amtFormatter(BigDecimal.ZERO));

		// 12.14
		BigDecimal itm12_14 = trialBalance12dot14Dtl.getDrAmount().subtract(trialBalance12dot14Dtl.getCrAmount());
		itm12_14 = itm12_14.divide(BigDecimal.valueOf(1000), 4);
		itm12_14 = itm12_14.setScale(2,RoundingMode.HALF_UP);
		schedule12.setScheduleItem12dot14Amt(amtFormatter(itm12_14));

		BigDecimal itm12_14Prv = trialBalance12dot14Prv.getDrAmount().subtract(trialBalance12dot14Prv.getCrAmount());
		itm12_14Prv = itm12_14Prv.divide(BigDecimal.valueOf(1000), 4);
		itm12_14Prv = itm12_14Prv.setScale(2,RoundingMode.HALF_UP);
		schedule12.setScheduleItem12dot14PreAmt(amtFormatter(itm12_14Prv));

		// 12.15
		schedule12.setScheduleItem12dot15Amt(amtFormatter(BigDecimal.ZERO));
		schedule12.setScheduleItem12dot15PreAmt(amtFormatter(BigDecimal.ZERO));

		// 12.16
		BigDecimal itm12_16 = trialBalance12dot16Dtl.getDrAmount();
		itm12_16 = itm12_16.divide(BigDecimal.valueOf(1000), 4);
		itm12_16 = itm12_16.setScale(2,RoundingMode.HALF_UP);
		schedule12.setScheduleItem12dot16Amt(amtFormatter(itm12_16));

		BigDecimal itm12_16Prv = trialBalance12dot16Prv.getDrAmount();
		itm12_16Prv = itm12_16Prv.divide(BigDecimal.valueOf(1000), 4);
		itm12_16Prv = itm12_16Prv.setScale(2,RoundingMode.HALF_UP);
		schedule12.setScheduleItem12dot16PreAmt(amtFormatter(itm12_16Prv));

		// 12.18
		BigDecimal itm12_18 = trialBalance12dot18Dtl.getDrAmount();
		itm12_18 = itm12_18.divide(BigDecimal.valueOf(1000), 4);
		itm12_18 = itm12_18.setScale(2,RoundingMode.HALF_UP);
		schedule12.setScheduleItem12dot18Amt(amtFormatter(itm12_18));

		BigDecimal itm12_18Prv = trialBalance12dot18Prv.getDrAmount();
		itm12_18Prv = itm12_18Prv.divide(BigDecimal.valueOf(1000), 4);
		itm12_18Prv = itm12_18Prv.setScale(2,RoundingMode.HALF_UP);
		schedule12.setScheduleItem12dot18PreAmt(amtFormatter(itm12_18Prv));

		// 12.20
		BigDecimal itm12_20 = trialBalance12dot20Dtl.getDrAmount();
		itm12_20 = itm12_20.divide(BigDecimal.valueOf(1000), 4);
		itm12_20 = itm12_20.setScale(2,RoundingMode.HALF_UP);
		schedule12.setScheduleItem12dot20Amt(amtFormatter(itm12_20));

		BigDecimal itm12_20Prv = trialBalance12dot18Prv.getDrAmount();
		itm12_20Prv = itm12_20Prv.divide(BigDecimal.valueOf(1000), 4);
		itm12_20Prv = itm12_20Prv.setScale(2,RoundingMode.HALF_UP);
		schedule12.setScheduleItem12dot20PreAmt(amtFormatter(itm12_20Prv));

		// 12.21
		BigDecimal itm12_21 = trialBalance12dot21Dtl.getCrAmount();
		itm12_21 = itm12_21.divide(BigDecimal.valueOf(1000), 4);
		itm12_21 = itm12_21.setScale(2,RoundingMode.HALF_UP);
		schedule12.setScheduleItem12dot21Amt(amtFormatter(itm12_21));

		BigDecimal itm12_21Prv = trialBalance12dot21Prv.getCrAmount();
		itm12_21Prv = itm12_21Prv.divide(BigDecimal.valueOf(1000), 4);
		itm12_21Prv = itm12_21Prv.setScale(2,RoundingMode.HALF_UP);
		schedule12.setScheduleItem12dot21PreAmt(amtFormatter(itm12_21Prv));

		// 12.22
		BigDecimal itm12_22 = itm12_20.subtract(itm12_21);
		schedule12.setScheduleItem12dot22Amt(amtFormatter(itm12_22));

		BigDecimal itm12_22Prv = itm12_20Prv.subtract(itm12_21Prv);
		schedule12.setScheduleItem12dot22PreAmt(amtFormatter(itm12_22Prv));

		// 12.23
		schedule12.setScheduleItem12dot23Amt(amtFormatter(BigDecimal.ZERO));
		schedule12.setScheduleItem12dot23PreAmt(amtFormatter(BigDecimal.ZERO));

		// 12.24
		schedule12.setScheduleItem12dot24Amt(amtFormatter(BigDecimal.ZERO));
		schedule12.setScheduleItem12dot24PreAmt(amtFormatter(BigDecimal.ZERO));

		// 12.25
		schedule12.setScheduleItem12dot25Amt(amtFormatter(BigDecimal.ZERO));
		schedule12.setScheduleItem12dot25PreAmt(amtFormatter(BigDecimal.ZERO));

		// 12.26
		BigDecimal itm12_26 = trialBalance12dot26Dtl.getDrAmount();
		itm12_26 = itm12_26.divide(BigDecimal.valueOf(1000), 4);
		itm12_26 = itm12_26.setScale(2,RoundingMode.HALF_UP);
		schedule12.setScheduleItem12dot26Amt(amtFormatter(itm12_26));

		BigDecimal itm12_26Prv = trialBalance12dot26Prv.getDrAmount();
		itm12_26Prv = itm12_26Prv.divide(BigDecimal.valueOf(1000), 4);
		itm12_26Prv = itm12_26Prv.setScale(2,RoundingMode.HALF_UP);
		schedule12.setScheduleItem12dot26PreAmt(amtFormatter(itm12_26Prv));

		// 12.27
		BigDecimal itm12_27 = trialBalance12dot26Dtl.getDrAmount();
		itm12_27 = itm12_27.divide(BigDecimal.valueOf(1000), 4);
		itm12_27 = itm12_27.setScale(2,RoundingMode.HALF_UP);
		schedule12.setScheduleItem12dot27Amt(amtFormatter(itm12_27));

		BigDecimal itm12_27Prv = trialBalance12dot26Prv.getDrAmount();
		itm12_27Prv = itm12_27Prv.divide(BigDecimal.valueOf(1000), 4);
		itm12_27Prv = itm12_27Prv.setScale(2,RoundingMode.HALF_UP);
		schedule12.setScheduleItem12dot27PreAmt(amtFormatter(itm12_27Prv));

		// 12.28
		BigDecimal itm12_28 = itm12_26.subtract(itm12_27);
		schedule12.setScheduleItem12dot28Amt(amtFormatter(itm12_28));

		BigDecimal itm12_28Prv = itm12_26Prv.subtract(itm12_27Prv);
		schedule12.setScheduleItem12dot28PreAmt(amtFormatter(itm12_28Prv));

		// 12.29
		BigDecimal itm12_29 = itm12_22.add(itm12_28);
		schedule12.setScheduleItem12dot29Amt(amtFormatter(itm12_29));

		BigDecimal itm12_29Prv = itm12_22Prv.add(itm12_28Prv);
		schedule12.setScheduleItem12dot29PreAmt(amtFormatter(itm12_29Prv));

		// 12.30
		BigDecimal itm12_30 = trialBalance12dot30Dtl.getDrAmount().subtract(trialBalance12dot30Dtl.getCrAmount());
		itm12_30 = itm12_30.divide(BigDecimal.valueOf(1000), 4);
		itm12_30 = itm12_30.setScale(2,RoundingMode.HALF_UP);
		schedule12.setScheduleItem12dot30Amt(amtFormatter(itm12_30));

		BigDecimal itm12_30Prv = trialBalance12dot30Prv.getDrAmount().subtract(trialBalance12dot30Prv.getCrAmount());
		itm12_30Prv = itm12_30Prv.divide(BigDecimal.valueOf(1000), 4);
		itm12_30Prv = itm12_30Prv.setScale(2,RoundingMode.HALF_UP);
		schedule12.setScheduleItem12dot30PreAmt(amtFormatter(itm12_30Prv));

		// 12.31
		BigDecimal itm12_31 = trialBalance12dot31Dtl.getCrAmount();
		itm12_31 = itm12_31.divide(BigDecimal.valueOf(1000), 4);
		itm12_31 = itm12_31.setScale(2,RoundingMode.HALF_UP);
		schedule12.setScheduleItem12dot31Amt(amtFormatter(itm12_31));

		BigDecimal itm12_31Prv = trialBalance12dot31Prv.getCrAmount();
		itm12_31Prv = itm12_31Prv.divide(BigDecimal.valueOf(1000), 4);
		itm12_31Prv = itm12_31Prv.setScale(2,RoundingMode.HALF_UP);
		schedule12.setScheduleItem12dot31PreAmt(amtFormatter(itm12_31Prv));

		// 12.32
		BigDecimal itm12_32 = itm12_30.subtract(itm12_31);
		schedule12.setScheduleItem12dot32Amt(amtFormatter(itm12_32));

		BigDecimal itm12_32Prv = itm12_30Prv.subtract(itm12_31Prv);
		schedule12.setScheduleItem12dot32PreAmt(amtFormatter(itm12_32Prv));

		// 12.33
		BigDecimal itm12_33 = trialBalance12dot33Dtl.getDrAmount().subtract(trialBalance12dot33Dtl.getCrAmount());
		itm12_33 = itm12_33.divide(BigDecimal.valueOf(1000), 4);
		itm12_33 = itm12_33.setScale(2,RoundingMode.HALF_UP);
		schedule12.setScheduleItem12dot33Amt(amtFormatter(itm12_33));

		BigDecimal itm12_33Prv = trialBalance12dot33Prv.getDrAmount().subtract(trialBalance12dot33Prv.getCrAmount());
		itm12_33Prv = itm12_33Prv.divide(BigDecimal.valueOf(1000), 4);
		itm12_33Prv = itm12_33Prv.setScale(2,RoundingMode.HALF_UP);
		schedule12.setScheduleItem12dot33PreAmt(amtFormatter(itm12_33Prv));

		// 12.34
		schedule12.setScheduleItem12dot34Amt(amtFormatter(BigDecimal.ZERO));
		schedule12.setScheduleItem12dot34PreAmt(amtFormatter(BigDecimal.ZERO));

		// 12.35
		schedule12.setScheduleItem12dot35Amt(amtFormatter(itm12_33));
		schedule12.setScheduleItem12dot35PreAmt(amtFormatter(itm12_33Prv));

		// 12.37
		BigDecimal itm12_37 = trialBalance12dot37Dtl.getDrAmount();
		itm12_37 = itm12_37.divide(BigDecimal.valueOf(1000), 4);
		itm12_37 = itm12_37.setScale(2,RoundingMode.HALF_UP);
		schedule12.setScheduleItem12dot37Amt(amtFormatter(itm12_37));

		BigDecimal itm12_37Prv = trialBalance12dot37Prv.getDrAmount();
		itm12_37Prv = itm12_37Prv.divide(BigDecimal.valueOf(1000), 4);
		itm12_37Prv = itm12_37Prv.setScale(2,RoundingMode.HALF_UP);
		schedule12.setScheduleItem12dot37PreAmt(amtFormatter(itm12_37Prv));

		// 12.36
		BigDecimal itm12_36 = trialBalance12dot36Dtl.getDrAmount().subtract(trialBalance12dot36Dtl.getCrAmount());
		itm12_36 = itm12_36.divide(BigDecimal.valueOf(1000), 4);
		itm12_36 = itm12_36.setScale(2,RoundingMode.HALF_UP);
		itm12_36 = itm12_36.subtract(itm12_37);
		schedule12.setScheduleItem12dot36Amt(amtFormatter(itm12_36));

		BigDecimal itm12_36Prv = trialBalance12dot36Prv.getDrAmount().subtract(trialBalance12dot36Dtl.getCrAmount());
		itm12_36Prv = itm12_36Prv.divide(BigDecimal.valueOf(1000), 4);
		itm12_36Prv = itm12_36Prv.setScale(2,RoundingMode.HALF_UP);
		itm12_36Prv = itm12_36Prv.subtract(itm12_37Prv);
		schedule12.setScheduleItem12dot36PreAmt(amtFormatter(itm12_36Prv));

		// sum 12.36 12.37
		BigDecimal itm12_3637 = itm12_36.add(itm12_37);
		schedule12.setScheduleItem12dot36And37Amt(amtFormatter(itm12_3637));

		BigDecimal itm12_3637Prv = itm12_36Prv.add(itm12_37Prv);
		schedule12.setScheduleItem12dot36And37PreAmt(amtFormatter(itm12_3637Prv));

		// 12.38
		BigDecimal itm12_38 = trialBalance12dot38Dtl.getDrAmount().subtract(trialBalance12dot38Dtl.getCrAmount());
		itm12_38 = itm12_38.divide(BigDecimal.valueOf(1000), 4);
		itm12_38 = itm12_38.setScale(2,RoundingMode.HALF_UP);
		schedule12.setScheduleItem12dot38Amt(amtFormatter(itm12_38));

		BigDecimal itm12_38Prv = trialBalance12dot38Prv.getDrAmount().subtract(trialBalance12dot38Prv.getCrAmount());
		itm12_38Prv = itm12_38Prv.divide(BigDecimal.valueOf(1000), 4);
		itm12_38Prv = itm12_38Prv.setScale(2,RoundingMode.HALF_UP);
		schedule12.setScheduleItem12dot38PreAmt(amtFormatter(itm12_38Prv));

		// 12.39
		BigDecimal itm12_39 = itm12_38.add(itm12_3637).add(itm12_33).add(itm12_32).add(itm12_29).add(itm12_18)
				.add(itm12_16).add(itm12_14).add(itm12_10);
		schedule12.setScheduleItem12dot39Amt(amtFormatter(itm12_39));

		BigDecimal itm12_39Prv = itm12_38Prv.add(itm12_3637Prv).add(itm12_33Prv).add(itm12_32Prv).add(itm12_29Prv).add(itm12_18Prv)
				.add(itm12_16Prv).add(itm12_14Prv).add(itm12_10Prv);
		schedule12.setScheduleItem12dot39PreAmt(amtFormatter(itm12_39Prv));
		
		//total
		BigDecimal itm12 = itm12_39.add(itm12_8);
		schedule12.setFinalSchedule12Amt(amtFormatter(itm12));
		
		BigDecimal itm12Prv = itm12_39Prv.add(itm12_8Prv);
		schedule12.setFinalSchedule12PreAmt(amtFormatter(itm12Prv));
		

		return schedule12;
	}
	
	
	// --------------------------------------------------------schedule 8-------------------------------------------------------------

		@Override
		public Schedule8 getSchedule8(LocalDate date,Schedule8 schedule8) {
			log.debug("ScheduleServiceImpl-->getSchedule13()");

			Schedule8 sch8 = null;
			// if data is present directly take values from trail balance table
			if (scheduleDao.checkForInputDt(date) > 0) {

				sch8 = getSchedule8Data(date,schedule8);
				// else generate trail balance and then take values
			} else {

				int curtb = scheduleDao.generateTb(date);

				LocalDate prvDt = date.minusYears(1);

				int prvtb = scheduleDao.generateTbPrv(prvDt);

				if (curtb > 0 && prvtb > 0) {
					sch8 = getSchedule8Data(date,schedule8);
				}

			}

			return sch8;
		}

		public Schedule8 getSchedule8Data(LocalDate date,Schedule8 schedule8) {
			TrialBalanceDtl trialBalance8dot2Dtl = getTrialBalanceDtl("8", "8.2", date);
			TrialBalanceDtl trialBalance8dot3Dtl = getTrialBalanceDtl("8", "8.3", date);
			TrialBalanceDtl trialBalance8dot6Dtl = getTrialBalanceDtl("8", "8.6", date);
			TrialBalanceDtl trialBalance8dot8Dtl = getTrialBalanceDtl("8", "8.8", date);
			TrialBalanceDtl trialBalance8dot10Dtl = getTrialBalanceDtl("8", "8.10", date);
			TrialBalanceDtl trialBalance8dot11Dtl = getTrialBalanceDtl("8", "8.11", date);
			TrialBalanceDtl trialBalance8dot14Dtl = getTrialBalanceDtl("8", "8.14", date);
			TrialBalanceDtl trialBalance8dot15Dtl = getTrialBalanceDtl("8", "8.15", date);
			

			LocalDate prvDt = date.minusYears(1);

			TrialBalanceDtl trialBalance8dot2Prv = getTrialBalanceDtlPrv("8", "8.2", prvDt);
			TrialBalanceDtl trialBalance8dot3Prv = getTrialBalanceDtlPrv("8", "8.3", prvDt);
			TrialBalanceDtl trialBalance8dot6Prv = getTrialBalanceDtlPrv("8", "8.6", prvDt);
			TrialBalanceDtl trialBalance8dot8Prv = getTrialBalanceDtlPrv("8", "8.8", prvDt);
			TrialBalanceDtl trialBalance8dot10Prv = getTrialBalanceDtlPrv("8", "8.10", prvDt);
			TrialBalanceDtl trialBalance8dot11Prv = getTrialBalanceDtlPrv("8", "8.11", prvDt);
			TrialBalanceDtl trialBalance8dot14Prv = getTrialBalanceDtlPrv("8", "8.14", prvDt);
			TrialBalanceDtl trialBalance8dot15Prv = getTrialBalanceDtlPrv("8", "8.15", prvDt);
			
			// write here

			schedule8.setCreatedBy(userInfoService.getName());
			schedule8.setScheduleItem8dot1Name("लंबी अवधि के निवेश/LONG TERM INVESTMENTS");
			schedule8.setScheduleItem8dot2Name("सरकारी प्रतिभूतियाँ और सरकार द्वारा गारंटीत बॉन्ड, ट्रेजरी बिल्स सहित/Government securities and Government guaranteed bonds including Treasury Bills");
			schedule8.setScheduleItem8dot3Name("अन्य मंजूर सुरक्षें/Other approved Securities");
			schedule8.setScheduleItem8dot4Name("अन्य निवेश/Other Investments");
			schedule8.setScheduleItem8dot5Name("शेयर्स/Shares");
			schedule8.setScheduleItem8dot6Name("इक्विटी/Equity");
			schedule8.setScheduleItem8dot7Name("प्राथमिकता शेयर/Preference Shares");
			schedule8.setScheduleItem8dot8Name("म्युचुअल फंड/Mutual Funds");
			schedule8.setScheduleItem8dot9Name("डेरिवेटिव उपकरण/Derivative Instruments");
			schedule8.setScheduleItem8dot10Name("डेबेंचर/बॉन्ड/Debentures/Bonds");
			schedule8.setScheduleItem8dot11Name("अन्य प्रतिभूतियाँ (TREPS, CP, CD)/Other Securities (TREPS, CP, CD)");
			schedule8.setScheduleItem8dot12Name("सहायक कंपनियाँ/Subsidiaries");
			schedule8.setScheduleItem8dot13Name("निवेश संपत्तियाँ-रियल एस्टेट/Investment Properties-Real Estate");
			schedule8.setScheduleItem8dot14Name("बुनियादी ढांचा और सामाजिक क्षेत्र में निवेश/Investments in Infrastructure and Social Sector");
			schedule8.setScheduleItem8dot15Name("मंजूर निवेशों के अतिरिक्त/Other than Approved Investments");
			schedule8.setScheduleItem8dot16Name("कुल( A )/Total( A )");
			schedule8.setScheduleItem8dot17Name("छोटी अवधि के निवेश/SHORT TERM INVESTMENTS");
			schedule8.setScheduleItem8dot18Name("सरकारी प्रतिभूतियाँ और सरकार द्वारा गारंटीत बॉन्ड, ट्रेजरी बिल्स सहित/Government securities and Government guaranteed bonds including Treasury Bills");
			schedule8.setScheduleItem8dot19Name("अन्य मंजूर सुरक्षें/Other Approved Securities");
			schedule8.setScheduleItem8dot20Name("अन्य निवेश/Other Investments");
			schedule8.setScheduleItem8dot21Name("शेयर्स/Shares");
			schedule8.setScheduleItem8dot22Name("इक्विटी/Equity");
			schedule8.setScheduleItem8dot23Name("प्राथमिकता शेयर/Preference Shares");
			schedule8.setScheduleItem8dot24Name("म्युचुअल फंड/Mutual Funds");
			schedule8.setScheduleItem8dot25Name("डेरिवेटिव उपकरण/Derivative Instruments");
			schedule8.setScheduleItem8dot26Name("डेबेंचर/बॉन्ड/Debentures/Bonds");
			schedule8.setScheduleItem8dot27Name("अन्य प्रतिभूतियाँ (TREPS, CP, CD)/Other Securities (TREPS, CP, CD)");
			schedule8.setScheduleItem8dot28Name("सहायक कंपनियाँ/Subsidiaries");
			schedule8.setScheduleItem8dot29Name("निवेश संपत्तियाँ-रियल एस्टेट/Investment Properties-Real Estate");
			schedule8.setScheduleItem8dot30Name("बुनियादी ढांचा और सामाजिक क्षेत्र में निवेश/Investments in Infrastructure and Social Sector");
			schedule8.setScheduleItem8dot31Name("मंजूर निवेशों के अतिरिक्त/Other than Approved Investments");
			schedule8.setScheduleItem8dot32Name("कुल( B )/Total( B )");
			schedule8.setFinalSchedule8Name("कुल( A + B )/TOTAL( A + B )");
			
			//8A
			Schedule8A schedule8a = new Schedule8A();
			
			//8.2
			BigDecimal itm8_2 = trialBalance8dot2Dtl.getDrAmount().subtract(trialBalance8dot2Dtl.getCrAmount());
			itm8_2 = itm8_2.divide(BigDecimal.valueOf(1000), 4);
			itm8_2 = itm8_2.setScale(2,RoundingMode.HALF_UP);
			itm8_2=itm8_2.subtract(new BigDecimal(schedule8.getScheduleItem8dot18Amt()));
			
			BigDecimal itm8a_2 = itm8_2;
			itm8_2 =itm8_2.multiply(BigDecimal.valueOf(0.5));
			itm8_2 =itm8_2.setScale(2,RoundingMode.DOWN);
			itm8a_2=itm8a_2.subtract(itm8_2);
			
			schedule8.setScheduleItem8dot2Amt(amtFormatter(itm8_2));
			schedule8a.setScheduleItem8Adot2Amt(amtFormatter(itm8a_2));
			

			BigDecimal itm8_2Prv = trialBalance8dot2Prv.getDrAmount().subtract(trialBalance8dot2Prv.getCrAmount());
			itm8_2Prv = itm8_2Prv.divide(BigDecimal.valueOf(1000), 4);
			itm8_2Prv = itm8_2Prv.setScale(2,RoundingMode.HALF_UP);
			itm8_2Prv=itm8_2Prv.subtract(new BigDecimal(schedule8.getScheduleItem8dot18PreAmt()));
			
			BigDecimal itm8a_2Prv = itm8_2Prv;
			BigDecimal itm8_2P = itm8_2Prv;
			itm8_2Prv =itm8_2Prv.multiply(BigDecimal.valueOf(0.45));
			itm8_2Prv =itm8_2Prv.setScale(2,RoundingMode.DOWN);
			
			itm8_2P =itm8_2P.multiply(BigDecimal.valueOf(0.5));
			itm8_2P =itm8_2P.setScale(2,RoundingMode.DOWN);
			itm8a_2Prv=itm8a_2Prv.subtract(itm8_2P);
			
			schedule8.setScheduleItem8dot2PreAmt(amtFormatter(itm8_2Prv));
			schedule8a.setScheduleItem8Adot2PreAmt(amtFormatter(itm8a_2Prv));
			
			//8.18
			BigDecimal itm8_18 = new BigDecimal(schedule8.getScheduleItem8dot18Amt());
			itm8_18 =itm8_18.multiply(BigDecimal.valueOf(0.5));
			itm8_18 =itm8_18.setScale(2,RoundingMode.DOWN);
			
			schedule8.setScheduleItem8dot18Amt(amtFormatter(itm8_18));
			schedule8a.setScheduleItem8Adot18Amt(amtFormatter(itm8_18));
			
			BigDecimal itm8_18Prv = new BigDecimal(schedule8.getScheduleItem8dot18PreAmt());
			BigDecimal itm8_18P =itm8_18Prv.multiply(BigDecimal.valueOf(0.5));
			itm8_18P =itm8_18P.setScale(2,RoundingMode.DOWN);
			
			
			itm8_18Prv =itm8_18Prv.multiply(BigDecimal.valueOf(0.45));
			itm8_18Prv =itm8_18Prv.setScale(2,RoundingMode.DOWN);
			
			schedule8.setScheduleItem8dot18PreAmt(amtFormatter(itm8_18Prv));
			schedule8a.setScheduleItem8Adot18PreAmt(amtFormatter(itm8_18P));
			
			
			//8.3
			BigDecimal itm8_3 = trialBalance8dot3Dtl.getDrAmount().subtract(trialBalance8dot3Dtl.getCrAmount());
			itm8_3 = itm8_3.divide(BigDecimal.valueOf(1000), 4);
			itm8_3 = itm8_3.setScale(2,RoundingMode.HALF_UP);
			itm8_3=itm8_3.subtract(new BigDecimal(schedule8.getScheduleItem8dot19Amt()));
			
			BigDecimal itm8a_3 = itm8_3;
			itm8_3 =itm8_3.multiply(BigDecimal.valueOf(0.5));
			itm8_3 =itm8_3.setScale(2,RoundingMode.DOWN);
			itm8a_3=itm8a_3.subtract(itm8_3);
			
			schedule8.setScheduleItem8dot3Amt(amtFormatter(itm8_3));
			schedule8a.setScheduleItem8Adot3Amt(amtFormatter(itm8a_3));

			BigDecimal itm8_3Prv = trialBalance8dot3Prv.getDrAmount().subtract(trialBalance8dot3Prv.getCrAmount());
			itm8_3Prv = itm8_3Prv.divide(BigDecimal.valueOf(1000), 4);
			itm8_3Prv = itm8_3Prv.setScale(2,RoundingMode.HALF_UP);
			itm8_3Prv=itm8_3Prv.subtract(new BigDecimal(schedule8.getScheduleItem8dot19PreAmt()));
			
			BigDecimal itm8a_3Prv = itm8_3Prv;
			BigDecimal itm8_3P = itm8_3Prv;
			itm8_3Prv =itm8_3Prv.multiply(BigDecimal.valueOf(0.45));
			itm8_3Prv =itm8_3Prv.setScale(2,RoundingMode.DOWN);
			
			itm8_3P =itm8_3P.multiply(BigDecimal.valueOf(0.5));
			itm8_3P =itm8_3P.setScale(2,RoundingMode.DOWN);
			itm8a_3Prv=itm8a_3Prv.subtract(itm8_3P);
			
			schedule8.setScheduleItem8dot3PreAmt(amtFormatter(itm8_3Prv));
			schedule8a.setScheduleItem8Adot3PreAmt(amtFormatter(itm8a_3Prv));
			
			//8.19
			BigDecimal itm8_19 = new BigDecimal(schedule8.getScheduleItem8dot19Amt());
			itm8_19 =itm8_19.multiply(BigDecimal.valueOf(0.5));
			itm8_19 =itm8_19.setScale(2,RoundingMode.DOWN);
			
			schedule8.setScheduleItem8dot19Amt(amtFormatter(itm8_19));
			schedule8a.setScheduleItem8Adot19Amt(amtFormatter(itm8_19));
			
			BigDecimal itm8_19Prv = new BigDecimal(schedule8.getScheduleItem8dot19PreAmt());
			BigDecimal itm8_19P =itm8_19Prv.multiply(BigDecimal.valueOf(0.5));
			itm8_19P =itm8_19P.setScale(2,RoundingMode.DOWN);
			
			itm8_19Prv =itm8_19Prv.multiply(BigDecimal.valueOf(0.45));
			itm8_19Prv =itm8_19Prv.setScale(2,RoundingMode.DOWN);
			
			
			schedule8.setScheduleItem8dot19PreAmt(amtFormatter(itm8_19Prv));
			schedule8a.setScheduleItem8Adot19PreAmt(amtFormatter(itm8_19P));
			
			//8.6
			BigDecimal itm8_6 = trialBalance8dot6Dtl.getDrAmount().subtract(trialBalance8dot6Dtl.getCrAmount());
			itm8_6 = itm8_6.divide(BigDecimal.valueOf(1000), 4);
			itm8_6 = itm8_6.setScale(2,RoundingMode.HALF_UP);
			itm8_6=itm8_6.subtract(new BigDecimal(schedule8.getScheduleItem8dot22Amt()));
			
			BigDecimal itm8a_6 = itm8_6;
			itm8_6 =itm8_6.multiply(BigDecimal.valueOf(0.5));
			itm8_6 =itm8_6.setScale(2,RoundingMode.DOWN);
			itm8a_6=itm8a_6.subtract(itm8_6);
			
			schedule8.setScheduleItem8dot6Amt(amtFormatter(itm8_6));
			schedule8a.setScheduleItem8Adot6Amt(amtFormatter(itm8a_3));

			BigDecimal itm8_6Prv = trialBalance8dot6Prv.getDrAmount().subtract(trialBalance8dot6Prv.getCrAmount());
			itm8_6Prv = itm8_6Prv.divide(BigDecimal.valueOf(1000), 4);
			itm8_6Prv = itm8_6Prv.setScale(2,RoundingMode.HALF_UP);
			itm8_6Prv=itm8_6Prv.subtract(new BigDecimal(schedule8.getScheduleItem8dot22PreAmt()));
			
			BigDecimal itm8a_6Prv = itm8_6Prv;
			BigDecimal itm8_6P = itm8_6Prv;
			itm8_6Prv =itm8_6Prv.multiply(BigDecimal.valueOf(0.45));
			itm8_6Prv =itm8_6Prv.setScale(2,RoundingMode.DOWN);
			
			itm8_6P =itm8_6P.multiply(BigDecimal.valueOf(0.5));
			itm8_6P =itm8_6P.setScale(2,RoundingMode.DOWN);
			itm8a_6Prv=itm8a_6Prv.subtract(itm8_6P);
			
			
			schedule8.setScheduleItem8dot6PreAmt(amtFormatter(itm8_6Prv));
			schedule8a.setScheduleItem8Adot6PreAmt(amtFormatter(itm8a_6Prv));
			
			//8.22
			BigDecimal itm8_22 = new BigDecimal(schedule8.getScheduleItem8dot22Amt());
			itm8_22 =itm8_22.multiply(BigDecimal.valueOf(0.5));
			itm8_22 =itm8_22.setScale(2,RoundingMode.DOWN);
			
			schedule8.setScheduleItem8dot22Amt(amtFormatter(itm8_22));
			schedule8a.setScheduleItem8Adot22Amt(amtFormatter(itm8_22));
			
			BigDecimal itm8_22Prv = new BigDecimal(schedule8.getScheduleItem8dot22PreAmt());
			BigDecimal itm8_22P =itm8_22Prv.multiply(BigDecimal.valueOf(0.5));
			itm8_22P =itm8_22P.setScale(2,RoundingMode.DOWN);
			
			itm8_22Prv =itm8_22Prv.multiply(BigDecimal.valueOf(0.45));
			itm8_22Prv =itm8_22Prv.setScale(2,RoundingMode.DOWN);
			
			schedule8.setScheduleItem8dot22PreAmt(amtFormatter(itm8_22Prv));
			schedule8a.setScheduleItem8Adot22PreAmt(amtFormatter(itm8_22P));
			
			//8.7
			schedule8.setScheduleItem8dot7Amt(amtFormatter(BigDecimal.ZERO));
			schedule8a.setScheduleItem8Adot7PreAmt(amtFormatter(BigDecimal.ZERO));
			schedule8.setScheduleItem8dot7PreAmt(amtFormatter(BigDecimal.ZERO));
			schedule8a.setScheduleItem8Adot7PreAmt(amtFormatter(BigDecimal.ZERO));
			
			//8.23
			BigDecimal itm8_23 =new BigDecimal(schedule8.getScheduleItem8dot23Amt());
			BigDecimal itm8_23P =new BigDecimal(schedule8.getScheduleItem8dot23PreAmt());
			schedule8.setScheduleItem8dot23Amt(amtFormatter(new BigDecimal(schedule8.getScheduleItem8dot23Amt())));
			schedule8.setScheduleItem8dot23PreAmt(amtFormatter(new BigDecimal(schedule8.getScheduleItem8dot23PreAmt())));
			schedule8a.setScheduleItem8Adot23Amt(amtFormatter(itm8_23));
			schedule8a.setScheduleItem8Adot23PreAmt(amtFormatter(itm8_23P));
			
			//8.8
			BigDecimal itm8_8 = trialBalance8dot8Dtl.getDrAmount().subtract(trialBalance8dot8Dtl.getCrAmount());
			itm8_8 = itm8_8.divide(BigDecimal.valueOf(1000), 2);
			itm8_8=itm8_8.subtract(new BigDecimal(schedule8.getScheduleItem8dot24Amt()));
			
			BigDecimal itm8a_8 = itm8_8;
			itm8_8 =itm8_8.multiply(BigDecimal.valueOf(0.5));
			itm8_8 =itm8_8.setScale(2,RoundingMode.DOWN);
			itm8a_8=itm8a_8.subtract(itm8_8);
			
			schedule8.setScheduleItem8dot8Amt(amtFormatter(itm8_8));
			schedule8a.setScheduleItem8Adot8Amt(amtFormatter(itm8a_8));
			

			BigDecimal itm8_8Prv = trialBalance8dot8Prv.getDrAmount().subtract(trialBalance8dot8Prv.getCrAmount());
			itm8_8Prv = itm8_8Prv.divide(BigDecimal.valueOf(1000), 4);
			itm8_8Prv = itm8_8Prv.setScale(2,RoundingMode.HALF_UP);
			itm8_8Prv=itm8_8Prv.subtract(new BigDecimal(schedule8.getScheduleItem8dot24PreAmt()));
			
			BigDecimal itm8a_8Prv = itm8_8Prv;
			BigDecimal itm8_8P = itm8_8Prv;
			
			itm8_8Prv =itm8_8Prv.multiply(BigDecimal.valueOf(0.45));
			itm8_8Prv =itm8_8Prv.setScale(2,RoundingMode.DOWN);
			
			
			itm8_8P =itm8_8P.multiply(BigDecimal.valueOf(0.5));
			itm8_8P =itm8_8P.setScale(2,RoundingMode.DOWN);
			itm8a_8Prv=itm8a_8Prv.subtract(itm8_8P);
			
			schedule8.setScheduleItem8dot8PreAmt(amtFormatter(itm8_8Prv));
			schedule8a.setScheduleItem8Adot8PreAmt(amtFormatter(itm8a_8Prv));
			
			
			//8.24
			BigDecimal itm8_24 = new BigDecimal(schedule8.getScheduleItem8dot24Amt());
			itm8_24 =itm8_24.multiply(BigDecimal.valueOf(0.5));
			itm8_24 =itm8_24.setScale(2,RoundingMode.DOWN);
			
			schedule8.setScheduleItem8dot24Amt(amtFormatter(itm8_24));
			schedule8a.setScheduleItem8Adot24Amt(amtFormatter(itm8_24));
			
			BigDecimal itm8_24Prv = new BigDecimal(schedule8.getScheduleItem8dot24PreAmt());
			BigDecimal itm8_24P =itm8_24Prv.multiply(BigDecimal.valueOf(0.5));
			itm8_24P =itm8_24P.setScale(2,RoundingMode.DOWN);
			
			
			itm8_24Prv =itm8_24Prv.multiply(BigDecimal.valueOf(0.45));
			itm8_24Prv =itm8_24Prv.setScale(2,RoundingMode.DOWN);
			
			schedule8.setScheduleItem8dot24PreAmt(amtFormatter(itm8_24Prv));
			schedule8a.setScheduleItem8Adot24PreAmt(amtFormatter(itm8_24P));
			
			//8.9
			schedule8.setScheduleItem8dot9Amt(amtFormatter(BigDecimal.ZERO));
			schedule8.setScheduleItem8dot9PreAmt(amtFormatter(BigDecimal.ZERO));
			schedule8a.setScheduleItem8Adot9Amt(amtFormatter(BigDecimal.ZERO));
			schedule8a.setScheduleItem8Adot9PreAmt(amtFormatter(BigDecimal.ZERO));
			
			//8.25
			schedule8.setScheduleItem8dot25Amt(amtFormatter(BigDecimal.ZERO));
			schedule8.setScheduleItem8dot25PreAmt(amtFormatter(BigDecimal.ZERO));
			schedule8a.setScheduleItem8Adot25Amt(amtFormatter(BigDecimal.ZERO));
			schedule8a.setScheduleItem8Adot25PreAmt(amtFormatter(BigDecimal.ZERO));
			
			
		
			//8.10
			BigDecimal itm8_10 = trialBalance8dot10Dtl.getDrAmount().subtract(trialBalance8dot10Dtl.getCrAmount());
			itm8_10 = itm8_10.divide(BigDecimal.valueOf(1000), 4);
			itm8_10 = itm8_10.setScale(2,RoundingMode.HALF_UP);
			itm8_10=itm8_10.subtract(new BigDecimal(schedule8.getScheduleItem8dot26Amt()));
			
			BigDecimal itm8a_10 = itm8_10;
			itm8_10 =itm8_10.multiply(BigDecimal.valueOf(0.5));
			itm8_10 =itm8_10.setScale(2,RoundingMode.DOWN);
			itm8a_10=itm8a_10.subtract(itm8_10);
			
			schedule8.setScheduleItem8dot10Amt(amtFormatter(itm8_10));
			schedule8a.setScheduleItem8Adot10Amt(amtFormatter(itm8a_10));
			

			BigDecimal itm8_10Prv = trialBalance8dot10Prv.getDrAmount().subtract(trialBalance8dot10Prv.getCrAmount());
			itm8_10Prv = itm8_10Prv.divide(BigDecimal.valueOf(1000), 4);
			itm8_10Prv = itm8_10Prv.setScale(2,RoundingMode.HALF_UP);
			itm8_10Prv=itm8_10Prv.subtract(new BigDecimal(schedule8.getScheduleItem8dot26PreAmt()));
			
			BigDecimal itm8a_10Prv = itm8_10Prv;
			BigDecimal itm8_10P = itm8_10Prv;
			
			itm8_10Prv =itm8_10Prv.multiply(BigDecimal.valueOf(0.45));
			itm8_10Prv =itm8_10Prv.setScale(2,RoundingMode.DOWN);
			
			itm8_10P =itm8_10P.multiply(BigDecimal.valueOf(0.5));
			itm8_10P =itm8_10P.setScale(2,RoundingMode.DOWN);
			itm8a_10Prv=itm8a_10Prv.subtract(itm8_10P);
			
			schedule8.setScheduleItem8dot10PreAmt(amtFormatter(itm8_10Prv));
			schedule8a.setScheduleItem8Adot10PreAmt(amtFormatter(itm8a_10Prv));
			
			
			
			//8.26
			BigDecimal itm8_26 = new BigDecimal(schedule8.getScheduleItem8dot26Amt());
			itm8_26 =itm8_26.multiply(BigDecimal.valueOf(0.5));
			itm8_26 =itm8_26.setScale(2,RoundingMode.DOWN);
			schedule8.setScheduleItem8dot26Amt(amtFormatter(itm8_26));
			schedule8a.setScheduleItem8Adot26Amt(amtFormatter(itm8_26));
			
			BigDecimal itm8_26Prv = new BigDecimal(schedule8.getScheduleItem8dot26PreAmt());
			BigDecimal itm8_26P =itm8_26Prv.multiply(BigDecimal.valueOf(0.5));
			itm8_26P =itm8_26P.setScale(2,RoundingMode.DOWN);
			
			itm8_26Prv =itm8_26Prv.multiply(BigDecimal.valueOf(0.45));
			itm8_26Prv =itm8_26Prv.setScale(2,RoundingMode.DOWN);
			
			schedule8.setScheduleItem8dot26PreAmt(amtFormatter(itm8_26Prv));
			schedule8a.setScheduleItem8Adot26PreAmt(amtFormatter(itm8_26P));
			
			//--------------------------------------------------------------------------------------
			
			//8.11
			BigDecimal itm8_11 = trialBalance8dot11Dtl.getDrAmount();
			itm8_11 = itm8_11.divide(BigDecimal.valueOf(1000), 4);
			itm8_11 = itm8_11.setScale(2,RoundingMode.HALF_UP);
			itm8_11=itm8_11.subtract(new BigDecimal(schedule8.getScheduleItem8dot27Amt()));
			
			BigDecimal itm8a_11 = itm8_11;
			itm8_11 =itm8_11.multiply(BigDecimal.valueOf(0.5));
			itm8_11 =itm8_11.setScale(2,RoundingMode.DOWN);
			itm8a_11=itm8a_11.subtract(itm8_11);
			
			schedule8.setScheduleItem8dot11Amt(amtFormatter(itm8_11));
			schedule8a.setScheduleItem8Adot11Amt(amtFormatter(itm8a_11));

			BigDecimal itm8_11Prv = trialBalance8dot11Prv.getDrAmount();
			itm8_11Prv = itm8_11Prv.divide(BigDecimal.valueOf(1000), 4);
			itm8_11Prv = itm8_11Prv.setScale(2,RoundingMode.HALF_UP);
			itm8_11Prv=itm8_11Prv.subtract(new BigDecimal(schedule8.getScheduleItem8dot27PreAmt()));
			
			BigDecimal itm8a_11Prv = itm8_11Prv;
			BigDecimal itm8_11P = itm8_11Prv;
			
			itm8_11Prv =itm8_11Prv.multiply(BigDecimal.valueOf(0.45));
			itm8_11Prv =itm8_11Prv.setScale(2,RoundingMode.DOWN);
			
			itm8_11P =itm8_11P.multiply(BigDecimal.valueOf(0.5));
			itm8_11P =itm8_11P.setScale(2,RoundingMode.DOWN);
			itm8a_11Prv=itm8a_11Prv.subtract(itm8_11P);
			
			schedule8.setScheduleItem8dot11PreAmt(amtFormatter(itm8_11Prv));
			schedule8a.setScheduleItem8Adot11PreAmt(amtFormatter(itm8a_11Prv));
			
			
			//8.27
			BigDecimal itm8_27 = new BigDecimal(schedule8.getScheduleItem8dot27Amt());
			itm8_27 =itm8_27.multiply(BigDecimal.valueOf(0.5));
			itm8_27 =itm8_27.setScale(2,RoundingMode.DOWN);
			
			schedule8.setScheduleItem8dot27Amt(amtFormatter(itm8_27));
			schedule8a.setScheduleItem8Adot27Amt(amtFormatter(itm8_27));
			
			BigDecimal itm8_27Prv = new BigDecimal(schedule8.getScheduleItem8dot27PreAmt());
			BigDecimal itm8_27P =itm8_27Prv.multiply(BigDecimal.valueOf(0.5));
			itm8_27P =itm8_27P.setScale(2,RoundingMode.DOWN);
			
			itm8_27Prv =itm8_27Prv.multiply(BigDecimal.valueOf(0.45));
			itm8_27Prv =itm8_27Prv.setScale(2,RoundingMode.DOWN);
			
			schedule8.setScheduleItem8dot27PreAmt(amtFormatter(itm8_27Prv));
			schedule8a.setScheduleItem8Adot27PreAmt(amtFormatter(itm8_27P));
			
			//8.9
			schedule8.setScheduleItem8dot12Amt(amtFormatter(BigDecimal.ZERO));
			schedule8.setScheduleItem8dot12PreAmt(amtFormatter(BigDecimal.ZERO));
			schedule8a.setScheduleItem8Adot12Amt(amtFormatter(BigDecimal.ZERO));
			schedule8a.setScheduleItem8Adot12PreAmt(amtFormatter(BigDecimal.ZERO));
			
			//8.9
			schedule8.setScheduleItem8dot13Amt(amtFormatter(BigDecimal.ZERO));
			schedule8.setScheduleItem8dot13PreAmt(amtFormatter(BigDecimal.ZERO));
			schedule8a.setScheduleItem8Adot13Amt(amtFormatter(BigDecimal.ZERO));
			schedule8a.setScheduleItem8Adot13PreAmt(amtFormatter(BigDecimal.ZERO));
			
			//8.28
			BigDecimal itm8_28 =new BigDecimal(schedule8.getScheduleItem8dot28Amt());
			BigDecimal itm8_28P =new BigDecimal(schedule8.getScheduleItem8dot28PreAmt());
			schedule8.setScheduleItem8dot28Amt(amtFormatter(new BigDecimal(schedule8.getScheduleItem8dot28Amt())));
			schedule8.setScheduleItem8dot28PreAmt(amtFormatter(new BigDecimal(schedule8.getScheduleItem8dot28PreAmt())));
			schedule8a.setScheduleItem8Adot28Amt(amtFormatter(itm8_28));
			schedule8a.setScheduleItem8Adot28PreAmt(amtFormatter(itm8_28P));
			
			//8.29
			BigDecimal itm8_29 =new BigDecimal(schedule8.getScheduleItem8dot29Amt());
			BigDecimal itm8_29P =new BigDecimal(schedule8.getScheduleItem8dot29PreAmt());
			schedule8.setScheduleItem8dot29Amt(amtFormatter(new BigDecimal(schedule8.getScheduleItem8dot29Amt())));
			schedule8.setScheduleItem8dot29PreAmt(amtFormatter(new BigDecimal(schedule8.getScheduleItem8dot29PreAmt())));
			schedule8a.setScheduleItem8Adot29Amt(amtFormatter(itm8_29));
			schedule8a.setScheduleItem8Adot29PreAmt(amtFormatter(itm8_29P));
			
			//-----------------------------------------------------------------
			
			//8.14
			BigDecimal itm8_14 = trialBalance8dot14Dtl.getDrAmount().subtract(trialBalance8dot14Dtl.getCrAmount());
			itm8_14 = itm8_14.divide(BigDecimal.valueOf(1000), 2);
			
			itm8_14=itm8_14.subtract(new BigDecimal(schedule8.getScheduleItem8dot30Amt()));
			
			BigDecimal itm8a_14 = itm8_14;
			itm8_14 =itm8_14.multiply(BigDecimal.valueOf(0.5));
			itm8_14 =itm8_14.setScale(2,RoundingMode.DOWN);
			itm8a_14=itm8a_14.subtract(itm8_14);
			
			schedule8.setScheduleItem8dot14Amt(amtFormatter(itm8_14));
			schedule8a.setScheduleItem8Adot14Amt(amtFormatter(itm8a_14));
			

			BigDecimal itm8_14Prv = trialBalance8dot14Prv.getDrAmount().subtract(trialBalance8dot14Prv.getCrAmount());
			itm8_14Prv = itm8_14Prv.divide(BigDecimal.valueOf(1000), 2);
			itm8_14Prv=itm8_14Prv.subtract(new BigDecimal(schedule8.getScheduleItem8dot30PreAmt()));
			
			BigDecimal itm8a_14Prv = itm8_14Prv;
			BigDecimal itm8_14P = itm8_14Prv;
			
			itm8_14Prv =itm8_14Prv.multiply(BigDecimal.valueOf(0.45));
			itm8_14Prv =itm8_14Prv.setScale(2,RoundingMode.DOWN);
			
			itm8_14P =itm8_14P.multiply(BigDecimal.valueOf(0.5));
			itm8_14P =itm8_14P.setScale(2,RoundingMode.DOWN);
			itm8a_14Prv=itm8a_14Prv.subtract(itm8_14P);
			
			schedule8.setScheduleItem8dot14PreAmt(amtFormatter(itm8_14Prv));
			schedule8a.setScheduleItem8Adot14PreAmt(amtFormatter(itm8a_14Prv));
			
			//8.30
			BigDecimal itm8_30 = new BigDecimal(schedule8.getScheduleItem8dot30Amt());
			itm8_30 =itm8_30.multiply(BigDecimal.valueOf(0.5));
			itm8_30 =itm8_30.setScale(2,RoundingMode.DOWN);
			
			schedule8.setScheduleItem8dot30Amt(amtFormatter(itm8_30));
			schedule8a.setScheduleItem8Adot30Amt(amtFormatter(itm8_30));
			
			BigDecimal itm8_30Prv = new BigDecimal(schedule8.getScheduleItem8dot30PreAmt());
			BigDecimal itm8_30P =itm8_30Prv.multiply(BigDecimal.valueOf(0.5));
			itm8_30P =itm8_30P.setScale(2,RoundingMode.DOWN);
			
			itm8_30Prv =itm8_30Prv.multiply(BigDecimal.valueOf(0.45));
			itm8_30Prv =itm8_30Prv.setScale(2,RoundingMode.DOWN);
			
			schedule8.setScheduleItem8dot30PreAmt(amtFormatter(itm8_30Prv));
			schedule8a.setScheduleItem8Adot30PreAmt(amtFormatter(itm8_30P));
			
			//---------------------------------------------------------------------------------------------
			
			//8.15
			BigDecimal itm8_15 = trialBalance8dot15Dtl.getDrAmount();
			
			BigDecimal itm8a_15 = itm8_15;
			itm8_15 = itm8_15.divide(BigDecimal.valueOf(1000), 4);
			itm8_15 = itm8_15.setScale(2,RoundingMode.HALF_UP);
			itm8_15 =itm8_15.multiply(BigDecimal.valueOf(0.5));
			itm8_15 =itm8_15.setScale(2,RoundingMode.DOWN);
			itm8a_15=itm8a_15.subtract(itm8_15);
			
			schedule8.setScheduleItem8dot15Amt(amtFormatter(itm8_15));
			schedule8a.setScheduleItem8Adot15Amt(amtFormatter(itm8a_15));
			

			BigDecimal itm8_15Prv = trialBalance8dot15Prv.getDrAmount();
			
			BigDecimal itm8a_15Prv = itm8_15Prv;
			BigDecimal itm8_15P = itm8_15Prv;
			
			itm8_15Prv = itm8_15Prv.divide(BigDecimal.valueOf(1000), 4);
			itm8_15Prv = itm8_15Prv.setScale(2,RoundingMode.HALF_UP);
			itm8_15Prv =itm8_15Prv.multiply(BigDecimal.valueOf(0.45));
			itm8_15Prv =itm8_15Prv.setScale(2,RoundingMode.DOWN);
			
			itm8_15P =itm8_15P.multiply(BigDecimal.valueOf(0.5));
			itm8_15P =itm8_15P.setScale(2,RoundingMode.DOWN);
			itm8a_15Prv=itm8a_15Prv.subtract(itm8_15P);
			
			schedule8.setScheduleItem8dot15PreAmt(amtFormatter(itm8_15Prv));
			schedule8a.setScheduleItem8Adot15PreAmt(amtFormatter(itm8a_15Prv));
			
			//8.31
			BigDecimal itm8_31 = new BigDecimal(schedule8.getScheduleItem8dot31Amt());
			itm8_31 =itm8_31.multiply(BigDecimal.valueOf(0.5));
			itm8_31 =itm8_31.setScale(2,RoundingMode.DOWN);
			
			schedule8.setScheduleItem8dot31Amt(amtFormatter(itm8_31));
			schedule8a.setScheduleItem8Adot31Amt(amtFormatter(itm8_31));
			
			BigDecimal itm8_31Prv = new BigDecimal(schedule8.getScheduleItem8dot31PreAmt());
			BigDecimal itm8_31P =itm8_31Prv.multiply(BigDecimal.valueOf(0.5));
			itm8_31P =itm8_31P.setScale(2,RoundingMode.DOWN);
			
			itm8_31Prv =itm8_31Prv.multiply(BigDecimal.valueOf(0.45));
			itm8_31Prv =itm8_31Prv.setScale(2,RoundingMode.DOWN);
			
			schedule8.setScheduleItem8dot31PreAmt(amtFormatter(itm8_31Prv));
			schedule8a.setScheduleItem8Adot31PreAmt(amtFormatter(itm8_31P));
			
			//8.16
			BigDecimal itm8_16 = itm8_2.add(itm8_3).add(itm8_6)
								.add(itm8_8).add(itm8_10).add(itm8_11)
								.add(itm8_14).add(itm8_15);
			schedule8.setScheduleItem8dot16Amt(amtFormatter(itm8_16));
			
			BigDecimal itm8a_16 = itm8a_2.add(itm8a_3).add(itm8a_6)
					.add(itm8a_8).add(itm8a_10).add(itm8a_11)
					.add(itm8a_14).add(itm8a_15);
			schedule8a.setScheduleItem8Adot16Amt(amtFormatter(itm8a_16));
			
			BigDecimal itm8_16Prv = itm8_2Prv.add(itm8_3Prv).add(itm8_6Prv)
									.add(itm8_8Prv).add(itm8_10Prv).add(itm8_11Prv)
									.add(itm8_14Prv).add(itm8_15Prv);
			schedule8.setScheduleItem8dot16PreAmt(amtFormatter(itm8_16Prv));
			
			BigDecimal itm8a_16Prv = itm8a_2Prv.add(itm8a_3Prv).add(itm8a_6Prv)
					.add(itm8a_8Prv).add(itm8a_10Prv).add(itm8a_11Prv)
					.add(itm8a_14Prv).add(itm8a_15Prv);
			schedule8a.setScheduleItem8Adot16PreAmt(amtFormatter(itm8a_16Prv));
			
			//8.32
			BigDecimal itm8_32 = itm8_18.add(itm8_19).add(itm8_22)
								.add(itm8_24).add(itm8_26).add(itm8_27)
								.add(itm8_30).add(itm8_31);
			schedule8.setScheduleItem8dot32Amt(amtFormatter(itm8_32));
		
			schedule8a.setScheduleItem8Adot32Amt(amtFormatter(itm8_32));

			BigDecimal itm8_32Prv = itm8_18Prv.add(itm8_19Prv).add(itm8_22Prv)
									.add(itm8_24Prv).add(itm8_26Prv).add(itm8_27Prv)
									.add(itm8_30Prv).add(itm8_31Prv);
			schedule8.setScheduleItem8dot32PreAmt(amtFormatter(itm8_32Prv));
			
			BigDecimal itm8a_32Prv = itm8_18P.add(itm8_19P).add(itm8_22P)
					.add(itm8_24P).add(itm8_26P).add(itm8_27)
					.add(itm8_30P).add(itm8_31P);
			schedule8a.setScheduleItem8Adot32PreAmt(amtFormatter(itm8a_32Prv));
			
			//8
			
			BigDecimal itm8 = itm8_16.add(itm8_32);
			schedule8.setFinalSchedule8Amt(amtFormatter(itm8));

			BigDecimal itm8Prv = itm8_16Prv.add(itm8_32Prv);
			schedule8.setFinalSchedule8PreAmt(amtFormatter(itm8Prv));
			
			BigDecimal itm8a = itm8a_16.add(itm8_32);
			schedule8a.setFinalSchedule8AAmt(amtFormatter(itm8a));

			BigDecimal itm8aPrv = itm8a_16Prv.add(itm8a_32Prv);
			schedule8a.setFinalSchedule8APreAmt(amtFormatter(itm8aPrv));
			
			
		
			schedule8.setSchedule8a(schedule8a);
			
			
			return schedule8;
		}
		
		
		//-----------------------------------------------schedule 3------------------------------------------------------
		@Override
		public Schedule3 getSchedule3(LocalDate date) {
			log.debug("ScheduleServiceImpl-->getSchedule3()");

			Schedule3 schedule3 = null;
			// if data is present directly take values from trail balance table
			if (scheduleDao.checkForInputDt(date) > 0) {

				schedule3 = getSchedule3Data(date);
				// else generate trail balance and then take values
			} else {

				int curtb = scheduleDao.generateTb(date);

				LocalDate prvDt = date.minusYears(1);

				int prvtb = scheduleDao.generateTbPrv(prvDt);

				if (curtb > 0 && prvtb > 0) {
					schedule3 = getSchedule3Data(date);
				}

			}

			return schedule3;
		}

		public Schedule3 getSchedule3Data(LocalDate date) {

			TrialBalanceDtl trialBalance3dot2Dtl = getTrialBalanceDtl("3", "3.2", date);
			TrialBalanceDtl trialBalance3dot5Dtl = getTrialBalanceDtl("3", "3.5", date);
			TrialBalanceDtl trialBalance3dot8Dtl = getTrialBalanceDtl("3", "3.8", date);
			TrialBalanceDtl trialBalance3dot9Dtl = getTrialBalanceDtl("3", "3.9", date);
		
			LocalDate prvDt = date.minusYears(1);
			TrialBalanceDtl trialBalance3dot2Prv = getTrialBalanceDtlPrv("3", "3.2", prvDt);
			TrialBalanceDtl trialBalance3dot5Prv = getTrialBalanceDtlPrv("3", "3.5", prvDt);
			TrialBalanceDtl trialBalance3dot8Prv = getTrialBalanceDtlPrv("3", "3.8", prvDt);
			TrialBalanceDtl trialBalance3dot9Prv = getTrialBalanceDtlPrv("3", "3.9", prvDt);
	
			Schedule3 schedule3 = new Schedule3();

			schedule3.setCreatedBy(userInfoService.getName());
			schedule3.setScheduleItem3dot1Name("कमीशन भुगतान/Commission Paid");
			schedule3.setScheduleItem3dot2Name("प्रत्यक्ष/Direct");
			schedule3.setScheduleItem3dot3Name("कुल (ए)/TOTAL (A)");
			schedule3.setScheduleItem3dot4Name("जोड़ें:  पुनर्बीमा स्वीकृत पर कमीशन/Add : Commission on Reinsurance Accepted");
			schedule3.setScheduleItem3dot5Name("कमीशन कमी करें:  पुनर्बीमा सीडेड पर कमीशन/Less: Commission on Re-insurance Ceded");
			schedule3.setScheduleItem3dot6Name("नेट कमीशन/Net Commission");
			schedule3.setScheduleItem3dot7Name("एजेंट्स/Agents");
			schedule3.setScheduleItem3dot8Name("ब्रोकर/Brokers");
			schedule3.setScheduleItem3dot9Name("कॉर्पोरेट एजेंसी/Corporate Agency");
			schedule3.setScheduleItem3dot10Name("अन्य (कृपया निर्दिष्ट करें)/Others (pl. specify)");
			schedule3.setFinalScheduleName("कुल (बी)/TOTAL (B)");
			

			// 3.2 3.3
			BigDecimal itm3_2 = trialBalance3dot2Dtl.getDrAmount().subtract(trialBalance3dot2Dtl.getCrAmount());
			itm3_2 = itm3_2.divide(BigDecimal.valueOf(1000), 4);
			itm3_2=itm3_2.setScale(2,RoundingMode.HALF_UP);
			schedule3.setScheduleItem3dot2Amt(amtFormatter(itm3_2));
			schedule3.setScheduleItem3dot3Amt(amtFormatter(itm3_2));

			BigDecimal itm3_2Prv = trialBalance3dot2Prv.getDrAmount().subtract(trialBalance3dot2Prv.getCrAmount());
			itm3_2Prv = itm3_2Prv.divide(BigDecimal.valueOf(1000), 4);
			itm3_2Prv=itm3_2Prv.setScale(2,RoundingMode.HALF_UP);
			schedule3.setScheduleItem3dot2PreAmt(amtFormatter(itm3_2Prv));
			schedule3.setScheduleItem3dot3PreAmt(amtFormatter(itm3_2Prv));
			
			//3.4
			schedule3.setScheduleItem3dot4Amt(amtFormatter(BigDecimal.ZERO));
			schedule3.setScheduleItem3dot4PreAmt(amtFormatter(BigDecimal.ZERO));
			
			//3.5
			BigDecimal itm3_5 = trialBalance3dot5Dtl.getCrAmount().subtract(trialBalance3dot5Dtl.getDrAmount());
			itm3_5 = itm3_5.divide(BigDecimal.valueOf(1000), 4);
			itm3_5=itm3_5.setScale(2,RoundingMode.HALF_UP);
			schedule3.setScheduleItem3dot5Amt(amtFormatter(itm3_5));
			

			BigDecimal itm3_5Prv = trialBalance3dot5Prv.getCrAmount().subtract(trialBalance3dot5Prv.getDrAmount());
			itm3_5Prv = itm3_5Prv.divide(BigDecimal.valueOf(1000), 4);
			itm3_5Prv=itm3_5Prv.setScale(2,RoundingMode.HALF_UP);
			schedule3.setScheduleItem3dot5PreAmt(amtFormatter(itm3_5Prv));
			
			//3.6
			BigDecimal itm3_6 = itm3_2.subtract(itm3_5);
			schedule3.setScheduleItem3dot6Amt(amtFormatter(itm3_6));
			
			BigDecimal itm3_6Prv = itm3_2Prv.subtract(itm3_5Prv);
			schedule3.setScheduleItem3dot6PreAmt(amtFormatter(itm3_6Prv));
			
			//3.7
			schedule3.setScheduleItem3dot7Amt(amtFormatter(BigDecimal.ZERO));
			schedule3.setScheduleItem3dot7PreAmt(amtFormatter(BigDecimal.ZERO));
			
			//3.8
			BigDecimal itm3_8 = trialBalance3dot8Dtl.getDrAmount();
			itm3_8 = itm3_8.divide(BigDecimal.valueOf(1000), 4);
			itm3_8=itm3_8.setScale(2,RoundingMode.HALF_UP);
			schedule3.setScheduleItem3dot8Amt(amtFormatter(itm3_8));
			

			BigDecimal itm3_8Prv = trialBalance3dot8Prv.getDrAmount();
			itm3_8Prv = itm3_8Prv.divide(BigDecimal.valueOf(1000), 4);
			itm3_8Prv=itm3_8Prv.setScale(2,RoundingMode.HALF_UP);
			schedule3.setScheduleItem3dot8PreAmt(amtFormatter(itm3_8Prv));
			
			//3.9
			schedule3.setScheduleItem3dot9Amt(amtFormatter(BigDecimal.ZERO));
			schedule3.setScheduleItem3dot9PreAmt(amtFormatter(BigDecimal.ZERO));
			
			//3.10
			schedule3.setScheduleItem3dot10Amt(amtFormatter(BigDecimal.ZERO));
			schedule3.setScheduleItem3dot10PreAmt(amtFormatter(BigDecimal.ZERO));
			
			//3.10
			schedule3.setFinalSchedule3Amt(amtFormatter(itm3_8));
			schedule3.setFinalSchedule3PreAmt(amtFormatter(itm3_8Prv));
			
			return schedule3;

		}
		
		//--------------------------------------------------schedule 6------------------------------------------------------
				@Override
				public Schedule6 getSchedule6(LocalDate date) {
					log.debug("ScheduleServiceImpl-->getSchedule6()");

					Schedule6 schedule6 = null;
					// if data is present directly take values from trail balance table
					if (scheduleDao.checkForInputDt(date) > 0) {

						schedule6 = getSchedule6Data(date);
						// else generate trail balance and then take values
					} else {

						int curtb = scheduleDao.generateTb(date);

						LocalDate prvDt = date.minusYears(1);

						int prvtb = scheduleDao.generateTbPrv(prvDt);

						if (curtb > 0 && prvtb > 0) {
							schedule6 = getSchedule6Data(date);
						}

					}

					return schedule6;
				}

				public Schedule6 getSchedule6Data(LocalDate date) {

					TrialBalanceDtl trialBalance6dot4Dtl = getTrialBalanceDtl("6", "6.4", date);
					TrialBalanceDtl trialBalance6dot6Dtl = getTrialBalanceDtl("6", "6.6", date);
					
				
					LocalDate prvDt = date.minusYears(1);
					TrialBalanceDtl trialBalance6dot4Prv = getTrialBalanceDtlPrv("6", "6.4", prvDt);
					TrialBalanceDtl trialBalance6dot6Prv = getTrialBalanceDtlPrv("6", "6.6", prvDt);
					
					Schedule6 schedule6 = new Schedule6();

					schedule6.setCreatedBy(userInfoService.getName());
					schedule6.setScheduleItem6dot1Name("संपत्ति कोष/Capital Reserve");
					schedule6.setScheduleItem6dot2Name("पूंजी रद्दी कोष/Capital Redemption Reserve");
					schedule6.setScheduleItem6dot3Name("शेयर प्रीमियम/Share Premium");
					schedule6.setScheduleItem6dot4Name("सामान्य रिजर्व - प्रारंभिक शेष/General Reserve - Opening Balance");
					schedule6.setScheduleItem6dot4dot1Name("वर्ष के दौरान जोड़ा गया/Additions during year");
					schedule6.setScheduleItem6dot4dot2Name("वर्ष के दौरान कटौती/Deduction during year");
					schedule6.setScheduleItem6dot5Name("आपदा रिजर्व/Catastrophe Reserve");
					schedule6.setScheduleItem6dot6Name("फैक्टरिंग योजना रिजर्व/Factoring Scheme Reserve");
					schedule6.setScheduleItem6dot7Name("लाभ और हानि खाते में शेष/Balance in Profit & Loss Account");
					schedule6.setFinalSchedule6Name("कुल/TOTAL");
					
					
					//6.1
					schedule6.setScheduleItem6dot1Amt(amtFormatter(BigDecimal.ZERO));
					schedule6.setScheduleItem6dot1PreAmt(amtFormatter(BigDecimal.ZERO));
					
					//6.2
					schedule6.setScheduleItem6dot2Amt(amtFormatter(BigDecimal.ZERO));
					schedule6.setScheduleItem6dot2PreAmt(amtFormatter(BigDecimal.ZERO));
					
					//6.3
					schedule6.setScheduleItem6dot3Amt(amtFormatter(BigDecimal.ZERO));
					schedule6.setScheduleItem6dot3PreAmt(amtFormatter(BigDecimal.ZERO));
					
					//6.4
					BigDecimal itemCode6_4 = trialBalance6dot4Dtl.getCrAmount();
					itemCode6_4 = itemCode6_4.divide(BigDecimal.valueOf(1000), 4);
					itemCode6_4 = itemCode6_4.setScale(2,RoundingMode.HALF_UP );
					schedule6.setScheduleItem6dot4Amt(amtFormatter(itemCode6_4));
					
					
					BigDecimal itemCode6_4Prv = trialBalance6dot4Prv.getCrAmount();
					itemCode6_4Prv = itemCode6_4Prv.divide(BigDecimal.valueOf(1000), 4);
					itemCode6_4Prv = itemCode6_4Prv.setScale(2,RoundingMode.HALF_UP );
					schedule6.setScheduleItem6dot4PreAmt(amtFormatter(itemCode6_4Prv));
					
					
					//6.4.1
					schedule6.setScheduleItem6dot4dot1Amt(amtFormatter(BigDecimal.ZERO));
					schedule6.setScheduleItem6dot4dot1PreAmt(amtFormatter(BigDecimal.ZERO));
					
					//6.4.t
					schedule6.setScheduleItem6dot4t1Amt(amtFormatter(BigDecimal.ZERO));
					schedule6.setScheduleItem6dot4t1PreAmt(amtFormatter(BigDecimal.ZERO));
					
					//6.4.2
					schedule6.setScheduleItem6dot4dot2Amt(amtFormatter(BigDecimal.ZERO));
					schedule6.setScheduleItem6dot4dot2PreAmt(amtFormatter(BigDecimal.ZERO));
					
					//6.4.t2
					schedule6.setScheduleItem6dot4t2Amt(amtFormatter(itemCode6_4));
					schedule6.setScheduleItem6dot4t2PreAmt(amtFormatter(itemCode6_4));
					
					//6.5
					schedule6.setScheduleItem6dot5Amt(amtFormatter(BigDecimal.ZERO));
					schedule6.setScheduleItem6dot5PreAmt(amtFormatter(BigDecimal.ZERO));
					
					//6.6
					BigDecimal itemCode6_6 = trialBalance6dot6Dtl.getCrAmount();
					itemCode6_6 = itemCode6_6.divide(BigDecimal.valueOf(1000), 4);
					itemCode6_6 = itemCode6_6.setScale(2,RoundingMode.HALF_UP );
					schedule6.setScheduleItem6dot6Amt(amtFormatter(itemCode6_6));
					
					
					BigDecimal itemCode6_6Prv = trialBalance6dot6Prv.getCrAmount();
					itemCode6_6Prv = itemCode6_6Prv.divide(BigDecimal.valueOf(1000), 4);
					itemCode6_6Prv = itemCode6_6Prv.setScale(2,RoundingMode.HALF_UP );
					schedule6.setScheduleItem6dot6PreAmt(amtFormatter(itemCode6_6Prv));
					
					//6.7
					schedule6.setScheduleItem6dot7Amt(amtFormatter(BigDecimal.ZERO));
					schedule6.setScheduleItem6dot7PreAmt(amtFormatter(BigDecimal.ZERO));
				
					//total
					BigDecimal itm_6 = itemCode6_4.add(itemCode6_6);
					BigDecimal itm_6Prv = itemCode6_4Prv.add(itemCode6_6Prv);
					schedule6.setFinalSchedule6Amt(amtFormatter(itm_6));
					schedule6.setFinalSchedule6PreAmt(amtFormatter(itm_6Prv));
				
					return schedule6;

				}

				//---------------------------------------------schedule 4----------------------------------------------
				@Override
				public Schedule4 getSchedule4(LocalDate date) {
					log.debug("ScheduleServiceImpl-->getSchedule6()");

					Schedule4 schedule4 = null;
					// if data is present directly take values from trail balance table
					if (scheduleDao.checkForInputDt(date) > 0) {

						schedule4 = getSchedule4Data(date);
						// else generate trail balance and then take values
					} else {

						int curtb = scheduleDao.generateTb(date);

						LocalDate prvDt = date.minusYears(1);

						int prvtb = scheduleDao.generateTbPrv(prvDt);

						if (curtb > 0 && prvtb > 0) {
							schedule4 = getSchedule4Data(date);
						}

					}

					return schedule4;
				}

				public Schedule4 getSchedule4Data(LocalDate date) {

					TrialBalanceDtl trialBalance4dot1Dtl = getTrialBalanceDtl("4", "4.1", date);
					TrialBalanceDtl trialBalance4dot2Dtl = getTrialBalanceDtl("4", "4.2", date);
					TrialBalanceDtl trialBalance4dot3Dtl = getTrialBalanceDtl("4", "4.3", date);
					TrialBalanceDtl trialBalance4dot4Dtl = getTrialBalanceDtl("4", "4.4", date);
					TrialBalanceDtl trialBalance4dot5Dtl = getTrialBalanceDtl("4", "4.5", date);
					TrialBalanceDtl trialBalance4dot6Dtl = getTrialBalanceDtl("4", "4.6", date);
					TrialBalanceDtl trialBalance4dot7Dtl = getTrialBalanceDtl("4", "4.7", date);
					TrialBalanceDtl trialBalance4dot8Dtl = getTrialBalanceDtl("4", "4.8", date);
					TrialBalanceDtl trialBalance4dot10Dtl = getTrialBalanceDtl("4", "4.10", date);
					TrialBalanceDtl trialBalance4dot12Dtl = getTrialBalanceDtl("4", "4.12", date);
					TrialBalanceDtl trialBalance4dot15Dtl = getTrialBalanceDtl("4", "4.15", date);
					TrialBalanceDtl trialBalance4dot16Dtl = getTrialBalanceDtl("4", "4.16", date);
					TrialBalanceDtl trialBalance4dot17Dtl = getTrialBalanceDtl("4", "4.17", date);
					TrialBalanceDtl trialBalance4dot18Dtl = getTrialBalanceDtl("4", "4.18", date);
					TrialBalanceDtl trialBalance4dot19Dtl = getTrialBalanceDtl("4", "4.19", date);

				
					LocalDate prvDt = date.minusYears(1);
					TrialBalanceDtl trialBalance4dot1Prv = getTrialBalanceDtlPrv("4", "4.1", prvDt);
					TrialBalanceDtl trialBalance4dot2Prv = getTrialBalanceDtlPrv("4", "4.2", prvDt);
					TrialBalanceDtl trialBalance4dot3Prv = getTrialBalanceDtlPrv("4", "4.3", prvDt);
					TrialBalanceDtl trialBalance4dot4Prv = getTrialBalanceDtlPrv("4", "4.4", prvDt);
					TrialBalanceDtl trialBalance4dot5Prv = getTrialBalanceDtlPrv("4", "4.5", prvDt);
					TrialBalanceDtl trialBalance4dot6Prv = getTrialBalanceDtlPrv("4", "4.6", prvDt);
					TrialBalanceDtl trialBalance4dot7Prv = getTrialBalanceDtlPrv("4", "4.7", prvDt);
					TrialBalanceDtl trialBalance4dot8Prv = getTrialBalanceDtlPrv("4", "4.8", prvDt);
					TrialBalanceDtl trialBalance4dot10Prv = getTrialBalanceDtlPrv("4", "4.10", prvDt);
					TrialBalanceDtl trialBalance4dot12Prv = getTrialBalanceDtlPrv("4", "4.12", prvDt);
					TrialBalanceDtl trialBalance4dot15Prv = getTrialBalanceDtlPrv("4", "4.15", prvDt);
					TrialBalanceDtl trialBalance4dot16Prv = getTrialBalanceDtlPrv("4", "4.16", prvDt);
					TrialBalanceDtl trialBalance4dot17Prv = getTrialBalanceDtlPrv("4", "4.17", prvDt);
					TrialBalanceDtl trialBalance4dot18Prv = getTrialBalanceDtlPrv("4", "4.18", prvDt);
					TrialBalanceDtl trialBalance4dot19Prv = getTrialBalanceDtlPrv("4", "4.19", prvDt);

					Schedule4 schedule4 = new Schedule4();
					
					schedule4.setScheduleItem4dot1Name("कर्मचारियों का पारिश्रमिक और कल्याण लाभ/Employees' remuneration and welfare benefits");
					schedule4.setScheduleItem4dot2Name("यात्रा, परिवहन और वाहन चलाने का खर्च/Travel, conveyance and vehicle running expenses");
					schedule4.setScheduleItem4dot3Name("प्रशिक्षण व्यय/Training expenses");
					schedule4.setScheduleItem4dot4Name("किराया, दरों और कर/ Rent, rates & Taxes");
					schedule4.setScheduleItem4dot5Name("मरम्मत और रखरखाव/Repairs & Maintenance");
					schedule4.setScheduleItem4dot6Name("प्रिंटिंग और स्टेशनरी/Printing & Stationery");
					schedule4.setScheduleItem4dot7Name("संचार खर्च/Communication expenses");
					schedule4.setScheduleItem4dot8Name("कानूनी और पेशेवर शुल्क/Legal & professional charges");
					schedule4.setScheduleItem4dot9Name("समीक्षकों की फीस, व्यय आदि /Auditors' fees, expenses etc. ");
					schedule4.setScheduleItem4dot10Name("(ए) समीक्षक के रूप में/(a) As auditor");
					schedule4.setScheduleItem4dot11Name("(बी) सलाहकार के रूप में या किसी अन्य क्षमता में, के संबंध में/ (b) As adviser or in any other capacity, in respect of");
					schedule4.setScheduleItem4dot12Name("(i) कराधान संबंधी मामले/(i) Taxation matters");
					schedule4.setScheduleItem4dot13Name("(ii) बीमा मायने रखता है/(ii) Insurance matters");
					schedule4.setScheduleItem4dot14Name("(iii) प्रबंधन सेवाएँ/(iii) Management services");
					schedule4.setScheduleItem4dot15Name("(सी) किसी अन्य क्षमता में/(c) In any other capacity");
					schedule4.setScheduleItem4dot16Name("विज्ञापन और प्रचार/Advertisement and publicity");
					schedule4.setScheduleItem4dot17Name("ब्याज और बैंक शुल्क/Interest and Bank Charges");
					schedule4.setScheduleItem4dot18Name("अन्य - विविध खर्च/Miscellaneous Expenses and Other Expenses");
					schedule4.setScheduleItem4dot19Name("ध्वस्तावधि/Depreciation");
					schedule4.setFinalSchedule4Name("कुल/TOTAL");

				
					schedule4.setCreatedBy(userInfoService.getName());
					
					//4.1
					BigDecimal itemCode4_1 = trialBalance4dot1Dtl.getDrAmount().subtract(trialBalance4dot1Dtl.getCrAmount());
					itemCode4_1 = itemCode4_1.divide(BigDecimal.valueOf(1000), 4);
					itemCode4_1 = itemCode4_1.setScale(2,RoundingMode.HALF_UP );
					schedule4.setScheduleItem4dot1Amt(amtFormatter(itemCode4_1));
					
					
					BigDecimal itemCode4_1Prv = trialBalance4dot1Prv.getDrAmount().subtract(trialBalance4dot1Prv.getCrAmount());
					itemCode4_1Prv = itemCode4_1Prv.divide(BigDecimal.valueOf(1000), 4);
					itemCode4_1Prv = itemCode4_1Prv.setScale(2,RoundingMode.HALF_UP );
					schedule4.setScheduleItem4dot1PreAmt(amtFormatter(itemCode4_1Prv));
					
					
					//4.2
					BigDecimal itemCode4_2 = trialBalance4dot2Dtl.getDrAmount().subtract(trialBalance4dot2Dtl.getCrAmount());
					itemCode4_2 = itemCode4_2.divide(BigDecimal.valueOf(1000), 4);
					itemCode4_2 = itemCode4_2.setScale(2,RoundingMode.HALF_UP );
					schedule4.setScheduleItem4dot2Amt(amtFormatter(itemCode4_2));
					
					
					BigDecimal itemCode4_2Prv = trialBalance4dot2Prv.getDrAmount().subtract(trialBalance4dot2Prv.getCrAmount());
					itemCode4_2Prv = itemCode4_2Prv.divide(BigDecimal.valueOf(1000), 4);
					itemCode4_2Prv = itemCode4_2Prv.setScale(2,RoundingMode.HALF_UP );
					schedule4.setScheduleItem4dot2PreAmt(amtFormatter(itemCode4_2Prv));
					
					
					//4.3
					BigDecimal itemCode4_3 = trialBalance4dot3Dtl.getDrAmount();
					itemCode4_3 = itemCode4_3.divide(BigDecimal.valueOf(1000), 4);
					itemCode4_3 = itemCode4_3.setScale(2,RoundingMode.HALF_UP );
					schedule4.setScheduleItem4dot3Amt(amtFormatter(itemCode4_3));
					
					
					BigDecimal itemCode4_3Prv = trialBalance4dot3Prv.getDrAmount();
					itemCode4_3Prv = itemCode4_3Prv.divide(BigDecimal.valueOf(1000), 4);
					itemCode4_3Prv = itemCode4_3Prv.setScale(2,RoundingMode.HALF_UP );
					schedule4.setScheduleItem4dot3PreAmt(amtFormatter(itemCode4_3Prv));
					
					//4.4
					BigDecimal itemCode4_4 = trialBalance4dot4Dtl.getDrAmount();
					itemCode4_4 = itemCode4_4.divide(BigDecimal.valueOf(1000), 4);
					itemCode4_4 = itemCode4_4.setScale(2,RoundingMode.HALF_UP );
					schedule4.setScheduleItem4dot4Amt(amtFormatter(itemCode4_4));
					
					
					BigDecimal itemCode4_4Prv = trialBalance4dot4Prv.getDrAmount();
					itemCode4_4Prv = itemCode4_4Prv.divide(BigDecimal.valueOf(1000), 4);
					itemCode4_4Prv = itemCode4_4Prv.setScale(2,RoundingMode.HALF_UP );
					schedule4.setScheduleItem4dot4PreAmt(amtFormatter(itemCode4_4Prv));
					
					
					//4.5
					BigDecimal itemCode4_5 = trialBalance4dot5Dtl.getDrAmount();
					itemCode4_5 = itemCode4_5.divide(BigDecimal.valueOf(1000), 4);
					itemCode4_5 = itemCode4_5.setScale(2,RoundingMode.HALF_UP );
					schedule4.setScheduleItem4dot5Amt(amtFormatter(itemCode4_5));
					
					
					BigDecimal itemCode4_5Prv = trialBalance4dot5Prv.getDrAmount();
					itemCode4_5Prv = itemCode4_5Prv.divide(BigDecimal.valueOf(1000), 4);
					itemCode4_5Prv = itemCode4_5Prv.setScale(2,RoundingMode.HALF_UP );
					schedule4.setScheduleItem4dot5PreAmt(amtFormatter(itemCode4_5Prv));
					
					
					//4.6
					BigDecimal itemCode4_6 = trialBalance4dot6Dtl.getDrAmount();
					itemCode4_6 = itemCode4_6.divide(BigDecimal.valueOf(1000), 4);
					itemCode4_6 = itemCode4_6.setScale(2,RoundingMode.HALF_UP );
					schedule4.setScheduleItem4dot6Amt(amtFormatter(itemCode4_6));
					
					
					BigDecimal itemCode4_6Prv = trialBalance4dot6Prv.getDrAmount();
					itemCode4_6Prv = itemCode4_6Prv.divide(BigDecimal.valueOf(1000), 4);
					itemCode4_6Prv = itemCode4_6Prv.setScale(2,RoundingMode.HALF_UP );
					schedule4.setScheduleItem4dot6PreAmt(amtFormatter(itemCode4_6Prv));
					
					
					//4.7
					BigDecimal itemCode4_7 = trialBalance4dot7Dtl.getDrAmount();
					itemCode4_7 = itemCode4_7.divide(BigDecimal.valueOf(1000), 4);
					itemCode4_7 = itemCode4_7.setScale(2,RoundingMode.HALF_UP );
					schedule4.setScheduleItem4dot7Amt(amtFormatter(itemCode4_7));
					
					
					BigDecimal itemCode4_7Prv = trialBalance4dot7Prv.getDrAmount();
					itemCode4_7Prv = itemCode4_7Prv.divide(BigDecimal.valueOf(1000), 4);
					itemCode4_7Prv = itemCode4_7Prv.setScale(2,RoundingMode.HALF_UP );
					schedule4.setScheduleItem4dot7PreAmt(amtFormatter(itemCode4_7Prv));
					
					
					//4.8
					BigDecimal itemCode4_8 = trialBalance4dot8Dtl.getDrAmount();
					itemCode4_8 = itemCode4_8.divide(BigDecimal.valueOf(1000), 4);
					itemCode4_8 = itemCode4_8.setScale(2,RoundingMode.HALF_UP );
					schedule4.setScheduleItem4dot8Amt(amtFormatter(itemCode4_8));
					
					
					BigDecimal itemCode4_8Prv = trialBalance4dot8Prv.getDrAmount();
					itemCode4_8Prv = itemCode4_8Prv.divide(BigDecimal.valueOf(1000), 4);
					itemCode4_8Prv = itemCode4_8Prv.setScale(2,RoundingMode.HALF_UP );
					schedule4.setScheduleItem4dot8PreAmt(amtFormatter(itemCode4_8Prv));
					
					
					//4.10
					BigDecimal itemCode4_10 = trialBalance4dot10Dtl.getDrAmount();
					itemCode4_10 = itemCode4_10.divide(BigDecimal.valueOf(1000), 4);
					itemCode4_10 = itemCode4_10.setScale(2,RoundingMode.HALF_UP );
					schedule4.setScheduleItem4dot10Amt(amtFormatter(itemCode4_10));
					
					
					BigDecimal itemCode4_10Prv = trialBalance4dot10Prv.getDrAmount();
					itemCode4_10Prv = itemCode4_10Prv.divide(BigDecimal.valueOf(1000), 4);
					itemCode4_10Prv = itemCode4_10Prv.setScale(2,RoundingMode.HALF_UP );
					schedule4.setScheduleItem4dot10PreAmt(amtFormatter(itemCode4_10Prv));
					
					//4.12
					BigDecimal itemCode4_12 = trialBalance4dot12Dtl.getDrAmount();
					itemCode4_12 = itemCode4_12.divide(BigDecimal.valueOf(1000), 4);
					itemCode4_12 = itemCode4_12.setScale(2,RoundingMode.HALF_UP );
					schedule4.setScheduleItem4dot12Amt(amtFormatter(itemCode4_12));
					
					
					BigDecimal itemCode4_12Prv = trialBalance4dot12Prv.getDrAmount();
					itemCode4_12Prv = itemCode4_12Prv.divide(BigDecimal.valueOf(1000), 4);
					itemCode4_12Prv = itemCode4_12Prv.setScale(2,RoundingMode.HALF_UP );
					schedule4.setScheduleItem4dot12PreAmt(amtFormatter(itemCode4_12Prv));
					
					
					//4.13
					schedule4.setScheduleItem4dot13Amt(amtFormatter(BigDecimal.ZERO));
					schedule4.setScheduleItem4dot13PreAmt(amtFormatter(BigDecimal.ZERO));
					
					//4.14
					schedule4.setScheduleItem4dot14Amt(amtFormatter(BigDecimal.ZERO));
					schedule4.setScheduleItem4dot14PreAmt(amtFormatter(BigDecimal.ZERO));
					
					//4.15
					BigDecimal itemCode4_15 = trialBalance4dot15Dtl.getDrAmount();
					itemCode4_15 = itemCode4_15.divide(BigDecimal.valueOf(1000), 4);
					itemCode4_15 = itemCode4_15.setScale(2,RoundingMode.HALF_UP );
					schedule4.setScheduleItem4dot15Amt(amtFormatter(itemCode4_15));
					
					
					BigDecimal itemCode4_15Prv = trialBalance4dot15Prv.getDrAmount();
					itemCode4_15Prv = itemCode4_15Prv.divide(BigDecimal.valueOf(1000), 4);
					itemCode4_15Prv = itemCode4_15Prv.setScale(2,RoundingMode.HALF_UP );
					schedule4.setScheduleItem4dot15PreAmt(amtFormatter(itemCode4_15Prv));
					
					
					//4.16
					BigDecimal itemCode4_16 = trialBalance4dot16Dtl.getDrAmount();
					itemCode4_16 = itemCode4_16.divide(BigDecimal.valueOf(1000), 4);
					itemCode4_16 = itemCode4_16.setScale(2,RoundingMode.HALF_UP );
					schedule4.setScheduleItem4dot16Amt(amtFormatter(itemCode4_16));
					
					
					BigDecimal itemCode4_16Prv = trialBalance4dot16Prv.getDrAmount();
					itemCode4_16Prv = itemCode4_16Prv.divide(BigDecimal.valueOf(1000), 4);
					itemCode4_16Prv = itemCode4_16Prv.setScale(2,RoundingMode.HALF_UP );
					schedule4.setScheduleItem4dot16PreAmt(amtFormatter(itemCode4_16Prv));
					
					//4.17
					BigDecimal itemCode4_17 = trialBalance4dot17Dtl.getDrAmount();
					itemCode4_17 = itemCode4_17.divide(BigDecimal.valueOf(1000), 4);
					itemCode4_17 = itemCode4_17.setScale(2,RoundingMode.HALF_UP );
					schedule4.setScheduleItem4dot17Amt(amtFormatter(itemCode4_17));
					
					
					BigDecimal itemCode4_17Prv = trialBalance4dot17Prv.getDrAmount();
					itemCode4_17Prv = itemCode4_17Prv.divide(BigDecimal.valueOf(1000), 4);
					itemCode4_17Prv = itemCode4_17Prv.setScale(2,RoundingMode.HALF_UP );
					schedule4.setScheduleItem4dot17PreAmt(amtFormatter(itemCode4_17Prv));
					
					//4.18
					BigDecimal itemCode4_18 = trialBalance4dot18Dtl.getDrAmount().subtract(trialBalance4dot18Dtl.getCrAmount());
					itemCode4_18 = itemCode4_18.divide(BigDecimal.valueOf(1000), 4);
					itemCode4_18 = itemCode4_18.setScale(2,RoundingMode.HALF_UP );
					schedule4.setScheduleItem4dot18Amt(amtFormatter(itemCode4_18));
					
					
					BigDecimal itemCode4_18Prv = trialBalance4dot18Prv.getDrAmount().subtract(trialBalance4dot18Prv.getCrAmount());
					itemCode4_18Prv = itemCode4_18Prv.divide(BigDecimal.valueOf(1000), 4);
					itemCode4_18Prv = itemCode4_18Prv.setScale(2,RoundingMode.HALF_UP );
					schedule4.setScheduleItem4dot18PreAmt(amtFormatter(itemCode4_18Prv));
					
					
					//4.19
					BigDecimal itemCode4_19 = trialBalance4dot19Dtl.getDrAmount();
					itemCode4_19 = itemCode4_19.divide(BigDecimal.valueOf(1000), 4);
					itemCode4_19 = itemCode4_19.setScale(2,RoundingMode.HALF_UP );
					schedule4.setScheduleItem4dot19Amt(amtFormatter(itemCode4_19));
					
					
					BigDecimal itemCode4_19Prv = trialBalance4dot19Prv.getDrAmount();
					itemCode4_19Prv = itemCode4_19Prv.divide(BigDecimal.valueOf(1000), 4);
					itemCode4_19Prv = itemCode4_19Prv.setScale(2,RoundingMode.HALF_UP );
					schedule4.setScheduleItem4dot19PreAmt(amtFormatter(itemCode4_19Prv));
					
					
					
					//total
					BigDecimal itm4 = itemCode4_1.add(itemCode4_2).add(itemCode4_3).add(itemCode4_4)
												 .add(itemCode4_5).add(itemCode4_6).add(itemCode4_7)
												 .add(itemCode4_8).add(itemCode4_10).add(itemCode4_12)
												 .add(itemCode4_15).add(itemCode4_16).add(itemCode4_17)
												 .add(itemCode4_18).add(itemCode4_19);
					schedule4.setFinalSchedule4Amt(amtFormatter(itm4));
					
					//total
					BigDecimal itm4Prv = itemCode4_1Prv.add(itemCode4_2Prv).add(itemCode4_3Prv).add(itemCode4_4Prv)
												 .add(itemCode4_5Prv).add(itemCode4_6Prv).add(itemCode4_7Prv)
												 .add(itemCode4_8Prv).add(itemCode4_10Prv).add(itemCode4_12Prv)
												 .add(itemCode4_15Prv).add(itemCode4_16Prv).add(itemCode4_17Prv)
												 .add(itemCode4_18Prv).add(itemCode4_19Prv);
					schedule4.setFinalSchedule4PreAmt(amtFormatter(itm4Prv));
					
								
					return schedule4;

				}
				
				//------------------------------------------------- End -----------------------------------------------

}
