package in.ecgc.smile.erp.reporting.jasper.be.service.accounts;

import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;

import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.GLCodeStmtIn;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.GLCodeStmtOut;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.GLRangeStmtIn;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.GLRangeStmtOut;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.GLStmt;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.GLStmtOut;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.GlStmtIn;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.TdsDetails;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.TcodeLevel.TcodeLevelStmtOut;
import in.ecgc.smile.erp.reporting.jasper.be.model.external.BankBranch;

public interface GlTxnService {

	public GLStmtOut getTcodewiseGLTxnStatement(GlStmtIn glStmtIn);

	public List<GLStmt> getGLTransactionTypeWiseStatement(String logicallocCd, String txnType, String fromDtStr,
			String toDtStr);

	public List<GLRangeStmtOut> getGLRangewiseTxnStatement(GLRangeStmtIn glRangeStmtIn);

	public GLStmtOut getSubBfwiseGLTxnStatement(GlStmtIn glStmt);

	public GLCodeStmtOut getGLCodeStatementbyLoc(GLCodeStmtIn glCodeStmtIn);

	public GLStmtOut getTcodeAndSubBfwiseGLTxnStatement(GlStmtIn glStmtIn);

	public List<TdsDetails> getdetailsOfAmtPaidUnderTDSForYear(String logicallocCd, String fiscalYear);

	public String findBankByLogicalLocation(@PathVariable String logicalLocCode);

	public TcodeLevelStmtOut getTcodeLevelGLStatement(GlStmtIn glStmtIn);

}
