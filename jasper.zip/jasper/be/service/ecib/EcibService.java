package in.ecgc.smile.erp.reporting.jasper.be.service.ecib;

import java.util.List;
import java.util.Map;

import org.springframework.http.ResponseEntity;

import in.ecgc.smile.erp.reporting.jasper.be.model.ecib.EcibInUR16;
import in.ecgc.smile.erp.reporting.jasper.be.model.ecib.EcibInUR04;
import in.ecgc.smile.erp.reporting.jasper.be.model.ecib.EcibRoxbo11;
import in.ecgc.smile.erp.reporting.jasper.be.model.ecib.EcibRoxbo12;
import in.ecgc.smile.erp.reporting.jasper.be.model.ecib.EcibWtUR63;
import in.ecgc.smile.erp.reporting.jasper.be.model.ecib.EcibWtUR64;
import in.ecgc.smile.erp.reporting.jasper.be.model.reports.Report;
import in.ecgc.smile.erp.reporting.jasper.be.utils.Pair;


public interface EcibService {
	
	List<EcibRoxbo11> getListOfCoverTypeExporterMoreThan100Cr(int FromYear, int FromMonth, int ToYear, int ToMonth);

	List<EcibInUR04> getListOfInCoverIssueRegister(String fromDate, String toDate, String coverType);
		
	List<EcibRoxbo12> getListOfExporterMoreThan100Cr(int FromYear, int FromMonth, int ToYear, int ToMonth);

	List<EcibInUR16> getListEcibCoverAdjustedDeclaration(int fromYear, int fromMonth, int toYear, int toMonth);
	
	List<EcibWtUR63> getListBankwiseRvPremiumReport(int fromYear, int fromMonth, int toYear, int toMonth);

	List<EcibWtUR63> getListEcibTypewise(int fromYear, int fromMonth, int toYear, int toMonth);

	List<EcibWtUR63> getListBankwise(int fromYear, int fromMonth, int toYear, int toMonth);

	List<EcibWtUR64> getListEcgcBranchwisePremiumEarned(int fromYear, int fromMonth, int toYear, int toMonth);

	List<EcibWtUR64> getListEcibTypewise1(int fromYear, int fromMonth, int toYear, int toMonth);

	List<EcibWtUR64> getListBankwise1(int fromYear, int fromMonth, int toYear, int toMonth);

	public List<String>  getAllPolicyTypes();

	public Pair<Report, Exception> generateReport(Map<String, String> allRequestParams);

	public Pair<Report, Exception> getECIBWTUR36Report(String reportStatus,int fromYear, int toYear, int fromMonth,int toMonth , String logicalLocationCode,
			String coverTypes);
	
	public Pair<Report, Exception> getECIBCR49Report(String reportStatus, String reportDate);

	public List<String>  getyear();
	
	public List<String> getmonth();

	public Pair<Report, Exception> getECIBWTUR25Report(String coverType, String fromDate, String toDate);
	
	public Pair<Report, Exception> getECIB_MIS_R_08Report(String fromDate, String toDate);



}
