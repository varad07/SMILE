package in.ecgc.smile.erp.reporting.jasper.be.service.ecib;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.stereotype.Service;

import in.ecgc.smile.erp.reporting.jasper.be.model.ecib.EcibInUR04;
import in.ecgc.smile.erp.reporting.jasper.be.model.ecib.EcibInUR16;
import in.ecgc.smile.erp.reporting.jasper.be.model.ecib.EcibRoxbo11;
import in.ecgc.smile.erp.reporting.jasper.be.model.ecib.EcibRoxbo12;
import in.ecgc.smile.erp.reporting.jasper.be.model.ecib.EcibWtUR63;
import in.ecgc.smile.erp.reporting.jasper.be.model.ecib.EcibWtUR64;
import in.ecgc.smile.erp.reporting.jasper.be.model.reports.Report;
import in.ecgc.smile.erp.reporting.jasper.be.repository.common.ReportMetaDataDao;
import in.ecgc.smile.erp.reporting.jasper.be.repository.ecib.EcibDao;
import in.ecgc.smile.erp.reporting.jasper.be.utils.Pair;
import in.ecgc.smile.erp.reporting.jasper.be.utils.ecib.EcibQuery;


@Service
public class EcibServiceImpl implements EcibService {
	
	@Autowired
	private EcibDao ecibDao;
	
	@Autowired
	ReportMetaDataDao reportMetaDataDao;
	
	private static final Class<EcibQuery> QUERY_CLASS = EcibQuery.class;
	
	private static final Logger logger = LoggerFactory.getLogger(EcibServiceImpl.class);

	@Override
	public List<EcibRoxbo11> getListOfCoverTypeExporterMoreThan100Cr(int FromYear, int FromMonth, int ToYear,
			int ToMonth) {
		// TODO Auto-generated method stub
		return ecibDao.getListOfCoverTypeExporterMoreThan100Cr(FromYear, FromMonth, ToYear, ToMonth);
	}

	@Override
	public List<EcibInUR04> getListOfInCoverIssueRegister(String fromDate, String toDate, String coverType) {
		// TODO Auto-generated method stub
		return ecibDao.getListOfInCoverIssueRegister(fromDate, toDate, coverType);
	}
	public List<EcibRoxbo12> getListOfExporterMoreThan100Cr(int FromYear, int FromMonth, int ToYear, int ToMonth) {
		// TODO Auto-generated method stub
		return ecibDao.getListOfExporterMoreThan100Cr(FromYear, FromMonth, ToYear, ToMonth);
	}
	
	public List<EcibInUR16> getListEcibCoverAdjustedDeclaration(int fromYear, int fromMonth, int toYear, int toMonth) {
		// TODO Auto-generated method stub
		return ecibDao.getListEcibCoverAdjustedDeclaration(fromYear, fromMonth, toYear, toMonth);
	}
	
	public List<EcibWtUR63> getListBankwiseRvPremiumReport(int fromYear, int fromMonth, int toYear, int toMonth) {
		// TODO Auto-generated method stub
		return ecibDao.getListBankwiseRvPremiumReport(fromYear, fromMonth, toYear, toMonth);
	}

	@Override
	public List<EcibWtUR63> getListEcibTypewise(int fromYear, int fromMonth, int toYear, int toMonth) {
		// TODO Auto-generated method stub
		return ecibDao.getListEcibTypewise(fromYear, fromMonth, toYear, toMonth);
	}

	@Override
	public List<EcibWtUR63> getListBankwise(int fromYear, int fromMonth, int toYear, int toMonth) {
		// TODO Auto-generated method stub
		return ecibDao.getListBankwise(fromYear, fromMonth, toYear, toMonth);
	}

	@Override
	public List<EcibWtUR64> getListEcgcBranchwisePremiumEarned(int fromYear, int fromMonth, int toYear, int toMonth) {
		// TODO Auto-generated method stub
		return ecibDao.getListEcgcBranchwisePremiumEarned(fromYear, fromMonth, toYear, toMonth);
	}

	@Override
	public List<EcibWtUR64> getListEcibTypewise1(int fromYear, int fromMonth, int toYear, int toMonth) {
		// TODO Auto-generated method stub
		return ecibDao.getListEcibTypewise1(fromYear, fromMonth, toYear, toMonth);
	}

	@Override
	public List<EcibWtUR64> getListBankwise1(int fromYear, int fromMonth, int toYear, int toMonth) {
		// TODO Auto-generated method stub
		return ecibDao.getListBankwise1(fromYear, fromMonth, toYear, toMonth);
	}

	@Override
	public List<String> getAllPolicyTypes() {
		return ecibDao.getAllPolicyTypes();
	}
	
	@Override
	public List<String> getyear() {
		return ecibDao.getyear();
	}
	
	@Override
	public List<String> getmonth() {
		return ecibDao.getmonth();
	}

	@Override
	public Pair<Report, Exception> generateReport(Map<String, String> allRequestParams) {
		final String reportId = getReportId(allRequestParams.get("reportId"), allRequestParams.get("reportStatus"));
		try {

			return reportMetaDataDao.getReportForReportId(reportId, new MapSqlParameterSource(allRequestParams),
					QUERY_CLASS);
		} catch (IllegalArgumentException | NullPointerException | DataAccessException e) {
			e.printStackTrace();
			return new Pair<>(null, e);
		}
	}
	private String getReportId(String id, String reportStatus) {
		return String.format("%s_%s_", id, reportStatus.trim()).toUpperCase();
	}

	@Override
	public Pair<Report, Exception> getECIBWTUR36Report(String reportStatus, int fromYear, int toYear, int fromMonth,int toMonth,
			String logicalLocationCode, String coverTypes) {
		final String reportId = getReportId("ECIB_WT_U_R36", reportStatus);
		try {
			logger.info("Years & Months {} {} {} {}" +fromYear,toYear,fromMonth,toMonth);
			MapSqlParameterSource paramMap = new MapSqlParameterSource()
					.addValue("fromYear", fromYear)
					.addValue("toYear", toYear)
					.addValue("fromMonth", fromMonth)
					.addValue("toMonth", toMonth)
					.addValue("coverTypes", coverTypes)
					.addValue("logicalLocationCode", logicalLocationCode);

			return reportMetaDataDao.getReportForReportId(reportId, paramMap, QUERY_CLASS);
		} catch (IllegalArgumentException | NullPointerException | DataAccessException e) {
			e.printStackTrace();
			return new Pair<>(null, e);
		} catch (Exception e) {
			e.printStackTrace();
			return new Pair<>(null, e);
		}
	}

	@Override
	public Pair<Report, Exception> getECIBCR49Report(String reportStatus, String reportDate) {
		final String reportId = getReportId("ECIB_C_R49", reportStatus);
		try {
			logger.info("Report Date {}" +reportDate);
			MapSqlParameterSource paramMap = new MapSqlParameterSource()
					.addValue("reportDate", reportDate);

			return reportMetaDataDao.getReportForReportId(reportId, paramMap, QUERY_CLASS);
		} catch (IllegalArgumentException | NullPointerException | DataAccessException e) {
			e.printStackTrace();
			return new Pair<>(null, e);
		} catch (Exception e) {
			e.printStackTrace();
			return new Pair<>(null, e);
		}
	}

	@Override
	public Pair<Report, Exception> getECIBWTUR25Report(String coverType, String fromDate, String toDate) {
		
			logger.info("----Inside daoImple---");

			logger.info("From Date" + fromDate + "To Date" + toDate +  "Cover Type" + coverType );
			
			final String reportId = getReportId("ECIB_WT_U_R25", "A");
			try {

				MapSqlParameterSource paramMap = new MapSqlParameterSource()
						.addValue("coverType", coverType)
						.addValue("fromDate", fromDate)
						.addValue("toDate", toDate);
				

				return reportMetaDataDao.getReportForReportId(reportId, paramMap, QUERY_CLASS);
			} catch (IllegalArgumentException | NullPointerException | DataAccessException e) {
				logger.info("----Inside getECIBWTUR25Report exception---");
				e.printStackTrace();
				return new Pair<>(null, e);
			}catch (Exception e) {
				logger.info("----Inside getECIBWTUR25Report parent Exception---");
				e.printStackTrace();
				return new Pair<>(null, e);
			}
		}
	
	@Override
	public Pair<Report, Exception> getECIB_MIS_R_08Report(String fromDate, String toDate) {
			logger.info("----Inside getECIB_MIS_R_08Report---");
		
		final String reportId = getReportId("ECIB_MIS_R_08", "A");

		try {

			MapSqlParameterSource paramMap = new MapSqlParameterSource()
					.addValue("fromDate", fromDate)
					.addValue("toDate", toDate);
			return reportMetaDataDao.getReportForReportId(reportId, paramMap, QUERY_CLASS);
		} catch (IllegalArgumentException | NullPointerException | DataAccessException e) {
			return new Pair<>(null, e);
		}
	}

}


