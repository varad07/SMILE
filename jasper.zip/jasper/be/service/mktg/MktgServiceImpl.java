package in.ecgc.smile.erp.reporting.jasper.be.service.mktg;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ch.qos.logback.classic.Logger;
import in.ecgc.smile.erp.reporting.jasper.be.model.mktg.FormIXAgencyOrgStmt;
import in.ecgc.smile.erp.reporting.jasper.be.model.mktg.MKTIDRAI07;
import in.ecgc.smile.erp.reporting.jasper.be.model.mktg.MKTIRDAI02;
import in.ecgc.smile.erp.reporting.jasper.be.model.mktg.MKTIRDAI05Model;
import in.ecgc.smile.erp.reporting.jasper.be.repository.mktg.MktgDao;

@Service
public class MktgServiceImpl implements MktgService{
	
	@Autowired
	private MktgDao mktgDao;

	@Override
	public List<FormIXAgencyOrgStmt> getListMktIDRAI04(String fromDate, String toDate) {
		
		return mktgDao.getListMktIDRAI04(fromDate, toDate);
	}

	@Override
	public List<MKTIRDAI05Model> getListMktIDRAI05(String fromDate, String toDate) {
		
		return mktgDao.getListMktIDRAI05(fromDate, toDate);
	}

	@Override
	public List<MKTIRDAI02> getListMktIDRAI02(String fromDate, String toDate) {	
		
		return mktgDao.getListMktIDRAI02(fromDate, toDate);
	}

	@Override
	public List<MKTIDRAI07> getListMktIDRAI07(String fromDate, String toDate) {
		
		return mktgDao.getListMktIDRAI07(fromDate, toDate);
	}

}
