package in.ecgc.smile.erp.reporting.jasper.be.service.pebp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.stereotype.Service;

import in.ecgc.smile.erp.reporting.jasper.be.repository.common.ReportMetaDataDao;
import in.ecgc.smile.erp.reporting.jasper.be.controller.pebp.PebPController;
import in.ecgc.smile.erp.reporting.jasper.be.model.reports.Report;
import in.ecgc.smile.erp.reporting.jasper.be.utils.Pair;
import in.ecgc.smile.erp.reporting.jasper.be.utils.bud.BudQuery;
import in.ecgc.smile.erp.reporting.jasper.be.utils.pebp.PebPQuery;

@Service
public class PebPServiceImpl implements PebPService{
	
	private static final Class<PebPQuery> QUERY_CLASS = PebPQuery.class;
	
	private static final Logger logger = LoggerFactory.getLogger(PebPServiceImpl.class);
	
	@Autowired
	ReportMetaDataDao reportMetaDataDao;
		
	@Override
	public Pair<Report, Exception> getPEBP02Report(String fromDate, String toDate, String country,
			String coverType) {
		logger.info("----Inside daoImple---");

		logger.info("From Date" + fromDate + "To Date" + toDate + "country" + country + "Cover Type" + coverType );
		
		final String reportId = getReportId("PEB_P_02", "A");
		try {

			MapSqlParameterSource paramMap = new MapSqlParameterSource()
					.addValue("fromDate", fromDate)
					.addValue("toDate", toDate)
					.addValue("country", country)
					.addValue("coverType", coverType);
			

			return reportMetaDataDao.getReportForReportId(reportId, paramMap, QUERY_CLASS);
		} catch (IllegalArgumentException | NullPointerException | DataAccessException e) {
			logger.info("----Inside getPEBP02Report exception---");
			e.printStackTrace();
			return new Pair<>(null, e);
		}catch (Exception e) {
			logger.info("----Inside getPEBP02Report parent Exception---");
			e.printStackTrace();
			return new Pair<>(null, e);
		}
	}

	

	@Override
	public Pair<Report, Exception> getPEBP03Report(String country,String exporterCode) {
		final String reportId = getReportId("PEB_P_03", "A");
		try {

			MapSqlParameterSource paramMap = new MapSqlParameterSource()
					.addValue("country", country)
					.addValue("exporterCode", exporterCode);

			return reportMetaDataDao.getReportForReportId(reportId, paramMap, QUERY_CLASS);
		} catch (IllegalArgumentException | NullPointerException | DataAccessException e) {
			e.printStackTrace();
			return new Pair<>(null, e);
		}
	}
	
	private String getReportId(String id, String reportStatus) {
		return String.format("%s_%s_", id, reportStatus.trim()).toUpperCase();
	}

}
