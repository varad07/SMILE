package in.ecgc.smile.erp.reporting.jasper.be.service.pebp;

import in.ecgc.smile.erp.reporting.jasper.be.model.reports.Report;
import in.ecgc.smile.erp.reporting.jasper.be.utils.Pair;

public interface PebPService {
	
	public Pair<Report, Exception> getPEBP02Report(String fromDate, String toDate, String country,
			String coverType);
	
	public Pair<Report, Exception> getPEBP03Report(String country,String exporterCode);

}
