package in.ecgc.smile.erp.reporting.jasper.be.service.grv;

import java.util.List;

import in.ecgc.smile.erp.reporting.jasper.be.model.grv.Grv_R01;
import in.ecgc.smile.erp.reporting.jasper.be.model.grv.PragatiReport;


public interface GrvService {

	public List<PragatiReport> getPragatiReport(int month, int year);
	
	public List<Grv_R01> getGrv_R01(int year);
	
}
