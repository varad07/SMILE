package in.ecgc.smile.erp.reporting.jasper.be.service.grv;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.ecgc.smile.erp.reporting.jasper.be.model.grv.Grv_R01;
import in.ecgc.smile.erp.reporting.jasper.be.model.grv.PragatiReport;
import in.ecgc.smile.erp.reporting.jasper.be.repository.grv.GrvDao;

@Service
public class GrvServiceImpl implements GrvService{
	
	@Autowired
	private GrvDao grvDao;

	@Override
	public List<PragatiReport> getPragatiReport(int month, int year) {
		// TODO Auto-generated method stub
		return grvDao.getPragatiReport(month, year);
	}

	@Override
	public List<Grv_R01> getGrv_R01(int year) {
		// TODO Auto-generated method stub
		return grvDao.getGrv_R01(year);
	}

}
