package in.ecgc.smile.erp.reporting.jasper.be.service.poluw;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.stereotype.Service;

import in.ecgc.smile.erp.reporting.jasper.be.model.poluw.RegionBranch;
import in.ecgc.smile.erp.reporting.jasper.be.model.poluw.poluw_011;
import in.ecgc.smile.erp.reporting.jasper.be.model.poluw.poluw_013;
import in.ecgc.smile.erp.reporting.jasper.be.model.reports.Report;
import in.ecgc.smile.erp.reporting.jasper.be.repository.Poluw.PoluwDao;
import in.ecgc.smile.erp.reporting.jasper.be.repository.common.ReportMetaDataDao;
import in.ecgc.smile.erp.reporting.jasper.be.utils.Pair;
import in.ecgc.smile.erp.reporting.jasper.be.utils.poluw.PoluwQuery;

@Service
public class PoluwServiceImpl implements PoluwService {

	@Autowired
	PoluwDao poluwDao;

	@Autowired
	ReportMetaDataDao reportMetaDataDao;

	private static final Class<PoluwQuery> QUERY_CLASS = PoluwQuery.class;

	private static final Logger log = LoggerFactory.getLogger(PoluwServiceImpl.class);

	@Override
	public List<String> getAllPolicyTypes() {
		log.info("inside the get all policy types");
		return poluwDao.getAllPolicyTypes();
	}

	@Override
	public List<poluw_011> getPremiumAdjusted(List<String> polTypeList, LocalDate fromDt, LocalDate toDt) {
		return poluwDao.getPremiumAdjusted(polTypeList, fromDt, toDt);

	}

	@Override
	public List<poluw_013> getExpoBasedRiskValPremiumAdjusted(LocalDate fromDt, LocalDate toDt) {
		return poluwDao.getExpoBasedRiskValPremiumAdjusted(fromDt, toDt);
	}

	@Override
	public List<String> getRegion() {
		return poluwDao.getRegion();
	}

	@Override
	public Pair<Report, Exception> getPOLSTAUW12Report(String fromDate, String toDate, String region,
			String policyType) {
		log.info("----Inside daoImple---");

		log.info("From Date" + fromDate + "To Date" + toDate + "region" + region + "Policy Type" + policyType);

		final String reportId = getReportId("POL_ST_A_UW_012", "A");
		try {

			MapSqlParameterSource paramMap = new MapSqlParameterSource().addValue("fromDate", fromDate)
					.addValue("toDate", toDate).addValue("region", region).addValue("policyType", policyType);

			return reportMetaDataDao.getReportForReportId(reportId, paramMap, QUERY_CLASS);
		} catch (IllegalArgumentException | NullPointerException | DataAccessException e) {
			log.info("----Inside getPOLSTAUW12Report exception---");
			e.printStackTrace();
			return new Pair<>(null, e);
		} catch (Exception e) {
			log.info("----Inside getPOLSTAUW12Report parent Exception---");
			e.printStackTrace();
			return new Pair<>(null, e);
		}
	}

	private String getReportId(String id, String reportStatus) {
		return String.format("%s_%s_", id, reportStatus.trim()).toUpperCase();
	}

	@Override
	public Pair<Report, Exception> getPOLUW19Report(String fromDt, String toDt) {
		log.info("----Inside daoImple---");

		log.info("From Date" + fromDt + "To Date" + toDt);
		
		final String reportId = getReportId("POL_ST_A_UW_019", "A");
		try {

			MapSqlParameterSource paramMap = new MapSqlParameterSource()
					.addValue("fromDate", fromDt)
					.addValue("toDate", toDt);
		

			return reportMetaDataDao.getReportForReportId(reportId, paramMap, QUERY_CLASS);
		} catch (IllegalArgumentException | NullPointerException | DataAccessException e) {
			log.info("----Inside getPOLUW19Report exception---");
			e.printStackTrace();
			return new Pair<>(null, e);
		}catch (Exception e) {
			log.info("----Inside getPOLUW19Report parent Exception---");
			e.printStackTrace();
			return new Pair<>(null, e);
		}
	}

	@Override
	public Pair<Report, Exception> getPOL_ST_A_UW_10(String inputDate) {
		log.info("----Inside getPOL_ST_A_UW_10DaoImpl---");
		
		final String reportId = getReportId("POL_ST_A_UW_010", "A");

		try {

			MapSqlParameterSource paramMap = new MapSqlParameterSource()
					.addValue("inputDate", inputDate);
			return reportMetaDataDao.getReportForReportId(reportId, paramMap, QUERY_CLASS);
		} catch (IllegalArgumentException | NullPointerException | DataAccessException e) {
			return new Pair<>(null, e);
		}
	}

	@Override
	public List<RegionBranch> getRegionBranchInfo() {
		
		return poluwDao.getRegionBranchInfo();
		
	}

	@Override
	public Pair<Report, Exception> getPOL_ST_A_UW_019(String fromDate, String toDate, String reportStatus,
			String input) {
log.info("----Inside getPOL_ST_A_UW_19DaoImpl---");
		
		final String reportId = getReportId("POL_ST_A_UW_019", reportStatus);
		
		log.info("----Inside getPOL_ST_A_UW_19DaoImpl---{}",reportId);

		try {

			MapSqlParameterSource paramMap = new MapSqlParameterSource()
					.addValue("fromDate", fromDate)
					.addValue("toDate", toDate)
					.addValue("input", input);
			return reportMetaDataDao.getReportForReportId(reportId, paramMap, QUERY_CLASS);
		} catch (IllegalArgumentException | NullPointerException | DataAccessException e) {
			return new Pair<>(null, e);
		}
	}

}
