package in.ecgc.smile.erp.reporting.jasper.be.service.poluw;

import java.time.LocalDate;
import java.util.List;

import in.ecgc.smile.erp.reporting.jasper.be.model.poluw.RegionBranch;
import in.ecgc.smile.erp.reporting.jasper.be.model.poluw.poluw_011;
import in.ecgc.smile.erp.reporting.jasper.be.model.poluw.poluw_013;
import in.ecgc.smile.erp.reporting.jasper.be.model.reports.Report;
import in.ecgc.smile.erp.reporting.jasper.be.utils.Pair;

public interface PoluwService {

	public List<String> getAllPolicyTypes();

	public List<poluw_011> getPremiumAdjusted(List<String> polTypeList, LocalDate fromDt, LocalDate toDt);

	public List<poluw_013> getExpoBasedRiskValPremiumAdjusted(LocalDate fromDt, LocalDate toDt);

	public List<String>  getRegion();

	public  Pair<Report, Exception> getPOLSTAUW12Report(String fromDate, String toDate, String region, String policyType);

	public Pair<Report, Exception> getPOLUW19Report(String fromDt, String toDt);

	public Pair<Report, Exception> getPOL_ST_A_UW_10(String inputDate);

	public List<RegionBranch> getRegionBranchInfo();

	public Pair<Report, Exception> getPOL_ST_A_UW_019(String fromDate, String toDate, String reportStatus, String input);
	
	
}
