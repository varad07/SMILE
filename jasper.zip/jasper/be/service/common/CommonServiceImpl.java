package in.ecgc.smile.erp.reporting.jasper.be.service.common;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.ecgc.smile.erp.reporting.jasper.be.repository.common.CommonMasterDao;

@Service
public class CommonServiceImpl implements CommonService {

    @Autowired
    CommonMasterDao commonMasterDao;

    @Override
    public List<Map<String,Object>> getAllLogicalLocationCodes() {
        return commonMasterDao.getAllLogicalLocCd();
    }

    @Override
    public List<Map<String,Object>> getAllCountries() {
        return commonMasterDao.getAllCountryName();
    }

}
