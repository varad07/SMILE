package in.ecgc.smile.erp.reporting.jasper.be.service.common;

import java.util.List;
import java.util.Map;

public interface CommonService {
    public List<Map<String,Object>> getAllLogicalLocationCodes();

    public List<Map<String,Object>> getAllCountries();
}
