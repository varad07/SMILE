package in.ecgc.smile.erp.reporting.jasper.be.service.cud;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.ecgc.smile.erp.reporting.jasper.be.model.cud.CUDR09;
import in.ecgc.smile.erp.reporting.jasper.be.model.cud.CUDR10;
import in.ecgc.smile.erp.reporting.jasper.be.repository.cud.CudDao;

@Service
public class CudServiceImpl implements CudService{
	
	@Autowired
	private CudDao cudDao;

	@Override
	public List<CUDR09> getListCudR09(String fromDate, String toDate) {
		// TODO Auto-generated method stub
		return cudDao.getListCudR09(fromDate, toDate);
	}

	@Override
	public List<CUDR10> getListCudR10(String fromDate, String toDate) {
		
		return cudDao.getListCudR10(fromDate, toDate);
	}

}
