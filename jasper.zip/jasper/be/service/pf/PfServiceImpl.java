package in.ecgc.smile.erp.reporting.jasper.be.service.pf;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.TrialBalanceReport;
import in.ecgc.smile.erp.reporting.jasper.be.model.pf.Pf_r02;
import in.ecgc.smile.erp.reporting.jasper.be.model.pf.Pf_r07;
import in.ecgc.smile.erp.reporting.jasper.be.repository.pf.pfDao;

@Service
public class PfServiceImpl implements PfService{
	
	@Autowired
	pfDao PfDao;
	

	@Override
	public List<Pf_r02> getListPf_r02(String personal_ledger_code) {
		System.out.println("pl code:::"+personal_ledger_code);
		return PfDao.getListPf_r02(personal_ledger_code);
	}


	@Override
	public List<Pf_r07> getActuarialValuationReport_r07() {
		System.out.println("p07 service impl");
		return PfDao.getActuarialValuationReport_r07();
	}


	@Override
	public TrialBalanceReport getpfTrialBalacneAllLoc(String inputDate, Boolean isNil) {
		Integer txnCount = PfDao.generateTrialBalanceByDate(inputDate);
		System.err.println("Trial Balance Count : "+ txnCount);
		
		return  PfDao.getpfTrialBalacneAllLoc(inputDate, isNil);
	}


	@Override
	public Integer generateTrialBalanceByDate(String inputDate) {
		return PfDao.generateTrialBalanceByDate(inputDate);
	}

}
