package in.ecgc.smile.erp.reporting.jasper.be.service.payroll;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.ecgc.smile.erp.reporting.jasper.be.repository.common.ReportMetaDataDao;
import in.ecgc.smile.erp.reporting.jasper.be.repository.payroll.PayrollDao;

@Service
public class PayrollServiceImpl implements PayrollService {
	
	
	@Autowired
	private PayrollDao payrollDao;
	
	@Autowired
	ReportMetaDataDao reportMetaDataDao;
		
	private static final Logger logger = LoggerFactory.getLogger(PayrollServiceImpl.class);

}
