package in.ecgc.smile.erp.reporting.jasper.be.service.payroll;

public interface PayrollService {

}
