package in.ecgc.smile.erp.reporting.jasper.be.service.bud;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.stereotype.Service;

import in.ecgc.smile.erp.reporting.jasper.be.model.bud.BudR02;
import in.ecgc.smile.erp.reporting.jasper.be.model.bud.BudR09;
import in.ecgc.smile.erp.reporting.jasper.be.model.bud.BudR16;
import in.ecgc.smile.erp.reporting.jasper.be.model.bud.BudR17;
import in.ecgc.smile.erp.reporting.jasper.be.model.bud.BudR18;
import in.ecgc.smile.erp.reporting.jasper.be.model.bud.BudR20;
import in.ecgc.smile.erp.reporting.jasper.be.model.bud.BudR21;
import in.ecgc.smile.erp.reporting.jasper.be.model.bud.BudR23;
import in.ecgc.smile.erp.reporting.jasper.be.model.bud.BudR40;
import in.ecgc.smile.erp.reporting.jasper.be.model.bud.BudR48_1;
import in.ecgc.smile.erp.reporting.jasper.be.model.bud.BudR48_2;
import in.ecgc.smile.erp.reporting.jasper.be.model.bud.BudR49;
import in.ecgc.smile.erp.reporting.jasper.be.model.bud.BudR49_1;
import in.ecgc.smile.erp.reporting.jasper.be.model.reports.Report;
import in.ecgc.smile.erp.reporting.jasper.be.repository.bud.BudDao;
import in.ecgc.smile.erp.reporting.jasper.be.repository.common.ReportMetaDataDao;
import in.ecgc.smile.erp.reporting.jasper.be.utils.Pair;
import in.ecgc.smile.erp.reporting.jasper.be.utils.bud.BudQueries;
import in.ecgc.smile.erp.reporting.jasper.be.utils.bud.BudQuery;

@Service
public class BudServiceImpl implements BudService {

	private static final Class<BudQuery> QUERY_CLASS = BudQuery.class;

	@Autowired
	private BudDao budDao;

	@Autowired
	ReportMetaDataDao reportMetaDataDao;

	@Override
	public List<BudR21> getListBUDR21(String lastUpdatedDateFrom, String lastUpdatedDateTo) {
		// TODO Auto-generated method stub
		return budDao.getListBudR21(lastUpdatedDateFrom, lastUpdatedDateTo);
	}

	@Override
	public List<BudR49> getListBUDR49(String fromDate, String toDate) {
		// TODO Auto-generated method stub
		return budDao.getListBudR49(fromDate, toDate);
	}

	@Override
	public List<BudR02> getListBUDR02(String fromDate, String toDate) {
		// TODO Auto-generated method stub
		return budDao.getListBudR02(fromDate, toDate);
	}

	@Override
	public List<BudR49_1> getListBUDR49_1(String fromDate, String toDate) {
		// TODO Auto-generated method stub
		return budDao.getListBudR49_1(fromDate, toDate);
	}

	@Override
	public List<BudR16> getListBUDR16(String fromDate, String toDate) {
		// TODO Auto-generated method stub
		return budDao.getListBudR16(fromDate, toDate);
	}

	@Override
	public List<BudR17> getListBUDR17(String fromDate, String toDate) {
		// TODO Auto-generated method stub
		return budDao.getListBudR17(fromDate, toDate);
	}

	@Override
	public List<BudR18> getListBUDR18(String fromDate, String toDate) {
		// TODO Auto-generated method stub
		return budDao.getListBudR18(fromDate, toDate);
	}

	@Override
	public List<BudR18> getListBUDR18_1(String fromDate, String toDate) {
		// TODO Auto-generated method stub
		return budDao.getListBudR18_1(fromDate, toDate);
	}

	@Override
	public List<BudR20> getListBUDR20(String fromDate, String toDate) {
		// TODO Auto-generated method stub
		return budDao.getListBudR20(fromDate, toDate);
	}

	@Override
	public List<BudR20> getListBUDR20_1(String fromDate, String toDate) {
		// TODO Auto-generated method stub
		return budDao.getListBudR20_1(fromDate, toDate);
	}

	public List<BudR23> getListBUDR23(String fromDate, String toDate, String claType) {
		// TODO Auto-generated method stub
		return budDao.getListBudR23(fromDate, toDate, claType);
	}

	@Override
	public List<BudR09> getListBUDR09(String fromDate, String toDate, String reportStatus) {
		// TODO Auto-generated method stub
		return budDao.getListBudR09(fromDate, toDate, reportStatus);

	}

	@Override
	public List<BudR40> getListBUDR40(String fromDate, String toDate) {
		// TODO Auto-generated method stub
		return budDao.getListBudR40(fromDate, toDate);
	}

	@Override
	public List<BudR48_1> getListBUDR48_1(String fromDate, String toDate, String reportStatus) {
		// TODO Auto-generated method stub
		return budDao.getListBudR48_1(fromDate, toDate, reportStatus);
	}

	@Override
	public List<BudR48_2> getListBUDR48_2(String fromDate, String toDate, String reportStatus) {
		// TODO Auto-generated method stub
		return budDao.getListBudR48_2(fromDate, toDate, reportStatus);
	}

	@Override
	public List<String> getAllBudCellCodes() {
		return budDao.getAllBudCellCodes();
	}

	@Override
	public Pair<Report, Exception> getListBudR05(String reportStatus, String fromDate, String toDate,
			String cellCodeFrom,
			String cellCodeTo) {

		reportStatus = reportStatus.trim().toUpperCase();

		final String reportId = getReportId("BUD_R05", reportStatus);

		try {

			MapSqlParameterSource paramMap = new MapSqlParameterSource()
					.addValue("fromDate", fromDate)
					.addValue("toDate", toDate)
					.addValue("cellCodeFrom", Integer.valueOf(cellCodeFrom))
					.addValue("cellCodeTo", Integer.valueOf(cellCodeTo));

			return reportMetaDataDao.getReportForReportId(reportId, paramMap, QUERY_CLASS);
		} catch (IllegalArgumentException | NullPointerException | DataAccessException e) {
			return new Pair<>(null, e);
		}
	}

	@Override
	public Pair<Report, Exception> getListBudR67(String amountFrom, String amountTo, String cellNumber,
			String countryName, String reportStatus) {

		final String reportId = getReportId("BUD_R67", reportStatus);

		try {

			MapSqlParameterSource paramMap = new MapSqlParameterSource()
					.addValue("amountFrom", Double.valueOf(amountFrom))
					.addValue("amountTo", Double.valueOf(amountTo))
					.addValue("cellNumber", cellNumber)
					.addValue("countryName", countryName);

			return reportMetaDataDao.getReportForReportId(reportId, paramMap, QUERY_CLASS);
		} catch (IllegalArgumentException | NullPointerException | DataAccessException e) {
			return new Pair<>(null, e);
		}
	}

	@Override
	public Pair<Report, Exception> getBudR04(String reportStatus, String fromDate, String toDate, String cellCodeFrom,
			String cellCodeTo, String logicalLocationCode) {
		reportStatus = reportStatus.trim().toUpperCase();

		final String reportId = getReportId("BUD_R04", reportStatus);
		try {

			MapSqlParameterSource paramMap = new MapSqlParameterSource()
					.addValue("fromDate", fromDate)
					.addValue("toDate", toDate)
					.addValue("cellCodeFrom", Integer.valueOf(cellCodeFrom))
					.addValue("cellCodeTo", Integer.valueOf(cellCodeTo))
					.addValue("logicalLocationCode", logicalLocationCode);

			Pair<Report, Exception> result = reportMetaDataDao.getReportForReportId(reportId, paramMap, QUERY_CLASS);
			if (result.second() != null) {
				return new Pair<>(null, result.second());
			}

			return processBUD04Summary(result);

		} catch (IllegalArgumentException | NullPointerException | DataAccessException e) {
			e.printStackTrace();
			return new Pair<>(null, e);
		} catch (Exception e) {
			e.printStackTrace();
			return new Pair<>(null, e);
		}

	}

	private Pair<Report, Exception> processBUD04Summary(Pair<Report, Exception> result) {
		List<Map<String, Object>> data = new ArrayList<>();
		final String CLA_RECD_DT_IWD_DT = "Cla Recd Dt Iwd dt";

		final String REPORT_RECEIVED_DATE = "Report Received Date";

		final String REPORT_STATUS = "Report Status";
		for (int i = 0; i < result.first().getTables().size(); i++) {
			final String mappingKey = BUDR04Helper.getMappingKey(i);
			if (i == 0 || i == 5)
				data = result.first().getTables().get(i).getData();
			else if (i == 3) {

				BUDR04Helper.createSummaryTable(result, data.stream().filter(x -> x.get(mappingKey) != null)
						.collect(Collectors.groupingBy(map -> map.get(mappingKey), Collectors
								.mapping(
										map -> {
											HashMap<String, Object> m = new HashMap<>();
											m.put(REPORT_STATUS, map.get(REPORT_STATUS));
											m.put(REPORT_RECEIVED_DATE, map.get(REPORT_RECEIVED_DATE));
											m.put(CLA_RECD_DT_IWD_DT, map.get(CLA_RECD_DT_IWD_DT));
											return m;
										},
										Collectors.toList()))),
						i);

			} else if (i == 1 || i == 6 || i == 2 || i == 7 || i == 4 || i == 8) {

				BUDR04Helper.createSummaryTable(result, data.stream().filter(x -> x.get(mappingKey) != null)
						.collect(Collectors.groupingBy(map -> map.get(mappingKey), Collectors
								.mapping(map -> {
									HashMap<String, Object> m = new HashMap<>();
									m.put(REPORT_STATUS, map.get(REPORT_STATUS));
									return m;
								}, Collectors.toList()))),
						i);

			}

		}

		return result;
	}

	@Override
	public Pair<Report, Exception> getBUD48Report(String reportStatus, String fromDate, String toDate,
			String countryName, String decisionStatus, String defaultStat) {
		final String reportId = getReportId("BUD_R48", reportStatus);
		try {

			MapSqlParameterSource paramMap = new MapSqlParameterSource()
					.addValue("fromDate", fromDate)
					.addValue("toDate", toDate)
					.addValue("countryName", countryName)
					.addValue("decisionStatus", decisionStatus)
					.addValue("defaultStat", defaultStat);

			return reportMetaDataDao.getReportForReportId(reportId, paramMap, QUERY_CLASS);
		} catch (IllegalArgumentException | NullPointerException | DataAccessException e) {
			e.printStackTrace();
			return new Pair<>(null, e);
		} catch (Exception e) {
			e.printStackTrace();
			return new Pair<>(null, e);
		}
	}

	@Override
	public Pair<Report, Exception> getBUD08Report(String reportStatus, String fromDate, String toDate,
			String proposalStatus, String logicalLocationCode, String cellCode) {
		final String reportId = getReportId("BUD_R08", reportStatus);
		try {

			MapSqlParameterSource paramMap = new MapSqlParameterSource()
					.addValue("fromDate", fromDate)
					.addValue("toDate", toDate)
					.addValue("proposalStatus", proposalStatus)
					.addValue("cellCode", cellCode)
					.addValue("logicalLocationCode", logicalLocationCode);

			return reportMetaDataDao.getReportForReportId(reportId, paramMap, QUERY_CLASS);
		} catch (IllegalArgumentException | NullPointerException | DataAccessException e) {
			e.printStackTrace();
			return new Pair<>(null, e);
		} catch (Exception e) {
			e.printStackTrace();
			return new Pair<>(null, e);
		}
	}

	@Override
	public Pair<Report, Exception> getBUD13Report(String reportStatus, String fromDate, String toDate) {
		final String reportId = getReportId("BUD_R13", reportStatus);
		try {
			MapSqlParameterSource paramMap = new MapSqlParameterSource()
					.addValue("fromDate", fromDate)
					.addValue("toDate", toDate);
			return reportMetaDataDao.getReportForReportId(reportId, paramMap, QUERY_CLASS);
		} catch (IllegalArgumentException | NullPointerException | DataAccessException e) {
			e.printStackTrace();
			return new Pair<>(null, e);
		}
	}

	@Override
	public Pair<Report, Exception> getBUD29Report(String policyNo, String buyerCode, String buyerCountry,
			String fromDate) {
		final String reportId = getReportId("BUD_R29", "A");
		try {

			MapSqlParameterSource paramMap = new MapSqlParameterSource()
					.addValue("policyNo", policyNo)
					.addValue("buyerCode", buyerCode)
					.addValue("buyerCountry", buyerCountry)
					.addValue("fromDate", fromDate);

			return reportMetaDataDao.getReportForReportId(reportId, paramMap, QUERY_CLASS);
		} catch (IllegalArgumentException | NullPointerException | DataAccessException e) {
			e.printStackTrace();
			return new Pair<>(null, e);
		}
	}

	@Override
	public Pair<Report, Exception> getBUD69Report(String reportStatus, String cellCode) {
		final String reportId = getReportId("BUD_R69", reportStatus);
		try {

			MapSqlParameterSource paramMap = new MapSqlParameterSource()
					.addValue("cellCode", cellCode);

			return reportMetaDataDao.getReportForReportId(reportId, paramMap, QUERY_CLASS);
		} catch (IllegalArgumentException | NullPointerException | DataAccessException e) {
			e.printStackTrace();
			return new Pair<>(null, e);
		}
	}

	@Override
	public Pair<Report, Exception> generateBUD59Report(Map<String, Object> allRequestParams) {
		final String reportId = getReportId(String.valueOf(allRequestParams.get("reportId")),
				String.valueOf(allRequestParams.get("reportStatus")));
		try {

			return reportMetaDataDao.getReportForReportId(reportId, new MapSqlParameterSource(allRequestParams),
					QUERY_CLASS);
		} catch (IllegalArgumentException | NullPointerException | DataAccessException e) {
			e.printStackTrace();
			return new Pair<>(null, e);
		}
	}

	@Override
	public Pair<Report, Exception> generateReport(Map<String, String> allRequestParams) {
		final String reportId = getReportId(allRequestParams.get("reportId"), allRequestParams.get("reportStatus"));
		try {

			return reportMetaDataDao.getReportForReportId(reportId, new MapSqlParameterSource(allRequestParams),
					QUERY_CLASS);
		} catch (IllegalArgumentException | NullPointerException | DataAccessException e) {
			e.printStackTrace();
			return new Pair<>(null, e);
		}
	}

	private String getReportId(String id, String reportStatus) {
		return String.format("%s_%s_", id, reportStatus.trim()).toUpperCase();
	}

	@Override
	public List<Map<String, String>> getAllCla144Policies(Map<String, String> queryParams) {

		String query = BudQueries.GET_BUD_CLA144_POLICIES;
		if (queryParams.get("for").equalsIgnoreCase("buyer")) {
			query = BudQueries.GET_BUD_CLA144_BUYERS;
		}

		queryParams.forEach((key, value) -> {
			queryParams.put(key, "%" + value + "%");
		});
		return budDao.getAllCla144Policies(queryParams, query);
	}

	@Override
	public List<Map<String, Object>> getAllActiveApprovedLimits(String coverCatId, String logicalLocationCode) {
		return budDao.getAllActiveApprovedLimits(coverCatId, logicalLocationCode);
	}

	@Override
	public List<Map<String, Object>> getAllActiveApprovedLimitsBuyer(String coverCatId, String logicalLocationCode) {
		return budDao.getAllActiveApprovedLimitsBuyer(coverCatId, logicalLocationCode);
	}

	@Override
	public List<Map<String, Object>> getAllActiveApprovedLimitsBank(String coverCatId, String logicalLocationCode) {
		return budDao.getAllActiveApprovedLimitsBank(coverCatId, logicalLocationCode);
	}

	@Override
	public List<Map<String, Object>> getActiveApprovedLimitsBuyer(String coverCatId, String logicalLocationCode,
			String countryName) {
		return budDao.getActiveApprovedLimitsBuyer(coverCatId, logicalLocationCode, countryName);
	}

	@Override
	public List<Map<String, Object>> getActiveApprovedLimitsBank(String coverCatId, String logicalLocationCode,
			String countryName) {
		return budDao.getActiveApprovedLimitsBank(coverCatId, logicalLocationCode, countryName);
	}

	private static class BUDR04Helper {

		private static final String CLA_RECD_DT_IWD_DT = "Cla Recd Dt Iwd dt";

		private static final String REPORT_RECEIVED_DATE = "Report Received Date";

		private static final String REPORT_STATUS = "Report Status";

		public static void createSummaryTable(Pair<Report, Exception> result, Map<Object, List<Object>> groupedData,
				int index) {
			List<Map<String, Object>> list = new ArrayList<>();
			Map<Integer, String> keys = getKeyMap();

			if (groupedData.isEmpty()) {
				return;
			}

			extractedTableData(result.first().getTables().get(index).getData().get(0), groupedData, index, list, keys);

			result.first().getTables().get(index).setData(list);

		}

		private static void extractedTableData(Map<String, Object> map, Map<Object, List<Object>> groupedData,
				int index,
				List<Map<String, Object>> list, Map<Integer, String> keys) {
			for (Map.Entry<Object, List<Object>> entry : groupedData.entrySet()) {

				Map<String, Object> temp = new LinkedHashMap<>(map);
				temp.replaceAll((key, val) -> val == null ? 0 : val);
				temp.put(keys.get(index), entry.getKey());

				for (Object val : entry.getValue()) {
					@SuppressWarnings({ "rawtypes", "unchecked" })
					Map<String, Object> values = Collections.unmodifiableMap((Map) val);

					String status = String.valueOf(values.get(REPORT_STATUS)).toUpperCase();

					if (index != 3) {
						String key = "Total Pending";
						incrementKeyCount(temp, key);
					}

					String key = getKey(index, String.valueOf(values.get(CLA_RECD_DT_IWD_DT)),
							String.valueOf(values.get(REPORT_RECEIVED_DATE)), status);

					incrementKeyCount(temp, key);
				}
				list.add(temp);

			}
		}

		private static void incrementKeyCount(Map<String, Object> temp, String key) {
			temp.put(key, Integer.valueOf(
					String.valueOf(
							temp.get(key) == null ? "0" : temp.getOrDefault(key, 0)))
					+ 1);
		}

		private static String getKey(int index, String claInwdDate, String reportRecivedDate, String status) {
			String key = "";
			switch (status) {
				case "RECD":
					key = index == 3 ? getKeyString(reportRecivedDate, 3, 5, status)
							: "Report Called Received But Pending For Action";
					break;
				case "PEND":
					key = index == 3 ? getKeyString(claInwdDate, 10, 15, status)
							: "Report Called But Not Received";
					break;

				default:
					key = "Report Not Called";
					break;

			}
			return key;
		}

		private static String getKeyString(String date, int lower, int higher, String status) {
			String key;
			StringBuilder buffer = new StringBuilder();
			buffer.append("Pending For ");
			String days = " Days";

			LocalDateTime now = LocalDateTime.now(ZoneId.of(ZoneId.SHORT_IDS.get("IST")));
			LocalDateTime fromDate = LocalDate.parse(date, DateTimeFormatter.ofPattern("dd-MM-yyyy")).atTime(0, 0, 0);

			long diff = Duration.between(fromDate, now).toDays();

			String moreThan = "More Than ";
			if (diff > higher) {
				buffer.append(moreThan).append(higher).append(days);
			} else if (diff > lower) {
				buffer.append(moreThan).append(lower).append("Days Up to ").append(higher).append(days);
			} else {
				buffer.append("Up to ").append(lower).append(days);
			}

			if (status.equalsIgnoreCase("RECD")) {
				buffer.append(" From Report Received Date");
			} else {
				buffer.append(" From Inward Date");
			}
			key = buffer.toString();

			return key;
		}

		private static Map<Integer, String> getKeyMap() {
			String cellWise = "Cell Wise";
			Map<Integer, String> keys = new HashMap<>();
			keys.put(1, "Branch");
			keys.put(2, cellWise);
			keys.put(3, cellWise);
			keys.put(4, "Country Wise");
			keys.put(6, "Branch");
			keys.put(7, cellWise);
			keys.put(8, "Country Wise");
			return Collections.unmodifiableMap(keys);
		}

		private static String getMappingKey(int i) {
			Map<Integer, String> keys = new HashMap<>();
			keys.put(1, "Branch");
			keys.put(2, "Cell No");
			keys.put(3, "Cell No");
			keys.put(4, "Buyer Country");
			keys.put(6, "Branch");
			keys.put(7, "Cell No");
			keys.put(8, "Buyer Country");
			return keys.get(i);
		}
	}
}
