package in.ecgc.smile.erp.reporting.jasper.be.service.bud;

import java.util.List;
import java.util.Map;

import in.ecgc.smile.erp.reporting.jasper.be.model.bud.BudR02;
import in.ecgc.smile.erp.reporting.jasper.be.model.bud.BudR09;
import in.ecgc.smile.erp.reporting.jasper.be.model.bud.BudR16;
import in.ecgc.smile.erp.reporting.jasper.be.model.bud.BudR17;
import in.ecgc.smile.erp.reporting.jasper.be.model.bud.BudR18;
import in.ecgc.smile.erp.reporting.jasper.be.model.bud.BudR20;
import in.ecgc.smile.erp.reporting.jasper.be.model.bud.BudR21;
import in.ecgc.smile.erp.reporting.jasper.be.model.bud.BudR23;
import in.ecgc.smile.erp.reporting.jasper.be.model.bud.BudR40;
import in.ecgc.smile.erp.reporting.jasper.be.model.bud.BudR48_1;
import in.ecgc.smile.erp.reporting.jasper.be.model.bud.BudR48_2;
import in.ecgc.smile.erp.reporting.jasper.be.model.bud.BudR49;
import in.ecgc.smile.erp.reporting.jasper.be.model.bud.BudR49_1;
import in.ecgc.smile.erp.reporting.jasper.be.model.reports.Report;
import in.ecgc.smile.erp.reporting.jasper.be.utils.Pair;

public interface BudService {

	List<BudR21> getListBUDR21(String lastUpdatedDateFrom, String lastUpdatedDateTo);

	List<BudR49> getListBUDR49(String fromDate, String toDate);

	List<BudR02> getListBUDR02(String fromDate, String toDate);

	List<BudR49_1> getListBUDR49_1(String fromDate, String toDate);

	List<BudR16> getListBUDR16(String fromDate, String toDate);

	List<BudR17> getListBUDR17(String fromDate, String toDate);

	List<BudR18> getListBUDR18(String fromDate, String toDate);

	List<BudR18> getListBUDR18_1(String fromDate, String toDate);

	List<BudR20> getListBUDR20(String fromDate, String toDate);

	List<BudR20> getListBUDR20_1(String fromDate, String toDate);

	List<BudR23> getListBUDR23(String fromDate, String toDate, String claType);

	List<BudR09> getListBUDR09(String fromDate, String toDate, String reportStatus);

	List<BudR40> getListBUDR40(String fromDate, String toDate);

	List<BudR48_1> getListBUDR48_1(String fromDate, String toDate, String reportStatus);

	List<BudR48_2> getListBUDR48_2(String fromDate, String toDate, String reportStatus);

	public List<String> getAllBudCellCodes();

	public Pair<Report, Exception> getBudR04(String reportStatus, String fromDate, String toDate, String cellCodeFrom,
			String cellCodeTo, String logicalLocationCode);

	public Pair<Report, Exception> getListBudR05(String reportStatus, String fromDate, String toDate,
			String cellCodeFrom, String cellCodeTo);

	public Pair<Report, Exception> getListBudR67(String amountFrom, String amountTo, String cellNumber,
			String countryName, String reportStatus);

	public Pair<Report, Exception> getBUD48Report(String reportStatus, String fromDate, String toDate,
			String countryName, String decisionStatus, String defaultStat);

	public Pair<Report, Exception> getBUD08Report(String reportStatus, String fromDate, String toDate,
			String proposalStatus, String logicalLocationCode, String cellCode);

	public Pair<Report, Exception> getBUD13Report(String reportStatus, String fromDate, String toDate);

	public Pair<Report, Exception> getBUD29Report(String policyNo, String buyerCode, String buyerCountry,
			String fromDate);

	public Pair<Report, Exception> getBUD69Report(String reportStatus, String cellCode);

	public Pair<Report, Exception> generateBUD59Report(Map<String, Object> allRequestParams);

	public Pair<Report, Exception> generateReport(Map<String, String> allRequestParams);

	public List<Map<String, String>> getAllCla144Policies(final Map<String, String> query);

	public List<Map<String, Object>> getAllActiveApprovedLimits(String coverCatId, String logicalLocationCode);

	public List<Map<String, Object>> getAllActiveApprovedLimitsBank(String coverCatId, String logicalLocationCode);

	public List<Map<String, Object>> getAllActiveApprovedLimitsBuyer(String coverCatId, String logicalLocationCode);

	public List<Map<String, Object>> getActiveApprovedLimitsBuyer(String coverCatId, String logicalLocationCode,
			String countryName);

	public List<Map<String, Object>> getActiveApprovedLimitsBank(String coverCatId, String logicalLocationCode,
			String countryName);

}
