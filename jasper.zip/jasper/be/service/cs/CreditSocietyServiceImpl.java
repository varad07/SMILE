package in.ecgc.smile.erp.reporting.jasper.be.service.cs;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.EntityGL;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.GLCodeStmtIn;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.GLCodeStmtOut;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.GLStmt;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.TrialBalance;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.TrialBalanceReport;
import in.ecgc.smile.erp.reporting.jasper.be.model.cs.Employee;
import in.ecgc.smile.erp.reporting.jasper.be.model.cs.PLStmt;
import in.ecgc.smile.erp.reporting.jasper.be.model.cs.PlWiseSummary;
import in.ecgc.smile.erp.reporting.jasper.be.model.cs.PlwiseSumOut;
import in.ecgc.smile.erp.reporting.jasper.be.repository.accounts.GlTxnDao;
import in.ecgc.smile.erp.reporting.jasper.be.repository.accounts.TrialBalanceDao;
import in.ecgc.smile.erp.reporting.jasper.be.repository.cs.CreditSocietyDao;
import in.ecgc.smile.erp.reporting.jasper.be.service.accounts.EntityGLMasterService;


@Service
public class CreditSocietyServiceImpl implements CreditSocietyService {

private static final Logger logger = LoggerFactory.getLogger(CreditSocietyServiceImpl.class);
	
@Autowired
CreditSocietyDao creditSocietyDao;

@Autowired
TrialBalanceDao trialBalanceDao;

@Autowired
EntityGLMasterService entityGlMstService;

@Autowired
GlTxnDao txnDao;


	@Override
	public TrialBalanceReport getTrialBalacneAllLoc(String inputDate, Boolean isNil) throws SQLException {
		Integer txnCount = creditSocietyDao.generateTrialBalanceAllLocByDate(inputDate);
		System.err.println("Trial Balance Count : "+ txnCount);
		
		return  creditSocietyDao.getTrialBalacneAllLoc(inputDate, isNil);
		
	}

	@Override
	public Integer generateTrialBalanceByDate(String inputDate) {
		return creditSocietyDao.generateTrialBalanceAllLocByDate(inputDate);
	}

	@Override
	public TrialBalanceReport getBankReconciliation(String inputDate, Boolean isNil) throws SQLException {
		Integer txnCount = creditSocietyDao.generateBankReconciliation(inputDate, isNil);
		System.err.println("Trial Balance Count : "+ txnCount);
		return  creditSocietyDao.getBankReconciliation(inputDate, isNil);
	}

	@Override
	public Integer generateBankReconciliation(String inputDate,Boolean isNil) {
		return creditSocietyDao.generateBankReconciliation(inputDate,isNil);
	}

	@Override
	public GLCodeStmtOut getGLCodeStatementbyLoc(GLCodeStmtIn glCodeStmtIn) {
		GLCodeStmtOut glCodeStmtOut = new GLCodeStmtOut();

		TrialBalance fromDtBal = creditSocietyDao.getByLogicalLoc(
				glCodeStmtIn.getFromDt().minusDays(1).toString(), glCodeStmtIn.getMainglCd(), glCodeStmtIn.getSubglCd(),
				"", ""); // To Change

		glCodeStmtOut.setOpeningCrBal(fromDtBal.getCrAmount());
		glCodeStmtOut.setOpeningDrBal(fromDtBal.getDrAmount());

		TrialBalance toDtBal = creditSocietyDao.getByLogicalLoc(
				glCodeStmtIn.getToDt().toString(), glCodeStmtIn.getMainglCd(), glCodeStmtIn.getSubglCd(), "", ""); // To
																													// Change

		glCodeStmtOut.setClosingCrBal(toDtBal.getCrAmount());
		glCodeStmtOut.setClosingDrBal(toDtBal.getDrAmount());

		List<GLStmt> glCodeTxnStatement = txnDao.getGLCodeStatementbyAllLocation(glCodeStmtIn);

		String balanceType = "";
		String glType = entityGlMstService.findGLByBankGLCode(glCodeStmtIn.getMainglCd(), glCodeStmtIn.getSubglCd())
				.getGlType();

		if (!glType.isEmpty() || glType != null) {
			if (glType.equalsIgnoreCase("ASST") || glType.equalsIgnoreCase("EXPD") || glType.equalsIgnoreCase("EXP")) {
				balanceType = "DR";
			} else {
				balanceType = "CR";
			}
		}

		BigDecimal balance = BigDecimal.ZERO;

		if (fromDtBal.getDrAmount().compareTo(BigDecimal.ZERO) == 1) {
			balance = fromDtBal.getDrAmount();
		} else if (fromDtBal.getCrAmount().compareTo(BigDecimal.ZERO) == 1) {
			balance = fromDtBal.getCrAmount();
		}

		if (balanceType.equalsIgnoreCase("CR")) {
			for (GLStmt glStmt : glCodeTxnStatement) {
				if (glStmt.getTxnCrAmt().compareTo(glStmt.getTxnDrAmt()) == 1) {
					balance = balance.add(glStmt.getTxnCrAmt());
					glStmt.setBalance(balance);
				} else if (glStmt.getTxnDrAmt().compareTo(glStmt.getTxnCrAmt()) == 1) {

					balance = balance.subtract(glStmt.getTxnDrAmt());
					glStmt.setBalance(balance.abs());
				}
				glStmt.setBalanceType(balanceType);
			}
		} else {
			for (GLStmt glStmt : glCodeTxnStatement) {
				if (glStmt.getTxnDrAmt().compareTo(glStmt.getTxnCrAmt()) == 1) {
					balance = balance.add(glStmt.getTxnDrAmt());
					glStmt.setBalance(balance.abs());
				} else if (glStmt.getTxnCrAmt().compareTo(glStmt.getTxnDrAmt()) == 1) {
					balance = balance.subtract(glStmt.getTxnCrAmt());
					glStmt.setBalance(balance.abs());
				}
				glStmt.setBalanceType(balanceType);
			}
		}
		glCodeStmtOut.setGlStmt(glCodeTxnStatement);

		return glCodeStmtOut;
	}

	@Override
	public List<EntityGL> getAllGlCodes() {
		List<EntityGL> entitygl = new ArrayList<>();
		try {
			entitygl = creditSocietyDao.getAllGlCodes();
			return entitygl;
		}
		catch(Exception e ) {
			System.out.println(e.getMessage());
		}
		return entitygl;
	}


	@Override
	public List<Employee> getAllEmployeePl(String mainGlCd, String subGlCd) {
		return creditSocietyDao.getAllEmployeePl(mainGlCd,subGlCd);
		
	}

	@Override
	public PlwiseSumOut getGLCodeStatementbyLoc(PlWiseSummary plwiseSummary) {
		logger.info("Inside GlTxnServiceImpl#getGLCodeStatementbyLoc (Obj) : {}", plwiseSummary);

		PlwiseSumOut plwiseSumOut = new PlwiseSumOut();

		TrialBalance fromDtBal = creditSocietyDao.getGlRangeByDate(
				plwiseSummary.getFromDt().minusDays(1).toString(), plwiseSummary.getMainglCd(), plwiseSummary.getSubglCd(),plwiseSummary.getPlCd()
				); // To Change

		plwiseSumOut.setOpeningCrBal(fromDtBal.getCrAmount());
		plwiseSumOut.setOpeningDrBal(fromDtBal.getDrAmount());

		TrialBalance toDtBal = creditSocietyDao.getGlRangeByDate(
				plwiseSummary.getToDt().toString(), plwiseSummary.getMainglCd(), plwiseSummary.getSubglCd(),plwiseSummary.getPlCd() ); // To
																													// Change

		plwiseSumOut.setClosingCrBal(toDtBal.getCrAmount());
		plwiseSumOut.setClosingDrBal(toDtBal.getDrAmount());

		List<PLStmt> glCodeTxnStatement = creditSocietyDao.getGLCodeStatementbyLoc(plwiseSummary);

		String balanceType = null;
		String glType = entityGlMstService.findGLByBankGLCode(plwiseSummary.getMainglCd(), plwiseSummary.getSubglCd())
				.getGlType();

		if (!glType.isEmpty() || glType != null) {
			if (glType.equalsIgnoreCase("ASST") || glType.equalsIgnoreCase("EXPD") || glType.equalsIgnoreCase("EXP")) {
				balanceType = "DR";
			} else {
				balanceType = "CR";
			}
		}

		BigDecimal balance = BigDecimal.ZERO;

		if (fromDtBal.getDrAmount().compareTo(BigDecimal.ZERO) == 1) {
			balance = fromDtBal.getDrAmount();
		} else if (fromDtBal.getCrAmount().compareTo(BigDecimal.ZERO) == 1) {
			balance = fromDtBal.getCrAmount();
		}
		if (balanceType.equalsIgnoreCase("CR")) {
			for (PLStmt glStmt : glCodeTxnStatement) {
				if (glStmt.getTxnCrAmt().compareTo(glStmt.getTxnDrAmt()) == 1) {
					balance = balance.add(glStmt.getTxnCrAmt());
					glStmt.setBalance(balance.abs());
				} else if (glStmt.getTxnDrAmt().compareTo(glStmt.getTxnCrAmt()) == 1) {

					balance = balance.subtract(glStmt.getTxnDrAmt());
					glStmt.setBalance(balance.abs());
				}
				glStmt.setBalanceType(balanceType);
			}
		} else {
			for (PLStmt glStmt : glCodeTxnStatement) {
				if (glStmt.getTxnDrAmt().compareTo(glStmt.getTxnCrAmt()) == 1) {
					balance = balance.add(glStmt.getTxnDrAmt());
					glStmt.setBalance(balance.abs());
				} else if (glStmt.getTxnCrAmt().compareTo(glStmt.getTxnDrAmt()) == 1) {
					balance = balance.subtract(glStmt.getTxnCrAmt());
					glStmt.setBalance(balance.abs());
				}
				glStmt.setBalanceType(balanceType);
			}
		}
		plwiseSumOut.setPlStmt(glCodeTxnStatement);

		return plwiseSumOut;
	}

	@Override
	public PlwiseSumOut getCashBankBookDtls(PlWiseSummary plwiseSummary) {
		logger.info("Inside CreditSocietyServiceImpl#getCashBankBookDtlss (Obj) : {}", plwiseSummary);
		plwiseSummary.setMainglCd("1000");
		plwiseSummary.setSubglCd("004");
		logger.info("Inside CreditSocietyServ) main gl sub gl : {}", plwiseSummary);

		PlwiseSumOut plwiseSumOut = new PlwiseSumOut();

		TrialBalance fromDtBal = creditSocietyDao.getGlRangeByDateGL(
				 plwiseSummary.getMainglCd(), plwiseSummary.getSubglCd(),plwiseSummary.getFromDt().minusDays(1).toString()
				); // To Change

		plwiseSumOut.setOpeningCrBal(fromDtBal.getCrAmount());
		plwiseSumOut.setOpeningDrBal(fromDtBal.getDrAmount());

		TrialBalance toDtBal = creditSocietyDao.getGlRangeByDateGL(
				plwiseSummary.getMainglCd(), plwiseSummary.getSubglCd(),plwiseSummary.getToDt().toString()); // To
																													// Change

		plwiseSumOut.setClosingCrBal(toDtBal.getCrAmount());
		plwiseSumOut.setClosingDrBal(toDtBal.getDrAmount());

		List<PLStmt> glCodeTxnStatement = creditSocietyDao.getGLCodeStatementForCashBankBook(plwiseSummary);

		String balanceType = null;
		
	
		String glType = entityGlMstService.
findGLByBankGLCode(plwiseSummary.getMainglCd(), plwiseSummary.getSubglCd()).getGlType();

		if (!glType.isEmpty() || glType != null) {
			if (glType.equalsIgnoreCase("ASST") || glType.equalsIgnoreCase("EXPD") || glType.equalsIgnoreCase("EXP")) {
				balanceType = "DR";
			} else {
				balanceType = "CR";
			}
		}

		BigDecimal balance = BigDecimal.ZERO;

		if (fromDtBal.getDrAmount().compareTo(BigDecimal.ZERO) == 1) {
			balance = fromDtBal.getDrAmount();
		} else if (fromDtBal.getCrAmount().compareTo(BigDecimal.ZERO) == 1) {
			balance = fromDtBal.getCrAmount();
		}
		if (balanceType.equalsIgnoreCase("CR")) {
			for (PLStmt glStmt : glCodeTxnStatement) {
				if (glStmt.getTxnCrAmt().compareTo(glStmt.getTxnDrAmt()) == 1) {
					balance = balance.add(glStmt.getTxnCrAmt());
					glStmt.setBalance(balance.abs());
				} else if (glStmt.getTxnDrAmt().compareTo(glStmt.getTxnCrAmt()) == 1) {

					balance = balance.subtract(glStmt.getTxnDrAmt());
					glStmt.setBalance(balance.abs());
				}
				glStmt.setBalanceType(balanceType);
			}
		} else {
			for (PLStmt glStmt : glCodeTxnStatement) {
				if (glStmt.getTxnDrAmt().compareTo(glStmt.getTxnCrAmt()) == 1) {
					balance = balance.add(glStmt.getTxnDrAmt());
					glStmt.setBalance(balance.abs());
				} else if (glStmt.getTxnCrAmt().compareTo(glStmt.getTxnDrAmt()) == 1) {
					balance = balance.subtract(glStmt.getTxnCrAmt());
					glStmt.setBalance(balance.abs());
				}
				glStmt.setBalanceType(balanceType);
			}
		}
		plwiseSumOut.setPlStmt(glCodeTxnStatement);

		return plwiseSumOut;
	}



}
