package in.ecgc.smile.erp.reporting.jasper.be.service.cs;

import java.sql.SQLException;
import java.util.List;

import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.EntityGL;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.GLCodeStmtIn;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.GLCodeStmtOut;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.TrialBalanceReport;
import in.ecgc.smile.erp.reporting.jasper.be.model.cs.Employee;
import in.ecgc.smile.erp.reporting.jasper.be.model.cs.PlWiseSummary;
import in.ecgc.smile.erp.reporting.jasper.be.model.cs.PlwiseSumOut;


public interface CreditSocietyService {
	
	public TrialBalanceReport getTrialBalacneAllLoc(String inputDate, Boolean isNil) throws SQLException;

	public Integer generateTrialBalanceByDate(String inputDate);

	public TrialBalanceReport getBankReconciliation(String inputDate, Boolean isNil)throws SQLException;

	public Integer generateBankReconciliation(String inputDate, Boolean isNil);

	public GLCodeStmtOut getGLCodeStatementbyLoc(GLCodeStmtIn glCodeStmtIn);

	public List<EntityGL> getAllGlCodes();


	public List<Employee> getAllEmployeePl(String mainGlCd, String subGlCd);

	public PlwiseSumOut getGLCodeStatementbyLoc(PlWiseSummary plwiseSummary);

	public PlwiseSumOut getCashBankBookDtls(PlWiseSummary plwiseSummary);




}
