package in.ecgc.smile.erp.reporting.jasper.be.controller.cs;

import java.sql.SQLException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.EntityGL;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.GLCodeStmtIn;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.GLCodeStmtOut;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.TrialBalanceReport;
import in.ecgc.smile.erp.reporting.jasper.be.model.cs.Employee;
import in.ecgc.smile.erp.reporting.jasper.be.model.cs.PlWiseSummary;
import in.ecgc.smile.erp.reporting.jasper.be.model.cs.PlwiseSumOut;
import in.ecgc.smile.erp.reporting.jasper.be.service.cs.CreditSocietyService;

@RestController
@RequestMapping("/credit-society/trial-balance")
public class CreditSocietyController {
	
	@Autowired
	CreditSocietyService creditSocietyService;

	private static final Logger log = LoggerFactory.getLogger(CreditSocietyController.class);

	@GetMapping("/create-n-view-credit_society_trial-balance/{inputDate}/{isNil}")
	public ResponseEntity<TrialBalanceReport> getTrialBalacneAllLoc(@PathVariable("inputDate") String inputDate,
			@PathVariable("isNil") Boolean isNil) throws SQLException {
		log.info("Inside CreditSocietyController#getTrialBalacneByDateAllLoc");
		return new ResponseEntity<>(creditSocietyService.getTrialBalacneAllLoc(inputDate, isNil), HttpStatus.OK);
	}

	@GetMapping("/all-loc/{inputDate}/{isNil}")
	public ResponseEntity<Integer> generateTrialBalanceAllLocByDate(@PathVariable("inputDate") String inputDate) {
		log.info("Inside CreditSocietyController#generateTrialBalanceByDate");
		return new ResponseEntity<>(creditSocietyService.generateTrialBalanceByDate(inputDate), HttpStatus.OK);
	}
	
	@GetMapping("/create-n-view-cs-bank-reconciliation/{inputDate}/{isNil}")
	public ResponseEntity<TrialBalanceReport> getBankReconciliation(@PathVariable("inputDate") String inputDate,
			@PathVariable("isNil") Boolean isNil) throws SQLException {
		log.info("Inside CreditSocietyController#getBankReconciliation");
		TrialBalanceReport tb = creditSocietyService.getBankReconciliation(inputDate, isNil);
		log.info("Obj" + tb);
		return new ResponseEntity<>(tb, HttpStatus.OK);
	}
	
	@GetMapping("/bank-reconciliation/{inputDate}/{isNil}")
	public ResponseEntity<Integer> generateBankReconciliation(@PathVariable("inputDate") String inputDate,@PathVariable("isNil") Boolean isNil) {
		log.info("Inside CreditSocietyController#generateBankReconciliation");
		return new ResponseEntity<>(creditSocietyService.generateBankReconciliation(inputDate, isNil), HttpStatus.OK);
	}
	
	
	@PostMapping("/getGLCodeStatementbyLoc")
	public ResponseEntity<GLCodeStmtOut> getGLCodeStatementbyLoc(@RequestBody GLCodeStmtIn glCodeStmtIn) {
		log.info("Inside creditsocietyBEController#getGLCodeStatementbyLoc : {}",glCodeStmtIn);
		
		return new ResponseEntity<>(creditSocietyService.getGLCodeStatementbyLoc(glCodeStmtIn), HttpStatus.OK);
	}
	
	@GetMapping("/all-gl-codes")
	public ResponseEntity<List<EntityGL>> getAllGlCodes(){
		List<EntityGL> result = creditSocietyService.getAllGlCodes();
		log.info("result for entity {}", result.size());
		return new ResponseEntity<>(result, HttpStatus.OK);
	};
	
	@GetMapping("/get-emp-pl-level/{mainGlCd}/{subGlCd}")
	public ResponseEntity<List<Employee>> getAllEmpCodes(@PathVariable("mainGlCd") String mainGlCd, @PathVariable("subGlCd") String subGlCd){
		List<Employee> result = creditSocietyService.getAllEmployeePl(mainGlCd,subGlCd);
		log.info("result for entity {}", result.size());
		return new ResponseEntity<>(result, HttpStatus.OK);
	};
	
	@PostMapping("/getGLCodeStatement")
	public ResponseEntity<PlwiseSumOut> getGLCodeStatementbyLoc(@RequestBody PlWiseSummary plwiseSummary) {
		log.info("Inside csController#getGLCodeStatementbyLoc (Obj): {}", plwiseSummary);
		return new ResponseEntity<>(creditSocietyService.getGLCodeStatementbyLoc(plwiseSummary), HttpStatus.OK);
	}
	
	
	@PostMapping("/getCashBankBookDtls")
	public ResponseEntity<PlwiseSumOut> getCashBankBookDtls(@RequestBody PlWiseSummary plwiseSummary) {
		log.info("Inside csController#getCashBankBookDtls (Obj): {}", plwiseSummary);
		return new ResponseEntity<>(creditSocietyService.getCashBankBookDtls(plwiseSummary), HttpStatus.OK);
	}
}


