package in.ecgc.smile.erp.reporting.jasper.be.controller.pebp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import in.ecgc.smile.erp.reporting.jasper.be.model.reports.Report;
import in.ecgc.smile.erp.reporting.jasper.be.service.pebp.PebPService;
import in.ecgc.smile.erp.reporting.jasper.be.utils.Pair;

@Controller
@RequestMapping("/pebp-reports")
public class PebPController {

	@Autowired
	private PebPService pebPService;

	private static final Logger logger = LoggerFactory.getLogger(PebPController.class);


	@PostMapping("/PEB_P_02/")
	public ResponseEntity<Pair<Report, Exception>> getPEBP02Report(@RequestParam("fromDate") String fromDate,
			@RequestParam("toDate") String toDate, @RequestParam(required = false) String country,
			@RequestParam(required = false) @PathVariable("coverType") String coverType) {

		logger.info("From Date" + fromDate + "To Date" + toDate + "country" + country + "Cover Type" + coverType);

		logger.info("Inside PEB_P_02 PEBPController Controller");

		return new ResponseEntity<>(pebPService.getPEBP02Report(fromDate, toDate, country, coverType), HttpStatus.OK);

	}

	@PostMapping("/PEB_P_03/")
	public ResponseEntity<Pair<Report, Exception>> getPEBP03Report(@RequestParam("country") String country,
			@RequestParam(required = false) String exporterCode) {

		logger.info("country" + country + "Exporter Code" + exporterCode);

		logger.info("Inside PEB_P_03 PEBPController Controller");

		return new ResponseEntity<>(pebPService.getPEBP03Report(country, exporterCode), HttpStatus.OK);

	}
}
