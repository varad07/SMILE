package in.ecgc.smile.erp.reporting.jasper.be.controller.pf;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import in.ecgc.smile.erp.reporting.jasper.be.service.pf.PfService;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.TrialBalanceReport;
import in.ecgc.smile.erp.reporting.jasper.be.model.mktg.FormIXAgencyOrgStmt;
import in.ecgc.smile.erp.reporting.jasper.be.model.pf.Pf_r02;
import in.ecgc.smile.erp.reporting.jasper.be.model.pf.Pf_r07;

@Controller
@RestController
@RequestMapping("/pf-reports")
public class PfController {
	
	
	@Autowired
	Pf_r02 pf_r02; 
	
	@Autowired
	private PfService pfService;

	private static final Logger logger = LoggerFactory.getLogger(PfController.class);
	
	@PostMapping("/PF_R02/{personal_ledger_code}")
	public ResponseEntity<List<Pf_r02>> getListPf_r02(@PathVariable("personal_ledger_code") String personal_ledger_code ) {
		logger.info("Inside pf_r02 PfController Controller",personal_ledger_code);
		
		List<Pf_r02> list = pfService.getListPf_r02(personal_ledger_code);
		
		return new ResponseEntity<>(list, HttpStatus.OK);
	}
	
	
	@PostMapping("/PF_R07")
	public ResponseEntity<List<Pf_r07>> getActuarialValuationReport_r07() {
		logger.info("Inside ActuarialValuationReport_r07 PfController");
		
		List<Pf_r07> list = pfService.getActuarialValuationReport_r07();
		
		return new ResponseEntity<>(list, HttpStatus.OK);
	}
	
	@GetMapping("/create-n-view-pf-trial-bal-all-loc/{inputDate}/{isNil}")
	public ResponseEntity<TrialBalanceReport> getpfTrialBalacneAllLoc(@PathVariable("inputDate") String inputDate,
			@PathVariable("isNil") Boolean isNil) {
		logger.info("Inside TrialBalanceController#getTrialBalacneByDateAllLoc");
		return new ResponseEntity<>(pfService.getpfTrialBalacneAllLoc(inputDate, isNil), HttpStatus.OK);
	}
	
	@GetMapping("/generate-PF_R04/{inputDate}")
	public ResponseEntity<Integer> generateTrialBalanceAllLocByDate(@PathVariable("inputDate") String inputDate) {
		logger.info("Inside TrialBalanceController#generateTrialBalanceByDate");
		return new ResponseEntity<>(pfService.generateTrialBalanceByDate(inputDate), HttpStatus.OK);
	}

}
