package in.ecgc.smile.erp.reporting.jasper.be.controller.mktg;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import in.ecgc.smile.erp.reporting.jasper.be.model.mktg.FormIXAgencyOrgStmt;
import in.ecgc.smile.erp.reporting.jasper.be.model.mktg.MKTIDRAI07;
import in.ecgc.smile.erp.reporting.jasper.be.model.mktg.MKTIRDAI02;
import in.ecgc.smile.erp.reporting.jasper.be.model.mktg.MKTIRDAI05Model;
import in.ecgc.smile.erp.reporting.jasper.be.service.mktg.MktgService;

@RestController
@RequestMapping("/mktg-reports")
public class MktgController {
	
	@Autowired
	FormIXAgencyOrgStmt formIXAgencyOrgStmt; 
	
	@Autowired
	private MktgService mktgService;

	private static final Logger logger = LoggerFactory.getLogger(MktgController.class);
	
	
	@PostMapping("/MKT_IRDAI_04/{fromDate}/{toDate}")
	public ResponseEntity<List<FormIXAgencyOrgStmt>> getListMktIDRAI04(@PathVariable("fromDate") String fromDate,@PathVariable("toDate") String toDate ) {
		logger.debug("Inside MKT_IRDAI_04 MktgController");
		
		List<FormIXAgencyOrgStmt> list = mktgService.getListMktIDRAI04(fromDate,toDate);
	
		return new ResponseEntity<>(list, HttpStatus.OK);
	}
	
	@PostMapping("/MKT_IRDAI_05/{fromDate}/{toDate}")
	public ResponseEntity<List<MKTIRDAI05Model>> getListMktIDRAI05(@PathVariable("fromDate") String fromDate,@PathVariable("toDate") String toDate ) {
		logger.debug("Inside MKT_IRDAI_05 MktgController");
	
		List<MKTIRDAI05Model> list = mktgService.getListMktIDRAI05(fromDate,toDate);
		
		return new ResponseEntity<>(list, HttpStatus.OK);
	}
	
	
	@PostMapping("/MKT_IRDAI_02/{fromDate}/{toDate}")
	public ResponseEntity<List<MKTIRDAI02>> getListMktIDRAI02(@PathVariable("fromDate") String fromDate,@PathVariable("toDate") String toDate ) {
		logger.debug("Inside MKT_IRDAI_02 MktgController");
	
		List<MKTIRDAI02> list = mktgService.getListMktIDRAI02(fromDate,toDate);
		
		return new ResponseEntity<>(list, HttpStatus.OK);
	}
	
	
	@PostMapping("/MKT_IRDAI_07/{fromDate}/{toDate}")
	public ResponseEntity<List<MKTIDRAI07>> getListMktIDRAI07(@PathVariable("fromDate") String fromDate,@PathVariable("toDate") String toDate ) {
		logger.debug("Inside MKT_IRDAI_07 MktgController");
	
		List<MKTIDRAI07> list = mktgService.getListMktIDRAI07(fromDate,toDate);
		;
		return new ResponseEntity<>(list, HttpStatus.OK);
	}
	
	
	
}
