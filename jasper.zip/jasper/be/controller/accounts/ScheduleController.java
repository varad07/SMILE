package in.ecgc.smile.erp.reporting.jasper.be.controller.accounts;

import java.math.BigDecimal;
import java.time.LocalDate;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.Schedule1;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.Schedule11;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.Schedule12;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.Schedule13;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.Schedule14;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.Schedule15;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.Schedule2;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.Schedule3;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.Schedule4;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.Schedule5;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.Schedule5A;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.Schedule6;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.Schedule7;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.Schedule8;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.Schedule9;
import in.ecgc.smile.erp.reporting.jasper.be.service.accounts.ScheduleService;



@RestController
@RequestMapping("acct-schedules")
public class ScheduleController {
	
	private static Logger log = LoggerFactory.getLogger(ScheduleController.class);
	
	@Autowired
	private ScheduleService  scheduleService ;
	
	
	@GetMapping("schedule-1/{inputDate}")
	public ResponseEntity<Schedule1> getSchedule1(@PathVariable("inputDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date){
		log.debug("ScheduleController-->getSchedule1()");
		return new ResponseEntity<Schedule1>(scheduleService.getSchedule1(date), HttpStatus.OK);
	}
	
	@GetMapping("schedule-2/{inputDate}")
	public ResponseEntity<Schedule2> getSchedule2(@PathVariable("inputDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date){
		log.debug("ScheduleController-->getSchedule2()");
		return new ResponseEntity<Schedule2>(scheduleService.getSchedule2(date), HttpStatus.OK);
	}
	
	@GetMapping("schedule-7/{inputDate}")
	public ResponseEntity<Schedule7> getSchedule7(@PathVariable("inputDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date){
		log.debug("ScheduleController-->getSchedule7()");
		return new ResponseEntity<Schedule7>(scheduleService.getSchedule7(date), HttpStatus.OK);
	}
	
	
	@GetMapping("schedule-15/{inputDate}")
	public ResponseEntity<Schedule15> getSchedule15(@PathVariable("inputDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date){
		log.debug("ScheduleController-->getSchedule15()");
		return new ResponseEntity<Schedule15>(scheduleService.getSchedule15(date), HttpStatus.OK);
	}
	
	@GetMapping("schedule-5/{inputDate}/{scheduleItem5dot1Amt}/{scheduleItem5dot1PreAmt}")
	public ResponseEntity<Schedule5> getSchedule5(@PathVariable("inputDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date,
            						@PathVariable("scheduleItem5dot1Amt") BigDecimal authCapital,
            						@PathVariable("scheduleItem5dot1PreAmt") BigDecimal authPreCapital){
		log.debug("ScheduleController-->getSchedule5()");
		return new ResponseEntity<Schedule5>(scheduleService.getSchedule5(date,authCapital,authPreCapital), HttpStatus.OK);
	}
	
	
	@GetMapping("schedule-5A/{inputDate}")
	public ResponseEntity<Schedule5A> getSchedule5A(@PathVariable("inputDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date){
		log.debug("ScheduleController-->getSchedule5()");
		return new ResponseEntity<Schedule5A>(scheduleService.getSchedule5A(date), HttpStatus.OK);
	}
	
	@GetMapping("schedule-9/{inputDate}")
	public ResponseEntity<Schedule9> getSchedule9(@PathVariable("inputDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date){
		log.debug("ScheduleController-->getSchedule9()");
		return new ResponseEntity<Schedule9>(scheduleService.getSchedule9(date), HttpStatus.OK);
	}
	
	
	@GetMapping("schedule-11/{inputDate}")
	public ResponseEntity<Schedule11> getSchedule11(@PathVariable("inputDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date){
		log.debug("ScheduleController-->getSchedule11()");
		return new ResponseEntity<Schedule11>(scheduleService.getSchedule11(date), HttpStatus.OK);
	}
	
	
	@GetMapping("schedule-14/{inputDate}")
	public ResponseEntity<Schedule14> getSchedule14(@PathVariable("inputDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date){
		log.debug("ScheduleController-->getSchedule14()");
		return new ResponseEntity<Schedule14>(scheduleService.getSchedule14(date), HttpStatus.OK);
	}
	
	@GetMapping("schedule-13/{inputDate}")
	public ResponseEntity<Schedule13> getSchedule13(@PathVariable("inputDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date){
		log.debug("ScheduleController-->getSchedule13()");
		return new ResponseEntity<Schedule13>(scheduleService.getSchedule13(date), HttpStatus.OK);
	}
	
	@GetMapping("schedule-12/{inputDate}")
	public ResponseEntity<Schedule12> getSchedule12(@PathVariable("inputDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date){
		log.debug("ScheduleController-->getSchedule12()");
		return new ResponseEntity<Schedule12>(scheduleService.getSchedule12(date), HttpStatus.OK);
	}
	
	@PostMapping("schedule-8/{inputDate}")
	public ResponseEntity<Schedule8> getSchedule8(@PathVariable("inputDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date,
												  @RequestBody Schedule8 schedule8){
		log.debug("ScheduleController-->getSchedule8()");
		return new ResponseEntity<Schedule8>(scheduleService.getSchedule8(date,schedule8), HttpStatus.OK);
	}
	
	@GetMapping("schedule-3/{inputDate}")
	public ResponseEntity<Schedule3> getSchedule3(@PathVariable("inputDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date
												  ){
		log.debug("ScheduleController-->getSchedule3()");
		return new ResponseEntity<Schedule3>(scheduleService.getSchedule3(date), HttpStatus.OK);
	}
	
	@GetMapping("schedule-6/{inputDate}")
	public ResponseEntity<Schedule6> getSchedule6(@PathVariable("inputDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date
												  ){
		log.debug("ScheduleController-->getSchedule6()");
		return new ResponseEntity<Schedule6>(scheduleService.getSchedule6(date), HttpStatus.OK);
	}
	
	
	@GetMapping("schedule-4/{inputDate}")
	public ResponseEntity<Schedule4> getSchedule4(@PathVariable("inputDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date
												  ){
		log.debug("ScheduleController-->getSchedule4()");
		return new ResponseEntity<Schedule4>(scheduleService.getSchedule4(date), HttpStatus.OK);
	}
	
	

}
