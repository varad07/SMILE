package in.ecgc.smile.erp.reporting.jasper.be.controller.accounts;

import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.GLCodeStmtIn;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.GLCodeStmtOut;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.GLRangeStmtIn;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.GLRangeStmtOut;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.GLStmt;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.GLStmtOut;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.GlStmtIn;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.TdsDetails;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.TcodeLevel.TcodeLevelStmtOut;
import in.ecgc.smile.erp.reporting.jasper.be.service.accounts.GlTxnService;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;

@RestController
@RequestMapping("/accounts-reports")
public class AccountsBEController {

	@Autowired
	GlTxnService txnService;

	private static final Logger log = LoggerFactory.getLogger(AccountsBEController.class);

	@PostMapping("/getTcodewiseGLTxnStatement_x")
	public ResponseEntity<GLStmtOut> getTcodewiseGLTxnStatement(@RequestBody GlStmtIn glStmt) {
		log.info("Inside AccountsBEController#getTcodewiseGLTxnStatement_x ;{}", glStmt);
		return new ResponseEntity<>(txnService.getTcodewiseGLTxnStatement(glStmt), HttpStatus.OK);
	}
	
	@PostMapping("/getTcodewiseGLTxnStatement")
	public ResponseEntity<TcodeLevelStmtOut> getTcodeLevelGLStatement(@RequestBody GlStmtIn glStmt) {
		log.info("Inside AccountsBEController#getTcodeLevelGLStatement ;{}", glStmt);
		return new ResponseEntity<>(txnService.getTcodeLevelGLStatement(glStmt), HttpStatus.OK);
	}

	@PostMapping("/ACCT_R12/{logicallocCd}/{txnType}/{fromDt}/{toDt}")
	public ResponseEntity<List<GLStmt>> getGLTransactionTypeWiseStatement(
			@PathVariable("logicallocCd") String logicallocCd, @PathVariable("txnType") String txnType,
			@PathVariable("fromDt") String fromDtStr, @PathVariable("toDt") String toDtStr) {
		log.info("Inside AccountsBEController#getGLTransactionTypeWiseStatement Obj : {},{},{},{}", logicallocCd,
				txnType, fromDtStr, toDtStr);

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		LocalDate fromDt = null;
		LocalDate toDt = null;
		try {
			fromDt = LocalDate.parse(fromDtStr, formatter);
			toDt = LocalDate.parse(toDtStr, formatter);
		} catch (Exception e) {
			log.info("Error parsing the date: " + e.getMessage());
		}

		return new ResponseEntity<List<GLStmt>>(
				txnService.getGLTransactionTypeWiseStatement(logicallocCd, txnType, fromDtStr, toDtStr), HttpStatus.OK);
	}

	@PostMapping("/gl-txn-stmt-by-gl-range")
	public ResponseEntity<List<GLRangeStmtOut>> glTxnStmtByGlRange(@RequestBody GLRangeStmtIn glStmGlRangeStmtIn) {
		log.info("Inside AccountsBEController#glTxnStmtByGlRange Obj :{}", glStmGlRangeStmtIn);
		List<GLRangeStmtOut> glRangewiseTxnStatement = txnService.getGLRangewiseTxnStatement(glStmGlRangeStmtIn);
		return new ResponseEntity<List<GLRangeStmtOut>>(glRangewiseTxnStatement, HttpStatus.OK);
	}

	@PostMapping("/getGLCodeStatementbyLoc")
	public ResponseEntity<GLCodeStmtOut> getGLCodeStatementbyLoc(@RequestBody GLCodeStmtIn glCodeStmtIn) {
		log.info("Inside AccountsBEController#getGLCodeStatementbyLoc (Obj): {}", glCodeStmtIn);
		return new ResponseEntity<>(txnService.getGLCodeStatementbyLoc(glCodeStmtIn), HttpStatus.OK);
	}

	@PostMapping("/getSubBfwiseGLTxnStatement")
	public ResponseEntity<GLStmtOut> getSubBfwiseGLTxnStatement(@RequestBody GlStmtIn glStmt) {
		log.info("Inside AccountsBEController#getSubBfwiseGLTxnStatement glStmt(obj) :{}", glStmt);

		return new ResponseEntity<>(txnService.getSubBfwiseGLTxnStatement(glStmt), HttpStatus.OK);
	}

	@PostMapping("/getTcodeAndSubBfwiseGLTxnStatement")
	public ResponseEntity<GLStmtOut> getTcodeAndSubBfwiseGLTxnStatement(@RequestBody GlStmtIn glStmt) {
		log.info("Inside AccountsBEController#getTcodeAndSubBfwiseGLTxnStatement Obj :{}", glStmt);
		return new ResponseEntity<>(txnService.getTcodeAndSubBfwiseGLTxnStatement(glStmt), HttpStatus.OK);
	}

	// ACCT_R151
	@PostMapping("/getdetailsOfAmtPaidUnderTDSForYear/{logicallocCd}/{fiscalYear}")
	public ResponseEntity<List<TdsDetails>> getdetailsOfAmtPaidUnderTDSForYear(
			@PathVariable("logicallocCd") String logicallocCd, @PathVariable("fiscalYear") String fiscalYear) {
		log.info("Inside AccountsBEController#getdetailsOfAmtPaidUnderTDSForYear logicallocCd,fiscalYear (Obj): {},{}",
				logicallocCd, fiscalYear);
		return new ResponseEntity<List<TdsDetails>>(
				txnService.getdetailsOfAmtPaidUnderTDSForYear(logicallocCd, fiscalYear), HttpStatus.OK);
	}

}
