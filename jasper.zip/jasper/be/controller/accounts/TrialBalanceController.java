package in.ecgc.smile.erp.reporting.jasper.be.controller.accounts;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.ConsTrialBal;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.ConsTrialBaldtl;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.TrialBalance;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.TrialBalanceReport;
import in.ecgc.smile.erp.reporting.jasper.be.service.accounts.TrialBalanceService;

@RestController
@RequestMapping("/accounts/trial-balance")
public class TrialBalanceController {

	@Autowired
	TrialBalanceService trialBalanceService;

	private static final Logger log = LoggerFactory.getLogger(TrialBalanceController.class);

	@GetMapping("/create-n-view-trial-bal-all-loc/{inputDate}/{isNil}")
	public ResponseEntity<TrialBalanceReport> getTrialBalacneAllLoc(@PathVariable("inputDate") String inputDate,
			@PathVariable("isNil") Boolean isNil) {
		log.info("Inside TrialBalanceController#getTrialBalacneByDateAllLoc");
		return new ResponseEntity<>(trialBalanceService.getTrialBalacneAllLoc(inputDate, isNil), HttpStatus.OK);
	}

	@GetMapping("/create-n-view-trial-bal-loc-wise/{inputDate}/{logicalLocation}/{isNil}")
	public ResponseEntity<TrialBalanceReport> getTrialBalacneByLoc(@PathVariable("inputDate") String inputDate,
			@PathVariable("logicalLocation") String logicalLocation, @PathVariable("isNil") Boolean isNil) {
		log.info("Inside TrialBalanceController#getTrialBalacneLocWiseByLoc");
		return new ResponseEntity<>(trialBalanceService.getTrialBalacneByLoc(inputDate, logicalLocation, isNil),
				HttpStatus.OK);
	}

	@GetMapping("/all-loc/{inputDate}")
	public ResponseEntity<Integer> generateTrialBalanceAllLocByDate(@PathVariable("inputDate") String inputDate) {
		log.info("Inside TrialBalanceController#generateTrialBalanceByDate");
		return new ResponseEntity<>(trialBalanceService.generateTrialBalanceByDate(inputDate), HttpStatus.OK);
	}

	@GetMapping("/loc-wise/{inputDate}/{logicalLocation}")
	public ResponseEntity<Integer> generateTrialBalanceLocWiseByDate(@PathVariable("inputDate") String inputDate,
			@PathVariable("logicalLocation") String logicalLocation) {
		log.info("Inside TrialBalanceController#generateTrialBalanceLocWiseByDate");
		return new ResponseEntity<>(trialBalanceService.generateTrialBalanceLocWiseByDate(inputDate, logicalLocation),
				HttpStatus.OK);
	}

	@GetMapping("/logical-location-list")
	public ResponseEntity<List<String>> getEcgcBranchCodeList() {
		log.info("Inside TrialBalanceController # getEcgcBranchCodeList");
		return new ResponseEntity<>(trialBalanceService.getEcgcBranchCodeList(), HttpStatus.OK);
	}

	@GetMapping("/state-list")
	public ResponseEntity<List<String>> getAllStateMap() {
		log.info("Inside TrialBalanceController #getAllStateMap");
		return new ResponseEntity<>(trialBalanceService.getAllStateMap(), HttpStatus.OK);
	}
	
	@GetMapping("/region-list")
	public ResponseEntity<List<String>> getAllRegionMap() {
		log.info("Inside TrialBalanceController #getAllRegionMap");
		return new ResponseEntity<>(trialBalanceService.getAllRegionMap(), HttpStatus.OK);
	}
	
	@GetMapping("/create-n-view-trial-bal-state-wise/{inputDate}/{state}/{isNil}")
	public ResponseEntity<TrialBalanceReport> getTrialBalacneByState(@PathVariable("inputDate") String inputDate,
			@PathVariable("state") String state, @PathVariable("isNil") Boolean isNil) {
		log.info("Inside TrialBalanceController#getTrialBalacneStateWise");
		return new ResponseEntity<>(trialBalanceService.getTrialBalacneByState(inputDate, state, isNil),
				HttpStatus.OK);
	}

	@GetMapping("/state-wise/{inputDate}/{state}")
	public ResponseEntity<Integer> generateTrialBalacneByState(@PathVariable("inputDate") String inputDate,
			@PathVariable("state") String state) {
		log.info("Inside TrialBalanceController#generateTrialBalanceLocWiseByDate");
		return new ResponseEntity<>(trialBalanceService.generateTrialBalacneByState(inputDate, state), HttpStatus.OK);
	}
	
	@GetMapping("/create-n-view-trial-bal-region-wise/{inputDate}/{region}/{isNil}")
	public ResponseEntity<TrialBalanceReport> getTrialBalacneByRegion(@PathVariable("inputDate") String inputDate,
			@PathVariable("region") String region, @PathVariable("isNil") Boolean isNil) {
		log.info("Inside TrialBalanceController#getTrialBalacneByRegionWise");
		return new ResponseEntity<>(trialBalanceService.getTrialBalacneByRegion(inputDate, region, isNil),
				HttpStatus.OK);
	}
	
	@GetMapping("/region-wise/{inputDate}/{region}")
	public ResponseEntity<Integer> generateTrialBalacneByRegion(@PathVariable("inputDate") String inputDate,
			@PathVariable("region") String region) {
		log.info("Inside TrialBalanceController#generateTrialBalacneByRegionWise");
		return new ResponseEntity<>(trialBalanceService.generateTrialBalacneByRegion(inputDate, region), HttpStatus.OK);
	}
	
	@GetMapping("/create-n-view-trial-bal-gl-wise/{mainglCd}/{subGlCd}/{inputDate}/{isNil}")
	public ResponseEntity<TrialBalanceReport> getTrialBalacneByGlCode(@PathVariable("mainglCd") String mainglCd ,
			@PathVariable("subGlCd") String subGlCd, @PathVariable("inputDate") String inputDate,
			@PathVariable("isNil") Boolean isNil) {
				log.info("Inside TrialBalanceController#getTrialBalacneByGlCodeWise");
		return new ResponseEntity<>(trialBalanceService.getTrialBalacneByGlCode(mainglCd, subGlCd, inputDate, isNil),
				HttpStatus.OK);
	}
	
	@GetMapping("/gl-wise/{mainglCd}/{subGlCd}/{inputDate}/{isNil}")
	public ResponseEntity<Integer> generateTrialBalacneByGlCode(@PathVariable("mainglCd") String mainglCd ,
			@PathVariable("subGlCd") String subGlCd, @PathVariable("inputDate") String inputDate) {
		log.info("Inside TrialBalanceController#generateTrialBalacneByGlCodeWise : {},{},{}", mainglCd,subGlCd, inputDate);
		return new ResponseEntity<>(trialBalanceService.generateTrialBalacneByGlCode(mainglCd, subGlCd,inputDate), HttpStatus.OK);
	}

	@GetMapping("/gl-loc-wise/{logicalLocation}/{mainglCd}/{subglCd}/{balanceDate}")
	public ResponseEntity<TrialBalance> getByLogicalLoc(@PathVariable("logicalLocation")  String logicalLocation, @PathVariable("balanceDate")  String balanceDate,@PathVariable("mainglCd")  String mainglCd,@PathVariable("subglCd")  String subglCd){
		log.info("Inside TrialBalanceController#getByLogicalLoc : {},{},{}", logicalLocation, balanceDate, mainglCd, subglCd);
		return new ResponseEntity<>(trialBalanceService.getByLogicalLoc(logicalLocation, balanceDate, mainglCd, subglCd, "", ""), HttpStatus.OK);

	}
	
	@GetMapping("/get-consolidate-tb-by-area/{areaType}/{area}/{inputDate}")
	public ResponseEntity<ConsTrialBaldtl> getConsolidateTrialBalance(@PathVariable("areaType") String areaType, @PathVariable("area") String area, @PathVariable("inputDate") String inputDate){
		log.info("Inside TrialBalanceController#getConsolidateTrialBalance : {},{},{}", areaType, area, inputDate);
		ConsTrialBaldtl consTrialBaldtl = new ConsTrialBaldtl();
		
		Map<String, List<ConsTrialBal>> consolidateTrialBalance = trialBalanceService.getConsolidateTrialBalance(areaType, area, inputDate);
		consTrialBaldtl.setConsTrialBalMap(consolidateTrialBalance);
		
		
		return new ResponseEntity<>(consTrialBaldtl, HttpStatus.OK);

	}
	
}
