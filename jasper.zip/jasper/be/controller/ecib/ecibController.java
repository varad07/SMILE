package in.ecgc.smile.erp.reporting.jasper.be.controller.ecib;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import in.ecgc.smile.erp.reporting.jasper.be.model.ecib.EcibInUR04;
import in.ecgc.smile.erp.reporting.jasper.be.model.ecib.EcibInUR16;
import in.ecgc.smile.erp.reporting.jasper.be.model.ecib.EcibRoxbo11;
import in.ecgc.smile.erp.reporting.jasper.be.model.ecib.EcibRoxbo12;
import in.ecgc.smile.erp.reporting.jasper.be.model.ecib.EcibWtUR63;
import in.ecgc.smile.erp.reporting.jasper.be.model.ecib.EcibWtUR64;
import in.ecgc.smile.erp.reporting.jasper.be.model.reports.Report;
import in.ecgc.smile.erp.reporting.jasper.be.service.ecib.EcibService;
import in.ecgc.smile.erp.reporting.jasper.be.utils.Pair;

@RestController
@RequestMapping("/ecib-reports")
public class ecibController {

	private static final Logger logger = LoggerFactory.getLogger(ecibController.class);

	@Autowired
	private EcibService ecibService;

	@PostMapping("/ECIB_ROXBO_R11/{FromYear}/{FromMonth}/{ToYear}/{ToMonth}")
	public ResponseEntity<List<EcibRoxbo11>> getListOfCoverTypeExporterMoreThan100Cr(
			@PathVariable("FromYear") int FromYear, @PathVariable("FromMonth") int FromMonth,
			@PathVariable("ToYear") int ToYear, @PathVariable("ToMonth") int ToMonth) {
		logger.info("Inside ECIB_ROXBO_R11 ecibController Controller");

		List<EcibRoxbo11> list = ecibService.getListOfCoverTypeExporterMoreThan100Cr(FromYear, FromMonth, ToYear,
				ToMonth);
		logger.info("List " + list);
		return new ResponseEntity<>(list, HttpStatus.OK);
	}

	@PostMapping("/ECIB_IN_U_R04/{fromDate}/{toDate}/{coverType}")
	public ResponseEntity<List<EcibInUR04>> getListOfInCoverIssueRegister(@PathVariable("fromDate") String fromDate,
			@PathVariable("toDate") String toDate, @PathVariable("coverType") String coverType) {
		logger.info("Inside ECIB_IN_U_RO4 ecibController Controller");

		List<EcibInUR04> list = ecibService.getListOfInCoverIssueRegister(fromDate, toDate, coverType);
		logger.info("List " + list);
		return new ResponseEntity<>(list, HttpStatus.OK);
	}

	@PostMapping("/ECIB_ROXBO_R12/{FromYear}/{FromMonth}/{ToYear}/{ToMonth}")
	public ResponseEntity<List<EcibRoxbo12>> getListOfExporterMoreThan100Cr(@PathVariable("FromYear") int FromYear,
			@PathVariable("FromMonth") int FromMonth, @PathVariable("ToYear") int ToYear,
			@PathVariable("ToMonth") int ToMonth) {
		logger.info("Inside ECIB_ROXBO_R12 ecibController Controller");

		List<EcibRoxbo12> list = ecibService.getListOfExporterMoreThan100Cr(FromYear, FromMonth, ToYear, ToMonth);
		logger.info("List " + list);
		return new ResponseEntity<>(list, HttpStatus.OK);
	}

	@PostMapping("/ECIB_IN_U_R16/{fromYear}/{fromMonth}/{toYear}/{toMonth}")
	public ResponseEntity<List<EcibInUR16>> getListEcibCoverAdjustedDeclaration(@PathVariable("fromYear") int fromYear,
			@PathVariable("fromMonth") int fromMonth, @PathVariable("toYear") int toYear,
			@PathVariable("toMonth") int toMonth) {
		logger.info("Inside ECIB_IN_U_R16 ecibController Controller");

		List<EcibInUR16> list = ecibService.getListEcibCoverAdjustedDeclaration(fromYear, fromMonth, toYear, toMonth);
		logger.info("List " + list);
		return new ResponseEntity<>(list, HttpStatus.OK);
	}
	
	
	@PostMapping("/ECIB_WT_U_R63/{fromYear}/{fromMonth}/{toYear}/{toMonth}")
	public ResponseEntity<ArrayList<List<EcibWtUR63>>> getListBankwiseRvPremiumReport(@PathVariable("fromYear") int fromYear,
			@PathVariable("fromMonth") int fromMonth, @PathVariable("toYear") int toYear,
			@PathVariable("toMonth") int toMonth) {
		logger.info("Inside ECIB_WT_U_R63 ecibController Controller");
		
		ArrayList<List<EcibWtUR63>> arrayList = new ArrayList<>();

		List<EcibWtUR63> list = ecibService.getListBankwiseRvPremiumReport(fromYear, fromMonth, toYear, toMonth);
		
		List<EcibWtUR63> list1 = ecibService.getListEcibTypewise(fromYear, fromMonth, toYear, toMonth);
		
		List<EcibWtUR63> list2 = ecibService.getListBankwise(fromYear, fromMonth, toYear, toMonth);
		
		logger.info("list" + list);
		logger.info("list1" + list1);
		logger.info("list2" + list2);
		
		arrayList.add(list);
		arrayList.add(list1);
		arrayList.add(list2);
		
		//logger.info("List " + list);
		return new ResponseEntity<>(arrayList, HttpStatus.OK);
	}
	
	
	@PostMapping("/ECIB_WT_U_R64/{fromYear}/{fromMonth}/{toYear}/{toMonth}")
	public ResponseEntity<ArrayList<List<EcibWtUR64>>> getListEcgcBranchwisePremiumEarned(@PathVariable("fromYear") int fromYear,
			@PathVariable("fromMonth") int fromMonth, @PathVariable("toYear") int toYear,
			@PathVariable("toMonth") int toMonth) {
		logger.info("Inside ECIB_WT_U_R64 ecibController Controller");
		
		ArrayList<List<EcibWtUR64>> arrayList = new ArrayList<>();

		List<EcibWtUR64> list = ecibService.getListEcgcBranchwisePremiumEarned(fromYear, fromMonth, toYear, toMonth);
		
		List<EcibWtUR64> list1 = ecibService.getListEcibTypewise1(fromYear, fromMonth, toYear, toMonth);
		
		List<EcibWtUR64> list2 = ecibService.getListBankwise1(fromYear, fromMonth, toYear, toMonth);
		
		logger.info("list" + list);
		logger.info("list1" + list1);
		logger.info("list2" + list2);
		
		arrayList.add(list);
		arrayList.add(list1);
		arrayList.add(list2);
		
		//logger.info("List " + list);s
		return new ResponseEntity<>(arrayList, HttpStatus.OK);
	}

	@GetMapping("/get-all-policy-types")
	public ResponseEntity<List<String>> getAllPolicyTypes() {
		return new ResponseEntity<>(ecibService.getAllPolicyTypes(), HttpStatus.OK);
	}
	
	@GetMapping("/get-year")
	public ResponseEntity<List<String>> getyear() {
		return new ResponseEntity<>(ecibService.getyear(), HttpStatus.OK);
	}
	
	@GetMapping("/get-month")
	public ResponseEntity<List<String>> getmonth() {
		return new ResponseEntity<>(ecibService.getmonth(), HttpStatus.OK);
	}
	
	@PostMapping("ECIB_WT_U_R36/{reportStatus}/{fromYear}/{toYear}/{fromMonth}/{toMonth}/{logicalLocationCode}/{coverTypes}")
	public ResponseEntity<Pair<Report, Exception>> getECIBWTUR36Report(
			@PathVariable("reportStatus") String reportStatus, @PathVariable("fromYear") int fromYear,
			@PathVariable("toYear") int toYear,@PathVariable("fromMonth") int fromMonth,
			@PathVariable("toMonth") int toMonth, @PathVariable("logicalLocationCode") String logicalLocationCode,
			@PathVariable("coverTypes") String coverTypes) {
		logger.info("Inside ECIB_WT_U_R36 BudController");
		return new ResponseEntity<>(
				ecibService.getECIBWTUR36Report(reportStatus, fromYear,toYear,fromMonth,toMonth, logicalLocationCode,
						coverTypes),
				HttpStatus.OK);
	}
	
	
	@PostMapping("ECIB_C_R49/{reportStatus}/{reportDate}")
	public ResponseEntity<Pair<Report, Exception>> getECIBCR49Report(
			@PathVariable("reportStatus") String reportStatus, @PathVariable("reportDate") String reportDate) {
		logger.info("Inside ECIB_C_R49 EcibController");
		System.err.println(reportDate);
		return new ResponseEntity<>(
				ecibService.getECIBCR49Report(reportStatus, reportDate),
				HttpStatus.OK);
	}
	
	@PostMapping("/report/")
	ResponseEntity<Pair<Report, Exception>> getECIBReport(@RequestParam Map<String, String> allRequestParams) {
		logger.info("Inside  ecibController");
		return new ResponseEntity<>(
				ecibService.generateReport(allRequestParams), HttpStatus.OK);
	}
	

	@PostMapping("/ECIB_WT_U_R25/{coverType}/{fromDate}/{toDate}")
	public ResponseEntity<Pair<Report, Exception>> getECIBWTUR25Report(@PathVariable("coverType") String coverType,
			@PathVariable("fromDate") String fromDate,@PathVariable("toDate") String toDate){

		logger.info("From Date" + fromDate + "To Date" + toDate +  "Cover Type" + coverType);

		logger.info("Inside ECIB_WT_U_R25 ECIBController Controller");

		return new ResponseEntity<>(ecibService.getECIBWTUR25Report(coverType,fromDate, toDate), HttpStatus.OK);

	}
	
	
	@PostMapping("/ECIB_MIS_R_08/{fromDate}/{toDate}")
	public ResponseEntity<Pair<Report, Exception>> getECIB_MIS_R_08Report(@PathVariable("fromDate") String fromDate,
																		  @PathVariable("toDate") String toDate){
		logger.info("Inside ECIB_MIS_R_08Controller");
		return new ResponseEntity<>(ecibService.getECIB_MIS_R_08Report(fromDate,toDate),HttpStatus.OK);
	}

}



