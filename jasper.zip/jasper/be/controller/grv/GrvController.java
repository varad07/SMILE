package in.ecgc.smile.erp.reporting.jasper.be.controller.grv;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.ecgc.smile.erp.reporting.jasper.be.model.grv.Grv_R01;
import in.ecgc.smile.erp.reporting.jasper.be.model.grv.PragatiReport;
import in.ecgc.smile.erp.reporting.jasper.be.service.grv.GrvService;

@Controller
@RestController
@RequestMapping("/grv-reports")
public class GrvController {
	
	@Autowired
	PragatiReport pragatiReport; 
	
	@Autowired
	private GrvService grvService;

	private static final Logger logger = LoggerFactory.getLogger(GrvController.class);
	
	
	
	
	@PostMapping("/GRV_R04/{month}/{year}")
	public ResponseEntity<List<PragatiReport>> getPragatiReport(@PathVariable("month") int month,@PathVariable("year") int year ) {
		logger.info("Inside getPragatiReport GrvController Controller");
	
		List<PragatiReport> list = grvService.getPragatiReport(month,year);
		//logger.info("List of Object {}" +list);
		return new ResponseEntity<>(list, HttpStatus.OK);
	}
	
	@PostMapping("/grv_g01/{year}")
	public ResponseEntity<List<Grv_R01>> getGrv_R01(@PathVariable("year") int year ) {
		logger.info("Inside getGrv_R01 GrvController Controller");
	
		List<Grv_R01> list = grvService.getGrv_R01(year);
		
		return new ResponseEntity<>(list, HttpStatus.OK);
	}
}
