package in.ecgc.smile.erp.reporting.jasper.be.controller.payroll;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.ecgc.smile.erp.reporting.jasper.be.service.payroll.PayrollService;


@RestController
@RequestMapping("/payroll-reports")
public class payrollController {
	
	private static final Logger logger = LoggerFactory.getLogger(payrollController.class);

	@Autowired
	private PayrollService payrollService;

}
