package in.ecgc.smile.erp.reporting.jasper.be.controller.common;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.ecgc.smile.erp.reporting.jasper.be.service.common.CommonService;

@RestController
@RequestMapping("/")
public class CommonController {

    @Autowired
    CommonService commonService;

    @GetMapping("/get-all-logical-location-code")
    public ResponseEntity<List<Map<String,Object>>> getAllLogicalLocationCodes() {
        return new ResponseEntity<>(commonService.getAllLogicalLocationCodes(), HttpStatus.OK);
    }

    @GetMapping("/get-all-country")
    public ResponseEntity<List<Map<String,Object>>> getAllCountries() {
        return new ResponseEntity<>(commonService.getAllCountries(), HttpStatus.OK);
    }
}
