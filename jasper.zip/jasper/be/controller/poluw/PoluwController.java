package in.ecgc.smile.erp.reporting.jasper.be.controller.poluw;

import java.time.LocalDate;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import in.ecgc.smile.erp.reporting.jasper.be.model.poluw.RegionBranch;
import in.ecgc.smile.erp.reporting.jasper.be.model.poluw.poluw_011;
import in.ecgc.smile.erp.reporting.jasper.be.model.poluw.poluw_013;
import in.ecgc.smile.erp.reporting.jasper.be.model.reports.Report;
import in.ecgc.smile.erp.reporting.jasper.be.service.poluw.PoluwService;
import in.ecgc.smile.erp.reporting.jasper.be.utils.Pair;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/poluw")
public class PoluwController {

	@Autowired
	private PoluwService poluwService;

	private static final Logger logger = LoggerFactory.getLogger(PoluwController.class);

	@GetMapping("/policy-type-list")
	public ResponseEntity<List<String>> getAllPolicyTypes() {
		logger.info("Inside poluwController #getAllPolicyTypes");
		return new ResponseEntity<>(poluwService.getAllPolicyTypes(), HttpStatus.OK);
	}

	@ApiOperation(value = "To GET Premium Paid Details Based on Product ID and StartDt and EndDt", httpMethod = "GET")
	@ApiResponses({ @ApiResponse(code = 200, message = "Premium Paid Details Fetched Successfully"),
			@ApiResponse(code = 500, message = "Internal Server error"),
			@ApiResponse(code = 404, message = "Premium Details Not Found"),
			@ApiResponse(code = 400, message = "Bad Request"), @ApiResponse(code = 403, message = "Forbidden") })

	@GetMapping("/policy-type-list11/{policyType}/{fromDt}/{toDt}")
	public ResponseEntity<List<poluw_011>> getPremiumAdjusted(
			@ApiParam(value = "policyType") @PathVariable("policyType") List<String> polTypeList,
			@ApiParam(value = "fromDt") @PathVariable("fromDt") @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate fromDt,
			@ApiParam(value = "toDt") @PathVariable("toDt") @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate toDt) {

		List<poluw_011> list = poluwService.getPremiumAdjusted(polTypeList, fromDt, toDt);
		logger.info("final premiumAdjustedDtl list is here: {}", list);
		// List<PremiumPaidDetails> result = service.getPremiumPaidDetails(polNum,
		// productId, startDt, endDt);

		return new ResponseEntity<>(list, HttpStatus.OK);
	}

	@GetMapping("/exposure-policies-riskvalue-prumadjusted-regionwise/{fromDt}/{toDt}")
	public ResponseEntity<List<poluw_013>> getExpoBasedRiskValPremiumAdjusted(
			@ApiParam(value = "fromDt") @PathVariable("fromDt") @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate fromDt,
			@ApiParam(value = "toDt") @PathVariable("toDt") @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate toDt) {
		List<poluw_013> list = poluwService.getExpoBasedRiskValPremiumAdjusted(fromDt, toDt);
		logger.info("final premiumAdjustedDtl list is here: {}", list);
		// List<PremiumPaidDetails> result = service.getPremiumPaidDetails(polNum,
		// productId, startDt, endDt);

		return new ResponseEntity<>(list, HttpStatus.OK);
	}

	@GetMapping("/get-region")
	public ResponseEntity<List<String>> getRegion() {
		return new ResponseEntity<>(poluwService.getRegion(), HttpStatus.OK);
	}

	
	@PostMapping("/POL_ST_A_UW_012/{fromDate}/{toDate}/{region}/{policyType}")
	public ResponseEntity<Pair<Report, Exception>> getPOLSTAUW12Report(@PathVariable("fromDate") String fromDate,
			@PathVariable("toDate") String toDate, @PathVariable("region") String region,
			@PathVariable("policyType") String policyType) {
		
		    logger.info("From Date" + fromDate + "To Date" + toDate + "region" + region + "Policy Type" + policyType );
		
			logger.info("Inside POLSTAUW12 POLUWController Controller");

		return new ResponseEntity<>(poluwService.getPOLSTAUW12Report(fromDate, toDate, region, policyType), HttpStatus.OK);

	}
	
	
	@PostMapping("/POL_ST_A_UW_019/")
	public ResponseEntity<Pair<Report, Exception>> getPOLUW19Report(@RequestParam("fromDt") String fromDt,
			@RequestParam("toDate") String toDt) {

		logger.info("From Date" + fromDt + "To Date" + toDt);

		logger.info("Inside POL_ST_A_UW_019 POLUWController Controller");

		return new ResponseEntity<>(poluwService.getPOLUW19Report(fromDt, toDt), HttpStatus.OK);

	}
	
	
	@PostMapping("/POL_ST_A_UW_010/{inputDate}")
	public ResponseEntity<Pair<Report, Exception>> getPOL_ST_A_UW_10(@PathVariable("inputDate") String inputDate){
		logger.info("Inside POL_ST_A_UW_010 BudController");
		return new ResponseEntity<>(poluwService.getPOL_ST_A_UW_10(inputDate),HttpStatus.OK);
	}
	
	@GetMapping("/getRB")
	public ResponseEntity<List<RegionBranch>> getRegionBranchInfo(){
		
		return new ResponseEntity<>(poluwService.getRegionBranchInfo(),HttpStatus.OK);
	}
	
	@PostMapping("/POL_ST_A_UW_19/{fromDate}/{toDate}/{reportStatus}/{input}")
	public ResponseEntity<Pair<Report, Exception>> getPOL_ST_A_UW_019(@PathVariable("fromDate") String fromDate,
																	  @PathVariable("toDate") String toDate,
																	  @PathVariable("reportStatus")String reportStatus,
																	  @PathVariable("input") String input){
		logger.info("Inside POL_ST_A_UW_019 BudController");
		return new ResponseEntity<>(poluwService.getPOL_ST_A_UW_019(fromDate,toDate,reportStatus,input),HttpStatus.OK);
	}
}
