package in.ecgc.smile.erp.reporting.jasper.be.controller.cud;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.ecgc.smile.erp.reporting.jasper.be.model.cud.CUDR09;
import in.ecgc.smile.erp.reporting.jasper.be.model.cud.CUDR10;
import in.ecgc.smile.erp.reporting.jasper.be.service.cud.CudService;



@RestController
@RequestMapping("/cud-reports")
public class CudController {
	
	private static final Logger logger = LoggerFactory.getLogger(CudController.class);
	
	@Autowired
	private CudService cudService;
	
	@PostMapping("/CUD_R09/{fromDate}/{toDate}")
	public ResponseEntity<List<CUDR09>> getListCudR09(@PathVariable("fromDate") String fromDate,@PathVariable("toDate") String toDate ) {
		logger.info("Inside CUD_R09 MktgController Controller");
	
		List<CUDR09> list = cudService.getListCudR09(fromDate,toDate);
		logger.info("List " + list);
		return new ResponseEntity<>(list, HttpStatus.OK);
	}
	
	@PostMapping("/CUD_R10/{fromDate}/{toDate}")
	public ResponseEntity<List<CUDR10>> getListCudR10(@PathVariable("fromDate") String fromDate,@PathVariable("toDate") String toDate ) {
		logger.debug("Inside CUD_R10 MktgController Controller");
	
		List<CUDR10> list = cudService.getListCudR10(fromDate,toDate);
		
		return new ResponseEntity<>(list, HttpStatus.OK);
	}

}
