package in.ecgc.smile.erp.reporting.jasper.be.controller.bud;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import in.ecgc.smile.erp.reporting.jasper.be.model.bud.BudR02;
import in.ecgc.smile.erp.reporting.jasper.be.model.bud.BudR09;
import in.ecgc.smile.erp.reporting.jasper.be.model.bud.BudR16;
import in.ecgc.smile.erp.reporting.jasper.be.model.bud.BudR17;
import in.ecgc.smile.erp.reporting.jasper.be.model.bud.BudR18;
import in.ecgc.smile.erp.reporting.jasper.be.model.bud.BudR20;
import in.ecgc.smile.erp.reporting.jasper.be.model.bud.BudR21;
import in.ecgc.smile.erp.reporting.jasper.be.model.bud.BudR23;
import in.ecgc.smile.erp.reporting.jasper.be.model.bud.BudR40;
import in.ecgc.smile.erp.reporting.jasper.be.model.bud.BudR48_1;
import in.ecgc.smile.erp.reporting.jasper.be.model.bud.BudR48_2;
import in.ecgc.smile.erp.reporting.jasper.be.model.bud.BudR49;
import in.ecgc.smile.erp.reporting.jasper.be.model.bud.BudR49_1;
import in.ecgc.smile.erp.reporting.jasper.be.model.reports.Report;
import in.ecgc.smile.erp.reporting.jasper.be.service.bud.BudService;
import in.ecgc.smile.erp.reporting.jasper.be.utils.Pair;

@RestController
@RequestMapping("/bud-reports")
public class BudController {

	@Autowired
	private BudR21 budR21;

	@Autowired
	private BudService budService;

	private static final Logger logger = LoggerFactory.getLogger(BudController.class);

	@PostMapping("/BUD_R21/{lastUpdatedDateFrom}/{lastUpdatedDateTo}")
	public ResponseEntity<List<BudR21>> getListBUDR21(@PathVariable("lastUpdatedDateFrom") String lastUpdatedDateFrom,
			@PathVariable("lastUpdatedDateTo") String lastUpdatedDateTo) {
		logger.info("Inside BUD_R21 BudController Controller");

		return new ResponseEntity<>(budService.getListBUDR21(lastUpdatedDateFrom, lastUpdatedDateTo), HttpStatus.OK);

	}

	@PostMapping("/BUD_R49/{fromDate}/{toDate}")
	public ResponseEntity<List<BudR49>> getListBUDR49(@PathVariable("fromDate") String fromDate,
			@PathVariable("toDate") String toDate) {
		logger.info("Inside BUD_R49 BudController Controller");

		return new ResponseEntity<>(budService.getListBUDR49(fromDate, toDate), HttpStatus.OK);

	}

	@PostMapping("/BUD_R49_1/{fromDate}/{toDate}")
	public ResponseEntity<List<BudR49_1>> getListBUDR49_1(@PathVariable("fromDate") String fromDate,
			@PathVariable("toDate") String toDate) {
		logger.info("Inside BUD_R49_1 BudController Controller");

		return new ResponseEntity<>(budService.getListBUDR49_1(fromDate, toDate), HttpStatus.OK);

	}

	@PostMapping("/BUD_R02/{fromDate}/{toDate}")
	public ResponseEntity<List<BudR02>> getListBUDR02(@PathVariable("fromDate") String fromDate,
			@PathVariable("toDate") String toDate) {
		logger.info("Inside BUD_R02 BudController Controller");

		return new ResponseEntity<>(budService.getListBUDR02(fromDate, toDate), HttpStatus.OK);

	}

	@PostMapping("/BUD_R16/{fromDate}/{toDate}")
	public ResponseEntity<List<BudR16>> getListBUDR16(@PathVariable("fromDate") String fromDate,
			@PathVariable("toDate") String toDate) {
		logger.info("Inside BUD_R16 BudController Controller");

		return new ResponseEntity<>(budService.getListBUDR16(fromDate, toDate), HttpStatus.OK);

	}

	@PostMapping("/BUD_R17/{fromDate}/{toDate}")
	public ResponseEntity<List<BudR17>> getListBUDR17(@PathVariable("fromDate") String fromDate,
			@PathVariable("toDate") String toDate) {
		logger.info("Inside BUD_R17 BudController Controller");

		return new ResponseEntity<>(budService.getListBUDR17(fromDate, toDate), HttpStatus.OK);

	}

	@PostMapping("/BUD_R18/{fromDate}/{toDate}")
	public ResponseEntity<ArrayList<List<BudR18>>> getListBUDR18(@PathVariable("fromDate") String fromDate,
			@PathVariable("toDate") String toDate) {
		logger.info("Inside BUD_R18 BudController Controller");

		ArrayList<List<BudR18>> arrayList = new ArrayList<>();

		List<BudR18> list = budService.getListBUDR18(fromDate, toDate);
		List<BudR18> list1 = budService.getListBUDR18_1(fromDate, toDate);

		logger.info("list" + list);
		logger.info("list1" + list1);

		arrayList.add(list);
		arrayList.add(list1);

		return new ResponseEntity<>(arrayList, HttpStatus.OK);

	}

	@PostMapping("/BUD_R20/{fromDate}/{toDate}")
	public ResponseEntity<ArrayList<List<BudR20>>> getListBUDR20(@PathVariable("fromDate") String fromDate,
			@PathVariable("toDate") String toDate) {
		logger.info("Inside BUD_R20 BudController Controller");

		ArrayList<List<BudR20>> arrayList = new ArrayList<>();

		List<BudR20> list = budService.getListBUDR20(fromDate, toDate);
		List<BudR20> list1 = budService.getListBUDR20_1(fromDate, toDate);

		logger.info("list" + list);
		logger.info("list1" + list1);

		arrayList.add(list);
		arrayList.add(list1);

		return new ResponseEntity<>(arrayList, HttpStatus.OK);

	}

	@PostMapping("/BUD_R23/{fromDate}/{toDate}/{claType}")
	public ResponseEntity<List<BudR23>> getListBUDR23(@PathVariable("fromDate") String fromDate,
			@PathVariable("toDate") String toDate, @PathVariable("claType") String claType) {
		logger.info("Inside BUD_R23 BudController Controller");

		budService.getListBUDR23(fromDate, toDate, claType);
		return new ResponseEntity<>(budService.getListBUDR23(fromDate, toDate, claType), HttpStatus.OK);

	}

	@PostMapping("/BUD_R09/{fromDate}/{toDate}/{reportStatus}")
	public ResponseEntity<List<BudR09>> getListBUDR09(@PathVariable("fromDate") String fromDate,
			@PathVariable("toDate") String toDate, @PathVariable("reportStatus") String reportStatus) {
		logger.info("Inside BUD_R09 BudController Controller");

		return new ResponseEntity<>(budService.getListBUDR09(fromDate, toDate, reportStatus), HttpStatus.OK);

	}

	@PostMapping("/BUD_R40/{fromDate}/{toDate}")
	public ResponseEntity<List<BudR40>> getListBUDR40(@PathVariable("fromDate") String fromDate,
			@PathVariable("toDate") String toDate) {
		logger.info("Inside BUD_R40 BudController Controller");

		return new ResponseEntity<>(budService.getListBUDR40(fromDate, toDate), HttpStatus.OK);

	}

	@PostMapping("/BUD_R48_1/{fromDate}/{toDate}/{reportStatus}")
	public ResponseEntity<List<BudR48_1>> getListBUDR48_1(@PathVariable("fromDate") String fromDate,
			@PathVariable("toDate") String toDate, @PathVariable("reportStatus") String reportStatus) {
		logger.info("Inside BUD_R48_1 BudController Controller");

		return new ResponseEntity<>(budService.getListBUDR48_1(fromDate, toDate, reportStatus), HttpStatus.OK);

	}

	@PostMapping("/BUD_R48_2/{fromDate}/{toDate}/{reportStatus}")
	public ResponseEntity<List<BudR48_2>> getListBUDR48_2(@PathVariable("fromDate") String fromDate,
			@PathVariable("toDate") String toDate, @PathVariable("reportStatus") String reportStatus) {
		logger.info("Inside BUD_R48_2 BudController Controller");

		return new ResponseEntity<>(budService.getListBUDR48_2(fromDate, toDate, reportStatus), HttpStatus.OK);

	}

	@PostMapping("/BUD_R04/{reportStatus}/{fromDate}/{toDate}/{cellCodeFrom}/{cellCodeTo}/{logicalLocationCode}")
	public ResponseEntity<Pair<Report, Exception>> getBudR04Report(@PathVariable("reportStatus") String reportStatus,
			@PathVariable("fromDate") String fromDate, @PathVariable("toDate") String toDate,
			@PathVariable("cellCodeFrom") String cellCodeFrom, @PathVariable("cellCodeTo") String cellCodeTo,
			@PathVariable String logicalLocationCode) {
		logger.info("Inside BUD_R04 BudController");
		return new ResponseEntity<>(
				budService.getBudR04(reportStatus, fromDate, toDate, cellCodeFrom, cellCodeTo, logicalLocationCode),
				HttpStatus.OK);

	}

	@PostMapping("/BUD_R05/{reportStatus}/{fromDate}/{toDate}/{cellCodeFrom}/{cellCodeTo}")
	public ResponseEntity<Pair<Report, Exception>> getListBudR05(@PathVariable("reportStatus") String reportStatus,
			@PathVariable("fromDate") String fromDate, @PathVariable("toDate") String toDate,
			@PathVariable("cellCodeFrom") String cellCodeFrom, @PathVariable("cellCodeTo") String cellCodeTo) {
		logger.info("Inside BUD_R05 BudController");
		return new ResponseEntity<>(budService.getListBudR05(reportStatus, fromDate, toDate, cellCodeFrom, cellCodeTo),
				HttpStatus.OK);
	}

	@PostMapping("/BUD_R48/{reportStatus}/{fromDate}/{toDate}/{countryName}/{decisionStatus}/{defaultStat}")
	public ResponseEntity<Pair<Report, Exception>> getBUD48Report(@PathVariable("reportStatus") String reportStatus,
			@PathVariable("fromDate") String fromDate, @PathVariable("toDate") String toDate,
			@PathVariable("countryName") String countryName, @PathVariable("decisionStatus") String decisionStatus,
			@PathVariable("defaultStat") String defaultStat) {
		logger.info("Inside BUD_R48 BudController");
		return new ResponseEntity<>(budService.getBUD48Report(reportStatus, fromDate, toDate,
				countryName, decisionStatus, defaultStat),
				HttpStatus.OK);
	}

	@PostMapping("/BUD_R08/{reportStatus}/{fromDate}/{toDate}/{proposalStatus}/{logicalLocationCode}/{cellCode}")
	public ResponseEntity<Pair<Report, Exception>> getBUD08Report(@PathVariable("reportStatus") String reportStatus,
			@PathVariable("fromDate") String fromDate, @PathVariable("toDate") String toDate,
			@PathVariable("proposalStatus") String proposalStatus,
			@PathVariable("logicalLocationCode") String logicalLocationCode,
			@PathVariable("cellCode") String cellCode) {
		logger.info("Inside BUD_R08 BudController");
		return new ResponseEntity<>(
				budService.getBUD08Report(reportStatus, fromDate, toDate, proposalStatus, logicalLocationCode,
						cellCode),
				HttpStatus.OK);
	}

	@PostMapping("/BUD_R67/{amountFrom}/{amountTo}/{cellNumber}/{countryName}/{reportStatus}")
	public ResponseEntity<Pair<Report, Exception>> getListBudR67(@PathVariable("amountFrom") String amountFrom,
			@PathVariable("amountTo") String amountTo, @PathVariable("cellNumber") String cellNumber,
			@PathVariable("countryName") String countryName, @PathVariable("reportStatus") String reportStatus) {
		logger.info("Inside BUD_R67 BudController");
		return new ResponseEntity<>(
				budService.getListBudR67(amountFrom, amountTo, cellNumber, countryName, reportStatus),
				HttpStatus.OK);
	}

	@PostMapping("/BUD_R13/{reportStatus}/{fromDate}/{toDate}")
	ResponseEntity<Pair<Report, Exception>> getBUD13Report(@PathVariable("reportStatus") String reportStatus,
			@PathVariable("fromDate") String fromDate, @PathVariable("toDate") String toDate) {
		logger.info("Inside BUD_R13 BudController");
		return new ResponseEntity<>(budService.getBUD13Report(reportStatus, fromDate, toDate),
				HttpStatus.OK);
	}

	@PostMapping("/BUD_R29/{policyNo}/{buyerCode}/{buyerCountry}/{fromDate}")
	public ResponseEntity<Pair<Report, Exception>> getBUD29Report(@PathVariable("policyNo") String policyNo,
			@PathVariable("buyerCode") String buyerCode, @PathVariable("buyerCountry") String buyerCountry,
			@PathVariable("fromDate") String fromDate) {
		logger.info("Inside BUD_R29 BudController");
		return new ResponseEntity<>(
				budService.getBUD29Report(policyNo, buyerCode, buyerCountry, fromDate), HttpStatus.OK);
	}

	@PostMapping("/BUD_R69/{reportStatus}/{cellCode}")
	ResponseEntity<Pair<Report, Exception>> getBUD69Report(@PathVariable("reportStatus") String reportStatus,
			@PathVariable("cellCode") String cellCode) {
		logger.info("Inside BUD_R69 BudController");
		return new ResponseEntity<>(
				budService.getBUD69Report(reportStatus, cellCode), HttpStatus.OK);
	}

	@PostMapping("/BUD_R59")
	ResponseEntity<Pair<Report, Exception>> getBUD59Report(@RequestParam Map<String, String> allRequestParams) {
		logger.info("Inside BUD_R59 BudController");
		Map<String, Object> reqParams = new HashMap<>(allRequestParams);

		reqParams.put("buyerCountryName",
				Arrays.asList(String.valueOf(reqParams.get("buyerCountryName")).trim().split(",")));
		reqParams.put("bankCountryName",
				Arrays.asList(String.valueOf(reqParams.get("bankCountryName")).trim().split(",")));

		return new ResponseEntity<>(
				budService.generateBUD59Report(reqParams), HttpStatus.OK);
	}

	@PostMapping("/report/")
	ResponseEntity<Pair<Report, Exception>> getBUDReport(@RequestParam Map<String, String> allRequestParams) {
		logger.info("Inside bud report BudController");
		return new ResponseEntity<>(
				budService.generateReport(allRequestParams), HttpStatus.OK);
	}

	@GetMapping("/get-all-cell-codes")
	public ResponseEntity<List<String>> getAllBudCellCodes() {
		return new ResponseEntity<>(budService.getAllBudCellCodes(), HttpStatus.OK);
	}

	@GetMapping("/get-cla144-policies")
	public ResponseEntity<List<Map<String, String>>> getCla144Policies(@RequestParam Map<String, String> query) {
		return new ResponseEntity<>(budService.getAllCla144Policies(query), HttpStatus.OK);
	}

	@GetMapping("/get-budR59-all-active-approved-limits")
	public ResponseEntity<List<Map<String, Object>>> getAllActiveApprovedLimits(@RequestParam String coverCatId,
			@RequestParam String logicalLocationCode) {
		return new ResponseEntity<>(budService.getAllActiveApprovedLimits(coverCatId, logicalLocationCode),
				HttpStatus.OK);
	}

	@GetMapping("/get-budR59-all-active-approved-limits-bank")
	public ResponseEntity<List<Map<String, Object>>> getAllActiveApprovedLimitsBank(@RequestParam String coverCatId,
			@RequestParam String logicalLocationCode) {
		return new ResponseEntity<>(budService.getAllActiveApprovedLimitsBank(coverCatId, logicalLocationCode),
				HttpStatus.OK);
	}

	@GetMapping("/get-budR59-all-active-approved-limits-buyer")
	public ResponseEntity<List<Map<String, Object>>> getAllActiveApprovedLimitsBuyer(@RequestParam String coverCatId,
			@RequestParam String logicalLocationCode) {
		return new ResponseEntity<>(budService.getAllActiveApprovedLimitsBuyer(coverCatId, logicalLocationCode),
				HttpStatus.OK);
	}

	@GetMapping("/get-budR59-active-approved-limits-bank")
	public ResponseEntity<List<Map<String, Object>>> getActiveApprovedLimitsBank(@RequestParam String coverCatId,
			@RequestParam String logicalLocationCode, @RequestParam String countryName) {
		return new ResponseEntity<>(
				budService.getActiveApprovedLimitsBank(coverCatId, logicalLocationCode, countryName),
				HttpStatus.OK);
	}

	@GetMapping("/get-budR59-active-approved-limits-buyer")
	public ResponseEntity<List<Map<String, Object>>> getActiveApprovedLimitsBuyer(@RequestParam String coverCatId,
			@RequestParam String logicalLocationCode, @RequestParam String countryName) {
		return new ResponseEntity<>(
				budService.getActiveApprovedLimitsBuyer(coverCatId, logicalLocationCode, countryName),
				HttpStatus.OK);
	}

}
