package in.ecgc.smile.erp.reporting.jasper.be.model.cs;

import java.time.LocalDate;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;

public class PlWiseSummary {

	private String logicallocCd;
	private String mainglCd;
	private String subglCd;
	private String plCd;
	private List<String> plCdList;
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate fromDt;
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate toDt;
	public String getLogicallocCd() {
		return logicallocCd;
	}
	public void setLogicallocCd(String logicallocCd) {
		this.logicallocCd = logicallocCd;
	}
	public String getMainglCd() {
		return mainglCd;
	}
	public void setMainglCd(String mainglCd) {
		this.mainglCd = mainglCd;
	}
	public String getSubglCd() {
		return subglCd;
	}
	public void setSubglCd(String subglCd) {
		this.subglCd = subglCd;
	}
	public String getPlCd() {
		return plCd;
	}
	public void setPlCd(String plCd) {
		this.plCd = plCd;
	}
	public List<String> getPlCdList() {
		return plCdList;
	}
	public void setPlCdList(List<String> plCdList) {
		this.plCdList = plCdList;
	}
	public LocalDate getFromDt() {
		return fromDt;
	}
	public void setFromDt(LocalDate fromDt) {
		this.fromDt = fromDt;
	}
	public LocalDate getToDt() {
		return toDt;
	}
	public void setToDt(LocalDate toDt) {
		this.toDt = toDt;
	}
	@Override
	public String toString() {
		return "PlWiseSummary [logicallocCd=" + logicallocCd + ", mainglCd=" + mainglCd + ", subglCd=" + subglCd
				+ ", plCd=" + plCd + ", plCdList=" + plCdList + ", fromDt=" + fromDt + ", toDt=" + toDt + "]";
	}
	
	

}
