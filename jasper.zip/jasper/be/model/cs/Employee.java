package in.ecgc.smile.erp.reporting.jasper.be.model.cs;

import java.util.Date;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;

import lombok.Data;


@Data
public class Employee {

	
	/* Employee Id which is used for Employee reference */
	private Integer empNo;
	
	private String prefix;
	
	/* Employee First Name*/
	//@Pattern(regexp="^[A-Za-z]+$", message="Enter Valid First Name")  
	private String firstName;
	
	/* Employee Middle Name*/
	private String midName;
	
	/* Employee Last Name*/
	//@Pattern(regexp="^[A-Za-z]+$", message="Enter Valid Last Name")
	private String lastName;
	
	private String empAlias;
	
	private String gender;
	
	private String birthPlace;
	
	private String nationality;
	
	/* Employee DOB*/
	//@NotNull(message = "Please provide a date")
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private Date dob;
	
	/* Employee Confirmation date */
	//@NotNull(message = "Please provide a date")
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private Date confDate;
	
	private String bloodGrp;
	
	/* Employee Date of joining*/
	//@NotNull(message = "Please provide a date")
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private Date doj;
	
	/* Employee Type*/
	private String empType;

	/* Employee Location */
	/*
	 * @NotBlank(message="Please provide Location") private String logicalLocCd;
	 */
	
	/* Employee office branch code */
	//@NotBlank(message="Please Select Employee Branch Code")
	private String branchCode;
	
	private String branchDesc;
	
	/* Employee office region code */
	//@NotBlank(message="Please Select Employee Region Code")
	private String regionCode;
	
	private String regionName;
	
	//@DateTimeFormat(pattern="yyyy-MM-dd")
	private Date probToDate;
	
	/* Employee rank */
	//@NotBlank(message="Please Select Employee Rank")
	private String rankId;
	
	private String rankDesc;
	
	/* Employee Designation */
	//@NotBlank(message="Please Select Employee Designation")
	private String desigId;
	
	private String desigDesc;
	
	private String joinDesigId;
	
	private String joinDesigDesc;
	
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private Date lastPrmDate;
	
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private Date lastIncDate;
	
	/* Employee category */
	//@NotBlank(message="Please Select Employee Categoty")
	private String categoryCd;
	
	private String categoryDesc;
	
	/* Employee religion */
	private String religion;
	
	private String classCd;
	
	/* Employee handicap flag */
	//@NotBlank(message="Please Select Employee Handicap Field  ")
	private String handicapFlg;
	
	/* Employee disability percentage */
	private long disabilityPerc;
	
	/* Employee handicap description */
	private String handicapDesc;
	
	/* Employee Status */
	private String statusCd;
	
	private String empStatusDesc;
	
	private String divCd;
	
	private String divDesc;
	
	private String deptCd;
	
	private String deptDesc;
	
	private String sectorCd;
	
	private String sectorDesc;
	
	private Integer reportingTo;
	
	/* Salary Details */
	private Double prsntBasicSal;
	
	private String salPayMode;
	
	private Double fixedDa;
	
	private Double persAllowance;
	
	private String permDeputation;
	
	private String payrollEmpStatus;
	
	private String createdBy;
	
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private Date createdDt;
	
	private String lastUpdatedBy;
	
	//private String designation;
	
	private String handicapChildFlag;
	
	private String compAccom;
	
	private String spclConvFlag;
	
	private String creditSocHsgFlag;
	
	private Date csJoiningDt;
	
	private String isGtiOpted;
	
	private String pensionOpted;
	
	private String npsOpted;
	
	@DateTimeFormat(pattern="yyyy-MM-dd")
	Date lastUpdatedDt;
	
	private String officeId;
	
	private String officeDesc;

	public Integer getEmpNo() {
		return empNo;
	}

	public void setEmpNo(Integer empNo) {
		this.empNo = empNo;
	}

	public String getPrefix() {
		return prefix;
	}

	public void setPrefix(String prefix) {
		this.prefix = prefix;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMidName() {
		return midName;
	}

	public void setMidName(String midName) {
		this.midName = midName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmpAlias() {
		return empAlias;
	}

	public void setEmpAlias(String empAlias) {
		this.empAlias = empAlias;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getBirthPlace() {
		return birthPlace;
	}

	public void setBirthPlace(String birthPlace) {
		this.birthPlace = birthPlace;
	}

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public Date getConfDate() {
		return confDate;
	}

	public void setConfDate(Date confDate) {
		this.confDate = confDate;
	}

	public String getBloodGrp() {
		return bloodGrp;
	}

	public void setBloodGrp(String bloodGrp) {
		this.bloodGrp = bloodGrp;
	}

	public Date getDoj() {
		return doj;
	}

	public void setDoj(Date doj) {
		this.doj = doj;
	}

	public String getEmpType() {
		return empType;
	}

	public void setEmpType(String empType) {
		this.empType = empType;
	}

	public String getBranchCode() {
		return branchCode;
	}

	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}

	public String getBranchDesc() {
		return branchDesc;
	}

	public void setBranchDesc(String branchDesc) {
		this.branchDesc = branchDesc;
	}

	public String getRegionCode() {
		return regionCode;
	}

	public void setRegionCode(String regionCode) {
		this.regionCode = regionCode;
	}

	public String getRegionName() {
		return regionName;
	}

	public void setRegionName(String regionName) {
		this.regionName = regionName;
	}

	public Date getProbToDate() {
		return probToDate;
	}

	public void setProbToDate(Date probToDate) {
		this.probToDate = probToDate;
	}

	public String getRankId() {
		return rankId;
	}

	public void setRankId(String rankId) {
		this.rankId = rankId;
	}

	public String getRankDesc() {
		return rankDesc;
	}

	public void setRankDesc(String rankDesc) {
		this.rankDesc = rankDesc;
	}

	public String getDesigId() {
		return desigId;
	}

	public void setDesigId(String desigId) {
		this.desigId = desigId;
	}

	public String getDesigDesc() {
		return desigDesc;
	}

	public void setDesigDesc(String desigDesc) {
		this.desigDesc = desigDesc;
	}

	public String getJoinDesigId() {
		return joinDesigId;
	}

	public void setJoinDesigId(String joinDesigId) {
		this.joinDesigId = joinDesigId;
	}

	public String getJoinDesigDesc() {
		return joinDesigDesc;
	}

	public void setJoinDesigDesc(String joinDesigDesc) {
		this.joinDesigDesc = joinDesigDesc;
	}

	public Date getLastPrmDate() {
		return lastPrmDate;
	}

	public void setLastPrmDate(Date lastPrmDate) {
		this.lastPrmDate = lastPrmDate;
	}

	public Date getLastIncDate() {
		return lastIncDate;
	}

	public void setLastIncDate(Date lastIncDate) {
		this.lastIncDate = lastIncDate;
	}

	public String getCategoryCd() {
		return categoryCd;
	}

	public void setCategoryCd(String categoryCd) {
		this.categoryCd = categoryCd;
	}

	public String getCategoryDesc() {
		return categoryDesc;
	}

	public void setCategoryDesc(String categoryDesc) {
		this.categoryDesc = categoryDesc;
	}

	public String getReligion() {
		return religion;
	}

	public void setReligion(String religion) {
		this.religion = religion;
	}

	public String getClassCd() {
		return classCd;
	}

	public void setClassCd(String classCd) {
		this.classCd = classCd;
	}

	public String getHandicapFlg() {
		return handicapFlg;
	}

	public void setHandicapFlg(String handicapFlg) {
		this.handicapFlg = handicapFlg;
	}

	public long getDisabilityPerc() {
		return disabilityPerc;
	}

	public void setDisabilityPerc(long disabilityPerc) {
		this.disabilityPerc = disabilityPerc;
	}

	public String getHandicapDesc() {
		return handicapDesc;
	}

	public void setHandicapDesc(String handicapDesc) {
		this.handicapDesc = handicapDesc;
	}

	public String getStatusCd() {
		return statusCd;
	}

	public void setStatusCd(String statusCd) {
		this.statusCd = statusCd;
	}

	public String getEmpStatusDesc() {
		return empStatusDesc;
	}

	public void setEmpStatusDesc(String empStatusDesc) {
		this.empStatusDesc = empStatusDesc;
	}

	public String getDivCd() {
		return divCd;
	}

	public void setDivCd(String divCd) {
		this.divCd = divCd;
	}

	public String getDivDesc() {
		return divDesc;
	}

	public void setDivDesc(String divDesc) {
		this.divDesc = divDesc;
	}

	public String getDeptCd() {
		return deptCd;
	}

	public void setDeptCd(String deptCd) {
		this.deptCd = deptCd;
	}

	public String getDeptDesc() {
		return deptDesc;
	}

	public void setDeptDesc(String deptDesc) {
		this.deptDesc = deptDesc;
	}

	public String getSectorCd() {
		return sectorCd;
	}

	public void setSectorCd(String sectorCd) {
		this.sectorCd = sectorCd;
	}

	public String getSectorDesc() {
		return sectorDesc;
	}

	public void setSectorDesc(String sectorDesc) {
		this.sectorDesc = sectorDesc;
	}

	public Integer getReportingTo() {
		return reportingTo;
	}

	public void setReportingTo(Integer reportingTo) {
		this.reportingTo = reportingTo;
	}

	public Double getPrsntBasicSal() {
		return prsntBasicSal;
	}

	public void setPrsntBasicSal(Double prsntBasicSal) {
		this.prsntBasicSal = prsntBasicSal;
	}

	public String getSalPayMode() {
		return salPayMode;
	}

	public void setSalPayMode(String salPayMode) {
		this.salPayMode = salPayMode;
	}

	public Double getFixedDa() {
		return fixedDa;
	}

	public void setFixedDa(Double fixedDa) {
		this.fixedDa = fixedDa;
	}

	public Double getPersAllowance() {
		return persAllowance;
	}

	public void setPersAllowance(Double persAllowance) {
		this.persAllowance = persAllowance;
	}

	public String getPermDeputation() {
		return permDeputation;
	}

	public void setPermDeputation(String permDeputation) {
		this.permDeputation = permDeputation;
	}

	public String getPayrollEmpStatus() {
		return payrollEmpStatus;
	}

	public void setPayrollEmpStatus(String payrollEmpStatus) {
		this.payrollEmpStatus = payrollEmpStatus;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDt() {
		return createdDt;
	}

	public void setCreatedDt(Date createdDt) {
		this.createdDt = createdDt;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public String getHandicapChildFlag() {
		return handicapChildFlag;
	}

	public void setHandicapChildFlag(String handicapChildFlag) {
		this.handicapChildFlag = handicapChildFlag;
	}

	public String getCompAccom() {
		return compAccom;
	}

	public void setCompAccom(String compAccom) {
		this.compAccom = compAccom;
	}

	public String getSpclConvFlag() {
		return spclConvFlag;
	}

	public void setSpclConvFlag(String spclConvFlag) {
		this.spclConvFlag = spclConvFlag;
	}

	public String getCreditSocHsgFlag() {
		return creditSocHsgFlag;
	}

	public void setCreditSocHsgFlag(String creditSocHsgFlag) {
		this.creditSocHsgFlag = creditSocHsgFlag;
	}

	public Date getCsJoiningDt() {
		return csJoiningDt;
	}

	public void setCsJoiningDt(Date csJoiningDt) {
		this.csJoiningDt = csJoiningDt;
	}

	public String getIsGtiOpted() {
		return isGtiOpted;
	}

	public void setIsGtiOpted(String isGtiOpted) {
		this.isGtiOpted = isGtiOpted;
	}

	public String getPensionOpted() {
		return pensionOpted;
	}

	public void setPensionOpted(String pensionOpted) {
		this.pensionOpted = pensionOpted;
	}

	public String getNpsOpted() {
		return npsOpted;
	}

	public void setNpsOpted(String npsOpted) {
		this.npsOpted = npsOpted;
	}

	public Date getLastUpdatedDt() {
		return lastUpdatedDt;
	}

	public void setLastUpdatedDt(Date lastUpdatedDt) {
		this.lastUpdatedDt = lastUpdatedDt;
	}

	public String getOfficeId() {
		return officeId;
	}

	public void setOfficeId(String officeId) {
		this.officeId = officeId;
	}

	public String getOfficeDesc() {
		return officeDesc;
	}

	public void setOfficeDesc(String officeDesc) {
		this.officeDesc = officeDesc;
	}

	@Override
	public String toString() {
		return "Employee [empNo=" + empNo + ", prefix=" + prefix + ", firstName=" + firstName + ", midName=" + midName
				+ ", lastName=" + lastName + ", empAlias=" + empAlias + ", gender=" + gender + ", birthPlace="
				+ birthPlace + ", nationality=" + nationality + ", dob=" + dob + ", confDate=" + confDate
				+ ", bloodGrp=" + bloodGrp + ", doj=" + doj + ", empType=" + empType + ", branchCode=" + branchCode
				+ ", branchDesc=" + branchDesc + ", regionCode=" + regionCode + ", regionName=" + regionName
				+ ", probToDate=" + probToDate + ", rankId=" + rankId + ", rankDesc=" + rankDesc + ", desigId="
				+ desigId + ", desigDesc=" + desigDesc + ", joinDesigId=" + joinDesigId + ", joinDesigDesc="
				+ joinDesigDesc + ", lastPrmDate=" + lastPrmDate + ", lastIncDate=" + lastIncDate + ", categoryCd="
				+ categoryCd + ", categoryDesc=" + categoryDesc + ", religion=" + religion + ", classCd=" + classCd
				+ ", handicapFlg=" + handicapFlg + ", disabilityPerc=" + disabilityPerc + ", handicapDesc="
				+ handicapDesc + ", statusCd=" + statusCd + ", empStatusDesc=" + empStatusDesc + ", divCd=" + divCd
				+ ", divDesc=" + divDesc + ", deptCd=" + deptCd + ", deptDesc=" + deptDesc + ", sectorCd=" + sectorCd
				+ ", sectorDesc=" + sectorDesc + ", reportingTo=" + reportingTo + ", prsntBasicSal=" + prsntBasicSal
				+ ", salPayMode=" + salPayMode + ", fixedDa=" + fixedDa + ", persAllowance=" + persAllowance
				+ ", permDeputation=" + permDeputation + ", payrollEmpStatus=" + payrollEmpStatus + ", createdBy="
				+ createdBy + ", createdDt=" + createdDt + ", lastUpdatedBy=" + lastUpdatedBy + ", handicapChildFlag="
				+ handicapChildFlag + ", compAccom=" + compAccom + ", spclConvFlag=" + spclConvFlag
				+ ", creditSocHsgFlag=" + creditSocHsgFlag + ", csJoiningDt=" + csJoiningDt + ", isGtiOpted="
				+ isGtiOpted + ", pensionOpted=" + pensionOpted + ", npsOpted=" + npsOpted + ", lastUpdatedDt="
				+ lastUpdatedDt + ", officeId=" + officeId + ", officeDesc=" + officeDesc + "]";
	}
	
	

	
	
}

	
	
	

	
