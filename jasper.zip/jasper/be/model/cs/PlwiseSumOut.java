package in.ecgc.smile.erp.reporting.jasper.be.model.cs;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;



public class PlwiseSumOut {
	
	List<PLStmt> plStmt;

	private BigDecimal openingCrBal;
	private BigDecimal openingDrBal;
	private BigDecimal closingCrBal;
	private BigDecimal closingDrBal;

	private String logicalLocCd;
	private String mainGlCd;
	private String subGlCd;

	// @JsonSerialize(using = LocalDateSerializer.class)
	// @JsonDeserialize(using = LocalDateDeserializer.class)
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate fromDt;
	// @JsonSerialize(using = LocalDateSerializer.class)
	// @JsonDeserialize(using = LocalDateDeserializer.class)
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate toDt;
	private String branch;
	
	

	public List<PLStmt> getPlStmt() {
		return plStmt;
	}

	public void setPlStmt(List<PLStmt> plStmt) {
		this.plStmt = plStmt;
	}

	public BigDecimal getOpeningCrBal() {
		return openingCrBal;
	}

	public void setOpeningCrBal(BigDecimal openingCrBal) {
		this.openingCrBal = openingCrBal;
	}

	public BigDecimal getOpeningDrBal() {
		return openingDrBal;
	}

	public void setOpeningDrBal(BigDecimal openingDrBal) {
		this.openingDrBal = openingDrBal;
	}

	public BigDecimal getClosingCrBal() {
		return closingCrBal;
	}

	public void setClosingCrBal(BigDecimal closingCrBal) {
		this.closingCrBal = closingCrBal;
	}

	public BigDecimal getClosingDrBal() {
		return closingDrBal;
	}

	public void setClosingDrBal(BigDecimal closingDrBal) {
		this.closingDrBal = closingDrBal;
	}

	public String getLogicalLocCd() {
		return logicalLocCd;
	}

	public void setLogicalLocCd(String logicalLocCd) {
		this.logicalLocCd = logicalLocCd;
	}

	public String getMainGlCd() {
		return mainGlCd;
	}

	public void setMainGlCd(String mainGlCd) {
		this.mainGlCd = mainGlCd;
	}

	public String getSubGlCd() {
		return subGlCd;
	}

	public void setSubGlCd(String subGlCd) {
		this.subGlCd = subGlCd;
	}

	public LocalDate getFromDt() {
		return fromDt;
	}

	public void setFromDt(LocalDate fromDt) {
		this.fromDt = fromDt;
	}

	public LocalDate getToDt() {
		return toDt;
	}

	public void setToDt(LocalDate toDt) {
		this.toDt = toDt;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	@Override
	public String toString() {
		return "PlwiseSumOut [plStmt=" + plStmt + ", openingCrBal=" + openingCrBal + ", openingDrBal=" + openingDrBal
				+ ", closingCrBal=" + closingCrBal + ", closingDrBal=" + closingDrBal + ", logicalLocCd=" + logicalLocCd
				+ ", mainGlCd=" + mainGlCd + ", subGlCd=" + subGlCd + ", fromDt=" + fromDt + ", toDt=" + toDt
				+ ", branch=" + branch + "]";
	}
	

}
