package in.ecgc.smile.erp.reporting.jasper.be.model.reports;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.function.BiFunction;
import java.util.stream.Collectors;

import in.ecgc.smile.erp.reporting.jasper.be.utils.reports.ReportGenUtils;

public class ReportTable {
    private String id;
    private String tableTitle;
    private List<Map<String, Object>> data;
    private Map<String, Object> summary;

    private float height;
    private float width;
    private float marginTop;
    private float marginBottom;
    private float marginRight;
    private float marginLeft;
    private float paddingTop;
    private float paddingBottom;
    private float paddingRight;
    private float paddingLeft;
    private float fontSize;
    private boolean hasSummary;
    private SummaryType summaryType;
    private List<String> summaryKeys;

    public String getId() {
        return id;
    }

    public ReportTable setId(String id) {
        this.id = id;
        return this;
    }

    public String getTableTitle() {
        return tableTitle;
    }

    public ReportTable setTableTitle(String tableTitle) {
        this.tableTitle = tableTitle;
        return this;
    }

    public List<Map<String, Object>> getData() {
        return data;
    }

    public ReportTable setData(List<Map<String, Object>> data) {
        this.data = data;
        return this;
    }

    public Map<String, Object> getSummary() {
        return summary;
    }

    public ReportTable setSummary(Map<String, Object> summary) {
        this.summary = summary;
        return this;
    }

    public float getHeight() {
        return height;
    }

    public ReportTable setHeight(float height) {
        this.height = height;
        return this;
    }

    public float getWidth() {
        return width;
    }

    public ReportTable setWidth(float width) {
        this.width = width;
        return this;
    }

    public float getMarginTop() {
        return marginTop;
    }

    public ReportTable setMarginTop(float marginTop) {
        this.marginTop = marginTop;
        return this;
    }

    public float getMarginBottom() {
        return marginBottom;
    }

    public ReportTable setMarginBottom(float marginBottom) {
        this.marginBottom = marginBottom;
        return this;
    }

    public float getMarginRight() {
        return marginRight;
    }

    public ReportTable setMarginRight(float marginRight) {
        this.marginRight = marginRight;
        return this;
    }

    public float getMarginLeft() {
        return marginLeft;
    }

    public ReportTable setMarginLeft(float marginLeft) {
        this.marginLeft = marginLeft;
        return this;
    }

    public float getPaddingTop() {
        return paddingTop;
    }

    public ReportTable setPaddingTop(float paddingTop) {
        this.paddingTop = paddingTop;
        return this;
    }

    public float getPaddingBottom() {
        return paddingBottom;
    }

    public ReportTable setPaddingBottom(float paddingBottom) {
        this.paddingBottom = paddingBottom;
        return this;
    }

    public float getPaddingRight() {
        return paddingRight;
    }

    public ReportTable setPaddingRight(float paddingRight) {
        this.paddingRight = paddingRight;
        return this;
    }

    public float getPaddingLeft() {
        return paddingLeft;
    }

    public ReportTable setPaddingLeft(float paddingLeft) {
        this.paddingLeft = paddingLeft;
        return this;
    }

    public float getFontSize() {
        return fontSize;
    }

    public ReportTable setFontSize(float fontSize) {
        this.fontSize = fontSize;
        return this;
    }

    public boolean isHasSummary() {
        return hasSummary;
    }

    public ReportTable setHasSummary(boolean hasSummary) {
        this.hasSummary = hasSummary;
        return this;
    }

    public SummaryType getSummaryType() {
        return summaryType;
    }

    public ReportTable setSummaryType(SummaryType summaryType) {
        this.summaryType = summaryType;
        return this;
    }

    public List<String> getSummaryKeys() {
        return summaryKeys;
    }

    public ReportTable setSummaryKeys(List<String> summaryKeys) {
        this.summaryKeys = summaryKeys;
        return this;
    }

    public enum SummaryType implements BiFunction<List<Map<String, Object>>, List<String>, Map<String, Object>> {
        SUM("Total") {

            @Override
            public Map<String, Object> apply(List<Map<String, Object>> data, List<String> keys) {

                return data.stream().flatMap(
                        m -> m.entrySet().stream().filter(x -> keys.contains(x.getKey()) && x.getValue() != null))
                        .collect( // Collectors.groupingBy(Map.Entry::getValue,
                                Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue,
                                        (s, a) -> ReportGenUtils.formatIntoCurrency(
                                                new BigDecimal(ReportGenUtils.valueForBigDecimal(s))
                                                        .add(new BigDecimal(ReportGenUtils.valueForBigDecimal(a))),
                                                String.valueOf(a).contains("₹"))));

            }
        },
        PRODUCT("Product") {

            @Override
            public Map<String, Object> apply(List<Map<String, Object>> data, List<String> keys) {

                return data.stream().flatMap(
                        m -> m.entrySet().stream().filter(x -> keys.contains(x.getKey()) && x.getValue() != null))
                        .collect( // Collectors.groupingBy(Map.Entry::getValue,
                                Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue,
                                        (s, a) -> ReportGenUtils.formatIntoCurrency(
                                                new BigDecimal(ReportGenUtils.valueForBigDecimal(s))
                                                        .multiply(new BigDecimal(ReportGenUtils.valueForBigDecimal(a))),
                                                String.valueOf(a).contains("₹"))));

            }
        },
        AVG("Average") {

            @Override
            public Map<String, Object> apply(List<Map<String, Object>> data, List<String> keys) {

                return Collections.unmodifiableMap(data.stream()
                        .flatMap(m -> m.entrySet().stream())
                        .collect(Collectors.groupingBy(Map.Entry::getKey, Collectors.averagingDouble(
                                x -> Double.valueOf(x.getValue() == null ? "0" : String.valueOf(x.getValue()))))));

            }
        },

        COUNT("Count") {
            @Override
            public Map<String, Object> apply(List<Map<String, Object>> data, List<String> keys) {

                return Collections.unmodifiableMap(data.stream()
                        .flatMap(m -> m.entrySet().stream().filter(x -> keys.contains(x.getKey())))
                        .collect(Collectors.groupingBy(Map.Entry::getKey, Collectors.counting())));

            }
        };

        private String displayName;

        private SummaryType(String displayName) {
            this.displayName = displayName;
        }

        public static SummaryType getType(String type) throws IllegalArgumentException {
            for (SummaryType s : SummaryType.values()) {
                if (s.displayName.equalsIgnoreCase(type)) {
                    return s;
                }
            }
            throw new IllegalArgumentException(
                    String.format("Invalid argument %s for enum SummaryType.No such Type Present", type));
        }

        // public SummaryFunction getSummaryFunction(List<String> keys) {
        // SummaryFunction s = null;
        // switch (this) {
        // case SUM:
        // s = new Sum(keys, displayName);
        // break;
        // case PRODUCT:
        // s = new Product(keys, displayName);
        // break;

        // default:
        // break;
        // }
        // return s;
        // }

    }

}
