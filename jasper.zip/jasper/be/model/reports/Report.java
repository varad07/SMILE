package in.ecgc.smile.erp.reporting.jasper.be.model.reports;

import java.util.ArrayList;
import java.util.List;

public class Report {

    String heading = "ECGC Ltd.\n\u0908\u0938\u0940\u091c\u0940\u0938\u0940 \u093f\u0932\u093f\u092e\u091f\u0947\u0921";
    String subHeading = "(A Government of India Enterprise)\n(भारत सरकार का उद्यम)";
    String title;
    String generatedBy;
    String creationDate;
    List<ReportTable> tables;

    public String getHeading() {
        return heading;
    }

    public Report setHeading(String heading) {
        this.heading = heading;
        return this;
    }

    public String getSubHeading() {
        return subHeading;
    }

    public Report setSubHeading(String subHeading) {
        this.subHeading = subHeading;
        return this;
    }

    public String getTitle() {
        return title;
    }

    public Report setTitle(String title) {
        this.title = title;
        return this;
    }

    public String getGeneratedBy() {
        return generatedBy;
    }

    public Report setGeneratedBy(String generatedBy) {
        this.generatedBy = generatedBy;
        return this;
    }

    public String getCreationDate() {
        return creationDate;
    }

    public Report setCreationDate(String creationDate) {
        this.creationDate = creationDate;
        return this;
    }

    public List<ReportTable> getTables() {
        return tables;
    }

    public Report setTables(List<ReportTable> tables) {
        this.tables = tables;
        return this;
    }

    @Override
    public String toString() {
        return "Report [heading=" + heading + ", subHeading=" + subHeading + ", title=" + title + ", generatedBy="
                + generatedBy + ", creationDate=" + creationDate + ", tables=" + tables + "]";
    }

    public Report() {
        this.tables = new ArrayList<>();
    }

}
