package in.ecgc.smile.erp.reporting.jasper.be.model.reports;

public enum Orientation {
    PORTRAIT,
    LANDSCAPE
}