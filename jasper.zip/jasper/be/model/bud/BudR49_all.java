package in.ecgc.smile.erp.reporting.jasper.be.model.bud;



import org.springframework.stereotype.Component;

@Component
public class BudR49_all {


}
