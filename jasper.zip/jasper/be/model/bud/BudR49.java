package in.ecgc.smile.erp.reporting.jasper.be.model.bud;



import org.springframework.stereotype.Component;

@Component
public class BudR49 {

	private String branch;
	private String policy_no;
	private String exporter_name;
	private String buyer_code;
	private String buyer_name;
	private String country;
	private String cell_code;
	private String buyer_in_default;
	private String ol_status;
	private String claim_date;
	private String claim_status;
	private Double claimed_amount;
	private Double claim_paid_amount;
	private String reason;
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	public String getPolicy_no() {
		return policy_no;
	}
	public void setPolicy_no(String policy_no) {
		this.policy_no = policy_no;
	}
	public String getExporter_name() {
		return exporter_name;
	}
	public void setExporter_name(String exporter_name) {
		this.exporter_name = exporter_name;
	}
	public String getBuyer_code() {
		return buyer_code;
	}
	public void setBuyer_code(String buyer_code) {
		this.buyer_code = buyer_code;
	}
	public String getBuyer_name() {
		return buyer_name;
	}
	public void setBuyer_name(String buyer_name) {
		this.buyer_name = buyer_name;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getCell_code() {
		return cell_code;
	}
	public void setCell_code(String cell_code) {
		this.cell_code = cell_code;
	}
	public String getBuyer_in_default() {
		return buyer_in_default;
	}
	public void setBuyer_in_default(String buyer_in_default) {
		this.buyer_in_default = buyer_in_default;
	}
	public String getOl_status() {
		return ol_status;
	}
	public void setOl_status(String ol_status) {
		this.ol_status = ol_status;
	}
	public String getClaim_date() {
		return claim_date;
	}
	public void setClaim_date(String claim_date) {
		this.claim_date = claim_date;
	}
	public String getClaim_status() {
		return claim_status;
	}
	public void setClaim_status(String claim_status) {
		this.claim_status = claim_status;
	}
	public Double getClaimed_amount() {
		return claimed_amount;
	}
	public void setClaimed_amount(Double claimed_amount) {
		this.claimed_amount = claimed_amount;
	}
	public Double getClaim_paid_amount() {
		return claim_paid_amount;
	}
	public void setClaim_paid_amount(Double claim_paid_amount) {
		this.claim_paid_amount = claim_paid_amount;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	@Override
	public String toString() {
		return "BudR49 [branch=" + branch + ", policy_no=" + policy_no + ", exporter_name=" + exporter_name
				+ ", buyer_code=" + buyer_code + ", buyer_name=" + buyer_name + ", country=" + country + ", cell_code="
				+ cell_code + ", buyer_in_default=" + buyer_in_default + ", ol_status=" + ol_status + ", claim_date="
				+ claim_date + ", claim_status=" + claim_status + ", claimed_amount=" + claimed_amount
				+ ", claim_paid_amount=" + claim_paid_amount + ", reason=" + reason + "]";
	}
	
	
	
	

}
