package in.ecgc.smile.erp.reporting.jasper.be.model.bud;



import org.springframework.stereotype.Component;

@Component
public class BudR16 {

	private String commodity_name;
	private Double claim_preferred_amount;
	private Double claim_paid_amount;
	private String claim_paid_date;
	private String claim_no;
	private int premium_received;
	private int claim_premiuim_ratio;
	
	public String getCommodity_name() {
		return commodity_name;
	}
	public void setCommodity_name(String commodity_name) {
		this.commodity_name = commodity_name;
	}
	public Double getClaim_preferred_amount() {
		return claim_preferred_amount;
	}
	public void setClaim_preferred_amount(Double claim_preferred_amount) {
		this.claim_preferred_amount = claim_preferred_amount;
	}
	public Double getClaim_paid_amount() {
		return claim_paid_amount;
	}
	public void setClaim_paid_amount(Double claim_paid_amount) {
		this.claim_paid_amount = claim_paid_amount;
	}
	public String getClaim_paid_date() {
		return claim_paid_date;
	}
	public void setClaim_paid_date(String claim_paid_date) {
		this.claim_paid_date = claim_paid_date;
	}
	public String getClaim_no() {
		return claim_no;
	}
	public void setClaim_no(String claim_no) {
		this.claim_no = claim_no;
	}
	public int getPremium_received() {
		return premium_received;
	}
	public void setPremium_received(int premium_received) {
		this.premium_received = premium_received;
	}
	public int getClaim_premiuim_ratio() {
		return claim_premiuim_ratio;
	}
	public void setClaim_premiuim_ratio(int claim_premiuim_ratio) {
		this.claim_premiuim_ratio = claim_premiuim_ratio;
	}
	@Override
	public String toString() {
		return "BudR16 [commodity_name=" + commodity_name + ", claim_preferred_amount=" + claim_preferred_amount
				+ ", claim_paid_amount=" + claim_paid_amount + ", claim_paid_date=" + claim_paid_date + ", claim_no="
				+ claim_no + ", premium_received=" + premium_received + ", claim_premiuim_ratio=" + claim_premiuim_ratio
				+ "]";
	}

	
	
	
	
	
}
