package in.ecgc.smile.erp.reporting.jasper.be.model.bud;



import org.springframework.stereotype.Component;

@Component
public class BudR49_1 {

	private String branch;
	private String gurantee_number;
	private String claim_no;
	private String exporter_name;
	private String buyer_code;
	private String buyer_name;
	private String country;
	private String cell_code;
	private String ol_status;
	private String clm_pref_date;
	private String clm_decision_date;
	private String claim_status;
	private int clm_paid_amount;
	private int clm_pref_amt;
	private int recovered_amt;
	private String claim_reason;
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	public String getGurantee_number() {
		return gurantee_number;
	}
	public void setGurantee_number(String gurantee_number) {
		this.gurantee_number = gurantee_number;
	}
	public String getClaim_no() {
		return claim_no;
	}
	public void setClaim_no(String claim_no) {
		this.claim_no = claim_no;
	}
	public String getExporter_name() {
		return exporter_name;
	}
	public void setExporter_name(String exporter_name) {
		this.exporter_name = exporter_name;
	}
	public String getBuyer_code() {
		return buyer_code;
	}
	public void setBuyer_code(String buyer_code) {
		this.buyer_code = buyer_code;
	}
	public String getBuyer_name() {
		return buyer_name;
	}
	public void setBuyer_name(String buyer_name) {
		this.buyer_name = buyer_name;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getCell_code() {
		return cell_code;
	}
	public void setCell_code(String cell_code) {
		this.cell_code = cell_code;
	}
	public String getOl_status() {
		return ol_status;
	}
	public void setOl_status(String ol_status) {
		this.ol_status = ol_status;
	}
	public String getClm_pref_date() {
		return clm_pref_date;
	}
	public void setClm_pref_date(String clm_pref_date) {
		this.clm_pref_date = clm_pref_date;
	}
	public String getClm_decision_date() {
		return clm_decision_date;
	}
	public void setClm_decision_date(String clm_decision_date) {
		this.clm_decision_date = clm_decision_date;
	}
	public String getClaim_status() {
		return claim_status;
	}
	public void setClaim_status(String claim_status) {
		this.claim_status = claim_status;
	}
	public int getClm_paid_amount() {
		return clm_paid_amount;
	}
	public void setClm_paid_amount(int clm_paid_amount) {
		this.clm_paid_amount = clm_paid_amount;
	}
	public int getClm_pref_amt() {
		return clm_pref_amt;
	}
	public void setClm_pref_amt(int clm_pref_amt) {
		this.clm_pref_amt = clm_pref_amt;
	}
	public int getRecovered_amt() {
		return recovered_amt;
	}
	public void setRecovered_amt(int recovered_amt) {
		this.recovered_amt = recovered_amt;
	}
	public String getClaim_reason() {
		return claim_reason;
	}
	public void setClaim_reason(String claim_reason) {
		this.claim_reason = claim_reason;
	}
	@Override
	public String toString() {
		return "BudR49_1 [branch=" + branch + ", gurantee_number=" + gurantee_number + ", claim_no=" + claim_no
				+ ", exporter_name=" + exporter_name + ", buyer_code=" + buyer_code + ", buyer_name=" + buyer_name
				+ ", country=" + country + ", cell_code=" + cell_code + ", ol_status=" + ol_status + ", clm_pref_date="
				+ clm_pref_date + ", clm_decision_date=" + clm_decision_date + ", claim_status=" + claim_status
				+ ", clm_paid_amount=" + clm_paid_amount + ", clm_pref_amt=" + clm_pref_amt + ", recovered_amt="
				+ recovered_amt + ", claim_reason=" + claim_reason + "]";
	}
	
	

}
