package in.ecgc.smile.erp.reporting.jasper.be.model.bud;



import org.springframework.stereotype.Component;

@Component
public class BudR48_1 {

	private String logicalloc_cd ;
	private String pol_num;
	private String policy_type;
	private String exporter_name;
	private String buyer_code;
	private String buyer_name;
	private String country;
	private String ship_date;
	private String invoice_amount;
	private String default_status;
	private String default_received_date;
	private String default_from_date;
	private String cell_code;
	private String ol_status;
	private String byr_default_list;
	private String balance;
	private String total_overall_limit;
	private String total_sanctioned_limit;
	public String getLogicalloc_cd() {
		return logicalloc_cd;
	}
	public void setLogicalloc_cd(String logicalloc_cd) {
		this.logicalloc_cd = logicalloc_cd;
	}
	public String getPol_num() {
		return pol_num;
	}
	public void setPol_num(String pol_num) {
		this.pol_num = pol_num;
	}
	public String getPolicy_type() {
		return policy_type;
	}
	public void setPolicy_type(String policy_type) {
		this.policy_type = policy_type;
	}
	public String getExporter_name() {
		return exporter_name;
	}
	public void setExporter_name(String exporter_name) {
		this.exporter_name = exporter_name;
	}
	public String getBuyer_code() {
		return buyer_code;
	}
	public void setBuyer_code(String buyer_code) {
		this.buyer_code = buyer_code;
	}
	public String getBuyer_name() {
		return buyer_name;
	}
	public void setBuyer_name(String buyer_name) {
		this.buyer_name = buyer_name;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getShip_date() {
		return ship_date;
	}
	public void setShip_date(String ship_date) {
		this.ship_date = ship_date;
	}
	public String getInvoice_amount() {
		return invoice_amount;
	}
	public void setInvoice_amount(String invoice_amount) {
		this.invoice_amount = invoice_amount;
	}
	public String getDefault_status() {
		return default_status;
	}
	public void setDefault_status(String default_status) {
		this.default_status = default_status;
	}
	public String getDefault_received_date() {
		return default_received_date;
	}
	public void setDefault_received_date(String default_received_date) {
		this.default_received_date = default_received_date;
	}
	public String getDefault_from_date() {
		return default_from_date;
	}
	public void setDefault_from_date(String default_from_date) {
		this.default_from_date = default_from_date;
	}
	public String getCell_code() {
		return cell_code;
	}
	public void setCell_code(String cell_code) {
		this.cell_code = cell_code;
	}
	public String getOl_status() {
		return ol_status;
	}
	public void setOl_status(String ol_status) {
		this.ol_status = ol_status;
	}
	public String getByr_default_list() {
		return byr_default_list;
	}
	public void setByr_default_list(String byr_default_list) {
		this.byr_default_list = byr_default_list;
	}
	public String getBalance() {
		return balance;
	}
	public void setBalance(String balance) {
		this.balance = balance;
	}
	public String getTotal_overall_limit() {
		return total_overall_limit;
	}
	public void setTotal_overall_limit(String total_overall_limit) {
		this.total_overall_limit = total_overall_limit;
	}
	public String getTotal_sanctioned_limit() {
		return total_sanctioned_limit;
	}
	public void setTotal_sanctioned_limit(String total_sanctioned_limit) {
		this.total_sanctioned_limit = total_sanctioned_limit;
	}
	@Override
	public String toString() {
		return "BudR48_1 [logicalloc_cd=" + logicalloc_cd + ", pol_num=" + pol_num + ", policy_type=" + policy_type
				+ ", exporter_name=" + exporter_name + ", buyer_code=" + buyer_code + ", buyer_name=" + buyer_name
				+ ", country=" + country + ", ship_date=" + ship_date + ", invoice_amount=" + invoice_amount
				+ ", default_status=" + default_status + ", default_received_date=" + default_received_date
				+ ", default_from_date=" + default_from_date + ", cell_code=" + cell_code + ", ol_status=" + ol_status
				+ ", byr_default_list=" + byr_default_list + ", balance=" + balance + ", total_overall_limit="
				+ total_overall_limit + ", total_sanctioned_limit=" + total_sanctioned_limit + "]";
	}
	
}
