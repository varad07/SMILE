package in.ecgc.smile.erp.reporting.jasper.be.model.bud;

import java.math.BigDecimal;

public class BudR20 {
	
	private String buyer_name;
	
	private String buyer_code;
	
	private String cell_no;
	
	private String branch;
	
	private String policy_holder_name;
	
	private BigDecimal amount_of_limit_approved;
	
	private String terms_of_payement;
	
	private String cla_approval_date;
	
	private BigDecimal claim_pref_amt;
	
	private BigDecimal claim_paid_amt;
	
	private String claim_paid_date;
	
	private String reason;
	
	private BigDecimal top;
	
	private String country;
	
	private BigDecimal amount_of_regular_limit_approved;

	public String getBuyer_name() {
		return buyer_name;
	}

	public String getBuyer_code() {
		return buyer_code;
	}

	public String getCell_no() {
		return cell_no;
	}

	public String getBranch() {
		return branch;
	}

	public String getPolicy_holder_name() {
		return policy_holder_name;
	}

	public BigDecimal getAmount_of_limit_approved() {
		return amount_of_limit_approved;
	}

	public String getTerms_of_payement() {
		return terms_of_payement;
	}

	public String getCla_approval_date() {
		return cla_approval_date;
	}

	public BigDecimal getClaim_pref_amt() {
		return claim_pref_amt;
	}

	public BigDecimal getClaim_paid_amt() {
		return claim_paid_amt;
	}

	public String getClaim_paid_date() {
		return claim_paid_date;
	}

	public String getReason() {
		return reason;
	}

	public BigDecimal getTop() {
		return top;
	}

	public String getCountry() {
		return country;
	}

	public BigDecimal getAmount_of_regular_limit_approved() {
		return amount_of_regular_limit_approved;
	}

	public void setBuyer_name(String buyer_name) {
		this.buyer_name = buyer_name;
	}

	public void setBuyer_code(String buyer_code) {
		this.buyer_code = buyer_code;
	}

	public void setCell_no(String cell_no) {
		this.cell_no = cell_no;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public void setPolicy_holder_name(String policy_holder_name) {
		this.policy_holder_name = policy_holder_name;
	}

	public void setAmount_of_limit_approved(BigDecimal amount_of_limit_approved) {
		this.amount_of_limit_approved = amount_of_limit_approved;
	}

	public void setTerms_of_payement(String terms_of_payement) {
		this.terms_of_payement = terms_of_payement;
	}

	public void setCla_approval_date(String cla_approval_date) {
		this.cla_approval_date = cla_approval_date;
	}

	public void setClaim_pref_amt(BigDecimal claim_pref_amt) {
		this.claim_pref_amt = claim_pref_amt;
	}

	public void setClaim_paid_amt(BigDecimal claim_paid_amt) {
		this.claim_paid_amt = claim_paid_amt;
	}

	public void setClaim_paid_date(String claim_paid_date) {
		this.claim_paid_date = claim_paid_date;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public void setTop(BigDecimal top) {
		this.top = top;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public void setAmount_of_regular_limit_approved(BigDecimal amount_of_regular_limit_approved) {
		this.amount_of_regular_limit_approved = amount_of_regular_limit_approved;
	}

	@Override
	public String toString() {
		return "BudR20 [buyer_name=" + buyer_name + ", buyer_code=" + buyer_code + ", cell_no=" + cell_no + ", branch="
				+ branch + ", policy_holder_name=" + policy_holder_name + ", amount_of_limit_approved="
				+ amount_of_limit_approved + ", terms_of_payement=" + terms_of_payement + ", cla_approval_date="
				+ cla_approval_date + ", claim_pref_amt=" + claim_pref_amt + ", claim_paid_amt=" + claim_paid_amt
				+ ", claim_paid_date=" + claim_paid_date + ", reason=" + reason + ", top=" + top + ", country="
				+ country + ", amount_of_regular_limit_approved=" + amount_of_regular_limit_approved + "]";
	} 

	
	
}
