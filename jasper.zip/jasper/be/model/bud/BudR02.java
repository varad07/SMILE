package in.ecgc.smile.erp.reporting.jasper.be.model.bud;



import org.springframework.stereotype.Component;

@Component
public class BudR02 {

	private String cla_no;
	private String buyer_code;
	private String buyer_name;
	private String policy_no;
	private String policy_holders_name;
	private String cla_belongs_to;
	private String cancelled_at;
	private String user_id;
	private String cancellation_date;
	private String letter_generated_on;
	private String letter_generated_by;
	private String letter_generated_by_user_name;
	private String letter_generated_at;
	private String cancellation_reason;
	private String cell_code;
	private String country;
	private String cla_type;
	public String getCla_no() {
		return cla_no;
	}
	public void setCla_no(String cla_no) {
		this.cla_no = cla_no;
	}
	public String getBuyer_code() {
		return buyer_code;
	}
	public void setBuyer_code(String buyer_code) {
		this.buyer_code = buyer_code;
	}
	public String getBuyer_name() {
		return buyer_name;
	}
	public void setBuyer_name(String buyer_name) {
		this.buyer_name = buyer_name;
	}
	public String getPolicy_no() {
		return policy_no;
	}
	public void setPolicy_no(String policy_no) {
		this.policy_no = policy_no;
	}
	
	public String getPolicy_holders_name() {
		return policy_holders_name;
	}
	public void setPolicy_holders_name(String policy_holders_name) {
		this.policy_holders_name = policy_holders_name;
	}
	public String getCla_belongs_to() {
		return cla_belongs_to;
	}
	public void setCla_belongs_to(String cla_belongs_to) {
		this.cla_belongs_to = cla_belongs_to;
	}
	public String getCancelled_at() {
		return cancelled_at;
	}
	public void setCancelled_at(String cancelled_at) {
		this.cancelled_at = cancelled_at;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getCancellation_date() {
		return cancellation_date;
	}
	public void setCancellation_date(String cancellation_date) {
		this.cancellation_date = cancellation_date;
	}
	public String getLetter_generated_on() {
		return letter_generated_on;
	}
	public void setLetter_generated_on(String letter_generated_on) {
		this.letter_generated_on = letter_generated_on;
	}
	public String getLetter_generated_by() {
		return letter_generated_by;
	}
	public void setLetter_generated_by(String letter_generated_by) {
		this.letter_generated_by = letter_generated_by;
	}
	public String getLetter_generated_by_user_name() {
		return letter_generated_by_user_name;
	}
	public void setLetter_generated_by_user_name(String letter_generated_by_user_name) {
		this.letter_generated_by_user_name = letter_generated_by_user_name;
	}
	public String getLetter_generated_at() {
		return letter_generated_at;
	}
	public void setLetter_generated_at(String letter_generated_at) {
		this.letter_generated_at = letter_generated_at;
	}
	public String getCancellation_reason() {
		return cancellation_reason;
	}
	public void setCancellation_reason(String cancellation_reason) {
		this.cancellation_reason = cancellation_reason;
	}
	public String getCell_code() {
		return cell_code;
	}
	public void setCell_code(String cell_code) {
		this.cell_code = cell_code;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getCla_type() {
		return cla_type;
	}
	public void setCla_type(String cla_type) {
		this.cla_type = cla_type;
	}
	@Override
	public String toString() {
		return "BudR02 [cla_no=" + cla_no + ", buyer_code=" + buyer_code + ", buyer_name=" + buyer_name + ", policy_no="
				+ policy_no + ", policy_holders_name=" + policy_holders_name + ", cla_belongs_to=" + cla_belongs_to
				+ ", cancelled_at=" + cancelled_at + ", user_id=" + user_id + ", cancellation_date=" + cancellation_date
				+ ", letter_generated_on=" + letter_generated_on + ", letter_generated_by=" + letter_generated_by
				+ ", letter_generated_by_user_name=" + letter_generated_by_user_name + ", letter_generated_at="
				+ letter_generated_at + ", cancellation_reason=" + cancellation_reason + ", cell_code=" + cell_code
				+ ", country=" + country + ", cla_type=" + cla_type + "]";
	}

	
	

	
	
	
}
