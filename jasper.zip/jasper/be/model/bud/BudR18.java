package in.ecgc.smile.erp.reporting.jasper.be.model.bud;

import java.math.BigDecimal;

public class BudR18 {
	
	private String country_name;
	
	private String cell_no;
	
	private BigDecimal total_cla_received;
	
	private BigDecimal cla_approved;
	
	private BigDecimal cla_pending;
	
	private BigDecimal average_decision_days;

	public String getCountry_name() {
		return country_name;
	}

	public String getCell_no() {
		return cell_no;
	}
	
	public void setCountry_name(String country_name) {
		this.country_name = country_name;
	}

	public void setCell_no(String cell_no) {
		this.cell_no = cell_no;
	}

	public BigDecimal getTotal_cla_received() {
		return total_cla_received;
	}

	public void setTotal_cla_received(BigDecimal total_cla_received) {
		this.total_cla_received = total_cla_received;
	}

	public BigDecimal getCla_approved() {
		return cla_approved;
	}

	public void setCla_approved(BigDecimal cla_approved) {
		this.cla_approved = cla_approved;
	}

	public BigDecimal getCla_pending() {
		return cla_pending;
	}

	public void setCla_pending(BigDecimal cla_pending) {
		this.cla_pending = cla_pending;
	}

	public BigDecimal getAverage_decision_days() {
		return average_decision_days;
	}

	public void setAverage_decision_days(BigDecimal average_decision_days) {
		this.average_decision_days = average_decision_days;
	}

	@Override
	public String toString() {

		return "BudR18 [country_name=" + country_name + ", cell_no=" + cell_no + ", total_cla_received="
				+ total_cla_received + ", cla_approved=" + cla_approved + ", cla_pending=" + cla_pending
				+ ", average_decision_days=" + average_decision_days + "]";
	}
	
	

}
