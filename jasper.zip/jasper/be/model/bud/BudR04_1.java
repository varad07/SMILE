package in.ecgc.smile.erp.reporting.jasper.be.model.bud;



import org.springframework.stereotype.Component;

@Component
public class BudR04_1 {

	private String branch;
	private String cell_no;
	private String cla_no;
	private String cla_type;
	private String cla_recd_dt_iwd_dt;
	private String policy_number;
	private String policy_holder_name;
	private String buyer_code;
	private String buyer_name;
	private String ol_fixed;
	private String terms_of_payment;
	private String limit_sought_in_lacs;
	private String existing_limit_in_lacs;
	private String existing_limit_payment_terms;
	private String dp_balance_in_lacs;
	private String da_balance_in_lacs;
	private String total_ol_in_lacs;
	private String ol_dec_status;
	private String ol_last_trans_date;
	private String cla_entry_dt;
	private String request_no;
	private String request_date;
	private String status;
	private String report_received_date;
	private String buyer_in_default;
	private String previous_report_date;
	private String report_status;
	private String commodity_description;
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	public String getCell_no() {
		return cell_no;
	}
	public void setCell_no(String cell_no) {
		this.cell_no = cell_no;
	}
	public String getCla_no() {
		return cla_no;
	}
	public void setCla_no(String cla_no) {
		this.cla_no = cla_no;
	}
	public String getCla_type() {
		return cla_type;
	}
	public void setCla_type(String cla_type) {
		this.cla_type = cla_type;
	}
	public String getCla_recd_dt_iwd_dt() {
		return cla_recd_dt_iwd_dt;
	}
	public void setCla_recd_dt_iwd_dt(String cla_recd_dt_iwd_dt) {
		this.cla_recd_dt_iwd_dt = cla_recd_dt_iwd_dt;
	}
	public String getPolicy_number() {
		return policy_number;
	}
	public void setPolicy_number(String policy_number) {
		this.policy_number = policy_number;
	}
	public String getPolicy_holder_name() {
		return policy_holder_name;
	}
	public void setPolicy_holder_name(String policy_holder_name) {
		this.policy_holder_name = policy_holder_name;
	}
	public String getBuyer_code() {
		return buyer_code;
	}
	public void setBuyer_code(String buyer_code) {
		this.buyer_code = buyer_code;
	}
	public String getBuyer_name() {
		return buyer_name;
	}
	public void setBuyer_name(String buyer_name) {
		this.buyer_name = buyer_name;
	}
	public String getOl_fixed() {
		return ol_fixed;
	}
	public void setOl_fixed(String ol_fixed) {
		this.ol_fixed = ol_fixed;
	}
	public String getTerms_of_payment() {
		return terms_of_payment;
	}
	public void setTerms_of_payment(String terms_of_payment) {
		this.terms_of_payment = terms_of_payment;
	}
	public String getLimit_sought_in_lacs() {
		return limit_sought_in_lacs;
	}
	public void setLimit_sought_in_lacs(String limit_sought_in_lacs) {
		this.limit_sought_in_lacs = limit_sought_in_lacs;
	}
	public String getExisting_limit_in_lacs() {
		return existing_limit_in_lacs;
	}
	public void setExisting_limit_in_lacs(String existing_limit_in_lacs) {
		this.existing_limit_in_lacs = existing_limit_in_lacs;
	}
	public String getExisting_limit_payment_terms() {
		return existing_limit_payment_terms;
	}
	public void setExisting_limit_payment_terms(String existing_limit_payment_terms) {
		this.existing_limit_payment_terms = existing_limit_payment_terms;
	}
	public String getDp_balance_in_lacs() {
		return dp_balance_in_lacs;
	}
	public void setDp_balance_in_lacs(String dp_balance_in_lacs) {
		this.dp_balance_in_lacs = dp_balance_in_lacs;
	}
	public String getDa_balance_in_lacs() {
		return da_balance_in_lacs;
	}
	public void setDa_balance_in_lacs(String da_balance_in_lacs) {
		this.da_balance_in_lacs = da_balance_in_lacs;
	}
	public String getTotal_ol_in_lacs() {
		return total_ol_in_lacs;
	}
	public void setTotal_ol_in_lacs(String total_ol_in_lacs) {
		this.total_ol_in_lacs = total_ol_in_lacs;
	}
	public String getOl_dec_status() {
		return ol_dec_status;
	}
	public void setOl_dec_status(String ol_dec_status) {
		this.ol_dec_status = ol_dec_status;
	}
	public String getOl_last_trans_date() {
		return ol_last_trans_date;
	}
	public void setOl_last_trans_date(String ol_last_trans_date) {
		this.ol_last_trans_date = ol_last_trans_date;
	}
	public String getCla_entry_dt() {
		return cla_entry_dt;
	}
	public void setCla_entry_dt(String cla_entry_dt) {
		this.cla_entry_dt = cla_entry_dt;
	}
	public String getRequest_no() {
		return request_no;
	}
	public void setRequest_no(String request_no) {
		this.request_no = request_no;
	}
	public String getRequest_date() {
		return request_date;
	}
	public void setRequest_date(String request_date) {
		this.request_date = request_date;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getReport_received_date() {
		return report_received_date;
	}
	public void setReport_received_date(String report_received_date) {
		this.report_received_date = report_received_date;
	}
	public String getBuyer_in_default() {
		return buyer_in_default;
	}
	public void setBuyer_in_default(String buyer_in_default) {
		this.buyer_in_default = buyer_in_default;
	}
	public String getPrevious_report_date() {
		return previous_report_date;
	}
	public void setPrevious_report_date(String previous_report_date) {
		this.previous_report_date = previous_report_date;
	}
	public String getReport_status() {
		return report_status;
	}
	public void setReport_status(String report_status) {
		this.report_status = report_status;
	}
	public String getCommodity_description() {
		return commodity_description;
	}
	public void setCommodity_description(String commodity_description) {
		this.commodity_description = commodity_description;
	}
	@Override
	public String toString() {
		return "BudR04_1 [branch=" + branch + ", cell_no=" + cell_no + ", cla_no=" + cla_no + ", cla_type=" + cla_type
				+ ", cla_recd_dt_iwd_dt=" + cla_recd_dt_iwd_dt + ", policy_number=" + policy_number
				+ ", policy_holder_name=" + policy_holder_name + ", buyer_code=" + buyer_code + ", buyer_name="
				+ buyer_name + ", ol_fixed=" + ol_fixed + ", terms_of_payment=" + terms_of_payment
				+ ", limit_sought_in_lacs=" + limit_sought_in_lacs + ", existing_limit_in_lacs="
				+ existing_limit_in_lacs + ", existing_limit_payment_terms=" + existing_limit_payment_terms
				+ ", dp_balance_in_lacs=" + dp_balance_in_lacs + ", da_balance_in_lacs=" + da_balance_in_lacs
				+ ", total_ol_in_lacs=" + total_ol_in_lacs + ", ol_dec_status=" + ol_dec_status
				+ ", ol_last_trans_date=" + ol_last_trans_date + ", cla_entry_dt=" + cla_entry_dt + ", request_no="
				+ request_no + ", request_date=" + request_date + ", status=" + status + ", report_received_date="
				+ report_received_date + ", buyer_in_default=" + buyer_in_default + ", previous_report_date="
				+ previous_report_date + ", report_status=" + report_status + ", commodity_description="
				+ commodity_description + "]";
	}
	
}
