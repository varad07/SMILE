package in.ecgc.smile.erp.reporting.jasper.be.model.bud;



import org.springframework.stereotype.Component;

@Component
public class BudR23 {

	
	private long rn;
	private String cla_no;
	private String cla_type;
	private String logicalloc_cd;
	private String policy_no;
	private String buyer_bank_cd;
	private String buyer_bank_name;
	private String buyer_bank_country;
	private String ofn_decision;
	private String iwd_dt;
	private String cla_entry_dt;
	private String cla_decision_dt;
	private String ol_decision_dt;
	private String in_process;
	private String report_rec_date;
	private String report_req_date;
	private String report_status;
	private String ol_decision_date;
	private int disposal_day;
	public long getRn() {
		return rn;
	}
	public void setRn(long rn) {
		this.rn = rn;
	}
	public String getCla_no() {
		return cla_no;
	}
	public void setCla_no(String cla_no) {
		this.cla_no = cla_no;
	}
	public String getCla_type() {
		return cla_type;
	}
	public void setCla_type(String cla_type) {
		this.cla_type = cla_type;
	}
	public String getLogicalloc_cd() {
		return logicalloc_cd;
	}
	public void setLogicalloc_cd(String logicalloc_cd) {
		this.logicalloc_cd = logicalloc_cd;
	}
	public String getPolicy_no() {
		return policy_no;
	}
	public void setPolicy_no(String policy_no) {
		this.policy_no = policy_no;
	}
	public String getBuyer_bank_cd() {
		return buyer_bank_cd;
	}
	public void setBuyer_bank_cd(String buyer_bank_cd) {
		this.buyer_bank_cd = buyer_bank_cd;
	}
	public String getBuyer_bank_name() {
		return buyer_bank_name;
	}
	public void setBuyer_bank_name(String buyer_bank_name) {
		this.buyer_bank_name = buyer_bank_name;
	}
	public String getBuyer_bank_country() {
		return buyer_bank_country;
	}
	public void setBuyer_bank_country(String buyer_bank_country) {
		this.buyer_bank_country = buyer_bank_country;
	}
	public String getOfn_decision() {
		return ofn_decision;
	}
	public void setOfn_decision(String ofn_decision) {
		this.ofn_decision = ofn_decision;
	}
	public String getIwd_dt() {
		return iwd_dt;
	}
	public void setIwd_dt(String iwd_dt) {
		this.iwd_dt = iwd_dt;
	}
	public String getCla_entry_dt() {
		return cla_entry_dt;
	}
	public void setCla_entry_dt(String cla_entry_dt) {
		this.cla_entry_dt = cla_entry_dt;
	}
	public String getCla_decision_dt() {
		return cla_decision_dt;
	}
	public void setCla_decision_dt(String cla_decision_dt) {
		this.cla_decision_dt = cla_decision_dt;
	}
	public String getOl_decision_dt() {
		return ol_decision_dt;
	}
	public void setOl_decision_dt(String ol_decision_dt) {
		this.ol_decision_dt = ol_decision_dt;
	}
	public String getIn_process() {
		return in_process;
	}
	public void setIn_process(String in_process) {
		this.in_process = in_process;
	}
	public String getReport_rec_date() {
		return report_rec_date;
	}
	public void setReport_rec_date(String report_rec_date) {
		this.report_rec_date = report_rec_date;
	}
	public String getReport_req_date() {
		return report_req_date;
	}
	public void setReport_req_date(String report_req_date) {
		this.report_req_date = report_req_date;
	}
	public String getReport_status() {
		return report_status;
	}
	public void setReport_status(String report_status) {
		this.report_status = report_status;
	}
	public String getOl_decision_date() {
		return ol_decision_date;
	}
	public void setOl_decision_date(String ol_decision_date) {
		this.ol_decision_date = ol_decision_date;
	}
	public int getDisposal_day() {
		return disposal_day;
	}
	public void setDisposal_day(int disposal_day) {
		this.disposal_day = disposal_day;
	}
	@Override
	public String toString() {
		return "BudR23 [rn=" + rn + ", cla_no=" + cla_no + ", cla_type=" + cla_type + ", logicalloc_cd=" + logicalloc_cd
				+ ", policy_no=" + policy_no + ", buyer_bank_cd=" + buyer_bank_cd + ", buyer_bank_name="
				+ buyer_bank_name + ", buyer_bank_country=" + buyer_bank_country + ", ofn_decision=" + ofn_decision
				+ ", iwd_dt=" + iwd_dt + ", cla_entry_dt=" + cla_entry_dt + ", cla_decision_dt=" + cla_decision_dt
				+ ", ol_decision_dt=" + ol_decision_dt + ", in_process=" + in_process + ", report_rec_date="
				+ report_rec_date + ", report_req_date=" + report_req_date + ", report_status=" + report_status
				+ ", ol_decision_date=" + ol_decision_date + ", disposal_day=" + disposal_day + "]";
	}
	
	
	
	
}
