package in.ecgc.smile.erp.reporting.jasper.be.model.bud;




import java.math.BigDecimal;

import org.springframework.stereotype.Component;

@Component
public class BudR17 {

	private String country_name;
	private Double claim_preferred_amount;
	private Double claim_paid_amount;
	private String claim_paid_date;
	private String bud_cell_cd;
	private String claim_no;
	private BigDecimal premium_received;
	private BigDecimal claim_premiuim_ratio;
	
	public String getCountry_name() {
		return country_name;
	}
	public void setCountry_name(String country_name) {
		this.country_name = country_name;
	}
	public Double getClaim_preferred_amount() {
		return claim_preferred_amount;
	}
	public void setClaim_preferred_amount(Double claim_preferred_amount) {
		this.claim_preferred_amount = claim_preferred_amount;
	}
	public Double getClaim_paid_amount() {
		return claim_paid_amount;
	}
	public void setClaim_paid_amount(Double claim_paid_amount) {
		this.claim_paid_amount = claim_paid_amount;
	}
	public String getClaim_paid_date() {
		return claim_paid_date;
	}
	public void setClaim_paid_date(String claim_paid_date) {
		this.claim_paid_date = claim_paid_date;
	}
	public String getBud_cell_cd() {
		return bud_cell_cd;
	}
	public void setBud_cell_cd(String bud_cell_cd) {
		this.bud_cell_cd = bud_cell_cd;
	}
	public String getClaim_no() {
		return claim_no;
	}
	public void setClaim_no(String claim_no) {
		this.claim_no = claim_no;
	}
	public BigDecimal getPremium_received() {
		return premium_received;
	}
	public void setPremium_received(BigDecimal premium_received) {
		this.premium_received = premium_received;
	}
	public BigDecimal getClaim_premiuim_ratio() {
		return claim_premiuim_ratio;
	}
	public void setClaim_premiuim_ratio(BigDecimal claim_premiuim_ratio) {
		this.claim_premiuim_ratio = claim_premiuim_ratio;
	}
	@Override
	public String toString() {
		return "BudR17 [country_name=" + country_name + ", claim_preferred_amount=" + claim_preferred_amount
				+ ", claim_paid_amount=" + claim_paid_amount + ", claim_paid_date=" + claim_paid_date + ", bud_cell_cd="
				+ bud_cell_cd + ", claim_no=" + claim_no + ", premium_received=" + premium_received
				+ ", claim_premiuim_ratio=" + claim_premiuim_ratio + "]";
	}
	
	
	
	
	
	
	
}
