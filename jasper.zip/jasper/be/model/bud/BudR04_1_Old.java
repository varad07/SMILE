package in.ecgc.smile.erp.reporting.jasper.be.model.bud;



import org.springframework.stereotype.Component;

@Component
public class BudR04_1_Old {

	private String logicalloc_cd;
	private String bud_cell_cd;
	private String buyer_ctry;
	private String cla_no;
	private String cla_type;
	private String iwd_dt;
	private String policy_no;
	private String ph_name;
	private String buyer_cd;
	private String byr_name;
	private String ol_bal;
	private String ol_yesno;
	private String ol_auth_rank;
	private String ol_auth_dt;
	private String ol_bal_dp;
	private String ol_bal_da;
	private String top_name;
	private String top_amt;
	private String ol_dec_status;
	private String ol_last_update_date;
	private String cla_entry_dt;
	private String report_no;
	private String report_rec_date;
	private String status;
	private String report_rec_date_1;
	private String byr_default_list;
	private String total_overall_limit;
	private String report_date;
	private String report_status;
	private String commodity_description;
	public String getLogicalloc_cd() {
		return logicalloc_cd;
	}
	public void setLogicalloc_cd(String logicalloc_cd) {
		this.logicalloc_cd = logicalloc_cd;
	}
	public String getBud_cell_cd() {
		return bud_cell_cd;
	}
	public void setBud_cell_cd(String bud_cell_cd) {
		this.bud_cell_cd = bud_cell_cd;
	}
	public String getBuyer_ctry() {
		return buyer_ctry;
	}
	public void setBuyer_ctry(String buyer_ctry) {
		this.buyer_ctry = buyer_ctry;
	}
	public String getCla_no() {
		return cla_no;
	}
	public void setCla_no(String cla_no) {
		this.cla_no = cla_no;
	}
	public String getCla_type() {
		return cla_type;
	}
	public void setCla_type(String cla_type) {
		this.cla_type = cla_type;
	}
	public String getIwd_dt() {
		return iwd_dt;
	}
	public void setIwd_dt(String iwd_dt) {
		this.iwd_dt = iwd_dt;
	}
	public String getPolicy_no() {
		return policy_no;
	}
	public void setPolicy_no(String policy_no) {
		this.policy_no = policy_no;
	}
	public String getPh_name() {
		return ph_name;
	}
	public void setPh_name(String ph_name) {
		this.ph_name = ph_name;
	}
	public String getBuyer_cd() {
		return buyer_cd;
	}
	public void setBuyer_cd(String buyer_cd) {
		this.buyer_cd = buyer_cd;
	}
	public String getByr_name() {
		return byr_name;
	}
	public void setByr_name(String byr_name) {
		this.byr_name = byr_name;
	}
	public String getOl_bal() {
		return ol_bal;
	}
	public void setOl_bal(String ol_bal) {
		this.ol_bal = ol_bal;
	}
	public String getOl_yesno() {
		return ol_yesno;
	}
	public void setOl_yesno(String ol_yesno) {
		this.ol_yesno = ol_yesno;
	}
	public String getOl_auth_rank() {
		return ol_auth_rank;
	}
	public void setOl_auth_rank(String ol_auth_rank) {
		this.ol_auth_rank = ol_auth_rank;
	}
	public String getOl_auth_dt() {
		return ol_auth_dt;
	}
	public void setOl_auth_dt(String ol_auth_dt) {
		this.ol_auth_dt = ol_auth_dt;
	}
	public String getOl_bal_dp() {
		return ol_bal_dp;
	}
	public void setOl_bal_dp(String ol_bal_dp) {
		this.ol_bal_dp = ol_bal_dp;
	}
	public String getOl_bal_da() {
		return ol_bal_da;
	}
	public void setOl_bal_da(String ol_bal_da) {
		this.ol_bal_da = ol_bal_da;
	}
	public String getTop_name() {
		return top_name;
	}
	public void setTop_name(String top_name) {
		this.top_name = top_name;
	}
	public String getTop_amt() {
		return top_amt;
	}
	public void setTop_amt(String top_amt) {
		this.top_amt = top_amt;
	}
	public String getOl_dec_status() {
		return ol_dec_status;
	}
	public void setOl_dec_status(String ol_dec_status) {
		this.ol_dec_status = ol_dec_status;
	}
	public String getOl_last_update_date() {
		return ol_last_update_date;
	}
	public void setOl_last_update_date(String ol_last_update_date) {
		this.ol_last_update_date = ol_last_update_date;
	}
	public String getCla_entry_dt() {
		return cla_entry_dt;
	}
	public void setCla_entry_dt(String cla_entry_dt) {
		this.cla_entry_dt = cla_entry_dt;
	}
	public String getReport_no() {
		return report_no;
	}
	public void setReport_no(String report_no) {
		this.report_no = report_no;
	}
	public String getReport_rec_date() {
		return report_rec_date;
	}
	public void setReport_rec_date(String report_rec_date) {
		this.report_rec_date = report_rec_date;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getReport_rec_date_1() {
		return report_rec_date_1;
	}
	public void setReport_rec_date_1(String report_rec_date_1) {
		this.report_rec_date_1 = report_rec_date_1;
	}
	public String getByr_default_list() {
		return byr_default_list;
	}
	public void setByr_default_list(String byr_default_list) {
		this.byr_default_list = byr_default_list;
	}
	public String getTotal_overall_limit() {
		return total_overall_limit;
	}
	public void setTotal_overall_limit(String total_overall_limit) {
		this.total_overall_limit = total_overall_limit;
	}
	public String getReport_date() {
		return report_date;
	}
	public void setReport_date(String report_date) {
		this.report_date = report_date;
	}
	public String getReport_status() {
		return report_status;
	}
	public void setReport_status(String report_status) {
		this.report_status = report_status;
	}
	
	public String getCommodity_description() {
		return commodity_description;
	}
	public void setCommodity_description(String commodity_description) {
		this.commodity_description = commodity_description;
	}
	@Override
	public String toString() {
		return "BudR04_1 [logicalloc_cd=" + logicalloc_cd + ", bud_cell_cd=" + bud_cell_cd + ", buyer_ctry="
				+ buyer_ctry + ", cla_no=" + cla_no + ", cla_type=" + cla_type + ", iwd_dt=" + iwd_dt + ", policy_no="
				+ policy_no + ", ph_name=" + ph_name + ", buyer_cd=" + buyer_cd + ", byr_name=" + byr_name + ", ol_bal="
				+ ol_bal + ", ol_yesno=" + ol_yesno + ", ol_auth_rank=" + ol_auth_rank + ", ol_auth_dt=" + ol_auth_dt
				+ ", ol_bal_dp=" + ol_bal_dp + ", ol_bal_da=" + ol_bal_da + ", top_name=" + top_name + ", top_amt="
				+ top_amt + ", ol_dec_status=" + ol_dec_status + ", ol_last_update_date=" + ol_last_update_date
				+ ", cla_entry_dt=" + cla_entry_dt + ", report_no=" + report_no + ", report_rec_date=" + report_rec_date
				+ ", status=" + status + ", report_rec_date_1=" + report_rec_date_1 + ", byr_default_list="
				+ byr_default_list + ", total_overall_limit=" + total_overall_limit + ", report_date=" + report_date
				+ ", report_status=" + report_status + ", commodity_description=" + commodity_description + "]";
	}
	
	
	
}
