package in.ecgc.smile.erp.reporting.jasper.be.model.bud;



import org.springframework.stereotype.Component;

@Component
public class BudR09_b {

	
	private String request_number;
	private String buyer_bank_cd;
	private String country_id;
	private String report_status;
	private String request_dt;
	private String report_received_dt;
	private String bud_cell_cd;
	private String ol_auth_dt;
	private String last_trans_dt;
	private String day_diff;
	public String getRequest_number() {
		return request_number;
	}
	public void setRequest_number(String request_number) {
		this.request_number = request_number;
	}
	public String getBuyer_bank_cd() {
		return buyer_bank_cd;
	}
	public void setBuyer_bank_cd(String buyer_bank_cd) {
		this.buyer_bank_cd = buyer_bank_cd;
	}
	public String getCountry_id() {
		return country_id;
	}
	public void setCountry_id(String country_id) {
		this.country_id = country_id;
	}
	public String getReport_status() {
		return report_status;
	}
	public void setReport_status(String report_status) {
		this.report_status = report_status;
	}
	public String getRequest_dt() {
		return request_dt;
	}
	public void setRequest_dt(String request_dt) {
		this.request_dt = request_dt;
	}
	public String getReport_received_dt() {
		return report_received_dt;
	}
	public void setReport_received_dt(String report_received_dt) {
		this.report_received_dt = report_received_dt;
	}
	public String getBud_cell_cd() {
		return bud_cell_cd;
	}
	public void setBud_cell_cd(String bud_cell_cd) {
		this.bud_cell_cd = bud_cell_cd;
	}
	public String getOl_auth_dt() {
		return ol_auth_dt;
	}
	public void setOl_auth_dt(String ol_auth_dt) {
		this.ol_auth_dt = ol_auth_dt;
	}
	public String getLast_trans_dt() {
		return last_trans_dt;
	}
	public void setLast_trans_dt(String last_trans_dt) {
		this.last_trans_dt = last_trans_dt;
	}
	public String getDay_diff() {
		return day_diff;
	}
	public void setDay_diff(String day_diff) {
		this.day_diff = day_diff;
	}
	@Override
	public String toString() {
		return "BudR09_b [request_number=" + request_number + ", buyer_bank_cd=" + buyer_bank_cd + ", country_id="
				+ country_id + ", report_status=" + report_status + ", request_dt=" + request_dt
				+ ", report_received_dt=" + report_received_dt + ", bud_cell_cd=" + bud_cell_cd + ", ol_auth_dt="
				+ ol_auth_dt + ", last_trans_dt=" + last_trans_dt + ", day_diff=" + day_diff + "]";
	}
	
	
	
}