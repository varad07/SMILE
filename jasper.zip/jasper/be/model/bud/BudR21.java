package in.ecgc.smile.erp.reporting.jasper.be.model.bud;



import java.math.BigDecimal;

import org.springframework.stereotype.Component;

@Component
public class BudR21 {
	
	private String terms_of_Payment;
	
	private String country;
	
 	private String cell_No;
	
	private BigDecimal claim_Paid;

	public String getTerms_of_Payment() {
		return terms_of_Payment;
	}

	public void setTerms_of_Payment(String terms_of_Payment) {
		this.terms_of_Payment = terms_of_Payment;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getCell_No() {
		return cell_No;
	}

	public void setCell_No(String cell_No) {
		this.cell_No = cell_No;
	}

	public BigDecimal getClaim_Paid() {
		return claim_Paid;
	}

	public void setClaim_Paid(BigDecimal claim_Paid) {
		this.claim_Paid = claim_Paid;
	}

	@Override
	public String toString() {
		return "BudR21 [terms_of_Payment=" + terms_of_Payment + ", country=" + country + ", cell_No=" + cell_No
				+ ", claim_Paid=" + claim_Paid + "]";
	}

	

	

	
	

}
