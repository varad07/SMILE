package in.ecgc.smile.erp.reporting.jasper.be.model.bud;



import org.springframework.stereotype.Component;

@Component
public class BudR09 {

	
	private String buyer_code;
	private String buyer_country;
	private String request_no;
	private String report_status;
	private String request_dt;
	private String request_received_dt;
	private String ol_desc_dt;
	private String ol_last_trans_dt;
	private String cell_no;
	private String day_diff;
	public String getBuyer_code() {
		return buyer_code;
	}
	public void setBuyer_code(String buyer_code) {
		this.buyer_code = buyer_code;
	}
	public String getBuyer_country() {
		return buyer_country;
	}
	public void setBuyer_country(String buyer_country) {
		this.buyer_country = buyer_country;
	}
	public String getRequest_no() {
		return request_no;
	}
	public void setRequest_no(String request_no) {
		this.request_no = request_no;
	}
	


	public String getReport_status() {
		return report_status;
	}
	public void setReport_status(String report_status) {
		this.report_status = report_status;
	}
	public String getRequest_dt() {
		return request_dt;
	}
	public void setRequest_dt(String request_dt) {
		this.request_dt = request_dt;
	}


	public String getRequest_received_dt() {
		return request_received_dt;
	}
	public void setRequest_received_dt(String request_received_dt) {
		this.request_received_dt = request_received_dt;
	}
	public String getOl_desc_dt() {
		return ol_desc_dt;
	}
	public void setOl_desc_dt(String ol_desc_dt) {
		this.ol_desc_dt = ol_desc_dt;
	}
	public String getOl_last_trans_dt() {
		return ol_last_trans_dt;
	}
	public void setOl_last_trans_dt(String ol_last_trans_dt) {
		this.ol_last_trans_dt = ol_last_trans_dt;
	}
	public String getCell_no() {
		return cell_no;
	}
	public void setCell_no(String cell_no) {
		this.cell_no = cell_no;
	}
	
	public String getDay_diff() {
		return day_diff;
	}
	public void setDay_diff(String day_diff) {
		this.day_diff = day_diff;
	}
	@Override
	public String toString() {
		return "BudR09 [buyer_code=" + buyer_code + ", buyer_country=" + buyer_country + ", request_no=" + request_no
				+ ", report_status=" + report_status + ", request_dt=" + request_dt + ", request_received_dt="
				+ request_received_dt + ", ol_desc_dt=" + ol_desc_dt + ", ol_last_trans_dt=" + ol_last_trans_dt
				+ ", cell_no=" + cell_no + ", day_diff=" + day_diff + "]";
	}
	
	
	
}