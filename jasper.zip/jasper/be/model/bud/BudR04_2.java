package in.ecgc.smile.erp.reporting.jasper.be.model.bud;



import org.springframework.stereotype.Component;

@Component
public class BudR04_2 {

	private String logicalloc_cd;
	private String a;
	private String b;
	private String c;
	private String total_sum;
	public String getLogicalloc_cd() {
		return logicalloc_cd;
	}
	public void setLogicalloc_cd(String logicalloc_cd) {
		this.logicalloc_cd = logicalloc_cd;
	}
	public String getA() {
		return a;
	}
	public void setA(String a) {
		this.a = a;
	}
	public String getB() {
		return b;
	}
	public void setB(String b) {
		this.b = b;
	}
	public String getC() {
		return c;
	}
	public void setC(String c) {
		this.c = c;
	}
	public String getTotal_sum() {
		return total_sum;
	}
	public void setTotal_sum(String total_sum) {
		this.total_sum = total_sum;
	}
	@Override
	public String toString() {
		return "BudR04_2 [logicalloc_cd=" + logicalloc_cd + ", a=" + a + ", b=" + b + ", c=" + c + ", total_sum="
				+ total_sum + "]";
	}
	
	
	
}
