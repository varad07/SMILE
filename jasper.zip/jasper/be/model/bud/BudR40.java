package in.ecgc.smile.erp.reporting.jasper.be.model.bud;



import org.springframework.stereotype.Component;

@Component
public class BudR40 {

	private String buyer_cd;
	private String buyer_name;
	private String buyer_country;
	
	public String getBuyer_cd() {
		return buyer_cd;
	}
	public void setBuyer_cd(String buyer_cd) {
		this.buyer_cd = buyer_cd;
	}
	public String getBuyer_name() {
		return buyer_name;
	}
	public void setBuyer_name(String buyer_name) {
		this.buyer_name = buyer_name;
	}
	public String getBuyer_country() {
		return buyer_country;
	}
	public void setBuyer_country(String ctry_name) {
		this.buyer_country = ctry_name;
	}
	@Override
	public String toString() {
		return "BudR40 [buyer_cd=" + buyer_cd + ", buyer_name=" + buyer_name + ", buyer_country=" + buyer_country + "]";
	}
	
	
		
	
}
