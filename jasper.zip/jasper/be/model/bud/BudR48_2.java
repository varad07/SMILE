package in.ecgc.smile.erp.reporting.jasper.be.model.bud;



import org.springframework.stereotype.Component;

@Component
public class BudR48_2 {

	private String branch;
	private String rod_no;
	private String rod_entry_no;
	private String rod_status;
	private String cover_no;
	private String exporter_code;
	private String exporter_name;
	private String bank_code;
	private String bank_name;
	private String buyer_code;
	private String buyer_name;
	private String country;
	private String buyer_in_default;
	private String ol_status;
	private String limit_reported;
	private String total_outstanding;
	private String total_overall_limit;
	private String total_sanctioned_limit;
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	public String getRod_no() {
		return rod_no;
	}
	public void setRod_no(String rod_no) {
		this.rod_no = rod_no;
	}
	public String getRod_entry_no() {
		return rod_entry_no;
	}
	public void setRod_entry_no(String rod_entry_no) {
		this.rod_entry_no = rod_entry_no;
	}
	public String getRod_status() {
		return rod_status;
	}
	public void setRod_status(String rod_status) {
		this.rod_status = rod_status;
	}
	public String getCover_no() {
		return cover_no;
	}
	public void setCover_no(String cover_no) {
		this.cover_no = cover_no;
	}
	public String getExporter_code() {
		return exporter_code;
	}
	public void setExporter_code(String exporter_code) {
		this.exporter_code = exporter_code;
	}
	public String getExporter_name() {
		return exporter_name;
	}
	public void setExporter_name(String exporter_name) {
		this.exporter_name = exporter_name;
	}
	public String getBank_code() {
		return bank_code;
	}
	public void setBank_code(String bank_code) {
		this.bank_code = bank_code;
	}
	public String getBank_name() {
		return bank_name;
	}
	public void setBank_name(String bank_name) {
		this.bank_name = bank_name;
	}
	public String getBuyer_code() {
		return buyer_code;
	}
	public void setBuyer_code(String buyer_code) {
		this.buyer_code = buyer_code;
	}
	public String getBuyer_name() {
		return buyer_name;
	}
	public void setBuyer_name(String buyer_name) {
		this.buyer_name = buyer_name;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getBuyer_in_default() {
		return buyer_in_default;
	}
	public void setBuyer_in_default(String buyer_in_default) {
		this.buyer_in_default = buyer_in_default;
	}
	public String getOl_status() {
		return ol_status;
	}
	public void setOl_status(String ol_status) {
		this.ol_status = ol_status;
	}
	public String getLimit_reported() {
		return limit_reported;
	}
	public void setLimit_reported(String limit_reported) {
		this.limit_reported = limit_reported;
	}
	public String getTotal_outstanding() {
		return total_outstanding;
	}
	public void setTotal_outstanding(String total_outstanding) {
		this.total_outstanding = total_outstanding;
	}
	public String getTotal_overall_limit() {
		return total_overall_limit;
	}
	public void setTotal_overall_limit(String total_overall_limit) {
		this.total_overall_limit = total_overall_limit;
	}
	public String getTotal_sanctioned_limit() {
		return total_sanctioned_limit;
	}
	public void setTotal_sanctioned_limit(String total_sanctioned_limit) {
		this.total_sanctioned_limit = total_sanctioned_limit;
	}
	@Override
	public String toString() {
		return "BudR48_2 [branch=" + branch + ", rod_no=" + rod_no + ", rod_entry_no=" + rod_entry_no + ", rod_status="
				+ rod_status + ", cover_no=" + cover_no + ", exporter_code=" + exporter_code + ", exporter_name="
				+ exporter_name + ", bank_code=" + bank_code + ", bank_name=" + bank_name + ", buyer_code=" + buyer_code
				+ ", buyer_name=" + buyer_name + ", country=" + country + ", buyer_in_default=" + buyer_in_default
				+ ", ol_status=" + ol_status + ", limit_reported=" + limit_reported + ", total_outstanding="
				+ total_outstanding + ", total_overall_limit=" + total_overall_limit + ", total_sanctioned_limit="
				+ total_sanctioned_limit + "]";
	}

	


		
	
}
