package in.ecgc.smile.erp.reporting.jasper.be.model.pf;

import org.springframework.stereotype.Component;

@Component
public class Pf_r07 {

	    private String join_date;
	    private String pan_eff_frm_dt;
	    private String pl_code;
	    private String emp_firstname;
	    private Double balance;
	    private String gl_code;
	    private String gl_name;
		public String getJoin_date() {
			return join_date;
		}
		public void setJoin_date(String join_date) {
			this.join_date = join_date;
		}
		public String getPan_eff_frm_dt() {
			return pan_eff_frm_dt;
		}
		public void setPan_eff_frm_dt(String pan_eff_frm_dt) {
			this.pan_eff_frm_dt = pan_eff_frm_dt;
		}
		public String getPl_code() {
			return pl_code;
		}
		public void setPl_code(String pl_code) {
			this.pl_code = pl_code;
		}
		public String getEmp_firstname() {
			return emp_firstname;
		}
		public void setEmp_firstname(String emp_firstname) {
			this.emp_firstname = emp_firstname;
		}
		public Double getBalance() {
			return balance;
		}
		public void setBalance(Double balance) {
			this.balance = balance;
		}
		public String getGl_code() {
			return gl_code;
		}
		public void setGl_code(String gl_code) {
			this.gl_code = gl_code;
		}
		public String getGl_name() {
			return gl_name;
		}
		public void setGl_name(String gl_name) {
			this.gl_name = gl_name;
		}
		@Override
		public String toString() {
			return "Pf_r07 [join_date=" + join_date + ", pan_eff_frm_dt=" + pan_eff_frm_dt + ", pl_code=" + pl_code
					+ ", emp_firstname=" + emp_firstname + ", balance=" + balance + ", gl_code=" + gl_code
					+ ", gl_name=" + gl_name + "]";
		}
	    
	    	    
	
}
