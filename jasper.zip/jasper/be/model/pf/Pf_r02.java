package in.ecgc.smile.erp.reporting.jasper.be.model.pf;

import java.math.BigDecimal;

import org.springframework.stereotype.Component;

@Component
public class Pf_r02 {

	 private BigDecimal balance;
	    private String gl_code;
	    private String maingl_cd;
	    private String subgl_cd;
	    private String gl_name;
	    private String personal_ledger_cd;
		public BigDecimal getBalance() {
			return balance;
		}
		public void setBalance(BigDecimal balance) {
			this.balance = balance;
		}
		
		public String getGl_code() {
			return gl_code;
		}
		public void setGl_code(String gl_code) {
			this.gl_code = gl_code;
		}
		public String getMaingl_cd() {
			return maingl_cd;
		}
		public void setMaingl_cd(String maingl_cd) {
			this.maingl_cd = maingl_cd;
		}
		public String getSubgl_cd() {
			return subgl_cd;
		}
		public void setSubgl_cd(String subgl_cd) {
			this.subgl_cd = subgl_cd;
		}
		public String getGl_name() {
			return gl_name;
		}
		public void setGl_name(String gl_name) {
			this.gl_name = gl_name;
		}
		public String getPersonal_ledger_cd() {
			return personal_ledger_cd;
		}
		public void setPersonal_ledger_cd(String personal_ledger_cd) {
			this.personal_ledger_cd = personal_ledger_cd;
		}
		@Override
		public String toString() {
			return "Pf_r02 [balance=" + balance + ", GL_Code=" + gl_code + ", maingl_cd=" + maingl_cd + ", subgl_cd="
					+ subgl_cd + ", gl_name=" + gl_name + ", personal_ledger_cd=" + personal_ledger_cd + "]";
		}
	    
	    
	    
		
		
	    
	    
	
}
