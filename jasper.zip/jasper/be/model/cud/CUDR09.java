package in.ecgc.smile.erp.reporting.jasper.be.model.cud;

import java.math.BigDecimal;

import org.springframework.stereotype.Component;

@Component
public class CUDR09 {
	
	private String regionCd;
	
	private String country;
   
	private String commodity;
	
	private String branch;
	
	private String policyType;
	
	private BigDecimal riskValue;

	private BigDecimal premiumAdjusted;

	public String getRegionCd() {
		return regionCd;
	}

	public void setRegionCd(String regionCd) {
		this.regionCd = regionCd;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getCommodity() {
		return commodity;
	}

	public void setCommodity(String commodity) {
		this.commodity = commodity;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public String getPolicyType() {
		return policyType;
	}

	public void setPolicyType(String policyType) {
		this.policyType = policyType;
	}

	public BigDecimal getRiskValue() {
		return riskValue;
	}

	public void setRiskValue(BigDecimal riskValue) {
		this.riskValue = riskValue;
	}

	public BigDecimal getPremiumAdjusted() {
		return premiumAdjusted;
	}

	public void setPremiumAdjusted(BigDecimal premiumAdjusted) {
		this.premiumAdjusted = premiumAdjusted;
	}

	@Override
	public String toString() {
		return "CUDR09 [regionCd=" + regionCd + ", country=" + country + ", commodity=" + commodity + ", branch="
				+ branch + ", policyType=" + policyType + ", riskValue=" + riskValue + ", premiumAdjusted="
				+ premiumAdjusted + "]";
	}
	
	

}
