package in.ecgc.smile.erp.reporting.jasper.be.model.cud;

import java.math.BigDecimal;

import org.springframework.stereotype.Component;

@Component
public class CUDR10 {

	private String productId;

	private String policyNo;

	private String branch;

	private String regionName;

	private String financialYear;

	private String yearMonth;

	private BigDecimal totalRv;

	private BigDecimal totalPremAdj;

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public String getRegionName() {
		return regionName;
	}

	public void setRegionName(String regionName) {
		this.regionName = regionName;
	}

	public String getFinancialYear() {
		return financialYear;
	}

	public void setFinancialYear(String financialYear) {
		this.financialYear = financialYear;
	}

	public String getYearMonth() {
		return yearMonth;
	}

	public void setYearMonth(String yearMonth) {
		this.yearMonth = yearMonth;
	}

	public BigDecimal getTotalRv() {
		return totalRv;
	}

	public void setTotalRv(BigDecimal totalRv) {
		this.totalRv = totalRv;
	}

	public BigDecimal getTotalPremAdj() {
		return totalPremAdj;
	}

	public void setTotalPremAdj(BigDecimal totalPremAdj) {
		this.totalPremAdj = totalPremAdj;
	}

	@Override
	public String toString() {
		return "CUDR10 [productId=" + productId + ", policyNo=" + policyNo + ", branch=" + branch + ", regionName="
				+ regionName + ", financialYear=" + financialYear + ", yearMonth=" + yearMonth + ", totalRv=" + totalRv
				+ ", totalPremAdj=" + totalPremAdj + "]";
	}

}
