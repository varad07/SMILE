package in.ecgc.smile.erp.reporting.jasper.be.model.external;

import java.util.Date;

//USE FOR orgStructure

public class ParentOfficeMaster {

	private String parentOfficeId;

	private String parentOfficeName;

	private String status;

	private String createdBy;

	private Date createdDt;

	private String lastUpdatedBy;

	private Date lastUpdatedDt;


	public String getParentOfficeId() {
		return parentOfficeId;
	}

	public void setParentOfficeId(String parentOfficeId) {
		this.parentOfficeId = parentOfficeId;
	}

	public String getParentOfficeName() {
		return parentOfficeName;
	}

	public void setParentOfficeName(String parentOfficeName) {
		this.parentOfficeName = parentOfficeName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDt() {
		return createdDt;
	}

	public void setCreatedDt(Date createdDt) {
		this.createdDt = createdDt;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Date getLastUpdatedDt() {
		return lastUpdatedDt;
	}

	public void setLastUpdatedDt(Date lastUpdatedDt) {
		this.lastUpdatedDt = lastUpdatedDt;
	}

	

	@Override
	public String toString() {
		return "ParentOfficeMaster [parentOfficeId=" + parentOfficeId + ", parentOfficeName=" + parentOfficeName
				+ ", status=" + status + ", createdBy=" + createdBy + ", createdDt=" + createdDt + ", lastUpdatedBy="
				+ lastUpdatedBy + ", lastUpdatedDt=" + lastUpdatedDt +  "]";
	}

}
