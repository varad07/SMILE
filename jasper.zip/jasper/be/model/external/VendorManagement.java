package in.ecgc.smile.erp.reporting.jasper.be.model.external;

import lombok.Data;

@Data
public class VendorManagement {

	private String vendorCode;
	private String vendorName;
	private String vendorType;
	private String vendorAddress;
	private String vendorCity;
	private int vendorPincode;
	private String vendorState;
	private String pan;
	private String gstin;
	private String vendorStatus;

	public String getVendorCode() {
		return vendorCode;
	}

	public void setVendorCode(String vendorCode) {
		this.vendorCode = vendorCode;
	}

	public String getVendorName() {
		return vendorName;
	}

	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}

	public String getVendorType() {
		return vendorType;
	}

	public void setVendorType(String vendorType) {
		this.vendorType = vendorType;
	}

	public String getVendorAddress() {
		return vendorAddress;
	}

	public void setVendorAddress(String vendorAddress) {
		this.vendorAddress = vendorAddress;
	}

	public String getVendorCity() {
		return vendorCity;
	}

	public void setVendorCity(String vendorCity) {
		this.vendorCity = vendorCity;
	}

	public int getVendorPincode() {
		return vendorPincode;
	}

	public void setVendorPincode(int vendorPincode) {
		this.vendorPincode = vendorPincode;
	}

	public String getVendorState() {
		return vendorState;
	}

	public void setVendorState(String vendorState) {
		this.vendorState = vendorState;
	}

	public String getPan() {
		return pan;
	}

	public void setPan(String pan) {
		this.pan = pan;
	}

	public String getGstin() {
		return gstin;
	}

	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	public String getVendorStatus() {
		return vendorStatus;
	}

	public void setVendorStatus(String vendorStatus) {
		this.vendorStatus = vendorStatus;
	}

	@Override
	public String toString() {
		return "VendorManagement [vendorCode=" + vendorCode + ", vendorName=" + vendorName + ", vendorType="
				+ vendorType + ", vendorAddress=" + vendorAddress + ", vendorCity=" + vendorCity + ", vendorPincode="
				+ vendorPincode + ", vendorState=" + vendorState + ", pan=" + pan + ", gstin=" + gstin
				+ ", vendorStatus=" + vendorStatus + "]";
	}

}