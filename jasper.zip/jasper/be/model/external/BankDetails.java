package in.ecgc.smile.erp.reporting.jasper.be.model.external;

import lombok.Data;

@Data
public class BankDetails {

//	private String bankName;
	private String bankAccountNo;
	private String beneficiaryName;
//	private String bankBranch;
//	private String bankCity;
//	private String bankState;
//	private String serviceTaxNo;
//	private String rtgs;
//	private String bankAccountType;
//	private Integer micrCode;
//	private String ifscCode;
//	private Integer vendorSerialNo;
	
	
	
	@Override
	public String toString() {
		return "BankDetails [bankAccountNo=" + bankAccountNo + ", beneficiaryName=" + beneficiaryName + "]";
	}



	public String getBankAccountNo() {
		return bankAccountNo;
	}



	public void setBankAccountNo(String bankAccountNo) {
		this.bankAccountNo = bankAccountNo;
	}



	public String getBeneficiaryName() {
		return beneficiaryName;
	}



	public void setBeneficiaryName(String beneficiaryName) {
		this.beneficiaryName = beneficiaryName;
	}
	
	

}
