package in.ecgc.smile.erp.reporting.jasper.be.model.external;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
public class BankBranch {

	@NotBlank(message = "{logicalLocCode.required}")
	private String logicalLocCode;
	private String accountingLogicalLocCode;
	private String nodalBranch;
	private String description;
	@NotBlank(message = "{expensebankName.required}")
	private String expensebankName;
	@NotBlank(message = "{expensebankAddr.required}")
	private String expensebankAddr;
	@Pattern(regexp = "^\\d{9,18}$", message = "Please Enter a Valid Account Number")
	@NotBlank(message = "{expenseAccountNumber.required}")
	private String expenseAccountNumber;
	@Pattern(regexp = "^[A-Z|a-z]{4}[0][a-zA-Z0-9]{6}$", message = "Please Enter a Valid IFSC code")
	@NotBlank(message = "{expenseAcctIfscCode.required}")
	private String expenseAccountIfscCode;
	// @Pattern(regexp = "^[A-Z|a-z]{4}[0][a-zA-Z0-9]{6}$", message = "Please Enter
	// a Valid NEFT code")
	// @NotBlank(message = "{expenseAcctNeftCode.required}")
	private String expenseAcctNeftCode;

	@NotBlank(message = "Required For Transaction")
	private String dribmainGlCd;
	@NotBlank(message = "Required For Transaction")
	private String dribsubGlCd;

	@NotBlank(message = "Required For Transaction")
	private String cribmainGlCd;
	@NotBlank(message = "Required For Transaction")
	private String cribsubGlCd;

	@NotBlank(message = "Required For Transaction")
	private String expensebankmainGlCd;
	@NotBlank(message = "Required For Transaction")
	private String expensebanksubGlCd;

	// @NotBlank(message = "Required For Transaction")
	private String crsubbifurcationCd;

	// @NotBlank(message = "Required For Transaction")
	private String expencebanksubbifurcationCd;

	private String beneficiaryacctName;
	private String beneficiarycodeIbank;

	@NotBlank(message = "{clientId.required}")
	private String clientId;

	// @NotBlank(message = "{clientCd.required}")
	private String clientCd;

	@NotNull(message = "{active.required}")
	private Boolean active;

	private String gstin;

	private String tanNo;

	public String getLogicalLocCode() {
		return logicalLocCode;
	}

	public void setLogicalLocCode(String logicalLocCode) {
		this.logicalLocCode = logicalLocCode;
	}

	public String getAccountingLogicalLocCode() {
		return accountingLogicalLocCode;
	}

	public void setAccountingLogicalLocCode(String accountingLogicalLocCode) {
		this.accountingLogicalLocCode = accountingLogicalLocCode;
	}

	public String getNodalBranch() {
		return nodalBranch;
	}

	public void setNodalBranch(String nodalBranch) {
		this.nodalBranch = nodalBranch;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getExpensebankName() {
		return expensebankName;
	}

	public void setExpensebankName(String expensebankName) {
		this.expensebankName = expensebankName;
	}

	public String getExpensebankAddr() {
		return expensebankAddr;
	}

	public void setExpensebankAddr(String expensebankAddr) {
		this.expensebankAddr = expensebankAddr;
	}

	public String getExpenseAccountNumber() {
		return expenseAccountNumber;
	}

	public void setExpenseAccountNumber(String expenseAccountNumber) {
		this.expenseAccountNumber = expenseAccountNumber;
	}

	public String getExpenseAccountIfscCode() {
		return expenseAccountIfscCode;
	}

	public void setExpenseAccountIfscCode(String expenseAccountIfscCode) {
		this.expenseAccountIfscCode = expenseAccountIfscCode;
	}

	public String getExpenseAcctNeftCode() {
		return expenseAcctNeftCode;
	}

	public void setExpenseAcctNeftCode(String expenseAcctNeftCode) {
		this.expenseAcctNeftCode = expenseAcctNeftCode;
	}

	public String getDribmainGlCd() {
		return dribmainGlCd;
	}

	public void setDribmainGlCd(String dribmainGlCd) {
		this.dribmainGlCd = dribmainGlCd;
	}

	public String getDribsubGlCd() {
		return dribsubGlCd;
	}

	public void setDribsubGlCd(String dribsubGlCd) {
		this.dribsubGlCd = dribsubGlCd;
	}

	public String getCribmainGlCd() {
		return cribmainGlCd;
	}

	public void setCribmainGlCd(String cribmainGlCd) {
		this.cribmainGlCd = cribmainGlCd;
	}

	public String getCribsubGlCd() {
		return cribsubGlCd;
	}

	public void setCribsubGlCd(String cribsubGlCd) {
		this.cribsubGlCd = cribsubGlCd;
	}

	public String getExpensebankmainGlCd() {
		return expensebankmainGlCd;
	}

	public void setExpensebankmainGlCd(String expensebankmainGlCd) {
		this.expensebankmainGlCd = expensebankmainGlCd;
	}

	public String getExpensebanksubGlCd() {
		return expensebanksubGlCd;
	}

	public void setExpensebanksubGlCd(String expensebanksubGlCd) {
		this.expensebanksubGlCd = expensebanksubGlCd;
	}

	public String getCrsubbifurcationCd() {
		return crsubbifurcationCd;
	}

	public void setCrsubbifurcationCd(String crsubbifurcationCd) {
		this.crsubbifurcationCd = crsubbifurcationCd;
	}

	public String getExpencebanksubbifurcationCd() {
		return expencebanksubbifurcationCd;
	}

	public void setExpencebanksubbifurcationCd(String expencebanksubbifurcationCd) {
		this.expencebanksubbifurcationCd = expencebanksubbifurcationCd;
	}

	public String getBeneficiaryacctName() {
		return beneficiaryacctName;
	}

	public void setBeneficiaryacctName(String beneficiaryacctName) {
		this.beneficiaryacctName = beneficiaryacctName;
	}

	public String getBeneficiarycodeIbank() {
		return beneficiarycodeIbank;
	}

	public void setBeneficiarycodeIbank(String beneficiarycodeIbank) {
		this.beneficiarycodeIbank = beneficiarycodeIbank;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getClientCd() {
		return clientCd;
	}

	public void setClientCd(String clientCd) {
		this.clientCd = clientCd;
	}

	public Boolean getActive() {
		return active;
	}

	public void setActive(Boolean active) {
		this.active = active;
	}

	public String getGstin() {
		return gstin;
	}

	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	public String getTanNo() {
		return tanNo;
	}

	public void setTanNo(String tanNo) {
		this.tanNo = tanNo;
	}

	@Override
	public String toString() {
		return "BankBranch [logicalLocCode=" + logicalLocCode + ", accountingLogicalLocCode=" + accountingLogicalLocCode
				+ ", nodalBranch=" + nodalBranch + ", description=" + description + ", expensebankName="
				+ expensebankName + ", expensebankAddr=" + expensebankAddr + ", expenseAccountNumber="
				+ expenseAccountNumber + ", expenseAccountIfscCode=" + expenseAccountIfscCode + ", expenseAcctNeftCode="
				+ expenseAcctNeftCode + ", dribmainGlCd=" + dribmainGlCd + ", dribsubGlCd=" + dribsubGlCd
				+ ", cribmainGlCd=" + cribmainGlCd + ", cribsubGlCd=" + cribsubGlCd + ", expensebankmainGlCd="
				+ expensebankmainGlCd + ", expensebanksubGlCd=" + expensebanksubGlCd + ", crsubbifurcationCd="
				+ crsubbifurcationCd + ", expencebanksubbifurcationCd=" + expencebanksubbifurcationCd
				+ ", beneficiaryacctName=" + beneficiaryacctName + ", beneficiarycodeIbank=" + beneficiarycodeIbank
				+ ", clientId=" + clientId + ", clientCd=" + clientCd + ", active=" + active + ", gstin=" + gstin
				+ ", tanNo=" + tanNo + "]";
	}

}
