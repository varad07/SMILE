package in.ecgc.smile.erp.reporting.jasper.be.model.ecib;

import java.math.BigDecimal;

public class EcibInUR16 {
	
	private String coverNumber;
	
	private String coverType;
	
	private String bankName;
	
	private String bankBranchName;
	
	private String exporterName;
	
	private BigDecimal riskValue;
	
	private BigDecimal premiumAdjusted;
	
	private Integer year;
	
	private Integer month;

	public String getCoverNumber() {
		return coverNumber;
	}

	public void setCoverNumber(String coverNumber) {
		this.coverNumber = coverNumber;
	}

	public String getCoverType() {
		return coverType;
	}

	public void setCoverType(String coverType) {
		this.coverType = coverType;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getBankBranchName() {
		return bankBranchName;
	}

	public void setBankBranchName(String bankBranchName) {
		this.bankBranchName = bankBranchName;
	}

	public String getExporterName() {
		return exporterName;
	}

	public void setExporterName(String exporterName) {
		this.exporterName = exporterName;
	}

	public BigDecimal getRiskValue() {
		return riskValue;
	}

	public void setRiskValue(BigDecimal riskValue) {
		this.riskValue = riskValue;
	}

	public BigDecimal getPremiumAdjusted() {
		return premiumAdjusted;
	}

	public void setPremiumAdjusted(BigDecimal premiumAdjusted) {
		this.premiumAdjusted = premiumAdjusted;
	}

	public Integer getYear() {
		return year;
	}

	public void setYear(Integer year) {
		this.year = year;
	}

	public Integer getMonth() {
		return month;
	}

	public void setMonth(Integer month) {
		this.month = month;
	}

	@Override
	public String toString() {
		return "EcibInUR16 [coverNumber=" + coverNumber + ", coverType=" + coverType + ", bankName=" + bankName
				+ ", bankBranchName=" + bankBranchName + ", exporterName=" + exporterName + ", riskValue=" + riskValue
				+ ", premiumAdjusted=" + premiumAdjusted + ", year=" + year + ", month=" + month + "]";
	}
	
	
		

}
