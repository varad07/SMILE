package in.ecgc.smile.erp.reporting.jasper.be.model.ecib;

import java.math.BigDecimal;

public class EcibWtUR63 {
	
	private String ecibType;
	
	private String bankName;
	
	private BigDecimal premiumEarned;
	
	private BigDecimal riskValue;

	public String getEcibType() {
		return ecibType;
	}

	public void setEcibType(String ecibType) {
		this.ecibType = ecibType;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public BigDecimal getPremiumEarned() {
		return premiumEarned;
	}

	public void setPremiumEarned(BigDecimal premiumEarned) {
		this.premiumEarned = premiumEarned;
	}

	public BigDecimal getRiskValue() {
		return riskValue;
	}

	public void setRiskValue(BigDecimal riskValue) {
		this.riskValue = riskValue;
	}

	@Override
	public String toString() {
		return "EcibWtUR63 [ecibType=" + ecibType + ", bankName=" + bankName + ", premiumEarned=" + premiumEarned
				+ ", riskValue=" + riskValue + "]";
	}

}
