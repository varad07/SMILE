package in.ecgc.smile.erp.reporting.jasper.be.model.ecib;

import java.math.BigDecimal;

public class EcibWtUR64 {
	
	private String ecibType;
	
	private String ecgcBranchName;
	
	private BigDecimal premiumEarned;
	
	private BigDecimal riskValue;
	
	private String bankName;

	public String getEcibType() {
		return ecibType;
	}

	public void setEcibType(String ecibType) {
		this.ecibType = ecibType;
	}

	public String getEcgcBranchName() {
		return ecgcBranchName;
	}

	public void setEcgcBranchName(String ecgcBranchName) {
		this.ecgcBranchName = ecgcBranchName;
	}

	public BigDecimal getPremiumEarned() {
		return premiumEarned;
	}

	public void setPremiumEarned(BigDecimal premiumEarned) {
		this.premiumEarned = premiumEarned;
	}

	public BigDecimal getRiskValue() {
		return riskValue;
	}

	public void setRiskValue(BigDecimal riskValue) {
		this.riskValue = riskValue;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	@Override
	public String toString() {
		return "EcibWtUR64 [ecibType=" + ecibType + ", ecgcBranchName=" + ecgcBranchName + ", premiumEarned="
				+ premiumEarned + ", riskValue=" + riskValue + ", bankName=" + bankName + "]";
	}
	
	
	

}
