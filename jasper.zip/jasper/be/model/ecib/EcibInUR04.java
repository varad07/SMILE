package in.ecgc.smile.erp.reporting.jasper.be.model.ecib;

import java.math.BigDecimal;

public class EcibInUR04 {
	
	private String coverNumber;
	
	private String freshRenewal;
	
	private String bankBranchName;
	
	private String exporterName;
	
	private BigDecimal ecibCoverValue;
	
	private String coverPeriod;

	private  BigDecimal percentageOfCover;
	
	private BigDecimal premiumRate;
	
	private Boolean lcCoverForShipOnly;
	
	private Boolean lcCoverShipAssociate;
	
	private Boolean nursingEcibCover;
	
    private BigDecimal balAsDpInAcc;
	
	private String remarks;

	public String getCoverNumber() {
		return coverNumber;
	}

	public void setCoverNumber(String coverNumber) {
		this.coverNumber = coverNumber;
	}

	public String getFreshRenewal() {
		return freshRenewal;
	}

	public void setFreshRenewal(String freshRenewal) {
		this.freshRenewal = freshRenewal;
	}

	public String getBankBranchName() {
		return bankBranchName;
	}

	public void setBankBranchName(String bankBranchName) {
		this.bankBranchName = bankBranchName;
	}

	public String getExporterName() {
		return exporterName;
	}

	public void setExporterName(String exporterName) {
		this.exporterName = exporterName;
	}

	public BigDecimal getEcibCoverValue() {
		return ecibCoverValue;
	}

	public void setEcibCoverValue(BigDecimal ecibCoverValue) {
		this.ecibCoverValue = ecibCoverValue;
	}

	public String getCoverPeriod() {
		return coverPeriod;
	}

	public void setCoverPeriod(String coverPeriod) {
		this.coverPeriod = coverPeriod;
	}

	public BigDecimal getPercentageOfCover() {
		return percentageOfCover;
	}

	public void setPercentageOfCover(BigDecimal percentageOfCover) {
		this.percentageOfCover = percentageOfCover;
	}

	public BigDecimal getPremiumRate() {
		return premiumRate;
	}

	public void setPremiumRate(BigDecimal premiumRate) {
		this.premiumRate = premiumRate;
	}

	public Boolean getLcCoverForShipOnly() {
		return lcCoverForShipOnly;
	}

	public void setLcCoverForShipOnly(Boolean lcCoverForShipOnly) {
		this.lcCoverForShipOnly = lcCoverForShipOnly;
	}

	public Boolean getLcCoverShipAssociate() {
		return lcCoverShipAssociate;
	}

	public void setLcCoverShipAssociate(Boolean lcCoverShipAssociate) {
		this.lcCoverShipAssociate = lcCoverShipAssociate;
	}

	public Boolean getNursingEcibCover() {
		return nursingEcibCover;
	}

	public void setNursingEcibCover(Boolean nursingEcibCover) {
		this.nursingEcibCover = nursingEcibCover;
	}

	public BigDecimal getBalAsDpInAcc() {
		return balAsDpInAcc;
	}

	public void setBalAsDpInAcc(BigDecimal balAsDpInAcc) {
		this.balAsDpInAcc = balAsDpInAcc;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	@Override
	public String toString() {
		return "EcibInUR04 [coverNumber=" + coverNumber + ", freshRenewal=" + freshRenewal + ", bankBranchName="
				+ bankBranchName + ", exporterName=" + exporterName + ", ecibCoverValue=" + ecibCoverValue
				+ ", coverPeriod=" + coverPeriod + ", percentageOfCover=" + percentageOfCover + ", premiumRate="
				+ premiumRate + ", lcCoverForShipOnly=" + lcCoverForShipOnly + ", lcCoverShipAssociate="
				+ lcCoverShipAssociate + ", nursingEcibCover=" + nursingEcibCover + ", balAsDpInAcc=" + balAsDpInAcc
				+ ", remarks=" + remarks + "]";
	}
}
