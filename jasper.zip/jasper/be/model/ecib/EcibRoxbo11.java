package in.ecgc.smile.erp.reporting.jasper.be.model.ecib;

import java.math.BigDecimal;

public class EcibRoxbo11 {
	
private String bank_code;
	
	private String cover_type;
	
	private String expoter_code;
	
	private BigDecimal calculated_adp;
	
	private String calculated_adp_inr;
	
	private BigDecimal month;
	
	private BigDecimal year;

	public String getBank_code() {
		return bank_code;
	}

	public void setBank_code(String bank_code) {
		this.bank_code = bank_code;
	}

	public String getCover_type() {
		return cover_type;
	}

	public void setCover_type(String cover_type) {
		this.cover_type = cover_type;
	}

	public String getExpoter_code() {
		return expoter_code;
	}

	public void setExpoter_code(String expoter_code) {
		this.expoter_code = expoter_code;
	}

	public BigDecimal getCalculated_adp() {
		return calculated_adp;
	}

	public void setCalculated_adp(BigDecimal calculated_adp) {
		this.calculated_adp = calculated_adp;
	}

	public String getCalculated_adp_inr() {
		return calculated_adp_inr;
	}

	public void setCalculated_adp_inr(String calculated_adp_inr) {
		this.calculated_adp_inr = calculated_adp_inr;
	}

	public BigDecimal getMonth() {
		return month;
	}

	public void setMonth(BigDecimal month) {
		this.month = month;
	}

	public BigDecimal getYear() {
		return year;
	}

	public void setYear(BigDecimal year) {
		this.year = year;
	}

	@Override
	public String toString() {
		return "EcibRoxbo11 [bank_code=" + bank_code + ", cover_type=" + cover_type + ", expoter_code=" + expoter_code
				+ ", calculated_adp=" + calculated_adp + ", calculated_adp_inr=" + calculated_adp_inr + ", month="
				+ month + ", year=" + year + "]";
	}
	
	
	
	
	

}