package in.ecgc.smile.erp.reporting.jasper.be.model.ecib;

import java.math.BigDecimal;

public class EcibRoxbo12 {

	
private String expoter_code;
	
	private BigDecimal calculated_adp;
	
	private String calculated_adp_inr;
	
	private BigDecimal month;
	
	private BigDecimal year;

	

	public String getExpoter_code() {
		return expoter_code;
	}

	public void setExpoter_code(String expoter_code) {
		this.expoter_code = expoter_code;
	}

	public BigDecimal getCalculated_adp() {
		return calculated_adp;
	}

	public void setCalculated_adp(BigDecimal calculated_adp) {
		this.calculated_adp = calculated_adp;
	}

	public String getCalculated_adp_inr() {
		return calculated_adp_inr;
	}

	public void setCalculated_adp_inr(String calculated_adp_inr) {
		this.calculated_adp_inr = calculated_adp_inr;
	}

	public BigDecimal getMonth() {
		return month;
	}

	public void setMonth(BigDecimal month) {
		this.month = month;
	}

	public BigDecimal getYear() {
		return year;
	}

	public void setYear(BigDecimal year) {
		this.year = year;
	}

	@Override
	public String toString() {
		return "EcibRoxbo12 [expoter_code=" + expoter_code + ", calculated_adp=" + calculated_adp
				+ ", calculated_adp_inr=" + calculated_adp_inr + ", month=" + month + ", year=" + year + "]";
	}

	
}
