package in.ecgc.smile.erp.reporting.jasper.be.model.accounts;

import java.util.List;
import java.util.Map;

public class ConsTrialBaldtl {

	private Map<String, List<ConsTrialBal>> consTrialBalMap;

	public Map<String, List<ConsTrialBal>> getConsTrialBalMap() {
		return consTrialBalMap;
	}

	public void setConsTrialBalMap(Map<String, List<ConsTrialBal>> consTrialBalMap) {
		this.consTrialBalMap = consTrialBalMap;
	}

	@Override
	public String toString() {
		return "ConsTrialBaldtl [consTrialBalMap=" + consTrialBalMap + "]";
	}
	
	
}
