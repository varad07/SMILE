package in.ecgc.smile.erp.reporting.jasper.be.model.accounts;

public class Schedule5 {
	
	private String createdBy;

	private String scheduleItem5dot1Name;
	private String scheduleItem5dot1Amt;
	private String scheduleItem5dot1PreAmt;
	
	private String scheduleItem5dot2Name;
	private String scheduleItem5dot2Amt;
	private String scheduleItem5dot2PreAmt;
	
	private String scheduleItem5dot3Name;
	private String scheduleItem5dot3Amt;
	private String scheduleItem5dot3PreAmt;
	
	private String scheduleItem5dot4Name;
	private String scheduleItem5dot4Amt;
	private String scheduleItem5dot4PreAmt;
	
	private String scheduleItem5dot5Name;
	private String scheduleItem5dot5Amt;
	private String scheduleItem5dot5PreAmt;
	
	private String scheduleItem5dot6Name;
	private String scheduleItem5dot6Amt;
	private String scheduleItem5dot6PreAmt;

	private String scheduleItem5dot7Name;
	private String scheduleItem5dot7Amt;
	private String scheduleItem5dot7PreAmt;
	
	private String scheduleItem5dot8Name;
	private String scheduleItem5dot8Amt;
	private String scheduleItem5dot8PreAmt;
	
	private String finalSchedule5Name;
	private String finalSchedule5Amt;
	private String finalSchedule5PreAmt;
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getScheduleItem5dot1Name() {
		return scheduleItem5dot1Name;
	}
	public void setScheduleItem5dot1Name(String scheduleItem5dot1Name) {
		this.scheduleItem5dot1Name = scheduleItem5dot1Name;
	}
	public String getScheduleItem5dot1Amt() {
		return scheduleItem5dot1Amt;
	}
	public void setScheduleItem5dot1Amt(String scheduleItem5dot1Amt) {
		this.scheduleItem5dot1Amt = scheduleItem5dot1Amt;
	}
	public String getScheduleItem5dot1PreAmt() {
		return scheduleItem5dot1PreAmt;
	}
	public void setScheduleItem5dot1PreAmt(String scheduleItem5dot1PreAmt) {
		this.scheduleItem5dot1PreAmt = scheduleItem5dot1PreAmt;
	}
	public String getScheduleItem5dot2Name() {
		return scheduleItem5dot2Name;
	}
	public void setScheduleItem5dot2Name(String scheduleItem5dot2Name) {
		this.scheduleItem5dot2Name = scheduleItem5dot2Name;
	}
	public String getScheduleItem5dot2Amt() {
		return scheduleItem5dot2Amt;
	}
	public void setScheduleItem5dot2Amt(String scheduleItem5dot2Amt) {
		this.scheduleItem5dot2Amt = scheduleItem5dot2Amt;
	}
	public String getScheduleItem5dot2PreAmt() {
		return scheduleItem5dot2PreAmt;
	}
	public void setScheduleItem5dot2PreAmt(String scheduleItem5dot2PreAmt) {
		this.scheduleItem5dot2PreAmt = scheduleItem5dot2PreAmt;
	}
	public String getScheduleItem5dot3Name() {
		return scheduleItem5dot3Name;
	}
	public void setScheduleItem5dot3Name(String scheduleItem5dot3Name) {
		this.scheduleItem5dot3Name = scheduleItem5dot3Name;
	}
	public String getScheduleItem5dot3Amt() {
		return scheduleItem5dot3Amt;
	}
	public void setScheduleItem5dot3Amt(String scheduleItem5dot3Amt) {
		this.scheduleItem5dot3Amt = scheduleItem5dot3Amt;
	}
	public String getScheduleItem5dot3PreAmt() {
		return scheduleItem5dot3PreAmt;
	}
	public void setScheduleItem5dot3PreAmt(String scheduleItem5dot3PreAmt) {
		this.scheduleItem5dot3PreAmt = scheduleItem5dot3PreAmt;
	}
	public String getScheduleItem5dot4Name() {
		return scheduleItem5dot4Name;
	}
	public void setScheduleItem5dot4Name(String scheduleItem5dot4Name) {
		this.scheduleItem5dot4Name = scheduleItem5dot4Name;
	}
	public String getScheduleItem5dot4Amt() {
		return scheduleItem5dot4Amt;
	}
	public void setScheduleItem5dot4Amt(String scheduleItem5dot4Amt) {
		this.scheduleItem5dot4Amt = scheduleItem5dot4Amt;
	}
	public String getScheduleItem5dot4PreAmt() {
		return scheduleItem5dot4PreAmt;
	}
	public void setScheduleItem5dot4PreAmt(String scheduleItem5dot4PreAmt) {
		this.scheduleItem5dot4PreAmt = scheduleItem5dot4PreAmt;
	}
	public String getScheduleItem5dot5Name() {
		return scheduleItem5dot5Name;
	}
	public void setScheduleItem5dot5Name(String scheduleItem5dot5Name) {
		this.scheduleItem5dot5Name = scheduleItem5dot5Name;
	}
	public String getScheduleItem5dot5Amt() {
		return scheduleItem5dot5Amt;
	}
	public void setScheduleItem5dot5Amt(String scheduleItem5dot5Amt) {
		this.scheduleItem5dot5Amt = scheduleItem5dot5Amt;
	}
	public String getScheduleItem5dot5PreAmt() {
		return scheduleItem5dot5PreAmt;
	}
	public void setScheduleItem5dot5PreAmt(String scheduleItem5dot5PreAmt) {
		this.scheduleItem5dot5PreAmt = scheduleItem5dot5PreAmt;
	}
	public String getScheduleItem5dot6Name() {
		return scheduleItem5dot6Name;
	}
	public void setScheduleItem5dot6Name(String scheduleItem5dot6Name) {
		this.scheduleItem5dot6Name = scheduleItem5dot6Name;
	}
	public String getScheduleItem5dot6Amt() {
		return scheduleItem5dot6Amt;
	}
	public void setScheduleItem5dot6Amt(String scheduleItem5dot6Amt) {
		this.scheduleItem5dot6Amt = scheduleItem5dot6Amt;
	}
	public String getScheduleItem5dot6PreAmt() {
		return scheduleItem5dot6PreAmt;
	}
	public void setScheduleItem5dot6PreAmt(String scheduleItem5dot6PreAmt) {
		this.scheduleItem5dot6PreAmt = scheduleItem5dot6PreAmt;
	}
	public String getScheduleItem5dot7Name() {
		return scheduleItem5dot7Name;
	}
	public void setScheduleItem5dot7Name(String scheduleItem5dot7Name) {
		this.scheduleItem5dot7Name = scheduleItem5dot7Name;
	}
	public String getScheduleItem5dot7Amt() {
		return scheduleItem5dot7Amt;
	}
	public void setScheduleItem5dot7Amt(String scheduleItem5dot7Amt) {
		this.scheduleItem5dot7Amt = scheduleItem5dot7Amt;
	}
	public String getScheduleItem5dot7PreAmt() {
		return scheduleItem5dot7PreAmt;
	}
	public void setScheduleItem5dot7PreAmt(String scheduleItem5dot7PreAmt) {
		this.scheduleItem5dot7PreAmt = scheduleItem5dot7PreAmt;
	}
	public String getScheduleItem5dot8Name() {
		return scheduleItem5dot8Name;
	}
	public void setScheduleItem5dot8Name(String scheduleItem5dot8Name) {
		this.scheduleItem5dot8Name = scheduleItem5dot8Name;
	}
	public String getScheduleItem5dot8Amt() {
		return scheduleItem5dot8Amt;
	}
	public void setScheduleItem5dot8Amt(String scheduleItem5dot8Amt) {
		this.scheduleItem5dot8Amt = scheduleItem5dot8Amt;
	}
	public String getScheduleItem5dot8PreAmt() {
		return scheduleItem5dot8PreAmt;
	}
	public void setScheduleItem5dot8PreAmt(String scheduleItem5dot8PreAmt) {
		this.scheduleItem5dot8PreAmt = scheduleItem5dot8PreAmt;
	}
	public String getFinalSchedule5Name() {
		return finalSchedule5Name;
	}
	public void setFinalSchedule5Name(String finalSchedule5Name) {
		this.finalSchedule5Name = finalSchedule5Name;
	}
	public String getFinalSchedule5Amt() {
		return finalSchedule5Amt;
	}
	public void setFinalSchedule5Amt(String finalSchedule5Amt) {
		this.finalSchedule5Amt = finalSchedule5Amt;
	}
	public String getFinalSchedule5PreAmt() {
		return finalSchedule5PreAmt;
	}
	public void setFinalSchedule5PreAmt(String finalSchedule5PreAmt) {
		this.finalSchedule5PreAmt = finalSchedule5PreAmt;
	}
	@Override
	public String toString() {
		return "Schedule5 [createdBy=" + createdBy + ", scheduleItem5dot1Name=" + scheduleItem5dot1Name
				+ ", scheduleItem5dot1Amt=" + scheduleItem5dot1Amt + ", scheduleItem5dot1PreAmt="
				+ scheduleItem5dot1PreAmt + ", scheduleItem5dot2Name=" + scheduleItem5dot2Name
				+ ", scheduleItem5dot2Amt=" + scheduleItem5dot2Amt + ", scheduleItem5dot2PreAmt="
				+ scheduleItem5dot2PreAmt + ", scheduleItem5dot3Name=" + scheduleItem5dot3Name
				+ ", scheduleItem5dot3Amt=" + scheduleItem5dot3Amt + ", scheduleItem5dot3PreAmt="
				+ scheduleItem5dot3PreAmt + ", scheduleItem5dot4Name=" + scheduleItem5dot4Name
				+ ", scheduleItem5dot4Amt=" + scheduleItem5dot4Amt + ", scheduleItem5dot4PreAmt="
				+ scheduleItem5dot4PreAmt + ", scheduleItem5dot5Name=" + scheduleItem5dot5Name
				+ ", scheduleItem5dot5Amt=" + scheduleItem5dot5Amt + ", scheduleItem5dot5PreAmt="
				+ scheduleItem5dot5PreAmt + ", scheduleItem5dot6Name=" + scheduleItem5dot6Name
				+ ", scheduleItem5dot6Amt=" + scheduleItem5dot6Amt + ", scheduleItem5dot6PreAmt="
				+ scheduleItem5dot6PreAmt + ", scheduleItem5dot7Name=" + scheduleItem5dot7Name
				+ ", scheduleItem5dot7Amt=" + scheduleItem5dot7Amt + ", scheduleItem5dot7PreAmt="
				+ scheduleItem5dot7PreAmt + ", scheduleItem5dot8Name=" + scheduleItem5dot8Name
				+ ", scheduleItem5dot8Amt=" + scheduleItem5dot8Amt + ", scheduleItem5dot8PreAmt="
				+ scheduleItem5dot8PreAmt + ", finalSchedule5Name=" + finalSchedule5Name + ", finalSchedule5Amt="
				+ finalSchedule5Amt + ", finalSchedule5PreAmt=" + finalSchedule5PreAmt + "]";
	}
	
	
	

}
