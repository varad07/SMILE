package in.ecgc.smile.erp.reporting.jasper.be.model.accounts;

public class Schedule2 {

	private String createdBy;

	private String scheduleItem2dot1Name;
	
	private String scheduleItem2dot2Name;
	private String scheduleItem2dot2Amt;
	private String scheduleItem2dot2PreAmt;

	private String scheduleItem2dot3Name;
	private String scheduleItem2dot3Amt;
	private String scheduleItem2dot3PreAmt;

	private String scheduleItem2dot4Name;
	private String scheduleItem2dot4Amt;
	private String scheduleItem2dot4PreAmt;

	private String scheduleItem2dot5Name;
	
	private String scheduleItem2dot5dot1Name;
	private String scheduleItem2dot5dot1Amt;
	private String scheduleItem2dot5dot1PreAmt;
	
	private String scheduleItem2dot5dot2Name;
	private String scheduleItem2dot5dot2Amt;
	private String scheduleItem2dot5dot2PreAmt;
	
	private String scheduleItem2dot5dot3Name;
	private String scheduleItem2dot5dot3Amt;
	private String scheduleItem2dot5dot3PreAmt;
	
	private String scheduleItem2dot5dot4Amt;
	private String scheduleItem2dot5dot4PreAmt;
	
	private String scheduleItem2dot6Name;
	private String scheduleItem2dot6Amt;
	private String scheduleItem2dot6PreAmt;
	
	private String scheduleItem2dot7Name;
	private String scheduleItem2dot7Amt;
	private String scheduleItem2dot7PreAmt;
	
	private String scheduleItem2dot8Name;
	private String scheduleItem2dot8Amt;
	private String scheduleItem2dot8PreAmt;
	
	private String scheduleItem2dot9Name;
	private String scheduleItem2dot9Amt;
	private String scheduleItem2dot9PreAmt;
	
	private String scheduleItem2dot10Name;
	private String scheduleItem2dot10Amt;
	private String scheduleItem2dot10PreAmt;
	
	private String scheduleItem2dot11Name;
	private String scheduleItem2dot11Amt;
	private String scheduleItem2dot11PreAmt;
	
	private String scheduleItem2dot12Name;
	private String scheduleItem2dot12Amt;
	private String scheduleItem2dot12PreAmt;
	

	private String finalScheduleName;

	private String finalSchedule2Amt;
	private String finalSchedule2PreAmt;
	
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getScheduleItem2dot1Name() {
		return scheduleItem2dot1Name;
	}
	public void setScheduleItem2dot1Name(String scheduleItem2dot1Name) {
		this.scheduleItem2dot1Name = scheduleItem2dot1Name;
	}
	public String getScheduleItem2dot2Name() {
		return scheduleItem2dot2Name;
	}
	public void setScheduleItem2dot2Name(String scheduleItem2dot2Name) {
		this.scheduleItem2dot2Name = scheduleItem2dot2Name;
	}
	public String getScheduleItem2dot2Amt() {
		return scheduleItem2dot2Amt;
	}
	public void setScheduleItem2dot2Amt(String scheduleItem2dot2Amt) {
		this.scheduleItem2dot2Amt = scheduleItem2dot2Amt;
	}
	public String getScheduleItem2dot2PreAmt() {
		return scheduleItem2dot2PreAmt;
	}
	public void setScheduleItem2dot2PreAmt(String scheduleItem2dot2PreAmt) {
		this.scheduleItem2dot2PreAmt = scheduleItem2dot2PreAmt;
	}
	public String getScheduleItem2dot3Name() {
		return scheduleItem2dot3Name;
	}
	public void setScheduleItem2dot3Name(String scheduleItem2dot3Name) {
		this.scheduleItem2dot3Name = scheduleItem2dot3Name;
	}
	public String getScheduleItem2dot3Amt() {
		return scheduleItem2dot3Amt;
	}
	public void setScheduleItem2dot3Amt(String scheduleItem2dot3Amt) {
		this.scheduleItem2dot3Amt = scheduleItem2dot3Amt;
	}
	public String getScheduleItem2dot3PreAmt() {
		return scheduleItem2dot3PreAmt;
	}
	public void setScheduleItem2dot3PreAmt(String scheduleItem2dot3PreAmt) {
		this.scheduleItem2dot3PreAmt = scheduleItem2dot3PreAmt;
	}
	public String getScheduleItem2dot4Name() {
		return scheduleItem2dot4Name;
	}
	public void setScheduleItem2dot4Name(String scheduleItem2dot4Name) {
		this.scheduleItem2dot4Name = scheduleItem2dot4Name;
	}
	public String getScheduleItem2dot4Amt() {
		return scheduleItem2dot4Amt;
	}
	public void setScheduleItem2dot4Amt(String scheduleItem2dot4Amt) {
		this.scheduleItem2dot4Amt = scheduleItem2dot4Amt;
	}
	public String getScheduleItem2dot4PreAmt() {
		return scheduleItem2dot4PreAmt;
	}
	public void setScheduleItem2dot4PreAmt(String scheduleItem2dot4PreAmt) {
		this.scheduleItem2dot4PreAmt = scheduleItem2dot4PreAmt;
	}
	public String getScheduleItem2dot5Name() {
		return scheduleItem2dot5Name;
	}
	public void setScheduleItem2dot5Name(String scheduleItem2dot5Name) {
		this.scheduleItem2dot5Name = scheduleItem2dot5Name;
	}
	public String getScheduleItem2dot5dot1Name() {
		return scheduleItem2dot5dot1Name;
	}
	public void setScheduleItem2dot5dot1Name(String scheduleItem2dot5dot1Name) {
		this.scheduleItem2dot5dot1Name = scheduleItem2dot5dot1Name;
	}
	public String getScheduleItem2dot5dot1Amt() {
		return scheduleItem2dot5dot1Amt;
	}
	public void setScheduleItem2dot5dot1Amt(String scheduleItem2dot5dot1Amt) {
		this.scheduleItem2dot5dot1Amt = scheduleItem2dot5dot1Amt;
	}
	public String getScheduleItem2dot5dot1PreAmt() {
		return scheduleItem2dot5dot1PreAmt;
	}
	public void setScheduleItem2dot5dot1PreAmt(String scheduleItem2dot5dot1PreAmt) {
		this.scheduleItem2dot5dot1PreAmt = scheduleItem2dot5dot1PreAmt;
	}
	public String getScheduleItem2dot5dot2Name() {
		return scheduleItem2dot5dot2Name;
	}
	public void setScheduleItem2dot5dot2Name(String scheduleItem2dot5dot2Name) {
		this.scheduleItem2dot5dot2Name = scheduleItem2dot5dot2Name;
	}
	public String getScheduleItem2dot5dot2Amt() {
		return scheduleItem2dot5dot2Amt;
	}
	public void setScheduleItem2dot5dot2Amt(String scheduleItem2dot5dot2Amt) {
		this.scheduleItem2dot5dot2Amt = scheduleItem2dot5dot2Amt;
	}
	public String getScheduleItem2dot5dot2PreAmt() {
		return scheduleItem2dot5dot2PreAmt;
	}
	public void setScheduleItem2dot5dot2PreAmt(String scheduleItem2dot5dot2PreAmt) {
		this.scheduleItem2dot5dot2PreAmt = scheduleItem2dot5dot2PreAmt;
	}
	public String getScheduleItem2dot5dot3Name() {
		return scheduleItem2dot5dot3Name;
	}
	public void setScheduleItem2dot5dot3Name(String scheduleItem2dot5dot3Name) {
		this.scheduleItem2dot5dot3Name = scheduleItem2dot5dot3Name;
	}
	public String getScheduleItem2dot5dot3Amt() {
		return scheduleItem2dot5dot3Amt;
	}
	public void setScheduleItem2dot5dot3Amt(String scheduleItem2dot5dot3Amt) {
		this.scheduleItem2dot5dot3Amt = scheduleItem2dot5dot3Amt;
	}
	public String getScheduleItem2dot5dot3PreAmt() {
		return scheduleItem2dot5dot3PreAmt;
	}
	public void setScheduleItem2dot5dot3PreAmt(String scheduleItem2dot5dot3PreAmt) {
		this.scheduleItem2dot5dot3PreAmt = scheduleItem2dot5dot3PreAmt;
	}
	public String getScheduleItem2dot5dot4Amt() {
		return scheduleItem2dot5dot4Amt;
	}
	public void setScheduleItem2dot5dot4Amt(String scheduleItem2dot5dot4Amt) {
		this.scheduleItem2dot5dot4Amt = scheduleItem2dot5dot4Amt;
	}
	public String getScheduleItem2dot5dot4PreAmt() {
		return scheduleItem2dot5dot4PreAmt;
	}
	public void setScheduleItem2dot5dot4PreAmt(String scheduleItem2dot5dot4PreAmt) {
		this.scheduleItem2dot5dot4PreAmt = scheduleItem2dot5dot4PreAmt;
	}
	public String getScheduleItem2dot6Name() {
		return scheduleItem2dot6Name;
	}
	public void setScheduleItem2dot6Name(String scheduleItem2dot6Name) {
		this.scheduleItem2dot6Name = scheduleItem2dot6Name;
	}
	public String getScheduleItem2dot6Amt() {
		return scheduleItem2dot6Amt;
	}
	public void setScheduleItem2dot6Amt(String scheduleItem2dot6Amt) {
		this.scheduleItem2dot6Amt = scheduleItem2dot6Amt;
	}
	public String getScheduleItem2dot6PreAmt() {
		return scheduleItem2dot6PreAmt;
	}
	public void setScheduleItem2dot6PreAmt(String scheduleItem2dot6PreAmt) {
		this.scheduleItem2dot6PreAmt = scheduleItem2dot6PreAmt;
	}
	public String getScheduleItem2dot7Name() {
		return scheduleItem2dot7Name;
	}
	public void setScheduleItem2dot7Name(String scheduleItem2dot7Name) {
		this.scheduleItem2dot7Name = scheduleItem2dot7Name;
	}
	public String getScheduleItem2dot7Amt() {
		return scheduleItem2dot7Amt;
	}
	public void setScheduleItem2dot7Amt(String scheduleItem2dot7Amt) {
		this.scheduleItem2dot7Amt = scheduleItem2dot7Amt;
	}
	public String getScheduleItem2dot7PreAmt() {
		return scheduleItem2dot7PreAmt;
	}
	public void setScheduleItem2dot7PreAmt(String scheduleItem2dot7PreAmt) {
		this.scheduleItem2dot7PreAmt = scheduleItem2dot7PreAmt;
	}
	public String getScheduleItem2dot8Name() {
		return scheduleItem2dot8Name;
	}
	public void setScheduleItem2dot8Name(String scheduleItem2dot8Name) {
		this.scheduleItem2dot8Name = scheduleItem2dot8Name;
	}
	public String getScheduleItem2dot8Amt() {
		return scheduleItem2dot8Amt;
	}
	public void setScheduleItem2dot8Amt(String scheduleItem2dot8Amt) {
		this.scheduleItem2dot8Amt = scheduleItem2dot8Amt;
	}
	public String getScheduleItem2dot8PreAmt() {
		return scheduleItem2dot8PreAmt;
	}
	public void setScheduleItem2dot8PreAmt(String scheduleItem2dot8PreAmt) {
		this.scheduleItem2dot8PreAmt = scheduleItem2dot8PreAmt;
	}
	public String getScheduleItem2dot9Name() {
		return scheduleItem2dot9Name;
	}
	public void setScheduleItem2dot9Name(String scheduleItem2dot9Name) {
		this.scheduleItem2dot9Name = scheduleItem2dot9Name;
	}
	public String getScheduleItem2dot9Amt() {
		return scheduleItem2dot9Amt;
	}
	public void setScheduleItem2dot9Amt(String scheduleItem2dot9Amt) {
		this.scheduleItem2dot9Amt = scheduleItem2dot9Amt;
	}
	public String getScheduleItem2dot9PreAmt() {
		return scheduleItem2dot9PreAmt;
	}
	public void setScheduleItem2dot9PreAmt(String scheduleItem2dot9PreAmt) {
		this.scheduleItem2dot9PreAmt = scheduleItem2dot9PreAmt;
	}
	public String getScheduleItem2dot10Name() {
		return scheduleItem2dot10Name;
	}
	public void setScheduleItem2dot10Name(String scheduleItem2dot10Name) {
		this.scheduleItem2dot10Name = scheduleItem2dot10Name;
	}
	public String getScheduleItem2dot10Amt() {
		return scheduleItem2dot10Amt;
	}
	public void setScheduleItem2dot10Amt(String scheduleItem2dot10Amt) {
		this.scheduleItem2dot10Amt = scheduleItem2dot10Amt;
	}
	public String getScheduleItem2dot10PreAmt() {
		return scheduleItem2dot10PreAmt;
	}
	public void setScheduleItem2dot10PreAmt(String scheduleItem2dot10PreAmt) {
		this.scheduleItem2dot10PreAmt = scheduleItem2dot10PreAmt;
	}
	public String getScheduleItem2dot11Name() {
		return scheduleItem2dot11Name;
	}
	public void setScheduleItem2dot11Name(String scheduleItem2dot11Name) {
		this.scheduleItem2dot11Name = scheduleItem2dot11Name;
	}
	public String getScheduleItem2dot11Amt() {
		return scheduleItem2dot11Amt;
	}
	public void setScheduleItem2dot11Amt(String scheduleItem2dot11Amt) {
		this.scheduleItem2dot11Amt = scheduleItem2dot11Amt;
	}
	public String getScheduleItem2dot11PreAmt() {
		return scheduleItem2dot11PreAmt;
	}
	public void setScheduleItem2dot11PreAmt(String scheduleItem2dot11PreAmt) {
		this.scheduleItem2dot11PreAmt = scheduleItem2dot11PreAmt;
	}
	public String getScheduleItem2dot12Name() {
		return scheduleItem2dot12Name;
	}
	public void setScheduleItem2dot12Name(String scheduleItem2dot12Name) {
		this.scheduleItem2dot12Name = scheduleItem2dot12Name;
	}
	public String getScheduleItem2dot12Amt() {
		return scheduleItem2dot12Amt;
	}
	public void setScheduleItem2dot12Amt(String scheduleItem2dot12Amt) {
		this.scheduleItem2dot12Amt = scheduleItem2dot12Amt;
	}
	public String getScheduleItem2dot12PreAmt() {
		return scheduleItem2dot12PreAmt;
	}
	public void setScheduleItem2dot12PreAmt(String scheduleItem2dot12PreAmt) {
		this.scheduleItem2dot12PreAmt = scheduleItem2dot12PreAmt;
	}
	public String getFinalScheduleName() {
		return finalScheduleName;
	}
	public void setFinalScheduleName(String finalScheduleName) {
		this.finalScheduleName = finalScheduleName;
	}
	public String getFinalSchedule2Amt() {
		return finalSchedule2Amt;
	}
	public void setFinalSchedule2Amt(String finalSchedule2Amt) {
		this.finalSchedule2Amt = finalSchedule2Amt;
	}
	public String getFinalSchedule2PreAmt() {
		return finalSchedule2PreAmt;
	}
	public void setFinalSchedule2PreAmt(String finalSchedule2PreAmt) {
		this.finalSchedule2PreAmt = finalSchedule2PreAmt;
	}
	@Override
	public String toString() {
		return "Schedule2 [createdBy=" + createdBy + ", scheduleItem2dot1Name=" + scheduleItem2dot1Name
				+ ", scheduleItem2dot2Name=" + scheduleItem2dot2Name + ", scheduleItem2dot2Amt=" + scheduleItem2dot2Amt
				+ ", scheduleItem2dot2PreAmt=" + scheduleItem2dot2PreAmt + ", scheduleItem2dot3Name="
				+ scheduleItem2dot3Name + ", scheduleItem2dot3Amt=" + scheduleItem2dot3Amt
				+ ", scheduleItem2dot3PreAmt=" + scheduleItem2dot3PreAmt + ", scheduleItem2dot4Name="
				+ scheduleItem2dot4Name + ", scheduleItem2dot4Amt=" + scheduleItem2dot4Amt
				+ ", scheduleItem2dot4PreAmt=" + scheduleItem2dot4PreAmt + ", scheduleItem2dot5Name="
				+ scheduleItem2dot5Name + ", scheduleItem2dot5dot1Name=" + scheduleItem2dot5dot1Name
				+ ", scheduleItem2dot5dot1Amt=" + scheduleItem2dot5dot1Amt + ", scheduleItem2dot5dot1PreAmt="
				+ scheduleItem2dot5dot1PreAmt + ", scheduleItem2dot5dot2Name=" + scheduleItem2dot5dot2Name
				+ ", scheduleItem2dot5dot2Amt=" + scheduleItem2dot5dot2Amt + ", scheduleItem2dot5dot2PreAmt="
				+ scheduleItem2dot5dot2PreAmt + ", scheduleItem2dot5dot3Name=" + scheduleItem2dot5dot3Name
				+ ", scheduleItem2dot5dot3Amt=" + scheduleItem2dot5dot3Amt + ", scheduleItem2dot5dot3PreAmt="
				+ scheduleItem2dot5dot3PreAmt + ", scheduleItem2dot5dot4Amt=" + scheduleItem2dot5dot4Amt
				+ ", scheduleItem2dot5dot4PreAmt=" + scheduleItem2dot5dot4PreAmt + ", scheduleItem2dot6Name="
				+ scheduleItem2dot6Name + ", scheduleItem2dot6Amt=" + scheduleItem2dot6Amt
				+ ", scheduleItem2dot6PreAmt=" + scheduleItem2dot6PreAmt + ", scheduleItem2dot7Name="
				+ scheduleItem2dot7Name + ", scheduleItem2dot7Amt=" + scheduleItem2dot7Amt
				+ ", scheduleItem2dot7PreAmt=" + scheduleItem2dot7PreAmt + ", scheduleItem2dot8Name="
				+ scheduleItem2dot8Name + ", scheduleItem2dot8Amt=" + scheduleItem2dot8Amt
				+ ", scheduleItem2dot8PreAmt=" + scheduleItem2dot8PreAmt + ", scheduleItem2dot9Name="
				+ scheduleItem2dot9Name + ", scheduleItem2dot9Amt=" + scheduleItem2dot9Amt
				+ ", scheduleItem2dot9PreAmt=" + scheduleItem2dot9PreAmt + ", scheduleItem2dot10Name="
				+ scheduleItem2dot10Name + ", scheduleItem2dot10Amt=" + scheduleItem2dot10Amt
				+ ", scheduleItem2dot10PreAmt=" + scheduleItem2dot10PreAmt + ", scheduleItem2dot11Name="
				+ scheduleItem2dot11Name + ", scheduleItem2dot11Amt=" + scheduleItem2dot11Amt
				+ ", scheduleItem2dot11PreAmt=" + scheduleItem2dot11PreAmt + ", scheduleItem2dot12Name="
				+ scheduleItem2dot12Name + ", scheduleItem2dot12Amt=" + scheduleItem2dot12Amt
				+ ", scheduleItem2dot12PreAmt=" + scheduleItem2dot12PreAmt + ", finalScheduleName=" + finalScheduleName
				+ ", finalSchedule2Amt=" + finalSchedule2Amt + ", finalSchedule2PreAmt=" + finalSchedule2PreAmt + "]";
	}
	
	
}
