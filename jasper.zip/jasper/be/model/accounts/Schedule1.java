package in.ecgc.smile.erp.reporting.jasper.be.model.accounts;

import java.math.BigDecimal;



public class Schedule1 {
	
	private String scheduleName;
	
	private String createdBy;
	
	private String scheduleItem1dot1Name;
	
	private String scheduleItem1dot1Amt;	
	private String scheduleItem1dot1PreAmt;
	
	private String scheduleItem1dot2Name;
	
	private String scheduleItem1dot2Amt;	
	private String scheduleItem1dot2PreAmt;
	
	private String scheduleItem1dot3Name;
	
	private String scheduleItem1dot3Amt;
	private String scheduleItem1dot3PreAmt;
	
	private String scheduleItem1dot4Name;
	
	private String scheduleItem1dot4Amt;
	private String scheduleItem1dot4PreAmt;
	
	private String scheduleItem1dot5Name;
	
	private String scheduleItem1dot5Amt;
	private String scheduleItem1dot5PreAmt;
	

	private String finalScheduleName;
	
	private String finalSchedule1Amt;
	private String finalSchedule1PreAmt;
	public String getScheduleName() {
		return scheduleName;
	}
	public void setScheduleName(String scheduleName) {
		this.scheduleName = scheduleName;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getScheduleItem1dot1Name() {
		return scheduleItem1dot1Name;
	}
	public void setScheduleItem1dot1Name(String scheduleItem1dot1Name) {
		this.scheduleItem1dot1Name = scheduleItem1dot1Name;
	}
	public String getScheduleItem1dot1Amt() {
		return scheduleItem1dot1Amt;
	}
	public void setScheduleItem1dot1Amt(String scheduleItem1dot1Amt) {
		this.scheduleItem1dot1Amt = scheduleItem1dot1Amt;
	}
	public String getScheduleItem1dot1PreAmt() {
		return scheduleItem1dot1PreAmt;
	}
	public void setScheduleItem1dot1PreAmt(String scheduleItem1dot1PreAmt) {
		this.scheduleItem1dot1PreAmt = scheduleItem1dot1PreAmt;
	}
	public String getScheduleItem1dot2Name() {
		return scheduleItem1dot2Name;
	}
	public void setScheduleItem1dot2Name(String scheduleItem1dot2Name) {
		this.scheduleItem1dot2Name = scheduleItem1dot2Name;
	}
	public String getScheduleItem1dot2Amt() {
		return scheduleItem1dot2Amt;
	}
	public void setScheduleItem1dot2Amt(String scheduleItem1dot2Amt) {
		this.scheduleItem1dot2Amt = scheduleItem1dot2Amt;
	}
	public String getScheduleItem1dot2PreAmt() {
		return scheduleItem1dot2PreAmt;
	}
	public void setScheduleItem1dot2PreAmt(String scheduleItem1dot2PreAmt) {
		this.scheduleItem1dot2PreAmt = scheduleItem1dot2PreAmt;
	}
	public String getScheduleItem1dot3Name() {
		return scheduleItem1dot3Name;
	}
	public void setScheduleItem1dot3Name(String scheduleItem1dot3Name) {
		this.scheduleItem1dot3Name = scheduleItem1dot3Name;
	}
	public String getScheduleItem1dot3Amt() {
		return scheduleItem1dot3Amt;
	}
	public void setScheduleItem1dot3Amt(String scheduleItem1dot3Amt) {
		this.scheduleItem1dot3Amt = scheduleItem1dot3Amt;
	}
	public String getScheduleItem1dot3PreAmt() {
		return scheduleItem1dot3PreAmt;
	}
	public void setScheduleItem1dot3PreAmt(String scheduleItem1dot3PreAmt) {
		this.scheduleItem1dot3PreAmt = scheduleItem1dot3PreAmt;
	}
	public String getScheduleItem1dot4Name() {
		return scheduleItem1dot4Name;
	}
	public void setScheduleItem1dot4Name(String scheduleItem1dot4Name) {
		this.scheduleItem1dot4Name = scheduleItem1dot4Name;
	}
	public String getScheduleItem1dot4Amt() {
		return scheduleItem1dot4Amt;
	}
	public void setScheduleItem1dot4Amt(String scheduleItem1dot4Amt) {
		this.scheduleItem1dot4Amt = scheduleItem1dot4Amt;
	}
	public String getScheduleItem1dot4PreAmt() {
		return scheduleItem1dot4PreAmt;
	}
	public void setScheduleItem1dot4PreAmt(String scheduleItem1dot4PreAmt) {
		this.scheduleItem1dot4PreAmt = scheduleItem1dot4PreAmt;
	}
	public String getScheduleItem1dot5Name() {
		return scheduleItem1dot5Name;
	}
	public void setScheduleItem1dot5Name(String scheduleItem1dot5Name) {
		this.scheduleItem1dot5Name = scheduleItem1dot5Name;
	}
	public String getScheduleItem1dot5Amt() {
		return scheduleItem1dot5Amt;
	}
	public void setScheduleItem1dot5Amt(String scheduleItem1dot5Amt) {
		this.scheduleItem1dot5Amt = scheduleItem1dot5Amt;
	}
	public String getScheduleItem1dot5PreAmt() {
		return scheduleItem1dot5PreAmt;
	}
	public void setScheduleItem1dot5PreAmt(String scheduleItem1dot5PreAmt) {
		this.scheduleItem1dot5PreAmt = scheduleItem1dot5PreAmt;
	}
	public String getFinalScheduleName() {
		return finalScheduleName;
	}
	public void setFinalScheduleName(String finalScheduleName) {
		this.finalScheduleName = finalScheduleName;
	}
	public String getFinalSchedule1Amt() {
		return finalSchedule1Amt;
	}
	public void setFinalSchedule1Amt(String finalSchedule1Amt) {
		this.finalSchedule1Amt = finalSchedule1Amt;
	}
	public String getFinalSchedule1PreAmt() {
		return finalSchedule1PreAmt;
	}
	public void setFinalSchedule1PreAmt(String finalSchedule1PreAmt) {
		this.finalSchedule1PreAmt = finalSchedule1PreAmt;
	}
	@Override
	public String toString() {
		return "Schedule1 [scheduleName=" + scheduleName + ", createdBy=" + createdBy + ", scheduleItem1dot1Name="
				+ scheduleItem1dot1Name + ", scheduleItem1dot1Amt=" + scheduleItem1dot1Amt
				+ ", scheduleItem1dot1PreAmt=" + scheduleItem1dot1PreAmt + ", scheduleItem1dot2Name="
				+ scheduleItem1dot2Name + ", scheduleItem1dot2Amt=" + scheduleItem1dot2Amt
				+ ", scheduleItem1dot2PreAmt=" + scheduleItem1dot2PreAmt + ", scheduleItem1dot3Name="
				+ scheduleItem1dot3Name + ", scheduleItem1dot3Amt=" + scheduleItem1dot3Amt
				+ ", scheduleItem1dot3PreAmt=" + scheduleItem1dot3PreAmt + ", scheduleItem1dot4Name="
				+ scheduleItem1dot4Name + ", scheduleItem1dot4Amt=" + scheduleItem1dot4Amt
				+ ", scheduleItem1dot4PreAmt=" + scheduleItem1dot4PreAmt + ", scheduleItem1dot5Name="
				+ scheduleItem1dot5Name + ", scheduleItem1dot5Amt=" + scheduleItem1dot5Amt
				+ ", scheduleItem1dot5PreAmt=" + scheduleItem1dot5PreAmt + ", finalScheduleName=" + finalScheduleName
				+ ", finalSchedule1Amt=" + finalSchedule1Amt + ", finalSchedule1PreAmt=" + finalSchedule1PreAmt + "]";
	}
	
	
	
	
	
	
	
}
