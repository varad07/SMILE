package in.ecgc.smile.erp.reporting.jasper.be.model.accounts;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;

public class GLRangeStmtDtl { // (II)

	List<GLRangeStmt> glrangeStmt; // (III)

	private BigDecimal openingBal;
	private BigDecimal closingBal;
	private String openingFlag;
	private String closingFlag;

	private String mainGlCd;
	private String subGlCd;
	private String glName;

	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate fromDt;

	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate toDt;

	public List<GLRangeStmt> getGlrangeStmt() {
		return glrangeStmt;
	}

	public void setGlrangeStmt(List<GLRangeStmt> glrangeStmt) {
		this.glrangeStmt = glrangeStmt;
	}

	public BigDecimal getOpeningBal() {
		return openingBal;
	}

	public void setOpeningBal(BigDecimal openingBal) {
		this.openingBal = openingBal;
	}

	public BigDecimal getClosingBal() {
		return closingBal;
	}

	public void setClosingBal(BigDecimal closingBal) {
		this.closingBal = closingBal;
	}

	public String getMainGlCd() {
		return mainGlCd;
	}

	public void setMainGlCd(String mainGlCd) {
		this.mainGlCd = mainGlCd;
	}

	public String getSubGlCd() {
		return subGlCd;
	}

	public void setSubGlCd(String subGlCd) {
		this.subGlCd = subGlCd;
	}

	public String getGlName() {
		return glName;
	}

	public void setGlName(String glName) {
		this.glName = glName;
	}

	public LocalDate getFromDt() {
		return fromDt;
	}

	public void setFromDt(LocalDate fromDt) {
		this.fromDt = fromDt;
	}

	public LocalDate getToDt() {
		return toDt;
	}

	public void setToDt(LocalDate toDt) {
		this.toDt = toDt;
	}
	
	

	public String getOpeningFlag() {
		return openingFlag;
	}

	public void setOpeningFlag(String openingFlag) {
		this.openingFlag = openingFlag;
	}

	public String getClosingFlag() {
		return closingFlag;
	}

	public void setClosingFlag(String closingFlag) {
		this.closingFlag = closingFlag;
	}

	@Override
	public String toString() {
		return "GLRangeStmtDtl [glrangeStmt=" + glrangeStmt + ", openingBal=" + openingBal + ", closingBal="
				+ closingBal + ", openingFlag=" + openingFlag + ", closingFlag=" + closingFlag + ", mainGlCd="
				+ mainGlCd + ", subGlCd=" + subGlCd + ", glName=" + glName + ", fromDt=" + fromDt + ", toDt=" + toDt
				+ "]";
	}

	

}
