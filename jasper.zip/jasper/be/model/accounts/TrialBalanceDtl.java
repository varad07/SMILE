package in.ecgc.smile.erp.reporting.jasper.be.model.accounts;

import java.math.BigDecimal;

public class TrialBalanceDtl {

	private BigDecimal crAmount;
	private BigDecimal drAmount;
	private String particular;
	public BigDecimal getCrAmount() {
		return crAmount;
	}
	public void setCrAmount(BigDecimal crAmount) {
		this.crAmount = crAmount;
	}
	public BigDecimal getDrAmount() {
		return drAmount;
	}
	public void setDrAmount(BigDecimal drAmount) {
		this.drAmount = drAmount;
	}
	public String getParticular() {
		return particular;
	}
	public void setParticular(String particular) {
		this.particular = particular;
	}
	@Override
	public String toString() {
		return "TrialBalanceDtl [crAmount=" + crAmount + ", drAmount=" + drAmount + ", particular=" + particular + "]";
	}
	
	
}

