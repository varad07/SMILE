package in.ecgc.smile.erp.reporting.jasper.be.model.accounts;

public class Schedule7 {
	
	private String createdBy;

	private String scheduleItem7dot1Name;
	private String scheduleItem7dot1Amt;
	private String scheduleItem7dot1PreAmt;
	
	private String scheduleItem7dot2Name;
	private String scheduleItem7dot2Amt;
	private String scheduleItem7dot2PreAmt;
	
	private String scheduleItem7dot3Name;
	private String scheduleItem7dot3Amt;
	private String scheduleItem7dot3PreAmt;
	
	private String scheduleItem7dot4Name;
	private String scheduleItem7dot4Amt;
	private String scheduleItem7dot4PreAmt;
	
	private String finalSchedule7Name;
	private String finalSchedule7Amt;
	private String finalSchedule7PreAmt;
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getScheduleItem7dot1Name() {
		return scheduleItem7dot1Name;
	}
	public void setScheduleItem7dot1Name(String scheduleItem7dot1Name) {
		this.scheduleItem7dot1Name = scheduleItem7dot1Name;
	}
	public String getScheduleItem7dot1Amt() {
		return scheduleItem7dot1Amt;
	}
	public void setScheduleItem7dot1Amt(String scheduleItem7dot1Amt) {
		this.scheduleItem7dot1Amt = scheduleItem7dot1Amt;
	}
	public String getScheduleItem7dot1PreAmt() {
		return scheduleItem7dot1PreAmt;
	}
	public void setScheduleItem7dot1PreAmt(String scheduleItem7dot1PreAmt) {
		this.scheduleItem7dot1PreAmt = scheduleItem7dot1PreAmt;
	}
	public String getScheduleItem7dot2Name() {
		return scheduleItem7dot2Name;
	}
	public void setScheduleItem7dot2Name(String scheduleItem7dot2Name) {
		this.scheduleItem7dot2Name = scheduleItem7dot2Name;
	}
	public String getScheduleItem7dot2Amt() {
		return scheduleItem7dot2Amt;
	}
	public void setScheduleItem7dot2Amt(String scheduleItem7dot2Amt) {
		this.scheduleItem7dot2Amt = scheduleItem7dot2Amt;
	}
	public String getScheduleItem7dot2PreAmt() {
		return scheduleItem7dot2PreAmt;
	}
	public void setScheduleItem7dot2PreAmt(String scheduleItem7dot2PreAmt) {
		this.scheduleItem7dot2PreAmt = scheduleItem7dot2PreAmt;
	}
	public String getScheduleItem7dot3Name() {
		return scheduleItem7dot3Name;
	}
	public void setScheduleItem7dot3Name(String scheduleItem7dot3Name) {
		this.scheduleItem7dot3Name = scheduleItem7dot3Name;
	}
	public String getScheduleItem7dot3Amt() {
		return scheduleItem7dot3Amt;
	}
	public void setScheduleItem7dot3Amt(String scheduleItem7dot3Amt) {
		this.scheduleItem7dot3Amt = scheduleItem7dot3Amt;
	}
	public String getScheduleItem7dot3PreAmt() {
		return scheduleItem7dot3PreAmt;
	}
	public void setScheduleItem7dot3PreAmt(String scheduleItem7dot3PreAmt) {
		this.scheduleItem7dot3PreAmt = scheduleItem7dot3PreAmt;
	}
	public String getScheduleItem7dot4Name() {
		return scheduleItem7dot4Name;
	}
	public void setScheduleItem7dot4Name(String scheduleItem7dot4Name) {
		this.scheduleItem7dot4Name = scheduleItem7dot4Name;
	}
	public String getScheduleItem7dot4Amt() {
		return scheduleItem7dot4Amt;
	}
	public void setScheduleItem7dot4Amt(String scheduleItem7dot4Amt) {
		this.scheduleItem7dot4Amt = scheduleItem7dot4Amt;
	}
	public String getScheduleItem7dot4PreAmt() {
		return scheduleItem7dot4PreAmt;
	}
	public void setScheduleItem7dot4PreAmt(String scheduleItem7dot4PreAmt) {
		this.scheduleItem7dot4PreAmt = scheduleItem7dot4PreAmt;
	}
	public String getFinalSchedule7Name() {
		return finalSchedule7Name;
	}
	public void setFinalSchedule7Name(String finalSchedule7Name) {
		this.finalSchedule7Name = finalSchedule7Name;
	}
	public String getFinalSchedule7Amt() {
		return finalSchedule7Amt;
	}
	public void setFinalSchedule7Amt(String finalSchedule7Amt) {
		this.finalSchedule7Amt = finalSchedule7Amt;
	}
	public String getFinalSchedule7PreAmt() {
		return finalSchedule7PreAmt;
	}
	public void setFinalSchedule7PreAmt(String finalSchedule7PreAmt) {
		this.finalSchedule7PreAmt = finalSchedule7PreAmt;
	}
	@Override
	public String toString() {
		return "Schedule7 [createdBy=" + createdBy + ", scheduleItem7dot1Name=" + scheduleItem7dot1Name
				+ ", scheduleItem7dot1Amt=" + scheduleItem7dot1Amt + ", scheduleItem7dot1PreAmt="
				+ scheduleItem7dot1PreAmt + ", scheduleItem7dot2Name=" + scheduleItem7dot2Name
				+ ", scheduleItem7dot2Amt=" + scheduleItem7dot2Amt + ", scheduleItem7dot2PreAmt="
				+ scheduleItem7dot2PreAmt + ", scheduleItem7dot3Name=" + scheduleItem7dot3Name
				+ ", scheduleItem7dot3Amt=" + scheduleItem7dot3Amt + ", scheduleItem7dot3PreAmt="
				+ scheduleItem7dot3PreAmt + ", scheduleItem7dot4Name=" + scheduleItem7dot4Name
				+ ", scheduleItem7dot4Amt=" + scheduleItem7dot4Amt + ", scheduleItem7dot4PreAmt="
				+ scheduleItem7dot4PreAmt + ", finalSchedule7Name=" + finalSchedule7Name + ", finalSchedule7Amt="
				+ finalSchedule7Amt + ", finalSchedule7PreAmt=" + finalSchedule7PreAmt + "]";
	}
	
	
}
