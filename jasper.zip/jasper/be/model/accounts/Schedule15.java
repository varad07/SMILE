package in.ecgc.smile.erp.reporting.jasper.be.model.accounts;

public class Schedule15 {

	private String createdBy;

	private String scheduleItem15dot1Name;
	private String scheduleItem15dot1Amt;
	private String scheduleItem15dot1PreAmt;
	
	private String scheduleItem15dot2Name;
	private String scheduleItem15dot2Amt;
	private String scheduleItem15dot2PreAmt;
	
	private String finalSchedule15Name;
	private String finalSchedule15Amt;
	private String finalSchedule15PreAmt;
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getScheduleItem15dot1Name() {
		return scheduleItem15dot1Name;
	}
	public void setScheduleItem15dot1Name(String scheduleItem15dot1Name) {
		this.scheduleItem15dot1Name = scheduleItem15dot1Name;
	}
	public String getScheduleItem15dot1Amt() {
		return scheduleItem15dot1Amt;
	}
	public void setScheduleItem15dot1Amt(String scheduleItem15dot1Amt) {
		this.scheduleItem15dot1Amt = scheduleItem15dot1Amt;
	}
	public String getScheduleItem15dot1PreAmt() {
		return scheduleItem15dot1PreAmt;
	}
	public void setScheduleItem15dot1PreAmt(String scheduleItem15dot1PreAmt) {
		this.scheduleItem15dot1PreAmt = scheduleItem15dot1PreAmt;
	}
	@Override
	public String toString() {
		return "Schedule15 [createdBy=" + createdBy + ", scheduleItem15dot1Name=" + scheduleItem15dot1Name
				+ ", scheduleItem15dot1Amt=" + scheduleItem15dot1Amt + ", scheduleItem15dot1PreAmt="
				+ scheduleItem15dot1PreAmt + ", scheduleItem15dot2Name=" + scheduleItem15dot2Name
				+ ", scheduleItem15dot2Amt=" + scheduleItem15dot2Amt + ", scheduleItem15dot2PreAmt="
				+ scheduleItem15dot2PreAmt + ", finalSchedule15Name=" + finalSchedule15Name + ", finalSchedule15Amt="
				+ finalSchedule15Amt + ", finalSchedule15PreAmt=" + finalSchedule15PreAmt + "]";
	}
	public String getScheduleItem15dot2Name() {
		return scheduleItem15dot2Name;
	}
	public void setScheduleItem15dot2Name(String scheduleItem15dot2Name) {
		this.scheduleItem15dot2Name = scheduleItem15dot2Name;
	}
	public String getScheduleItem15dot2Amt() {
		return scheduleItem15dot2Amt;
	}
	public void setScheduleItem15dot2Amt(String scheduleItem15dot2Amt) {
		this.scheduleItem15dot2Amt = scheduleItem15dot2Amt;
	}
	public String getScheduleItem15dot2PreAmt() {
		return scheduleItem15dot2PreAmt;
	}
	public void setScheduleItem15dot2PreAmt(String scheduleItem15dot2PreAmt) {
		this.scheduleItem15dot2PreAmt = scheduleItem15dot2PreAmt;
	}
	public String getFinalSchedule15Name() {
		return finalSchedule15Name;
	}
	public void setFinalSchedule15Name(String finalSchedule15Name) {
		this.finalSchedule15Name = finalSchedule15Name;
	}
	public String getFinalSchedule15Amt() {
		return finalSchedule15Amt;
	}
	public void setFinalSchedule15Amt(String finalSchedule15Amt) {
		this.finalSchedule15Amt = finalSchedule15Amt;
	}
	public String getFinalSchedule15PreAmt() {
		return finalSchedule15PreAmt;
	}
	public void setFinalSchedule15PreAmt(String finalSchedule15PreAmt) {
		this.finalSchedule15PreAmt = finalSchedule15PreAmt;
	}
	
	
}