package in.ecgc.smile.erp.reporting.jasper.be.model.accounts;

import java.time.LocalDate;

import org.springframework.format.annotation.DateTimeFormat;

public class GLCodeStmtIn {

	private String logicallocCd;
	private String mainglCd;
	private String subglCd;
	private String subBfCd;
	private String subBfNameCd;
	// private String personalLedgerCd;
	// @JsonSerialize(using = LocalDateSerializer.class)
	// @JsonDeserialize(using = LocalDateDeserializer.class)
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate fromDt;
	// @JsonSerialize(using = LocalDateSerializer.class)
	// @JsonDeserialize(using = LocalDateDeserializer.class)
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate toDt;

	public String getLogicallocCd() {
		return logicallocCd;
	}

	public void setLogicallocCd(String logicallocCd) {
		this.logicallocCd = logicallocCd;
	}

	public String getMainglCd() {
		return mainglCd;
	}

	public void setMainglCd(String mainglCd) {
		this.mainglCd = mainglCd;
	}

	public String getSubglCd() {
		return subglCd;
	}

	public void setSubglCd(String subglCd) {
		this.subglCd = subglCd;
	}

	public String getSubBfCd() {
		return subBfCd;
	}

	public void setSubBfCd(String subBfCd) {
		this.subBfCd = subBfCd;
	}

	public String getSubBfNameCd() {
		return subBfNameCd;
	}

	public void setSubBfNameCd(String subBfNameCd) {
		this.subBfNameCd = subBfNameCd;
	}

	public LocalDate getFromDt() {
		return fromDt;
	}

	public void setFromDt(LocalDate fromDt) {
		this.fromDt = fromDt;
	}

	public LocalDate getToDt() {
		return toDt;
	}

	public void setToDt(LocalDate toDt) {
		this.toDt = toDt;
	}

	@Override
	public String toString() {
		return "GLCodeStmt [logicallocCd=" + logicallocCd + ", mainglCd=" + mainglCd + ", subglCd=" + subglCd
				+ ", subBfCd=" + subBfCd + ", subBfNameCd=" + subBfNameCd + ", fromDt=" + fromDt + ", toDt=" + toDt
				+ "]";
	}

}
