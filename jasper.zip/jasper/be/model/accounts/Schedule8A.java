package in.ecgc.smile.erp.reporting.jasper.be.model.accounts;

public class Schedule8A {
	

	private String scheduleItem8Adot2Amt;
	private String scheduleItem8Adot2PreAmt;
	
	
	private String scheduleItem8Adot3Amt;
	private String scheduleItem8Adot3PreAmt;
	

	private String scheduleItem8Adot6Amt;
	private String scheduleItem8Adot6PreAmt;

	private String scheduleItem8Adot7Amt;
	private String scheduleItem8Adot7PreAmt;

	private String scheduleItem8Adot8Amt;
	private String scheduleItem8Adot8PreAmt;
	
	private String scheduleItem8Adot9Amt;
	private String scheduleItem8Adot9PreAmt;

	private String scheduleItem8Adot10Amt;
	private String scheduleItem8Adot10PreAmt;

	private String scheduleItem8Adot11Amt;
	private String scheduleItem8Adot11PreAmt;

	private String scheduleItem8Adot12Amt;
	private String scheduleItem8Adot12PreAmt;

	private String scheduleItem8Adot13Amt;
	private String scheduleItem8Adot13PreAmt;

	private String scheduleItem8Adot14Amt;
	private String scheduleItem8Adot14PreAmt;

	private String scheduleItem8Adot15Amt;
	private String scheduleItem8Adot15PreAmt;

	private String scheduleItem8Adot16Amt;
	private String scheduleItem8Adot16PreAmt;

	private String scheduleItem8Adot18Amt;
	private String scheduleItem8Adot18PreAmt;
	
	private String scheduleItem8Adot19Amt;
	private String scheduleItem8Adot19PreAmt;

	private String scheduleItem8Adot22Amt;
	private String scheduleItem8Adot22PreAmt;

	private String scheduleItem8Adot23Amt;
	private String scheduleItem8Adot23PreAmt;

	private String scheduleItem8Adot24Amt;
	private String scheduleItem8Adot24PreAmt;

	private String scheduleItem8Adot25Amt;
	private String scheduleItem8Adot25PreAmt;

	private String scheduleItem8Adot26Amt;
	private String scheduleItem8Adot26PreAmt;

	private String scheduleItem8Adot27Amt;
	private String scheduleItem8Adot27PreAmt;

	private String scheduleItem8Adot28Amt;
	private String scheduleItem8Adot28PreAmt;

	private String scheduleItem8Adot29Amt;
	private String scheduleItem8Adot29PreAmt;

	private String scheduleItem8Adot30Amt;
	private String scheduleItem8Adot30PreAmt;
;
	private String scheduleItem8Adot31Amt;
	private String scheduleItem8Adot31PreAmt;

	private String scheduleItem8Adot32Amt;
	private String scheduleItem8Adot32PreAmt;

	private String finalSchedule8AAmt;
	private String finalSchedule8APreAmt;
	public String getScheduleItem8Adot2Amt() {
		return scheduleItem8Adot2Amt;
	}
	public void setScheduleItem8Adot2Amt(String scheduleItem8Adot2Amt) {
		this.scheduleItem8Adot2Amt = scheduleItem8Adot2Amt;
	}
	public String getScheduleItem8Adot2PreAmt() {
		return scheduleItem8Adot2PreAmt;
	}
	public void setScheduleItem8Adot2PreAmt(String scheduleItem8Adot2PreAmt) {
		this.scheduleItem8Adot2PreAmt = scheduleItem8Adot2PreAmt;
	}
	public String getScheduleItem8Adot3Amt() {
		return scheduleItem8Adot3Amt;
	}
	public void setScheduleItem8Adot3Amt(String scheduleItem8Adot3Amt) {
		this.scheduleItem8Adot3Amt = scheduleItem8Adot3Amt;
	}
	public String getScheduleItem8Adot3PreAmt() {
		return scheduleItem8Adot3PreAmt;
	}
	public void setScheduleItem8Adot3PreAmt(String scheduleItem8Adot3PreAmt) {
		this.scheduleItem8Adot3PreAmt = scheduleItem8Adot3PreAmt;
	}
	public String getScheduleItem8Adot6Amt() {
		return scheduleItem8Adot6Amt;
	}
	public void setScheduleItem8Adot6Amt(String scheduleItem8Adot6Amt) {
		this.scheduleItem8Adot6Amt = scheduleItem8Adot6Amt;
	}
	public String getScheduleItem8Adot6PreAmt() {
		return scheduleItem8Adot6PreAmt;
	}
	public void setScheduleItem8Adot6PreAmt(String scheduleItem8Adot6PreAmt) {
		this.scheduleItem8Adot6PreAmt = scheduleItem8Adot6PreAmt;
	}
	public String getScheduleItem8Adot7Amt() {
		return scheduleItem8Adot7Amt;
	}
	public void setScheduleItem8Adot7Amt(String scheduleItem8Adot7Amt) {
		this.scheduleItem8Adot7Amt = scheduleItem8Adot7Amt;
	}
	public String getScheduleItem8Adot7PreAmt() {
		return scheduleItem8Adot7PreAmt;
	}
	public void setScheduleItem8Adot7PreAmt(String scheduleItem8Adot7PreAmt) {
		this.scheduleItem8Adot7PreAmt = scheduleItem8Adot7PreAmt;
	}
	public String getScheduleItem8Adot8Amt() {
		return scheduleItem8Adot8Amt;
	}
	public void setScheduleItem8Adot8Amt(String scheduleItem8Adot8Amt) {
		this.scheduleItem8Adot8Amt = scheduleItem8Adot8Amt;
	}
	public String getScheduleItem8Adot8PreAmt() {
		return scheduleItem8Adot8PreAmt;
	}
	public void setScheduleItem8Adot8PreAmt(String scheduleItem8Adot8PreAmt) {
		this.scheduleItem8Adot8PreAmt = scheduleItem8Adot8PreAmt;
	}
	public String getScheduleItem8Adot9Amt() {
		return scheduleItem8Adot9Amt;
	}
	public void setScheduleItem8Adot9Amt(String scheduleItem8Adot9Amt) {
		this.scheduleItem8Adot9Amt = scheduleItem8Adot9Amt;
	}
	public String getScheduleItem8Adot9PreAmt() {
		return scheduleItem8Adot9PreAmt;
	}
	public void setScheduleItem8Adot9PreAmt(String scheduleItem8Adot9PreAmt) {
		this.scheduleItem8Adot9PreAmt = scheduleItem8Adot9PreAmt;
	}
	public String getScheduleItem8Adot10Amt() {
		return scheduleItem8Adot10Amt;
	}
	public void setScheduleItem8Adot10Amt(String scheduleItem8Adot10Amt) {
		this.scheduleItem8Adot10Amt = scheduleItem8Adot10Amt;
	}
	public String getScheduleItem8Adot10PreAmt() {
		return scheduleItem8Adot10PreAmt;
	}
	public void setScheduleItem8Adot10PreAmt(String scheduleItem8Adot10PreAmt) {
		this.scheduleItem8Adot10PreAmt = scheduleItem8Adot10PreAmt;
	}
	public String getScheduleItem8Adot11Amt() {
		return scheduleItem8Adot11Amt;
	}
	public void setScheduleItem8Adot11Amt(String scheduleItem8Adot11Amt) {
		this.scheduleItem8Adot11Amt = scheduleItem8Adot11Amt;
	}
	public String getScheduleItem8Adot11PreAmt() {
		return scheduleItem8Adot11PreAmt;
	}
	public void setScheduleItem8Adot11PreAmt(String scheduleItem8Adot11PreAmt) {
		this.scheduleItem8Adot11PreAmt = scheduleItem8Adot11PreAmt;
	}
	public String getScheduleItem8Adot12Amt() {
		return scheduleItem8Adot12Amt;
	}
	public void setScheduleItem8Adot12Amt(String scheduleItem8Adot12Amt) {
		this.scheduleItem8Adot12Amt = scheduleItem8Adot12Amt;
	}
	public String getScheduleItem8Adot12PreAmt() {
		return scheduleItem8Adot12PreAmt;
	}
	public void setScheduleItem8Adot12PreAmt(String scheduleItem8Adot12PreAmt) {
		this.scheduleItem8Adot12PreAmt = scheduleItem8Adot12PreAmt;
	}
	public String getScheduleItem8Adot13Amt() {
		return scheduleItem8Adot13Amt;
	}
	public void setScheduleItem8Adot13Amt(String scheduleItem8Adot13Amt) {
		this.scheduleItem8Adot13Amt = scheduleItem8Adot13Amt;
	}
	public String getScheduleItem8Adot13PreAmt() {
		return scheduleItem8Adot13PreAmt;
	}
	public void setScheduleItem8Adot13PreAmt(String scheduleItem8Adot13PreAmt) {
		this.scheduleItem8Adot13PreAmt = scheduleItem8Adot13PreAmt;
	}
	public String getScheduleItem8Adot14Amt() {
		return scheduleItem8Adot14Amt;
	}
	public void setScheduleItem8Adot14Amt(String scheduleItem8Adot14Amt) {
		this.scheduleItem8Adot14Amt = scheduleItem8Adot14Amt;
	}
	public String getScheduleItem8Adot14PreAmt() {
		return scheduleItem8Adot14PreAmt;
	}
	public void setScheduleItem8Adot14PreAmt(String scheduleItem8Adot14PreAmt) {
		this.scheduleItem8Adot14PreAmt = scheduleItem8Adot14PreAmt;
	}
	public String getScheduleItem8Adot15Amt() {
		return scheduleItem8Adot15Amt;
	}
	public void setScheduleItem8Adot15Amt(String scheduleItem8Adot15Amt) {
		this.scheduleItem8Adot15Amt = scheduleItem8Adot15Amt;
	}
	public String getScheduleItem8Adot15PreAmt() {
		return scheduleItem8Adot15PreAmt;
	}
	public void setScheduleItem8Adot15PreAmt(String scheduleItem8Adot15PreAmt) {
		this.scheduleItem8Adot15PreAmt = scheduleItem8Adot15PreAmt;
	}
	public String getScheduleItem8Adot16Amt() {
		return scheduleItem8Adot16Amt;
	}
	public void setScheduleItem8Adot16Amt(String scheduleItem8Adot16Amt) {
		this.scheduleItem8Adot16Amt = scheduleItem8Adot16Amt;
	}
	public String getScheduleItem8Adot16PreAmt() {
		return scheduleItem8Adot16PreAmt;
	}
	public void setScheduleItem8Adot16PreAmt(String scheduleItem8Adot16PreAmt) {
		this.scheduleItem8Adot16PreAmt = scheduleItem8Adot16PreAmt;
	}
	public String getScheduleItem8Adot18Amt() {
		return scheduleItem8Adot18Amt;
	}
	public void setScheduleItem8Adot18Amt(String scheduleItem8Adot18Amt) {
		this.scheduleItem8Adot18Amt = scheduleItem8Adot18Amt;
	}
	public String getScheduleItem8Adot18PreAmt() {
		return scheduleItem8Adot18PreAmt;
	}
	public void setScheduleItem8Adot18PreAmt(String scheduleItem8Adot18PreAmt) {
		this.scheduleItem8Adot18PreAmt = scheduleItem8Adot18PreAmt;
	}
	public String getScheduleItem8Adot19Amt() {
		return scheduleItem8Adot19Amt;
	}
	public void setScheduleItem8Adot19Amt(String scheduleItem8Adot19Amt) {
		this.scheduleItem8Adot19Amt = scheduleItem8Adot19Amt;
	}
	public String getScheduleItem8Adot19PreAmt() {
		return scheduleItem8Adot19PreAmt;
	}
	public void setScheduleItem8Adot19PreAmt(String scheduleItem8Adot19PreAmt) {
		this.scheduleItem8Adot19PreAmt = scheduleItem8Adot19PreAmt;
	}
	public String getScheduleItem8Adot22Amt() {
		return scheduleItem8Adot22Amt;
	}
	public void setScheduleItem8Adot22Amt(String scheduleItem8Adot22Amt) {
		this.scheduleItem8Adot22Amt = scheduleItem8Adot22Amt;
	}
	public String getScheduleItem8Adot22PreAmt() {
		return scheduleItem8Adot22PreAmt;
	}
	public void setScheduleItem8Adot22PreAmt(String scheduleItem8Adot22PreAmt) {
		this.scheduleItem8Adot22PreAmt = scheduleItem8Adot22PreAmt;
	}
	public String getScheduleItem8Adot23Amt() {
		return scheduleItem8Adot23Amt;
	}
	public void setScheduleItem8Adot23Amt(String scheduleItem8Adot23Amt) {
		this.scheduleItem8Adot23Amt = scheduleItem8Adot23Amt;
	}
	public String getScheduleItem8Adot23PreAmt() {
		return scheduleItem8Adot23PreAmt;
	}
	public void setScheduleItem8Adot23PreAmt(String scheduleItem8Adot23PreAmt) {
		this.scheduleItem8Adot23PreAmt = scheduleItem8Adot23PreAmt;
	}
	public String getScheduleItem8Adot24Amt() {
		return scheduleItem8Adot24Amt;
	}
	public void setScheduleItem8Adot24Amt(String scheduleItem8Adot24Amt) {
		this.scheduleItem8Adot24Amt = scheduleItem8Adot24Amt;
	}
	public String getScheduleItem8Adot24PreAmt() {
		return scheduleItem8Adot24PreAmt;
	}
	public void setScheduleItem8Adot24PreAmt(String scheduleItem8Adot24PreAmt) {
		this.scheduleItem8Adot24PreAmt = scheduleItem8Adot24PreAmt;
	}
	public String getScheduleItem8Adot25Amt() {
		return scheduleItem8Adot25Amt;
	}
	public void setScheduleItem8Adot25Amt(String scheduleItem8Adot25Amt) {
		this.scheduleItem8Adot25Amt = scheduleItem8Adot25Amt;
	}
	public String getScheduleItem8Adot25PreAmt() {
		return scheduleItem8Adot25PreAmt;
	}
	public void setScheduleItem8Adot25PreAmt(String scheduleItem8Adot25PreAmt) {
		this.scheduleItem8Adot25PreAmt = scheduleItem8Adot25PreAmt;
	}
	public String getScheduleItem8Adot26Amt() {
		return scheduleItem8Adot26Amt;
	}
	public void setScheduleItem8Adot26Amt(String scheduleItem8Adot26Amt) {
		this.scheduleItem8Adot26Amt = scheduleItem8Adot26Amt;
	}
	public String getScheduleItem8Adot26PreAmt() {
		return scheduleItem8Adot26PreAmt;
	}
	public void setScheduleItem8Adot26PreAmt(String scheduleItem8Adot26PreAmt) {
		this.scheduleItem8Adot26PreAmt = scheduleItem8Adot26PreAmt;
	}
	public String getScheduleItem8Adot27Amt() {
		return scheduleItem8Adot27Amt;
	}
	public void setScheduleItem8Adot27Amt(String scheduleItem8Adot27Amt) {
		this.scheduleItem8Adot27Amt = scheduleItem8Adot27Amt;
	}
	public String getScheduleItem8Adot27PreAmt() {
		return scheduleItem8Adot27PreAmt;
	}
	public void setScheduleItem8Adot27PreAmt(String scheduleItem8Adot27PreAmt) {
		this.scheduleItem8Adot27PreAmt = scheduleItem8Adot27PreAmt;
	}
	public String getScheduleItem8Adot28Amt() {
		return scheduleItem8Adot28Amt;
	}
	public void setScheduleItem8Adot28Amt(String scheduleItem8Adot28Amt) {
		this.scheduleItem8Adot28Amt = scheduleItem8Adot28Amt;
	}
	public String getScheduleItem8Adot28PreAmt() {
		return scheduleItem8Adot28PreAmt;
	}
	public void setScheduleItem8Adot28PreAmt(String scheduleItem8Adot28PreAmt) {
		this.scheduleItem8Adot28PreAmt = scheduleItem8Adot28PreAmt;
	}
	public String getScheduleItem8Adot29Amt() {
		return scheduleItem8Adot29Amt;
	}
	public void setScheduleItem8Adot29Amt(String scheduleItem8Adot29Amt) {
		this.scheduleItem8Adot29Amt = scheduleItem8Adot29Amt;
	}
	public String getScheduleItem8Adot29PreAmt() {
		return scheduleItem8Adot29PreAmt;
	}
	public void setScheduleItem8Adot29PreAmt(String scheduleItem8Adot29PreAmt) {
		this.scheduleItem8Adot29PreAmt = scheduleItem8Adot29PreAmt;
	}
	public String getScheduleItem8Adot30Amt() {
		return scheduleItem8Adot30Amt;
	}
	public void setScheduleItem8Adot30Amt(String scheduleItem8Adot30Amt) {
		this.scheduleItem8Adot30Amt = scheduleItem8Adot30Amt;
	}
	public String getScheduleItem8Adot30PreAmt() {
		return scheduleItem8Adot30PreAmt;
	}
	public void setScheduleItem8Adot30PreAmt(String scheduleItem8Adot30PreAmt) {
		this.scheduleItem8Adot30PreAmt = scheduleItem8Adot30PreAmt;
	}
	public String getScheduleItem8Adot31Amt() {
		return scheduleItem8Adot31Amt;
	}
	public void setScheduleItem8Adot31Amt(String scheduleItem8Adot31Amt) {
		this.scheduleItem8Adot31Amt = scheduleItem8Adot31Amt;
	}
	public String getScheduleItem8Adot31PreAmt() {
		return scheduleItem8Adot31PreAmt;
	}
	public void setScheduleItem8Adot31PreAmt(String scheduleItem8Adot31PreAmt) {
		this.scheduleItem8Adot31PreAmt = scheduleItem8Adot31PreAmt;
	}
	public String getScheduleItem8Adot32Amt() {
		return scheduleItem8Adot32Amt;
	}
	public void setScheduleItem8Adot32Amt(String scheduleItem8Adot32Amt) {
		this.scheduleItem8Adot32Amt = scheduleItem8Adot32Amt;
	}
	public String getScheduleItem8Adot32PreAmt() {
		return scheduleItem8Adot32PreAmt;
	}
	public void setScheduleItem8Adot32PreAmt(String scheduleItem8Adot32PreAmt) {
		this.scheduleItem8Adot32PreAmt = scheduleItem8Adot32PreAmt;
	}
	public String getFinalSchedule8AAmt() {
		return finalSchedule8AAmt;
	}
	public void setFinalSchedule8AAmt(String finalSchedule8AAmt) {
		this.finalSchedule8AAmt = finalSchedule8AAmt;
	}
	public String getFinalSchedule8APreAmt() {
		return finalSchedule8APreAmt;
	}
	public void setFinalSchedule8APreAmt(String finalSchedule8APreAmt) {
		this.finalSchedule8APreAmt = finalSchedule8APreAmt;
	}
	
	
	
}
