package in.ecgc.smile.erp.reporting.jasper.be.model.accounts;

public class StateMaster {
	
	private String state;

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	@Override
	public String toString() {
		return "StateMaster [state=" + state + "]";
	}
	
	

}
