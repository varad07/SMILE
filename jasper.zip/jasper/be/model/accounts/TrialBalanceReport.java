package in.ecgc.smile.erp.reporting.jasper.be.model.accounts;

import java.math.BigDecimal;
import java.util.List;

public class TrialBalanceReport {
	
	private List<TrialBalanceTxnDtl> trialBalanceTxnDtlList;
	
	private BigDecimal asstCrAmount;
	
	private BigDecimal asstDrAmount;
	
	private BigDecimal liabCrAmount;
	
	private BigDecimal liabDrAmount;
	
	private BigDecimal expdCrAmount;
	
	private BigDecimal expdDrAmount;
	
	private BigDecimal incmCrAmount;
	
	private BigDecimal incmDrAmount;
	
	private BigDecimal totalCrAmount;
	
	private BigDecimal totalDrAmount;
	
	private String logicalLocation;

	private String state;
	
	private String region;

	
	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getLogicalLocation() {
		return logicalLocation;
	}

	public void setLogicalLocation(String logicalLocation) {
		this.logicalLocation = logicalLocation;
	}

	public List<TrialBalanceTxnDtl> getTrialBalanceAllLocDtlList() {
		return trialBalanceTxnDtlList;
	}

	public void setTrialBalanceAllLocDtlList(List<TrialBalanceTxnDtl> trialBalanceAllLocDtlList) {
		this.trialBalanceTxnDtlList = trialBalanceAllLocDtlList;
	}

	public BigDecimal getAsstCrAmount() {
		return asstCrAmount;
	}

	public void setAsstCrAmount(BigDecimal asstCrAmount) {
		this.asstCrAmount = asstCrAmount;
	}

	public BigDecimal getAsstDrAmount() {
		return asstDrAmount;
	}

	public void setAsstDrAmount(BigDecimal asstDrAmount) {
		this.asstDrAmount = asstDrAmount;
	}

	public BigDecimal getLiabCrAmount() {
		return liabCrAmount;
	}

	public void setLiabCrAmount(BigDecimal liabCrAmount) {
		this.liabCrAmount = liabCrAmount;
	}

	public BigDecimal getLiabDrAmount() {
		return liabDrAmount;
	}

	public void setLiabDrAmount(BigDecimal liabDrAmount) {
		this.liabDrAmount = liabDrAmount;
	}

	public BigDecimal getExpdCrAmount() {
		return expdCrAmount;
	}

	public void setExpdCrAmount(BigDecimal expdCrAmount) {
		this.expdCrAmount = expdCrAmount;
	}

	public BigDecimal getExpdDrAmount() {
		return expdDrAmount;
	}

	public void setExpdDrAmount(BigDecimal expdDrAmount) {
		this.expdDrAmount = expdDrAmount;
	}

	public BigDecimal getTotalCrAmount() {
		return totalCrAmount;
	}

	public void setTotalCrAmount(BigDecimal totalCrAmount) {
		this.totalCrAmount = totalCrAmount;
	}

	public BigDecimal getTotalDrAmount() {
		return totalDrAmount;
	}

	public void setTotalDrAmount(BigDecimal totalDrAmount) {
		this.totalDrAmount = totalDrAmount;
	}
	
	
	

	public BigDecimal getIncmCrAmount() {
		return incmCrAmount;
	}

	public void setIncmCrAmount(BigDecimal incmCrAmount) {
		this.incmCrAmount = incmCrAmount;
	}

	public BigDecimal getIncmDrAmount() {
		return incmDrAmount;
	}

	public void setIncmDrAmount(BigDecimal incmDrAmount) {
		this.incmDrAmount = incmDrAmount;
	}

	public List<TrialBalanceTxnDtl> getTrialBalanceTxnDtlList() {
		return trialBalanceTxnDtlList;
	}

	public void setTrialBalanceTxnDtlList(List<TrialBalanceTxnDtl> trialBalanceTxnDtlList) {
		this.trialBalanceTxnDtlList = trialBalanceTxnDtlList;
	}

	@Override
	public String toString() {
		return "TrialBalanceReport [trialBalanceTxnDtlList=" + trialBalanceTxnDtlList + ", asstCrAmount=" + asstCrAmount
				+ ", asstDrAmount=" + asstDrAmount + ", liabCrAmount=" + liabCrAmount + ", liabDrAmount=" + liabDrAmount
				+ ", expdCrAmount=" + expdCrAmount + ", expdDrAmount=" + expdDrAmount + ", incmCrAmount=" + incmCrAmount
				+ ", incmDrAmount=" + incmDrAmount + ", totalCrAmount=" + totalCrAmount + ", totalDrAmount="
				+ totalDrAmount + ", logicalLocation=" + logicalLocation + ", state=" + state + ", region=" + region
				+ "]";
	}

	

	
	
}
