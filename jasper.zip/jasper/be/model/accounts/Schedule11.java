package in.ecgc.smile.erp.reporting.jasper.be.model.accounts;

public class Schedule11 {
	
	private String createdBy;

	private String scheduleItem11dot1Name;
	private String scheduleItem11dot1Amt;
	private String scheduleItem11dot1PreAmt;
	
	
	private String scheduleItem11dot2Name;
	private String scheduleItem11dot3Name; 
	private String scheduleItem11dot4Name;
	
	private String scheduleItem11dot5Name;
	private String scheduleItem11dot5Amt;
	private String scheduleItem11dot5PreAmt;
	
	private String scheduleItem11dot6Name;
	private String scheduleItem11dot6Amt;
	private String scheduleItem11dot6PreAmt;
	
	private String scheduleItem11dot7Name;
	

	private String scheduleItem11dot8Amt;
	private String scheduleItem11dot8PreAmt;
	
	
	
	private String scheduleItem11dot9Amt;
	private String scheduleItem11dot9PreAmt;
	
	private String scheduleItem11dot10Name;
	private String scheduleItem11dot10Amt;
	private String scheduleItem11dot10PreAmt;
	
	private String scheduleItem11dot11Name;
	private String scheduleItem11dot11Amt;
	private String scheduleItem11dot11PreAmt;
	
	private String finalSchedule11Name;
	private String finalSchedule11Amt;
	private String finalSchedule11PreAmt;
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getScheduleItem11dot1Name() {
		return scheduleItem11dot1Name;
	}
	public void setScheduleItem11dot1Name(String scheduleItem11dot1Name) {
		this.scheduleItem11dot1Name = scheduleItem11dot1Name;
	}
	public String getScheduleItem11dot1Amt() {
		return scheduleItem11dot1Amt;
	}
	public void setScheduleItem11dot1Amt(String scheduleItem11dot1Amt) {
		this.scheduleItem11dot1Amt = scheduleItem11dot1Amt;
	}
	public String getScheduleItem11dot1PreAmt() {
		return scheduleItem11dot1PreAmt;
	}
	public void setScheduleItem11dot1PreAmt(String scheduleItem11dot1PreAmt) {
		this.scheduleItem11dot1PreAmt = scheduleItem11dot1PreAmt;
	}
	public String getScheduleItem11dot2Name() {
		return scheduleItem11dot2Name;
	}
	public void setScheduleItem11dot2Name(String scheduleItem11dot2Name) {
		this.scheduleItem11dot2Name = scheduleItem11dot2Name;
	}
	public String getScheduleItem11dot3Name() {
		return scheduleItem11dot3Name;
	}
	public void setScheduleItem11dot3Name(String scheduleItem11dot3Name) {
		this.scheduleItem11dot3Name = scheduleItem11dot3Name;
	}
	public String getScheduleItem11dot4Name() {
		return scheduleItem11dot4Name;
	}
	public void setScheduleItem11dot4Name(String scheduleItem11dot4Name) {
		this.scheduleItem11dot4Name = scheduleItem11dot4Name;
	}
	public String getScheduleItem11dot5Name() {
		return scheduleItem11dot5Name;
	}
	public void setScheduleItem11dot5Name(String scheduleItem11dot5Name) {
		this.scheduleItem11dot5Name = scheduleItem11dot5Name;
	}
	public String getScheduleItem11dot5Amt() {
		return scheduleItem11dot5Amt;
	}
	public void setScheduleItem11dot5Amt(String scheduleItem11dot5Amt) {
		this.scheduleItem11dot5Amt = scheduleItem11dot5Amt;
	}
	public String getScheduleItem11dot5PreAmt() {
		return scheduleItem11dot5PreAmt;
	}
	public void setScheduleItem11dot5PreAmt(String scheduleItem11dot5PreAmt) {
		this.scheduleItem11dot5PreAmt = scheduleItem11dot5PreAmt;
	}
	public String getScheduleItem11dot6Name() {
		return scheduleItem11dot6Name;
	}
	public void setScheduleItem11dot6Name(String scheduleItem11dot6Name) {
		this.scheduleItem11dot6Name = scheduleItem11dot6Name;
	}
	public String getScheduleItem11dot6Amt() {
		return scheduleItem11dot6Amt;
	}
	public void setScheduleItem11dot6Amt(String scheduleItem11dot6Amt) {
		this.scheduleItem11dot6Amt = scheduleItem11dot6Amt;
	}
	public String getScheduleItem11dot6PreAmt() {
		return scheduleItem11dot6PreAmt;
	}
	public void setScheduleItem11dot6PreAmt(String scheduleItem11dot6PreAmt) {
		this.scheduleItem11dot6PreAmt = scheduleItem11dot6PreAmt;
	}
	public String getScheduleItem11dot7Name() {
		return scheduleItem11dot7Name;
	}
	public void setScheduleItem11dot7Name(String scheduleItem11dot7Name) {
		this.scheduleItem11dot7Name = scheduleItem11dot7Name;
	}
	public String getScheduleItem11dot8Amt() {
		return scheduleItem11dot8Amt;
	}
	public void setScheduleItem11dot8Amt(String scheduleItem11dot8Amt) {
		this.scheduleItem11dot8Amt = scheduleItem11dot8Amt;
	}
	public String getScheduleItem11dot8PreAmt() {
		return scheduleItem11dot8PreAmt;
	}
	public void setScheduleItem11dot8PreAmt(String scheduleItem11dot8PreAmt) {
		this.scheduleItem11dot8PreAmt = scheduleItem11dot8PreAmt;
	}
	public String getScheduleItem11dot9Amt() {
		return scheduleItem11dot9Amt;
	}
	public void setScheduleItem11dot9Amt(String scheduleItem11dot9Amt) {
		this.scheduleItem11dot9Amt = scheduleItem11dot9Amt;
	}
	public String getScheduleItem11dot9PreAmt() {
		return scheduleItem11dot9PreAmt;
	}
	public void setScheduleItem11dot9PreAmt(String scheduleItem11dot9PreAmt) {
		this.scheduleItem11dot9PreAmt = scheduleItem11dot9PreAmt;
	}
	public String getScheduleItem11dot10Name() {
		return scheduleItem11dot10Name;
	}
	public void setScheduleItem11dot10Name(String scheduleItem11dot10Name) {
		this.scheduleItem11dot10Name = scheduleItem11dot10Name;
	}
	public String getScheduleItem11dot10Amt() {
		return scheduleItem11dot10Amt;
	}
	public void setScheduleItem11dot10Amt(String scheduleItem11dot10Amt) {
		this.scheduleItem11dot10Amt = scheduleItem11dot10Amt;
	}
	public String getScheduleItem11dot10PreAmt() {
		return scheduleItem11dot10PreAmt;
	}
	public void setScheduleItem11dot10PreAmt(String scheduleItem11dot10PreAmt) {
		this.scheduleItem11dot10PreAmt = scheduleItem11dot10PreAmt;
	}
	public String getScheduleItem11dot11Name() {
		return scheduleItem11dot11Name;
	}
	public void setScheduleItem11dot11Name(String scheduleItem11dot11Name) {
		this.scheduleItem11dot11Name = scheduleItem11dot11Name;
	}
	public String getScheduleItem11dot11Amt() {
		return scheduleItem11dot11Amt;
	}
	public void setScheduleItem11dot11Amt(String scheduleItem11dot11Amt) {
		this.scheduleItem11dot11Amt = scheduleItem11dot11Amt;
	}
	public String getScheduleItem11dot11PreAmt() {
		return scheduleItem11dot11PreAmt;
	}
	public void setScheduleItem11dot11PreAmt(String scheduleItem11dot11PreAmt) {
		this.scheduleItem11dot11PreAmt = scheduleItem11dot11PreAmt;
	}
	public String getFinalSchedule11Name() {
		return finalSchedule11Name;
	}
	public void setFinalSchedule11Name(String finalSchedule11Name) {
		this.finalSchedule11Name = finalSchedule11Name;
	}
	public String getFinalSchedule11Amt() {
		return finalSchedule11Amt;
	}
	public void setFinalSchedule11Amt(String finalSchedule11Amt) {
		this.finalSchedule11Amt = finalSchedule11Amt;
	}
	public String getFinalSchedule11PreAmt() {
		return finalSchedule11PreAmt;
	}
	public void setFinalSchedule11PreAmt(String finalSchedule11PreAmt) {
		this.finalSchedule11PreAmt = finalSchedule11PreAmt;
	}
	

}
