package in.ecgc.smile.erp.reporting.jasper.be.model.accounts;

import java.math.BigDecimal;
import java.time.LocalDate;

import javax.validation.constraints.NotBlank;

import org.springframework.format.annotation.DateTimeFormat;

import lombok.Data;

@Data
public class TdsDetails {
	@NotBlank(message = "Required For Transaction")
	private String mainGlCd;
	@NotBlank(message = "Required For Transaction")
	private String subGlCd;
	private String accountHead;
	private String sectionCd;
	private String sectionName;
	private int quarter;
	private String glTxnType;
	private String pvJvNo;
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate pvJvDate;
	private String paidTo;
	private String panNo;
	private BigDecimal totalBillAmt;
	private BigDecimal taxableAmt;
	private BigDecimal nonTaxableAmt;
	private BigDecimal tdsRate;
	private BigDecimal tdsPayable;
	private BigDecimal tdsPaid;
	private String reasonForNonTaxableAmt;

	private String payToType;
	private String pymtPartyCd;

	public String getMainGlCd() {
		return mainGlCd;
	}

	public void setMainGlCd(String mainGlCd) {
		this.mainGlCd = mainGlCd;
	}

	public String getSubGlCd() {
		return subGlCd;
	}

	public void setSubGlCd(String subGlCd) {
		this.subGlCd = subGlCd;
	}

	public String getAccountHead() {
		return accountHead;
	}

	public void setAccountHead(String accountHead) {
		this.accountHead = accountHead;
	}

	public String getSectionCd() {
		return sectionCd;
	}

	public void setSectionCd(String sectionCd) {
		this.sectionCd = sectionCd;
	}

	public String getSectionName() {
		return sectionName;
	}

	public void setSectionName(String sectionName) {
		this.sectionName = sectionName;
	}

	public int getQuarter() {
		return quarter;
	}

	public void setQuarter(int quarter) {
		this.quarter = quarter;
	}

	public String getGlTxnType() {
		return glTxnType;
	}

	public void setGlTxnType(String glTxnType) {
		this.glTxnType = glTxnType;
	}

	public String getPvJvNo() {
		return pvJvNo;
	}

	public void setPvJvNo(String pvJvNo) {
		this.pvJvNo = pvJvNo;
	}

	public LocalDate getPvJvDate() {
		return pvJvDate;
	}

	public void setPvJvDate(LocalDate pvJvDate) {
		this.pvJvDate = pvJvDate;
	}

	public String getPaidTo() {
		return paidTo;
	}

	public void setPaidTo(String paidTo) {
		this.paidTo = paidTo;
	}

	public String getPanNo() {
		return panNo;
	}

	public void setPanNo(String panNo) {
		this.panNo = panNo;
	}

	public BigDecimal getTotalBillAmt() {
		return totalBillAmt;
	}

	public void setTotalBillAmt(BigDecimal totalBillAmt) {
		this.totalBillAmt = totalBillAmt;
	}

	public BigDecimal getTaxableAmt() {
		return taxableAmt;
	}

	public void setTaxableAmt(BigDecimal taxableAmt) {
		this.taxableAmt = taxableAmt;
	}

	public BigDecimal getNonTaxableAmt() {
		return nonTaxableAmt;
	}

	public void setNonTaxableAmt(BigDecimal nonTaxableAmt) {
		this.nonTaxableAmt = nonTaxableAmt;
	}

	public BigDecimal getTdsRate() {
		return tdsRate;
	}

	public void setTdsRate(BigDecimal tdsRate) {
		this.tdsRate = tdsRate;
	}

	public BigDecimal getTdsPayable() {
		return tdsPayable;
	}

	public void setTdsPayable(BigDecimal tdsPayable) {
		this.tdsPayable = tdsPayable;
	}

	public BigDecimal getTdsPaid() {
		return tdsPaid;
	}

	public void setTdsPaid(BigDecimal tdsPaid) {
		this.tdsPaid = tdsPaid;
	}

	public String getReasonForNonTaxableAmt() {
		return reasonForNonTaxableAmt;
	}

	public void setReasonForNonTaxableAmt(String reasonForNonTaxableAmt) {
		this.reasonForNonTaxableAmt = reasonForNonTaxableAmt;
	}

	public String getPayToType() {
		return payToType;
	}

	public void setPayToType(String payToType) {
		this.payToType = payToType;
	}

	public String getPymtPartyCd() {
		return pymtPartyCd;
	}

	public void setPymtPartyCd(String pymtPartyCd) {
		this.pymtPartyCd = pymtPartyCd;
	}

	@Override
	public String toString() {
		return "TdsDetails [mainGlCd=" + mainGlCd + ", subGlCd=" + subGlCd + ", accountHead=" + accountHead
				+ ", sectionCd=" + sectionCd + ", sectionName=" + sectionName + ", quarter=" + quarter + ", glTxnType="
				+ glTxnType + ", pvJvNo=" + pvJvNo + ", pvJvDate=" + pvJvDate + ", paidTo=" + paidTo + ", panNo="
				+ panNo + ", totalBillAmt=" + totalBillAmt + ", taxableAmt=" + taxableAmt + ", nonTaxableAmt="
				+ nonTaxableAmt + ", tdsRate=" + tdsRate + ", tdsPayable=" + tdsPayable + ", tdsPaid=" + tdsPaid
				+ ", reasonForNonTaxableAmt=" + reasonForNonTaxableAmt + ", payToType=" + payToType + ", pymtPartyCd="
				+ pymtPartyCd + "]";
	}

}
