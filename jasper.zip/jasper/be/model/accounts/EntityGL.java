package in.ecgc.smile.erp.reporting.jasper.be.model.accounts;

import java.time.LocalDate;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.springframework.format.annotation.DateTimeFormat;

public class EntityGL {
	
	
	private String entityGlCd;
	
	@NotBlank(message = "MainGL Code is Required")
	@Pattern(regexp = "^[0-9]{4}$", message ="Main GL Code should be between 0000 to 9999")
	private String mainglCd;
	
	@Pattern(regexp = "^[0-9]{3}$", message ="Sub GL Code should be between 000 to 999")
	@NotBlank(message = "Sub GL Code is Required")
	private String subglCd;
	
    @NotNull(message = "GL Name is required")
    @Size(min = 1, max=100, message = "GL Name should be between 1 to 100 characters")
	private String glName;
	
	private Character glIsGroup;
	
	@NotNull(message = "GL Type is required")
	@Size(min = 2, max=4, message = "GL Type should be 4 characters")
	private String glType;
	
//	@NotBlank(message = "GL Sub Type is Required")
	private String glSubtype;
	private String balInd;
	
	private Character zeroBalFlg;
	private Character active;
	private Integer cashFlow;
	
	private String logicalLocCd;
	
	private String plLevel;
	private Character t1;
	private Character t2;
	private Character t3;
	private Character t4;
	private Character t5;
	private Character t6;
	private Character t7;
	private Character t8;
	private Character t9;
	private Character t10;
	private Character t11;
	private Character t12;
	private Character t13;
	private Character t14;
	private Character t15;
	private Character t16;
	private Character t17;
	private Character t18;
	private Character t19;
	private Character t20;
	private Character t21;
	private Character t22;
	private Character t23;
	private Character t24;
	private Character t25;
	private Character t26;
	private Character t27;
	private Character t28;
	private Character t29;
	private Character t30;
	private Character t31;
	private Character t32;
	private Character t33;
	private Character t34;
	private Character t35;
	private Character t36;
	private Character t37;
	private Character t38;
	private Character t39;
	private Character t40;
	
	
	
//	@NotBlank(message = "IRDABPA Code is Required")
	private String irdaBpaCd;
	
//	@NotBlank(message = "IRDA Code is Required")
	private String irdaCd;
	
//	@NotBlank(message = "Schedule code is Required")
	private String schedule6;
	
//	@NotBlank(message = "Financial Form Name is Required")
	private String financialFormName;
	
//	@NotBlank(message = "Sub Bifurcation Level is Required")
	private String subBifurcationLevel;
	private Integer cashaccount;
	private String createdBy;
	
	@DateTimeFormat(pattern = "dd-MM-yyyy")
	private LocalDate createdDt;
	private String lastUpdatedBy;
	
	@DateTimeFormat(pattern = "dd-MM-yyyy")
	private LocalDate lastUpdatedDt;
	private String metaRemarks;
	private String oldCd;
	private String scheduleItemCd;
	private String scheduleCd;
	private Boolean pFeeFlg;
	public String getEntityGlCd() {
		return entityGlCd;
	}
	public void setEntityGlCd(String entityGlCd) {
		this.entityGlCd = entityGlCd;
	}
	public String getMainglCd() {
		return mainglCd;
	}
	public void setMainglCd(String mainglCd) {
		this.mainglCd = mainglCd;
	}
	public String getSubglCd() {
		return subglCd;
	}
	public void setSubglCd(String subglCd) {
		this.subglCd = subglCd;
	}
	public String getGlName() {
		return glName;
	}
	public void setGlName(String glName) {
		this.glName = glName;
	}
	public Character getGlIsGroup() {
		return glIsGroup;
	}
	public void setGlIsGroup(Character glIsGroup) {
		this.glIsGroup = glIsGroup;
	}
	public String getGlType() {
		return glType;
	}
	public void setGlType(String glType) {
		this.glType = glType;
	}
	public String getGlSubtype() {
		return glSubtype;
	}
	public void setGlSubtype(String glSubtype) {
		this.glSubtype = glSubtype;
	}
	public String getBalInd() {
		return balInd;
	}
	public void setBalInd(String balInd) {
		this.balInd = balInd;
	}
	public Character getZeroBalFlg() {
		return zeroBalFlg;
	}
	public void setZeroBalFlg(Character zeroBalFlg) {
		this.zeroBalFlg = zeroBalFlg;
	}
	public Character getActive() {
		return active;
	}
	public void setActive(Character active) {
		this.active = active;
	}
	public Integer getCashFlow() {
		return cashFlow;
	}
	public void setCashFlow(Integer cashFlow) {
		this.cashFlow = cashFlow;
	}
	public String getLogicalLocCd() {
		return logicalLocCd;
	}
	public void setLogicalLocCd(String logicalLocCd) {
		this.logicalLocCd = logicalLocCd;
	}
	public String getPlLevel() {
		return plLevel;
	}
	public void setPlLevel(String plLevel) {
		this.plLevel = plLevel;
	}
	public Character getT1() {
		return t1;
	}
	public void setT1(Character t1) {
		this.t1 = t1;
	}
	public Character getT2() {
		return t2;
	}
	public void setT2(Character t2) {
		this.t2 = t2;
	}
	public Character getT3() {
		return t3;
	}
	public void setT3(Character t3) {
		this.t3 = t3;
	}
	public Character getT4() {
		return t4;
	}
	public void setT4(Character t4) {
		this.t4 = t4;
	}
	public Character getT5() {
		return t5;
	}
	public void setT5(Character t5) {
		this.t5 = t5;
	}
	public Character getT6() {
		return t6;
	}
	public void setT6(Character t6) {
		this.t6 = t6;
	}
	public Character getT7() {
		return t7;
	}
	public void setT7(Character t7) {
		this.t7 = t7;
	}
	public Character getT8() {
		return t8;
	}
	public void setT8(Character t8) {
		this.t8 = t8;
	}
	public Character getT9() {
		return t9;
	}
	public void setT9(Character t9) {
		this.t9 = t9;
	}
	public Character getT10() {
		return t10;
	}
	public void setT10(Character t10) {
		this.t10 = t10;
	}
	public Character getT11() {
		return t11;
	}
	public void setT11(Character t11) {
		this.t11 = t11;
	}
	public Character getT12() {
		return t12;
	}
	public void setT12(Character t12) {
		this.t12 = t12;
	}
	public Character getT13() {
		return t13;
	}
	public void setT13(Character t13) {
		this.t13 = t13;
	}
	public Character getT14() {
		return t14;
	}
	public void setT14(Character t14) {
		this.t14 = t14;
	}
	public Character getT15() {
		return t15;
	}
	public void setT15(Character t15) {
		this.t15 = t15;
	}
	public Character getT16() {
		return t16;
	}
	public void setT16(Character t16) {
		this.t16 = t16;
	}
	public Character getT17() {
		return t17;
	}
	public void setT17(Character t17) {
		this.t17 = t17;
	}
	public Character getT18() {
		return t18;
	}
	public void setT18(Character t18) {
		this.t18 = t18;
	}
	public Character getT19() {
		return t19;
	}
	public void setT19(Character t19) {
		this.t19 = t19;
	}
	public Character getT20() {
		return t20;
	}
	public void setT20(Character t20) {
		this.t20 = t20;
	}
	public Character getT21() {
		return t21;
	}
	public void setT21(Character t21) {
		this.t21 = t21;
	}
	public Character getT22() {
		return t22;
	}
	public void setT22(Character t22) {
		this.t22 = t22;
	}
	public Character getT23() {
		return t23;
	}
	public void setT23(Character t23) {
		this.t23 = t23;
	}
	public Character getT24() {
		return t24;
	}
	public void setT24(Character t24) {
		this.t24 = t24;
	}
	public Character getT25() {
		return t25;
	}
	public void setT25(Character t25) {
		this.t25 = t25;
	}
	public Character getT26() {
		return t26;
	}
	public void setT26(Character t26) {
		this.t26 = t26;
	}
	public Character getT27() {
		return t27;
	}
	public void setT27(Character t27) {
		this.t27 = t27;
	}
	public Character getT28() {
		return t28;
	}
	public void setT28(Character t28) {
		this.t28 = t28;
	}
	public Character getT29() {
		return t29;
	}
	public void setT29(Character t29) {
		this.t29 = t29;
	}
	public Character getT30() {
		return t30;
	}
	public void setT30(Character t30) {
		this.t30 = t30;
	}
	public Character getT31() {
		return t31;
	}
	public void setT31(Character t31) {
		this.t31 = t31;
	}
	public Character getT32() {
		return t32;
	}
	public void setT32(Character t32) {
		this.t32 = t32;
	}
	public Character getT33() {
		return t33;
	}
	public void setT33(Character t33) {
		this.t33 = t33;
	}
	public Character getT34() {
		return t34;
	}
	public void setT34(Character t34) {
		this.t34 = t34;
	}
	public Character getT35() {
		return t35;
	}
	public void setT35(Character t35) {
		this.t35 = t35;
	}
	public Character getT36() {
		return t36;
	}
	public void setT36(Character t36) {
		this.t36 = t36;
	}
	public Character getT37() {
		return t37;
	}
	public void setT37(Character t37) {
		this.t37 = t37;
	}
	public Character getT38() {
		return t38;
	}
	public void setT38(Character t38) {
		this.t38 = t38;
	}
	public Character getT39() {
		return t39;
	}
	public void setT39(Character t39) {
		this.t39 = t39;
	}
	public Character getT40() {
		return t40;
	}
	public void setT40(Character t40) {
		this.t40 = t40;
	}
	public String getIrdaBpaCd() {
		return irdaBpaCd;
	}
	public void setIrdaBpaCd(String irdaBpaCd) {
		this.irdaBpaCd = irdaBpaCd;
	}
	public String getIrdaCd() {
		return irdaCd;
	}
	public void setIrdaCd(String irdaCd) {
		this.irdaCd = irdaCd;
	}
	public String getSchedule6() {
		return schedule6;
	}
	public void setSchedule6(String schedule6) {
		this.schedule6 = schedule6;
	}
	public String getFinancialFormName() {
		return financialFormName;
	}
	public void setFinancialFormName(String financialFormName) {
		this.financialFormName = financialFormName;
	}
	public String getSubBifurcationLevel() {
		return subBifurcationLevel;
	}
	public void setSubBifurcationLevel(String subBifurcationLevel) {
		this.subBifurcationLevel = subBifurcationLevel;
	}
	public Integer getCashaccount() {
		return cashaccount;
	}
	public void setCashaccount(Integer cashaccount) {
		this.cashaccount = cashaccount;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public LocalDate getCreatedDt() {
		return createdDt;
	}
	public void setCreatedDt(LocalDate createdDt) {
		this.createdDt = createdDt;
	}
	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}
	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}
	public LocalDate getLastUpdatedDt() {
		return lastUpdatedDt;
	}
	public void setLastUpdatedDt(LocalDate lastUpdatedDt) {
		this.lastUpdatedDt = lastUpdatedDt;
	}
	public String getMetaRemarks() {
		return metaRemarks;
	}
	public void setMetaRemarks(String metaRemarks) {
		this.metaRemarks = metaRemarks;
	}
	public String getOldCd() {
		return oldCd;
	}
	public void setOldCd(String oldCd) {
		this.oldCd = oldCd;
	}
	public String getScheduleItemCd() {
		return scheduleItemCd;
	}
	public void setScheduleItemCd(String scheduleItemCd) {
		this.scheduleItemCd = scheduleItemCd;
	}
	public String getScheduleCd() {
		return scheduleCd;
	}
	public void setScheduleCd(String scheduleCd) {
		this.scheduleCd = scheduleCd;
	}
	public Boolean getpFeeFlg() {
		return pFeeFlg;
	}
	public void setpFeeFlg(Boolean pFeeFlg) {
		this.pFeeFlg = pFeeFlg;
	}
	@Override
	public String toString() {
		return "EntityGL [entityGlCd=" + entityGlCd + ", mainglCd=" + mainglCd + ", subglCd=" + subglCd + ", glName="
				+ glName + ", glIsGroup=" + glIsGroup + ", glType=" + glType + ", glSubtype=" + glSubtype + ", balInd="
				+ balInd + ", zeroBalFlg=" + zeroBalFlg + ", active=" + active + ", cashFlow=" + cashFlow
				+ ", logicalLocCd=" + logicalLocCd + ", plLevel=" + plLevel + ", t1=" + t1 + ", t2=" + t2 + ", t3=" + t3
				+ ", t4=" + t4 + ", t5=" + t5 + ", t6=" + t6 + ", t7=" + t7 + ", t8=" + t8 + ", t9=" + t9 + ", t10="
				+ t10 + ", t11=" + t11 + ", t12=" + t12 + ", t13=" + t13 + ", t14=" + t14 + ", t15=" + t15 + ", t16="
				+ t16 + ", t17=" + t17 + ", t18=" + t18 + ", t19=" + t19 + ", t20=" + t20 + ", t21=" + t21 + ", t22="
				+ t22 + ", t23=" + t23 + ", t24=" + t24 + ", t25=" + t25 + ", t26=" + t26 + ", t27=" + t27 + ", t28="
				+ t28 + ", t29=" + t29 + ", t30=" + t30 + ", t31=" + t31 + ", t32=" + t32 + ", t33=" + t33 + ", t34="
				+ t34 + ", t35=" + t35 + ", t36=" + t36 + ", t37=" + t37 + ", t38=" + t38 + ", t39=" + t39 + ", t40="
				+ t40 + ", irdaBpaCd=" + irdaBpaCd + ", irdaCd=" + irdaCd + ", schedule6=" + schedule6
				+ ", financialFormName=" + financialFormName + ", subBifurcationLevel=" + subBifurcationLevel
				+ ", cashaccount=" + cashaccount + ", createdBy=" + createdBy + ", createdDt=" + createdDt
				+ ", lastUpdatedBy=" + lastUpdatedBy + ", lastUpdatedDt=" + lastUpdatedDt + ", metaRemarks="
				+ metaRemarks + ", oldCd=" + oldCd + ", scheduleItemCd=" + scheduleItemCd + ", scheduleCd=" + scheduleCd
				+ ", pFeeFlg=" + pFeeFlg + "]";
	}
		

	
}

