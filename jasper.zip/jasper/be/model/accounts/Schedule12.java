package in.ecgc.smile.erp.reporting.jasper.be.model.accounts;

public class Schedule12 {
	
	private String createdBy;

	private String scheduleItem12dot0Name;
	
	private String scheduleItem12dot1Name;
	private String scheduleItem12dot1Amt;
	private String scheduleItem12dot1PreAmt;
	
	private String scheduleItem12dot2Name;
	private String scheduleItem12dot2Amt;
	private String scheduleItem12dot2PreAmt;
	
	private String scheduleItem12dot3Name;
	private String scheduleItem12dot3Amt;
	private String scheduleItem12dot3PreAmt;
	
	private String scheduleItem12dot4Name;
	private String scheduleItem12dot4Amt;
	private String scheduleItem12dot4PreAmt;
	
	private String scheduleItem12dot5Name;
	private String scheduleItem12dot5Amt;
	private String scheduleItem12dot5PreAmt;
	
	private String scheduleItem12dot6Name;
	private String scheduleItem12dot6Amt;
	private String scheduleItem12dot6PreAmt;
	
	private String scheduleItem12dot7Name;
	private String scheduleItem12dot7Amt;
	private String scheduleItem12dot7PreAmt;
	
	private String scheduleItem12dot8Name;
	private String scheduleItem12dot8Amt;
	private String scheduleItem12dot8PreAmt;
	
	private String scheduleItem12dot9Name;
	
	private String scheduleItem12dot10Name;
	private String scheduleItem12dot10Amt;
	private String scheduleItem12dot10PreAmt;
	
	private String scheduleItem12dot11Name;
	private String scheduleItem12dot11Amt;
	private String scheduleItem12dot11PreAmt;
	
	private String scheduleItem12dot12Name;
	private String scheduleItem12dot12Amt;
	private String scheduleItem12dot12PreAmt;
	
	private String scheduleItem12dot13Name;
	private String scheduleItem12dot13Amt;
	private String scheduleItem12dot13PreAmt;
	
	private String scheduleItem12dot14Name;
	private String scheduleItem12dot14Amt;
	private String scheduleItem12dot14PreAmt;
	
	private String scheduleItem12dot15Name;
	private String scheduleItem12dot15Amt;
	private String scheduleItem12dot15PreAmt;

	private String scheduleItem12dot16Name;
	private String scheduleItem12dot16Amt;
	private String scheduleItem12dot16PreAmt;
	
	private String scheduleItem12dot17Name;
	private String scheduleItem12dot17Amt;
	private String scheduleItem12dot17PreAmt;
	
	private String scheduleItem12dot18Name;
	private String scheduleItem12dot18Amt;
	private String scheduleItem12dot18PreAmt;
	
	private String scheduleItem12dot19Name;
	private String scheduleItem12dot19Amt;
	private String scheduleItem12dot19PreAmt;
	
	private String scheduleItem12dot20Name;
	private String scheduleItem12dot20Amt;
	private String scheduleItem12dot20PreAmt;
	
	private String scheduleItem12dot21Name;
	private String scheduleItem12dot21Amt;
	private String scheduleItem12dot21PreAmt;
	
	private String scheduleItem12dot22Name;
	private String scheduleItem12dot22Amt;
	private String scheduleItem12dot22PreAmt;
	
	private String scheduleItem12dot23Name;
	private String scheduleItem12dot23Amt;
	private String scheduleItem12dot23PreAmt;
	
	private String scheduleItem12dot24Name;
	private String scheduleItem12dot24Amt;
	private String scheduleItem12dot24PreAmt;
	
	private String scheduleItem12dot25Name;
	private String scheduleItem12dot25Amt;
	private String scheduleItem12dot25PreAmt;
	
	private String scheduleItem12dot26Name;
	private String scheduleItem12dot26Amt;
	private String scheduleItem12dot26PreAmt;
	
	private String scheduleItem12dot27Name;
	private String scheduleItem12dot27Amt;
	private String scheduleItem12dot27PreAmt;
	
	private String scheduleItem12dot28Name;
	private String scheduleItem12dot28Amt;
	private String scheduleItem12dot28PreAmt;
	
	private String scheduleItem12dot29Name;
	private String scheduleItem12dot29Amt;
	private String scheduleItem12dot29PreAmt;
	
	private String scheduleItem12dot30Name;
	private String scheduleItem12dot30Amt;
	private String scheduleItem12dot30PreAmt;
	
	private String scheduleItem12dot31Name;
	private String scheduleItem12dot31Amt;
	private String scheduleItem12dot31PreAmt;
	
	private String scheduleItem12dot32Name;
	private String scheduleItem12dot32Amt;
	private String scheduleItem12dot32PreAmt;

	private String scheduleItem12dot33Name;
	private String scheduleItem12dot33Amt;
	private String scheduleItem12dot33PreAmt;
	
	private String scheduleItem12dot34Name;
	private String scheduleItem12dot34Amt;
	private String scheduleItem12dot34PreAmt;
	
	private String scheduleItem12dot35Name;
	private String scheduleItem12dot35Amt;
	private String scheduleItem12dot35PreAmt;
	
	private String scheduleItem12dot36Name;
	private String scheduleItem12dot36Amt;
	private String scheduleItem12dot36PreAmt;
	
	private String scheduleItem12dot37Name;
	private String scheduleItem12dot37Amt;
	private String scheduleItem12dot37PreAmt;
	
	private String scheduleItem12dot36And37Amt;
	private String scheduleItem12dot36And37PreAmt;
	
	private String scheduleItem12dot38Name;
	private String scheduleItem12dot38Amt;
	private String scheduleItem12dot38PreAmt;
	
	private String scheduleItem12dot39Name;
	private String scheduleItem12dot39Amt;
	private String scheduleItem12dot39PreAmt;

	
	private String finalSchedule12Name;
	private String finalSchedule12Amt;
	private String finalSchedule12PreAmt;
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getScheduleItem12dot0Name() {
		return scheduleItem12dot0Name;
	}
	public void setScheduleItem12dot0Name(String scheduleItem12dot0Name) {
		this.scheduleItem12dot0Name = scheduleItem12dot0Name;
	}
	public String getScheduleItem12dot1Name() {
		return scheduleItem12dot1Name;
	}
	public void setScheduleItem12dot1Name(String scheduleItem12dot1Name) {
		this.scheduleItem12dot1Name = scheduleItem12dot1Name;
	}
	public String getScheduleItem12dot1Amt() {
		return scheduleItem12dot1Amt;
	}
	public void setScheduleItem12dot1Amt(String scheduleItem12dot1Amt) {
		this.scheduleItem12dot1Amt = scheduleItem12dot1Amt;
	}
	public String getScheduleItem12dot1PreAmt() {
		return scheduleItem12dot1PreAmt;
	}
	public void setScheduleItem12dot1PreAmt(String scheduleItem12dot1PreAmt) {
		this.scheduleItem12dot1PreAmt = scheduleItem12dot1PreAmt;
	}
	public String getScheduleItem12dot2Name() {
		return scheduleItem12dot2Name;
	}
	public void setScheduleItem12dot2Name(String scheduleItem12dot2Name) {
		this.scheduleItem12dot2Name = scheduleItem12dot2Name;
	}
	public String getScheduleItem12dot2Amt() {
		return scheduleItem12dot2Amt;
	}
	public void setScheduleItem12dot2Amt(String scheduleItem12dot2Amt) {
		this.scheduleItem12dot2Amt = scheduleItem12dot2Amt;
	}
	public String getScheduleItem12dot2PreAmt() {
		return scheduleItem12dot2PreAmt;
	}
	public void setScheduleItem12dot2PreAmt(String scheduleItem12dot2PreAmt) {
		this.scheduleItem12dot2PreAmt = scheduleItem12dot2PreAmt;
	}
	public String getScheduleItem12dot3Name() {
		return scheduleItem12dot3Name;
	}
	public void setScheduleItem12dot3Name(String scheduleItem12dot3Name) {
		this.scheduleItem12dot3Name = scheduleItem12dot3Name;
	}
	public String getScheduleItem12dot3Amt() {
		return scheduleItem12dot3Amt;
	}
	public void setScheduleItem12dot3Amt(String scheduleItem12dot3Amt) {
		this.scheduleItem12dot3Amt = scheduleItem12dot3Amt;
	}
	public String getScheduleItem12dot3PreAmt() {
		return scheduleItem12dot3PreAmt;
	}
	public void setScheduleItem12dot3PreAmt(String scheduleItem12dot3PreAmt) {
		this.scheduleItem12dot3PreAmt = scheduleItem12dot3PreAmt;
	}
	public String getScheduleItem12dot4Name() {
		return scheduleItem12dot4Name;
	}
	public void setScheduleItem12dot4Name(String scheduleItem12dot4Name) {
		this.scheduleItem12dot4Name = scheduleItem12dot4Name;
	}
	public String getScheduleItem12dot4Amt() {
		return scheduleItem12dot4Amt;
	}
	public void setScheduleItem12dot4Amt(String scheduleItem12dot4Amt) {
		this.scheduleItem12dot4Amt = scheduleItem12dot4Amt;
	}
	public String getScheduleItem12dot4PreAmt() {
		return scheduleItem12dot4PreAmt;
	}
	public void setScheduleItem12dot4PreAmt(String scheduleItem12dot4PreAmt) {
		this.scheduleItem12dot4PreAmt = scheduleItem12dot4PreAmt;
	}
	public String getScheduleItem12dot5Name() {
		return scheduleItem12dot5Name;
	}
	public void setScheduleItem12dot5Name(String scheduleItem12dot5Name) {
		this.scheduleItem12dot5Name = scheduleItem12dot5Name;
	}
	public String getScheduleItem12dot5Amt() {
		return scheduleItem12dot5Amt;
	}
	public void setScheduleItem12dot5Amt(String scheduleItem12dot5Amt) {
		this.scheduleItem12dot5Amt = scheduleItem12dot5Amt;
	}
	public String getScheduleItem12dot5PreAmt() {
		return scheduleItem12dot5PreAmt;
	}
	public void setScheduleItem12dot5PreAmt(String scheduleItem12dot5PreAmt) {
		this.scheduleItem12dot5PreAmt = scheduleItem12dot5PreAmt;
	}
	public String getScheduleItem12dot6Name() {
		return scheduleItem12dot6Name;
	}
	public void setScheduleItem12dot6Name(String scheduleItem12dot6Name) {
		this.scheduleItem12dot6Name = scheduleItem12dot6Name;
	}
	public String getScheduleItem12dot6Amt() {
		return scheduleItem12dot6Amt;
	}
	public void setScheduleItem12dot6Amt(String scheduleItem12dot6Amt) {
		this.scheduleItem12dot6Amt = scheduleItem12dot6Amt;
	}
	public String getScheduleItem12dot6PreAmt() {
		return scheduleItem12dot6PreAmt;
	}
	public void setScheduleItem12dot6PreAmt(String scheduleItem12dot6PreAmt) {
		this.scheduleItem12dot6PreAmt = scheduleItem12dot6PreAmt;
	}
	public String getScheduleItem12dot7Name() {
		return scheduleItem12dot7Name;
	}
	public void setScheduleItem12dot7Name(String scheduleItem12dot7Name) {
		this.scheduleItem12dot7Name = scheduleItem12dot7Name;
	}
	public String getScheduleItem12dot7Amt() {
		return scheduleItem12dot7Amt;
	}
	public void setScheduleItem12dot7Amt(String scheduleItem12dot7Amt) {
		this.scheduleItem12dot7Amt = scheduleItem12dot7Amt;
	}
	public String getScheduleItem12dot7PreAmt() {
		return scheduleItem12dot7PreAmt;
	}
	public void setScheduleItem12dot7PreAmt(String scheduleItem12dot7PreAmt) {
		this.scheduleItem12dot7PreAmt = scheduleItem12dot7PreAmt;
	}
	public String getScheduleItem12dot8Name() {
		return scheduleItem12dot8Name;
	}
	public void setScheduleItem12dot8Name(String scheduleItem12dot8Name) {
		this.scheduleItem12dot8Name = scheduleItem12dot8Name;
	}
	public String getScheduleItem12dot8Amt() {
		return scheduleItem12dot8Amt;
	}
	public void setScheduleItem12dot8Amt(String scheduleItem12dot8Amt) {
		this.scheduleItem12dot8Amt = scheduleItem12dot8Amt;
	}
	public String getScheduleItem12dot8PreAmt() {
		return scheduleItem12dot8PreAmt;
	}
	public void setScheduleItem12dot8PreAmt(String scheduleItem12dot8PreAmt) {
		this.scheduleItem12dot8PreAmt = scheduleItem12dot8PreAmt;
	}
	public String getScheduleItem12dot9Name() {
		return scheduleItem12dot9Name;
	}
	public void setScheduleItem12dot9Name(String scheduleItem12dot9Name) {
		this.scheduleItem12dot9Name = scheduleItem12dot9Name;
	}
	public String getScheduleItem12dot10Name() {
		return scheduleItem12dot10Name;
	}
	public void setScheduleItem12dot10Name(String scheduleItem12dot10Name) {
		this.scheduleItem12dot10Name = scheduleItem12dot10Name;
	}
	public String getScheduleItem12dot10Amt() {
		return scheduleItem12dot10Amt;
	}
	public void setScheduleItem12dot10Amt(String scheduleItem12dot10Amt) {
		this.scheduleItem12dot10Amt = scheduleItem12dot10Amt;
	}
	public String getScheduleItem12dot10PreAmt() {
		return scheduleItem12dot10PreAmt;
	}
	public void setScheduleItem12dot10PreAmt(String scheduleItem12dot10PreAmt) {
		this.scheduleItem12dot10PreAmt = scheduleItem12dot10PreAmt;
	}
	public String getScheduleItem12dot11Name() {
		return scheduleItem12dot11Name;
	}
	public void setScheduleItem12dot11Name(String scheduleItem12dot11Name) {
		this.scheduleItem12dot11Name = scheduleItem12dot11Name;
	}
	public String getScheduleItem12dot11Amt() {
		return scheduleItem12dot11Amt;
	}
	public void setScheduleItem12dot11Amt(String scheduleItem12dot11Amt) {
		this.scheduleItem12dot11Amt = scheduleItem12dot11Amt;
	}
	public String getScheduleItem12dot11PreAmt() {
		return scheduleItem12dot11PreAmt;
	}
	public void setScheduleItem12dot11PreAmt(String scheduleItem12dot11PreAmt) {
		this.scheduleItem12dot11PreAmt = scheduleItem12dot11PreAmt;
	}
	public String getScheduleItem12dot12Name() {
		return scheduleItem12dot12Name;
	}
	public void setScheduleItem12dot12Name(String scheduleItem12dot12Name) {
		this.scheduleItem12dot12Name = scheduleItem12dot12Name;
	}
	public String getScheduleItem12dot12Amt() {
		return scheduleItem12dot12Amt;
	}
	public void setScheduleItem12dot12Amt(String scheduleItem12dot12Amt) {
		this.scheduleItem12dot12Amt = scheduleItem12dot12Amt;
	}
	public String getScheduleItem12dot12PreAmt() {
		return scheduleItem12dot12PreAmt;
	}
	public void setScheduleItem12dot12PreAmt(String scheduleItem12dot12PreAmt) {
		this.scheduleItem12dot12PreAmt = scheduleItem12dot12PreAmt;
	}
	public String getScheduleItem12dot13Name() {
		return scheduleItem12dot13Name;
	}
	public void setScheduleItem12dot13Name(String scheduleItem12dot13Name) {
		this.scheduleItem12dot13Name = scheduleItem12dot13Name;
	}
	public String getScheduleItem12dot13Amt() {
		return scheduleItem12dot13Amt;
	}
	public void setScheduleItem12dot13Amt(String scheduleItem12dot13Amt) {
		this.scheduleItem12dot13Amt = scheduleItem12dot13Amt;
	}
	public String getScheduleItem12dot13PreAmt() {
		return scheduleItem12dot13PreAmt;
	}
	public void setScheduleItem12dot13PreAmt(String scheduleItem12dot13PreAmt) {
		this.scheduleItem12dot13PreAmt = scheduleItem12dot13PreAmt;
	}
	public String getScheduleItem12dot14Name() {
		return scheduleItem12dot14Name;
	}
	public void setScheduleItem12dot14Name(String scheduleItem12dot14Name) {
		this.scheduleItem12dot14Name = scheduleItem12dot14Name;
	}
	public String getScheduleItem12dot14Amt() {
		return scheduleItem12dot14Amt;
	}
	public void setScheduleItem12dot14Amt(String scheduleItem12dot14Amt) {
		this.scheduleItem12dot14Amt = scheduleItem12dot14Amt;
	}
	public String getScheduleItem12dot14PreAmt() {
		return scheduleItem12dot14PreAmt;
	}
	public void setScheduleItem12dot14PreAmt(String scheduleItem12dot14PreAmt) {
		this.scheduleItem12dot14PreAmt = scheduleItem12dot14PreAmt;
	}
	public String getScheduleItem12dot15Name() {
		return scheduleItem12dot15Name;
	}
	public void setScheduleItem12dot15Name(String scheduleItem12dot15Name) {
		this.scheduleItem12dot15Name = scheduleItem12dot15Name;
	}
	public String getScheduleItem12dot15Amt() {
		return scheduleItem12dot15Amt;
	}
	public void setScheduleItem12dot15Amt(String scheduleItem12dot15Amt) {
		this.scheduleItem12dot15Amt = scheduleItem12dot15Amt;
	}
	public String getScheduleItem12dot15PreAmt() {
		return scheduleItem12dot15PreAmt;
	}
	public void setScheduleItem12dot15PreAmt(String scheduleItem12dot15PreAmt) {
		this.scheduleItem12dot15PreAmt = scheduleItem12dot15PreAmt;
	}
	public String getScheduleItem12dot16Name() {
		return scheduleItem12dot16Name;
	}
	public void setScheduleItem12dot16Name(String scheduleItem12dot16Name) {
		this.scheduleItem12dot16Name = scheduleItem12dot16Name;
	}
	public String getScheduleItem12dot16Amt() {
		return scheduleItem12dot16Amt;
	}
	public void setScheduleItem12dot16Amt(String scheduleItem12dot16Amt) {
		this.scheduleItem12dot16Amt = scheduleItem12dot16Amt;
	}
	public String getScheduleItem12dot16PreAmt() {
		return scheduleItem12dot16PreAmt;
	}
	public void setScheduleItem12dot16PreAmt(String scheduleItem12dot16PreAmt) {
		this.scheduleItem12dot16PreAmt = scheduleItem12dot16PreAmt;
	}
	public String getScheduleItem12dot17Name() {
		return scheduleItem12dot17Name;
	}
	public void setScheduleItem12dot17Name(String scheduleItem12dot17Name) {
		this.scheduleItem12dot17Name = scheduleItem12dot17Name;
	}
	public String getScheduleItem12dot17Amt() {
		return scheduleItem12dot17Amt;
	}
	public void setScheduleItem12dot17Amt(String scheduleItem12dot17Amt) {
		this.scheduleItem12dot17Amt = scheduleItem12dot17Amt;
	}
	public String getScheduleItem12dot17PreAmt() {
		return scheduleItem12dot17PreAmt;
	}
	public void setScheduleItem12dot17PreAmt(String scheduleItem12dot17PreAmt) {
		this.scheduleItem12dot17PreAmt = scheduleItem12dot17PreAmt;
	}
	public String getScheduleItem12dot18Name() {
		return scheduleItem12dot18Name;
	}
	public void setScheduleItem12dot18Name(String scheduleItem12dot18Name) {
		this.scheduleItem12dot18Name = scheduleItem12dot18Name;
	}
	public String getScheduleItem12dot18Amt() {
		return scheduleItem12dot18Amt;
	}
	public void setScheduleItem12dot18Amt(String scheduleItem12dot18Amt) {
		this.scheduleItem12dot18Amt = scheduleItem12dot18Amt;
	}
	public String getScheduleItem12dot18PreAmt() {
		return scheduleItem12dot18PreAmt;
	}
	public void setScheduleItem12dot18PreAmt(String scheduleItem12dot18PreAmt) {
		this.scheduleItem12dot18PreAmt = scheduleItem12dot18PreAmt;
	}
	public String getScheduleItem12dot19Name() {
		return scheduleItem12dot19Name;
	}
	public void setScheduleItem12dot19Name(String scheduleItem12dot19Name) {
		this.scheduleItem12dot19Name = scheduleItem12dot19Name;
	}
	public String getScheduleItem12dot19Amt() {
		return scheduleItem12dot19Amt;
	}
	public void setScheduleItem12dot19Amt(String scheduleItem12dot19Amt) {
		this.scheduleItem12dot19Amt = scheduleItem12dot19Amt;
	}
	public String getScheduleItem12dot19PreAmt() {
		return scheduleItem12dot19PreAmt;
	}
	public void setScheduleItem12dot19PreAmt(String scheduleItem12dot19PreAmt) {
		this.scheduleItem12dot19PreAmt = scheduleItem12dot19PreAmt;
	}
	public String getScheduleItem12dot20Name() {
		return scheduleItem12dot20Name;
	}
	public void setScheduleItem12dot20Name(String scheduleItem12dot20Name) {
		this.scheduleItem12dot20Name = scheduleItem12dot20Name;
	}
	public String getScheduleItem12dot20Amt() {
		return scheduleItem12dot20Amt;
	}
	public void setScheduleItem12dot20Amt(String scheduleItem12dot20Amt) {
		this.scheduleItem12dot20Amt = scheduleItem12dot20Amt;
	}
	public String getScheduleItem12dot20PreAmt() {
		return scheduleItem12dot20PreAmt;
	}
	public void setScheduleItem12dot20PreAmt(String scheduleItem12dot20PreAmt) {
		this.scheduleItem12dot20PreAmt = scheduleItem12dot20PreAmt;
	}
	public String getScheduleItem12dot21Name() {
		return scheduleItem12dot21Name;
	}
	public void setScheduleItem12dot21Name(String scheduleItem12dot21Name) {
		this.scheduleItem12dot21Name = scheduleItem12dot21Name;
	}
	public String getScheduleItem12dot21Amt() {
		return scheduleItem12dot21Amt;
	}
	public void setScheduleItem12dot21Amt(String scheduleItem12dot21Amt) {
		this.scheduleItem12dot21Amt = scheduleItem12dot21Amt;
	}
	public String getScheduleItem12dot21PreAmt() {
		return scheduleItem12dot21PreAmt;
	}
	public void setScheduleItem12dot21PreAmt(String scheduleItem12dot21PreAmt) {
		this.scheduleItem12dot21PreAmt = scheduleItem12dot21PreAmt;
	}
	public String getScheduleItem12dot22Name() {
		return scheduleItem12dot22Name;
	}
	public void setScheduleItem12dot22Name(String scheduleItem12dot22Name) {
		this.scheduleItem12dot22Name = scheduleItem12dot22Name;
	}
	public String getScheduleItem12dot22Amt() {
		return scheduleItem12dot22Amt;
	}
	public void setScheduleItem12dot22Amt(String scheduleItem12dot22Amt) {
		this.scheduleItem12dot22Amt = scheduleItem12dot22Amt;
	}
	public String getScheduleItem12dot22PreAmt() {
		return scheduleItem12dot22PreAmt;
	}
	public void setScheduleItem12dot22PreAmt(String scheduleItem12dot22PreAmt) {
		this.scheduleItem12dot22PreAmt = scheduleItem12dot22PreAmt;
	}
	public String getScheduleItem12dot23Name() {
		return scheduleItem12dot23Name;
	}
	public void setScheduleItem12dot23Name(String scheduleItem12dot23Name) {
		this.scheduleItem12dot23Name = scheduleItem12dot23Name;
	}
	public String getScheduleItem12dot23Amt() {
		return scheduleItem12dot23Amt;
	}
	public void setScheduleItem12dot23Amt(String scheduleItem12dot23Amt) {
		this.scheduleItem12dot23Amt = scheduleItem12dot23Amt;
	}
	public String getScheduleItem12dot23PreAmt() {
		return scheduleItem12dot23PreAmt;
	}
	public void setScheduleItem12dot23PreAmt(String scheduleItem12dot23PreAmt) {
		this.scheduleItem12dot23PreAmt = scheduleItem12dot23PreAmt;
	}
	public String getScheduleItem12dot24Name() {
		return scheduleItem12dot24Name;
	}
	public void setScheduleItem12dot24Name(String scheduleItem12dot24Name) {
		this.scheduleItem12dot24Name = scheduleItem12dot24Name;
	}
	public String getScheduleItem12dot24Amt() {
		return scheduleItem12dot24Amt;
	}
	public void setScheduleItem12dot24Amt(String scheduleItem12dot24Amt) {
		this.scheduleItem12dot24Amt = scheduleItem12dot24Amt;
	}
	public String getScheduleItem12dot24PreAmt() {
		return scheduleItem12dot24PreAmt;
	}
	public void setScheduleItem12dot24PreAmt(String scheduleItem12dot24PreAmt) {
		this.scheduleItem12dot24PreAmt = scheduleItem12dot24PreAmt;
	}
	public String getScheduleItem12dot25Name() {
		return scheduleItem12dot25Name;
	}
	public void setScheduleItem12dot25Name(String scheduleItem12dot25Name) {
		this.scheduleItem12dot25Name = scheduleItem12dot25Name;
	}
	public String getScheduleItem12dot25Amt() {
		return scheduleItem12dot25Amt;
	}
	public void setScheduleItem12dot25Amt(String scheduleItem12dot25Amt) {
		this.scheduleItem12dot25Amt = scheduleItem12dot25Amt;
	}
	public String getScheduleItem12dot25PreAmt() {
		return scheduleItem12dot25PreAmt;
	}
	public void setScheduleItem12dot25PreAmt(String scheduleItem12dot25PreAmt) {
		this.scheduleItem12dot25PreAmt = scheduleItem12dot25PreAmt;
	}
	public String getScheduleItem12dot26Name() {
		return scheduleItem12dot26Name;
	}
	public void setScheduleItem12dot26Name(String scheduleItem12dot26Name) {
		this.scheduleItem12dot26Name = scheduleItem12dot26Name;
	}
	public String getScheduleItem12dot26Amt() {
		return scheduleItem12dot26Amt;
	}
	public void setScheduleItem12dot26Amt(String scheduleItem12dot26Amt) {
		this.scheduleItem12dot26Amt = scheduleItem12dot26Amt;
	}
	public String getScheduleItem12dot26PreAmt() {
		return scheduleItem12dot26PreAmt;
	}
	public void setScheduleItem12dot26PreAmt(String scheduleItem12dot26PreAmt) {
		this.scheduleItem12dot26PreAmt = scheduleItem12dot26PreAmt;
	}
	public String getScheduleItem12dot27Name() {
		return scheduleItem12dot27Name;
	}
	public void setScheduleItem12dot27Name(String scheduleItem12dot27Name) {
		this.scheduleItem12dot27Name = scheduleItem12dot27Name;
	}
	public String getScheduleItem12dot27Amt() {
		return scheduleItem12dot27Amt;
	}
	public void setScheduleItem12dot27Amt(String scheduleItem12dot27Amt) {
		this.scheduleItem12dot27Amt = scheduleItem12dot27Amt;
	}
	public String getScheduleItem12dot27PreAmt() {
		return scheduleItem12dot27PreAmt;
	}
	public void setScheduleItem12dot27PreAmt(String scheduleItem12dot27PreAmt) {
		this.scheduleItem12dot27PreAmt = scheduleItem12dot27PreAmt;
	}
	public String getScheduleItem12dot28Name() {
		return scheduleItem12dot28Name;
	}
	public void setScheduleItem12dot28Name(String scheduleItem12dot28Name) {
		this.scheduleItem12dot28Name = scheduleItem12dot28Name;
	}
	public String getScheduleItem12dot28Amt() {
		return scheduleItem12dot28Amt;
	}
	public void setScheduleItem12dot28Amt(String scheduleItem12dot28Amt) {
		this.scheduleItem12dot28Amt = scheduleItem12dot28Amt;
	}
	public String getScheduleItem12dot28PreAmt() {
		return scheduleItem12dot28PreAmt;
	}
	public void setScheduleItem12dot28PreAmt(String scheduleItem12dot28PreAmt) {
		this.scheduleItem12dot28PreAmt = scheduleItem12dot28PreAmt;
	}
	public String getScheduleItem12dot29Name() {
		return scheduleItem12dot29Name;
	}
	public void setScheduleItem12dot29Name(String scheduleItem12dot29Name) {
		this.scheduleItem12dot29Name = scheduleItem12dot29Name;
	}
	public String getScheduleItem12dot29Amt() {
		return scheduleItem12dot29Amt;
	}
	public void setScheduleItem12dot29Amt(String scheduleItem12dot29Amt) {
		this.scheduleItem12dot29Amt = scheduleItem12dot29Amt;
	}
	public String getScheduleItem12dot29PreAmt() {
		return scheduleItem12dot29PreAmt;
	}
	public void setScheduleItem12dot29PreAmt(String scheduleItem12dot29PreAmt) {
		this.scheduleItem12dot29PreAmt = scheduleItem12dot29PreAmt;
	}
	public String getScheduleItem12dot30Name() {
		return scheduleItem12dot30Name;
	}
	public void setScheduleItem12dot30Name(String scheduleItem12dot30Name) {
		this.scheduleItem12dot30Name = scheduleItem12dot30Name;
	}
	public String getScheduleItem12dot30Amt() {
		return scheduleItem12dot30Amt;
	}
	public void setScheduleItem12dot30Amt(String scheduleItem12dot30Amt) {
		this.scheduleItem12dot30Amt = scheduleItem12dot30Amt;
	}
	public String getScheduleItem12dot30PreAmt() {
		return scheduleItem12dot30PreAmt;
	}
	public void setScheduleItem12dot30PreAmt(String scheduleItem12dot30PreAmt) {
		this.scheduleItem12dot30PreAmt = scheduleItem12dot30PreAmt;
	}
	public String getScheduleItem12dot31Name() {
		return scheduleItem12dot31Name;
	}
	public void setScheduleItem12dot31Name(String scheduleItem12dot31Name) {
		this.scheduleItem12dot31Name = scheduleItem12dot31Name;
	}
	public String getScheduleItem12dot31Amt() {
		return scheduleItem12dot31Amt;
	}
	public void setScheduleItem12dot31Amt(String scheduleItem12dot31Amt) {
		this.scheduleItem12dot31Amt = scheduleItem12dot31Amt;
	}
	public String getScheduleItem12dot31PreAmt() {
		return scheduleItem12dot31PreAmt;
	}
	public void setScheduleItem12dot31PreAmt(String scheduleItem12dot31PreAmt) {
		this.scheduleItem12dot31PreAmt = scheduleItem12dot31PreAmt;
	}
	public String getScheduleItem12dot32Name() {
		return scheduleItem12dot32Name;
	}
	public void setScheduleItem12dot32Name(String scheduleItem12dot32Name) {
		this.scheduleItem12dot32Name = scheduleItem12dot32Name;
	}
	public String getScheduleItem12dot32Amt() {
		return scheduleItem12dot32Amt;
	}
	public void setScheduleItem12dot32Amt(String scheduleItem12dot32Amt) {
		this.scheduleItem12dot32Amt = scheduleItem12dot32Amt;
	}
	public String getScheduleItem12dot32PreAmt() {
		return scheduleItem12dot32PreAmt;
	}
	public void setScheduleItem12dot32PreAmt(String scheduleItem12dot32PreAmt) {
		this.scheduleItem12dot32PreAmt = scheduleItem12dot32PreAmt;
	}
	public String getScheduleItem12dot33Name() {
		return scheduleItem12dot33Name;
	}
	public void setScheduleItem12dot33Name(String scheduleItem12dot33Name) {
		this.scheduleItem12dot33Name = scheduleItem12dot33Name;
	}
	public String getScheduleItem12dot33Amt() {
		return scheduleItem12dot33Amt;
	}
	public void setScheduleItem12dot33Amt(String scheduleItem12dot33Amt) {
		this.scheduleItem12dot33Amt = scheduleItem12dot33Amt;
	}
	public String getScheduleItem12dot33PreAmt() {
		return scheduleItem12dot33PreAmt;
	}
	public void setScheduleItem12dot33PreAmt(String scheduleItem12dot33PreAmt) {
		this.scheduleItem12dot33PreAmt = scheduleItem12dot33PreAmt;
	}
	public String getScheduleItem12dot34Name() {
		return scheduleItem12dot34Name;
	}
	public void setScheduleItem12dot34Name(String scheduleItem12dot34Name) {
		this.scheduleItem12dot34Name = scheduleItem12dot34Name;
	}
	public String getScheduleItem12dot34Amt() {
		return scheduleItem12dot34Amt;
	}
	public void setScheduleItem12dot34Amt(String scheduleItem12dot34Amt) {
		this.scheduleItem12dot34Amt = scheduleItem12dot34Amt;
	}
	public String getScheduleItem12dot34PreAmt() {
		return scheduleItem12dot34PreAmt;
	}
	public void setScheduleItem12dot34PreAmt(String scheduleItem12dot34PreAmt) {
		this.scheduleItem12dot34PreAmt = scheduleItem12dot34PreAmt;
	}
	public String getScheduleItem12dot35Name() {
		return scheduleItem12dot35Name;
	}
	public void setScheduleItem12dot35Name(String scheduleItem12dot35Name) {
		this.scheduleItem12dot35Name = scheduleItem12dot35Name;
	}
	public String getScheduleItem12dot35Amt() {
		return scheduleItem12dot35Amt;
	}
	public void setScheduleItem12dot35Amt(String scheduleItem12dot35Amt) {
		this.scheduleItem12dot35Amt = scheduleItem12dot35Amt;
	}
	public String getScheduleItem12dot35PreAmt() {
		return scheduleItem12dot35PreAmt;
	}
	public void setScheduleItem12dot35PreAmt(String scheduleItem12dot35PreAmt) {
		this.scheduleItem12dot35PreAmt = scheduleItem12dot35PreAmt;
	}
	public String getScheduleItem12dot36Name() {
		return scheduleItem12dot36Name;
	}
	public void setScheduleItem12dot36Name(String scheduleItem12dot36Name) {
		this.scheduleItem12dot36Name = scheduleItem12dot36Name;
	}
	public String getScheduleItem12dot36Amt() {
		return scheduleItem12dot36Amt;
	}
	public void setScheduleItem12dot36Amt(String scheduleItem12dot36Amt) {
		this.scheduleItem12dot36Amt = scheduleItem12dot36Amt;
	}
	public String getScheduleItem12dot36PreAmt() {
		return scheduleItem12dot36PreAmt;
	}
	public void setScheduleItem12dot36PreAmt(String scheduleItem12dot36PreAmt) {
		this.scheduleItem12dot36PreAmt = scheduleItem12dot36PreAmt;
	}
	public String getScheduleItem12dot37Name() {
		return scheduleItem12dot37Name;
	}
	public void setScheduleItem12dot37Name(String scheduleItem12dot37Name) {
		this.scheduleItem12dot37Name = scheduleItem12dot37Name;
	}
	public String getScheduleItem12dot37Amt() {
		return scheduleItem12dot37Amt;
	}
	public void setScheduleItem12dot37Amt(String scheduleItem12dot37Amt) {
		this.scheduleItem12dot37Amt = scheduleItem12dot37Amt;
	}
	public String getScheduleItem12dot37PreAmt() {
		return scheduleItem12dot37PreAmt;
	}
	public void setScheduleItem12dot37PreAmt(String scheduleItem12dot37PreAmt) {
		this.scheduleItem12dot37PreAmt = scheduleItem12dot37PreAmt;
	}
	public String getScheduleItem12dot38Name() {
		return scheduleItem12dot38Name;
	}
	public void setScheduleItem12dot38Name(String scheduleItem12dot38Name) {
		this.scheduleItem12dot38Name = scheduleItem12dot38Name;
	}
	public String getScheduleItem12dot38Amt() {
		return scheduleItem12dot38Amt;
	}
	public void setScheduleItem12dot38Amt(String scheduleItem12dot38Amt) {
		this.scheduleItem12dot38Amt = scheduleItem12dot38Amt;
	}
	public String getScheduleItem12dot38PreAmt() {
		return scheduleItem12dot38PreAmt;
	}
	public void setScheduleItem12dot38PreAmt(String scheduleItem12dot38PreAmt) {
		this.scheduleItem12dot38PreAmt = scheduleItem12dot38PreAmt;
	}
	public String getScheduleItem12dot39Name() {
		return scheduleItem12dot39Name;
	}
	public void setScheduleItem12dot39Name(String scheduleItem12dot39Name) {
		this.scheduleItem12dot39Name = scheduleItem12dot39Name;
	}
	public String getScheduleItem12dot39Amt() {
		return scheduleItem12dot39Amt;
	}
	public void setScheduleItem12dot39Amt(String scheduleItem12dot39Amt) {
		this.scheduleItem12dot39Amt = scheduleItem12dot39Amt;
	}
	public String getScheduleItem12dot39PreAmt() {
		return scheduleItem12dot39PreAmt;
	}
	public void setScheduleItem12dot39PreAmt(String scheduleItem12dot39PreAmt) {
		this.scheduleItem12dot39PreAmt = scheduleItem12dot39PreAmt;
	}
	public String getFinalSchedule12Name() {
		return finalSchedule12Name;
	}
	public void setFinalSchedule12Name(String finalSchedule12Name) {
		this.finalSchedule12Name = finalSchedule12Name;
	}
	public String getFinalSchedule12Amt() {
		return finalSchedule12Amt;
	}
	public void setFinalSchedule12Amt(String finalSchedule12Amt) {
		this.finalSchedule12Amt = finalSchedule12Amt;
	}
	public String getFinalSchedule12PreAmt() {
		return finalSchedule12PreAmt;
	}
	public void setFinalSchedule12PreAmt(String finalSchedule12PreAmt) {
		this.finalSchedule12PreAmt = finalSchedule12PreAmt;
	}
	public String getScheduleItem12dot36And37Amt() {
		return scheduleItem12dot36And37Amt;
	}
	public void setScheduleItem12dot36And37Amt(String scheduleItem12dot36And37Amt) {
		this.scheduleItem12dot36And37Amt = scheduleItem12dot36And37Amt;
	}
	public String getScheduleItem12dot36And37PreAmt() {
		return scheduleItem12dot36And37PreAmt;
	}
	public void setScheduleItem12dot36And37PreAmt(String scheduleItem12dot36And37PreAmt) {
		this.scheduleItem12dot36And37PreAmt = scheduleItem12dot36And37PreAmt;
	}
	
	
	

}
