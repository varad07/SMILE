package in.ecgc.smile.erp.reporting.jasper.be.model.accounts;

public class Schedule14 {
	
	private String createdBy;

	private String scheduleItem14dot1Name;
	private String scheduleItem14dot1Amt;
	private String scheduleItem14dot1PreAmt;
	
	private String scheduleItem14dot2Name;
	private String scheduleItem14dot2Amt;
	private String scheduleItem14dot2PreAmt;
	
	private String scheduleItem14dot3Name;
	private String scheduleItem14dot3Amt;
	private String scheduleItem14dot3PreAmt;
	
	private String scheduleItem14dot4Name;
	
	private String scheduleItem14dot5Name;
	private String scheduleItem14dot5Amt;
	private String scheduleItem14dot5PreAmt;
	
	private String scheduleItem14dot6Name;
	private String scheduleItem14dot6Amt;
	private String scheduleItem14dot6PreAmt;
	
	private String scheduleItem14dot7Name;
	private String scheduleItem14dot7Amt;
	private String scheduleItem14dot7PreAmt;
	
	private String scheduleItem14dot8Name;
	private String scheduleItem14dot8Amt;
	private String scheduleItem14dot8PreAmt;
	
	private String scheduleItem14dot9Name;
	private String scheduleItem14dot9Amt;
	private String scheduleItem14dot9PreAmt;
	
	private String scheduleItem14dot10Name;
	private String scheduleItem14dot10Amt;
	private String scheduleItem14dot10PreAmt;
	
	private String scheduleItem14dot11Name;
	private String scheduleItem14dot11Amt;
	private String scheduleItem14dot11PreAmt;
	
	private String scheduleItem14dot12Name;
	private String scheduleItem14dot12Amt;
	private String scheduleItem14dot12PreAmt;
	
	private String scheduleItem14dot13Name;
	private String scheduleItem14dot13Amt;
	private String scheduleItem14dot13PreAmt; 	
	
	private String finalSchedule14Name;
	private String finalSchedule14Amt;
	private String finalSchedule14PreAmt;
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getScheduleItem14dot1Name() {
		return scheduleItem14dot1Name;
	}
	public void setScheduleItem14dot1Name(String scheduleItem14dot1Name) {
		this.scheduleItem14dot1Name = scheduleItem14dot1Name;
	}
	public String getScheduleItem14dot1Amt() {
		return scheduleItem14dot1Amt;
	}
	public void setScheduleItem14dot1Amt(String scheduleItem14dot1Amt) {
		this.scheduleItem14dot1Amt = scheduleItem14dot1Amt;
	}
	public String getScheduleItem14dot1PreAmt() {
		return scheduleItem14dot1PreAmt;
	}
	public void setScheduleItem14dot1PreAmt(String scheduleItem14dot1PreAmt) {
		this.scheduleItem14dot1PreAmt = scheduleItem14dot1PreAmt;
	}
	public String getScheduleItem14dot2Name() {
		return scheduleItem14dot2Name;
	}
	public void setScheduleItem14dot2Name(String scheduleItem14dot2Name) {
		this.scheduleItem14dot2Name = scheduleItem14dot2Name;
	}
	public String getScheduleItem14dot2Amt() {
		return scheduleItem14dot2Amt;
	}
	public void setScheduleItem14dot2Amt(String scheduleItem14dot2Amt) {
		this.scheduleItem14dot2Amt = scheduleItem14dot2Amt;
	}
	public String getScheduleItem14dot2PreAmt() {
		return scheduleItem14dot2PreAmt;
	}
	public void setScheduleItem14dot2PreAmt(String scheduleItem14dot2PreAmt) {
		this.scheduleItem14dot2PreAmt = scheduleItem14dot2PreAmt;
	}
	public String getScheduleItem14dot3Name() {
		return scheduleItem14dot3Name;
	}
	public void setScheduleItem14dot3Name(String scheduleItem14dot3Name) {
		this.scheduleItem14dot3Name = scheduleItem14dot3Name;
	}
	public String getScheduleItem14dot3Amt() {
		return scheduleItem14dot3Amt;
	}
	public void setScheduleItem14dot3Amt(String scheduleItem14dot3Amt) {
		this.scheduleItem14dot3Amt = scheduleItem14dot3Amt;
	}
	public String getScheduleItem14dot3PreAmt() {
		return scheduleItem14dot3PreAmt;
	}
	public void setScheduleItem14dot3PreAmt(String scheduleItem14dot3PreAmt) {
		this.scheduleItem14dot3PreAmt = scheduleItem14dot3PreAmt;
	}
	public String getScheduleItem14dot4Name() {
		return scheduleItem14dot4Name;
	}
	public void setScheduleItem14dot4Name(String scheduleItem14dot4Name) {
		this.scheduleItem14dot4Name = scheduleItem14dot4Name;
	}
	public String getScheduleItem14dot5Name() {
		return scheduleItem14dot5Name;
	}
	public void setScheduleItem14dot5Name(String scheduleItem14dot5Name) {
		this.scheduleItem14dot5Name = scheduleItem14dot5Name;
	}
	public String getScheduleItem14dot5Amt() {
		return scheduleItem14dot5Amt;
	}
	public void setScheduleItem14dot5Amt(String scheduleItem14dot5Amt) {
		this.scheduleItem14dot5Amt = scheduleItem14dot5Amt;
	}
	public String getScheduleItem14dot5PreAmt() {
		return scheduleItem14dot5PreAmt;
	}
	public void setScheduleItem14dot5PreAmt(String scheduleItem14dot5PreAmt) {
		this.scheduleItem14dot5PreAmt = scheduleItem14dot5PreAmt;
	}
	public String getScheduleItem14dot6Name() {
		return scheduleItem14dot6Name;
	}
	public void setScheduleItem14dot6Name(String scheduleItem14dot6Name) {
		this.scheduleItem14dot6Name = scheduleItem14dot6Name;
	}
	public String getScheduleItem14dot6Amt() {
		return scheduleItem14dot6Amt;
	}
	public void setScheduleItem14dot6Amt(String scheduleItem14dot6Amt) {
		this.scheduleItem14dot6Amt = scheduleItem14dot6Amt;
	}
	public String getScheduleItem14dot6PreAmt() {
		return scheduleItem14dot6PreAmt;
	}
	public void setScheduleItem14dot6PreAmt(String scheduleItem14dot6PreAmt) {
		this.scheduleItem14dot6PreAmt = scheduleItem14dot6PreAmt;
	}
	public String getScheduleItem14dot7Name() {
		return scheduleItem14dot7Name;
	}
	public void setScheduleItem14dot7Name(String scheduleItem14dot7Name) {
		this.scheduleItem14dot7Name = scheduleItem14dot7Name;
	}
	public String getScheduleItem14dot7Amt() {
		return scheduleItem14dot7Amt;
	}
	public void setScheduleItem14dot7Amt(String scheduleItem14dot7Amt) {
		this.scheduleItem14dot7Amt = scheduleItem14dot7Amt;
	}
	public String getScheduleItem14dot7PreAmt() {
		return scheduleItem14dot7PreAmt;
	}
	public void setScheduleItem14dot7PreAmt(String scheduleItem14dot7PreAmt) {
		this.scheduleItem14dot7PreAmt = scheduleItem14dot7PreAmt;
	}
	public String getScheduleItem14dot8Name() {
		return scheduleItem14dot8Name;
	}
	public void setScheduleItem14dot8Name(String scheduleItem14dot8Name) {
		this.scheduleItem14dot8Name = scheduleItem14dot8Name;
	}
	public String getScheduleItem14dot8Amt() {
		return scheduleItem14dot8Amt;
	}
	public void setScheduleItem14dot8Amt(String scheduleItem14dot8Amt) {
		this.scheduleItem14dot8Amt = scheduleItem14dot8Amt;
	}
	public String getScheduleItem14dot8PreAmt() {
		return scheduleItem14dot8PreAmt;
	}
	public void setScheduleItem14dot8PreAmt(String scheduleItem14dot8PreAmt) {
		this.scheduleItem14dot8PreAmt = scheduleItem14dot8PreAmt;
	}
	public String getScheduleItem14dot9Name() {
		return scheduleItem14dot9Name;
	}
	public void setScheduleItem14dot9Name(String scheduleItem14dot9Name) {
		this.scheduleItem14dot9Name = scheduleItem14dot9Name;
	}
	public String getScheduleItem14dot9Amt() {
		return scheduleItem14dot9Amt;
	}
	public void setScheduleItem14dot9Amt(String scheduleItem14dot9Amt) {
		this.scheduleItem14dot9Amt = scheduleItem14dot9Amt;
	}
	public String getScheduleItem14dot9PreAmt() {
		return scheduleItem14dot9PreAmt;
	}
	public void setScheduleItem14dot9PreAmt(String scheduleItem14dot9PreAmt) {
		this.scheduleItem14dot9PreAmt = scheduleItem14dot9PreAmt;
	}
	public String getScheduleItem14dot10Name() {
		return scheduleItem14dot10Name;
	}
	public void setScheduleItem14dot10Name(String scheduleItem14dot10Name) {
		this.scheduleItem14dot10Name = scheduleItem14dot10Name;
	}
	public String getScheduleItem14dot10Amt() {
		return scheduleItem14dot10Amt;
	}
	public void setScheduleItem14dot10Amt(String scheduleItem14dot10Amt) {
		this.scheduleItem14dot10Amt = scheduleItem14dot10Amt;
	}
	public String getScheduleItem14dot10PreAmt() {
		return scheduleItem14dot10PreAmt;
	}
	public void setScheduleItem14dot10PreAmt(String scheduleItem14dot10PreAmt) {
		this.scheduleItem14dot10PreAmt = scheduleItem14dot10PreAmt;
	}
	public String getScheduleItem14dot11Name() {
		return scheduleItem14dot11Name;
	}
	public void setScheduleItem14dot11Name(String scheduleItem14dot11Name) {
		this.scheduleItem14dot11Name = scheduleItem14dot11Name;
	}
	public String getScheduleItem14dot11Amt() {
		return scheduleItem14dot11Amt;
	}
	public void setScheduleItem14dot11Amt(String scheduleItem14dot11Amt) {
		this.scheduleItem14dot11Amt = scheduleItem14dot11Amt;
	}
	public String getScheduleItem14dot11PreAmt() {
		return scheduleItem14dot11PreAmt;
	}
	public void setScheduleItem14dot11PreAmt(String scheduleItem14dot11PreAmt) {
		this.scheduleItem14dot11PreAmt = scheduleItem14dot11PreAmt;
	}
	public String getScheduleItem14dot12Name() {
		return scheduleItem14dot12Name;
	}
	public void setScheduleItem14dot12Name(String scheduleItem14dot12Name) {
		this.scheduleItem14dot12Name = scheduleItem14dot12Name;
	}
	public String getScheduleItem14dot12Amt() {
		return scheduleItem14dot12Amt;
	}
	public void setScheduleItem14dot12Amt(String scheduleItem14dot12Amt) {
		this.scheduleItem14dot12Amt = scheduleItem14dot12Amt;
	}
	public String getScheduleItem14dot12PreAmt() {
		return scheduleItem14dot12PreAmt;
	}
	public void setScheduleItem14dot12PreAmt(String scheduleItem14dot12PreAmt) {
		this.scheduleItem14dot12PreAmt = scheduleItem14dot12PreAmt;
	}
	public String getScheduleItem14dot13Name() {
		return scheduleItem14dot13Name;
	}
	public void setScheduleItem14dot13Name(String scheduleItem14dot13Name) {
		this.scheduleItem14dot13Name = scheduleItem14dot13Name;
	}
	public String getScheduleItem14dot13Amt() {
		return scheduleItem14dot13Amt;
	}
	public void setScheduleItem14dot13Amt(String scheduleItem14dot13Amt) {
		this.scheduleItem14dot13Amt = scheduleItem14dot13Amt;
	}
	public String getScheduleItem14dot13PreAmt() {
		return scheduleItem14dot13PreAmt;
	}
	public void setScheduleItem14dot13PreAmt(String scheduleItem14dot13PreAmt) {
		this.scheduleItem14dot13PreAmt = scheduleItem14dot13PreAmt;
	}
	public String getFinalSchedule14Name() {
		return finalSchedule14Name;
	}
	public void setFinalSchedule14Name(String finalSchedule14Name) {
		this.finalSchedule14Name = finalSchedule14Name;
	}
	public String getFinalSchedule14Amt() {
		return finalSchedule14Amt;
	}
	public void setFinalSchedule14Amt(String finalSchedule14Amt) {
		this.finalSchedule14Amt = finalSchedule14Amt;
	}
	public String getFinalSchedule14PreAmt() {
		return finalSchedule14PreAmt;
	}
	public void setFinalSchedule14PreAmt(String finalSchedule14PreAmt) {
		this.finalSchedule14PreAmt = finalSchedule14PreAmt;
	}
	
	
	
}
