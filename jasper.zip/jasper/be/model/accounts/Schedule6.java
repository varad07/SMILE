package in.ecgc.smile.erp.reporting.jasper.be.model.accounts;

public class Schedule6 {
	
	private String createdBy;

	private String scheduleItem6dot1Name;
	private String scheduleItem6dot1Amt;
	private String scheduleItem6dot1PreAmt;
	
	private String scheduleItem6dot2Name;
	private String scheduleItem6dot2Amt;
	private String scheduleItem6dot2PreAmt;
	
	private String scheduleItem6dot3Name;
	private String scheduleItem6dot3Amt;
	private String scheduleItem6dot3PreAmt;
	
	private String scheduleItem6dot4Name;
	private String scheduleItem6dot4Amt;
	private String scheduleItem6dot4PreAmt;
	
	private String scheduleItem6dot4dot1Name;
	private String scheduleItem6dot4dot1Amt;
	private String scheduleItem6dot4dot1PreAmt;
	
	private String scheduleItem6dot4t1Name;
	private String scheduleItem6dot4t1Amt;
	private String scheduleItem6dot4t1PreAmt;
	
	private String scheduleItem6dot4dot2Name;
	private String scheduleItem6dot4dot2Amt;
	private String scheduleItem6dot4dot2PreAmt;
	
	private String scheduleItem6dot4t2Name;
	private String scheduleItem6dot4t2Amt;
	private String scheduleItem6dot4t2PreAmt;
	
	private String scheduleItem6dot5Name;
	private String scheduleItem6dot5Amt;
	private String scheduleItem6dot5PreAmt;
	
	private String scheduleItem6dot6Name;
	private String scheduleItem6dot6Amt;
	private String scheduleItem6dot6PreAmt;
	
	private String scheduleItem6dot7Name;
	private String scheduleItem6dot7Amt;
	private String scheduleItem6dot7PreAmt;
	
	private String finalSchedule6Name;
	private String finalSchedule6Amt;
	private String finalSchedule6PreAmt;
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getScheduleItem6dot1Name() {
		return scheduleItem6dot1Name;
	}
	public void setScheduleItem6dot1Name(String scheduleItem6dot1Name) {
		this.scheduleItem6dot1Name = scheduleItem6dot1Name;
	}
	public String getScheduleItem6dot1Amt() {
		return scheduleItem6dot1Amt;
	}
	public void setScheduleItem6dot1Amt(String scheduleItem6dot1Amt) {
		this.scheduleItem6dot1Amt = scheduleItem6dot1Amt;
	}
	public String getScheduleItem6dot1PreAmt() {
		return scheduleItem6dot1PreAmt;
	}
	public void setScheduleItem6dot1PreAmt(String scheduleItem6dot1PreAmt) {
		this.scheduleItem6dot1PreAmt = scheduleItem6dot1PreAmt;
	}
	public String getScheduleItem6dot2Name() {
		return scheduleItem6dot2Name;
	}
	public void setScheduleItem6dot2Name(String scheduleItem6dot2Name) {
		this.scheduleItem6dot2Name = scheduleItem6dot2Name;
	}
	public String getScheduleItem6dot2Amt() {
		return scheduleItem6dot2Amt;
	}
	public void setScheduleItem6dot2Amt(String scheduleItem6dot2Amt) {
		this.scheduleItem6dot2Amt = scheduleItem6dot2Amt;
	}
	public String getScheduleItem6dot2PreAmt() {
		return scheduleItem6dot2PreAmt;
	}
	public void setScheduleItem6dot2PreAmt(String scheduleItem6dot2PreAmt) {
		this.scheduleItem6dot2PreAmt = scheduleItem6dot2PreAmt;
	}
	public String getScheduleItem6dot3Name() {
		return scheduleItem6dot3Name;
	}
	public void setScheduleItem6dot3Name(String scheduleItem6dot3Name) {
		this.scheduleItem6dot3Name = scheduleItem6dot3Name;
	}
	public String getScheduleItem6dot3Amt() {
		return scheduleItem6dot3Amt;
	}
	public void setScheduleItem6dot3Amt(String scheduleItem6dot3Amt) {
		this.scheduleItem6dot3Amt = scheduleItem6dot3Amt;
	}
	public String getScheduleItem6dot3PreAmt() {
		return scheduleItem6dot3PreAmt;
	}
	public void setScheduleItem6dot3PreAmt(String scheduleItem6dot3PreAmt) {
		this.scheduleItem6dot3PreAmt = scheduleItem6dot3PreAmt;
	}
	public String getScheduleItem6dot4Name() {
		return scheduleItem6dot4Name;
	}
	public void setScheduleItem6dot4Name(String scheduleItem6dot4Name) {
		this.scheduleItem6dot4Name = scheduleItem6dot4Name;
	}
	public String getScheduleItem6dot4Amt() {
		return scheduleItem6dot4Amt;
	}
	public void setScheduleItem6dot4Amt(String scheduleItem6dot4Amt) {
		this.scheduleItem6dot4Amt = scheduleItem6dot4Amt;
	}
	public String getScheduleItem6dot4PreAmt() {
		return scheduleItem6dot4PreAmt;
	}
	public void setScheduleItem6dot4PreAmt(String scheduleItem6dot4PreAmt) {
		this.scheduleItem6dot4PreAmt = scheduleItem6dot4PreAmt;
	}
	public String getScheduleItem6dot4dot1Name() {
		return scheduleItem6dot4dot1Name;
	}
	public void setScheduleItem6dot4dot1Name(String scheduleItem6dot4dot1Name) {
		this.scheduleItem6dot4dot1Name = scheduleItem6dot4dot1Name;
	}
	public String getScheduleItem6dot4dot1Amt() {
		return scheduleItem6dot4dot1Amt;
	}
	public void setScheduleItem6dot4dot1Amt(String scheduleItem6dot4dot1Amt) {
		this.scheduleItem6dot4dot1Amt = scheduleItem6dot4dot1Amt;
	}
	public String getScheduleItem6dot4dot1PreAmt() {
		return scheduleItem6dot4dot1PreAmt;
	}
	public void setScheduleItem6dot4dot1PreAmt(String scheduleItem6dot4dot1PreAmt) {
		this.scheduleItem6dot4dot1PreAmt = scheduleItem6dot4dot1PreAmt;
	}
	public String getScheduleItem6dot4t1Name() {
		return scheduleItem6dot4t1Name;
	}
	public void setScheduleItem6dot4t1Name(String scheduleItem6dot4t1Name) {
		this.scheduleItem6dot4t1Name = scheduleItem6dot4t1Name;
	}
	public String getScheduleItem6dot4t1Amt() {
		return scheduleItem6dot4t1Amt;
	}
	public void setScheduleItem6dot4t1Amt(String scheduleItem6dot4t1Amt) {
		this.scheduleItem6dot4t1Amt = scheduleItem6dot4t1Amt;
	}
	public String getScheduleItem6dot4t1PreAmt() {
		return scheduleItem6dot4t1PreAmt;
	}
	public void setScheduleItem6dot4t1PreAmt(String scheduleItem6dot4t1PreAmt) {
		this.scheduleItem6dot4t1PreAmt = scheduleItem6dot4t1PreAmt;
	}
	public String getScheduleItem6dot4dot2Name() {
		return scheduleItem6dot4dot2Name;
	}
	public void setScheduleItem6dot4dot2Name(String scheduleItem6dot4dot2Name) {
		this.scheduleItem6dot4dot2Name = scheduleItem6dot4dot2Name;
	}
	public String getScheduleItem6dot4dot2Amt() {
		return scheduleItem6dot4dot2Amt;
	}
	public void setScheduleItem6dot4dot2Amt(String scheduleItem6dot4dot2Amt) {
		this.scheduleItem6dot4dot2Amt = scheduleItem6dot4dot2Amt;
	}
	public String getScheduleItem6dot4dot2PreAmt() {
		return scheduleItem6dot4dot2PreAmt;
	}
	public void setScheduleItem6dot4dot2PreAmt(String scheduleItem6dot4dot2PreAmt) {
		this.scheduleItem6dot4dot2PreAmt = scheduleItem6dot4dot2PreAmt;
	}
	public String getScheduleItem6dot4t2Name() {
		return scheduleItem6dot4t2Name;
	}
	public void setScheduleItem6dot4t2Name(String scheduleItem6dot4t2Name) {
		this.scheduleItem6dot4t2Name = scheduleItem6dot4t2Name;
	}
	public String getScheduleItem6dot4t2Amt() {
		return scheduleItem6dot4t2Amt;
	}
	public void setScheduleItem6dot4t2Amt(String scheduleItem6dot4t2Amt) {
		this.scheduleItem6dot4t2Amt = scheduleItem6dot4t2Amt;
	}
	public String getScheduleItem6dot4t2PreAmt() {
		return scheduleItem6dot4t2PreAmt;
	}
	public void setScheduleItem6dot4t2PreAmt(String scheduleItem6dot4t2PreAmt) {
		this.scheduleItem6dot4t2PreAmt = scheduleItem6dot4t2PreAmt;
	}
	public String getScheduleItem6dot5Name() {
		return scheduleItem6dot5Name;
	}
	public void setScheduleItem6dot5Name(String scheduleItem6dot5Name) {
		this.scheduleItem6dot5Name = scheduleItem6dot5Name;
	}
	public String getScheduleItem6dot5Amt() {
		return scheduleItem6dot5Amt;
	}
	public void setScheduleItem6dot5Amt(String scheduleItem6dot5Amt) {
		this.scheduleItem6dot5Amt = scheduleItem6dot5Amt;
	}
	public String getScheduleItem6dot5PreAmt() {
		return scheduleItem6dot5PreAmt;
	}
	public void setScheduleItem6dot5PreAmt(String scheduleItem6dot5PreAmt) {
		this.scheduleItem6dot5PreAmt = scheduleItem6dot5PreAmt;
	}
	public String getScheduleItem6dot6Name() {
		return scheduleItem6dot6Name;
	}
	public void setScheduleItem6dot6Name(String scheduleItem6dot6Name) {
		this.scheduleItem6dot6Name = scheduleItem6dot6Name;
	}
	public String getScheduleItem6dot6Amt() {
		return scheduleItem6dot6Amt;
	}
	public void setScheduleItem6dot6Amt(String scheduleItem6dot6Amt) {
		this.scheduleItem6dot6Amt = scheduleItem6dot6Amt;
	}
	public String getScheduleItem6dot6PreAmt() {
		return scheduleItem6dot6PreAmt;
	}
	public void setScheduleItem6dot6PreAmt(String scheduleItem6dot6PreAmt) {
		this.scheduleItem6dot6PreAmt = scheduleItem6dot6PreAmt;
	}
	public String getScheduleItem6dot7Name() {
		return scheduleItem6dot7Name;
	}
	public void setScheduleItem6dot7Name(String scheduleItem6dot7Name) {
		this.scheduleItem6dot7Name = scheduleItem6dot7Name;
	}
	public String getScheduleItem6dot7Amt() {
		return scheduleItem6dot7Amt;
	}
	public void setScheduleItem6dot7Amt(String scheduleItem6dot7Amt) {
		this.scheduleItem6dot7Amt = scheduleItem6dot7Amt;
	}
	public String getScheduleItem6dot7PreAmt() {
		return scheduleItem6dot7PreAmt;
	}
	public void setScheduleItem6dot7PreAmt(String scheduleItem6dot7PreAmt) {
		this.scheduleItem6dot7PreAmt = scheduleItem6dot7PreAmt;
	}
	public String getFinalSchedule6Name() {
		return finalSchedule6Name;
	}
	public void setFinalSchedule6Name(String finalSchedule6Name) {
		this.finalSchedule6Name = finalSchedule6Name;
	}
	public String getFinalSchedule6Amt() {
		return finalSchedule6Amt;
	}
	public void setFinalSchedule6Amt(String finalSchedule6Amt) {
		this.finalSchedule6Amt = finalSchedule6Amt;
	}
	public String getFinalSchedule6PreAmt() {
		return finalSchedule6PreAmt;
	}
	public void setFinalSchedule6PreAmt(String finalSchedule6PreAmt) {
		this.finalSchedule6PreAmt = finalSchedule6PreAmt;
	}
	
	
}
