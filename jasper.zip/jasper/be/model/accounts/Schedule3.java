package in.ecgc.smile.erp.reporting.jasper.be.model.accounts;

public class Schedule3 {

	private String createdBy;

	private String scheduleItem3dot1Name;
	
	private String scheduleItem3dot2Name;
	private String scheduleItem3dot2Amt;
	private String scheduleItem3dot2PreAmt;

	private String scheduleItem3dot3Name;
	private String scheduleItem3dot3Amt;
	private String scheduleItem3dot3PreAmt;

	private String scheduleItem3dot4Name;
	private String scheduleItem3dot4Amt;
	private String scheduleItem3dot4PreAmt;

	private String scheduleItem3dot5Name;
	private String scheduleItem3dot5Amt;
	private String scheduleItem3dot5PreAmt;
	
	private String scheduleItem3dot6Name;
	private String scheduleItem3dot6Amt;
	private String scheduleItem3dot6PreAmt;
	
	private String scheduleItem3dot7Name;
	private String scheduleItem3dot7Amt;
	private String scheduleItem3dot7PreAmt;
	
	private String scheduleItem3dot8Name;
	private String scheduleItem3dot8Amt;
	private String scheduleItem3dot8PreAmt;
	
	private String scheduleItem3dot9Name;
	private String scheduleItem3dot9Amt;
	private String scheduleItem3dot9PreAmt;
	
	private String scheduleItem3dot10Name;
	private String scheduleItem3dot10Amt;
	private String scheduleItem3dot10PreAmt;
	
	private String finalScheduleName;
	private String finalSchedule3Amt;
	private String finalSchedule3PreAmt;
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getScheduleItem3dot1Name() {
		return scheduleItem3dot1Name;
	}
	public void setScheduleItem3dot1Name(String scheduleItem3dot1Name) {
		this.scheduleItem3dot1Name = scheduleItem3dot1Name;
	}
	public String getScheduleItem3dot2Name() {
		return scheduleItem3dot2Name;
	}
	public void setScheduleItem3dot2Name(String scheduleItem3dot2Name) {
		this.scheduleItem3dot2Name = scheduleItem3dot2Name;
	}
	public String getScheduleItem3dot2Amt() {
		return scheduleItem3dot2Amt;
	}
	public void setScheduleItem3dot2Amt(String scheduleItem3dot2Amt) {
		this.scheduleItem3dot2Amt = scheduleItem3dot2Amt;
	}
	public String getScheduleItem3dot2PreAmt() {
		return scheduleItem3dot2PreAmt;
	}
	public void setScheduleItem3dot2PreAmt(String scheduleItem3dot2PreAmt) {
		this.scheduleItem3dot2PreAmt = scheduleItem3dot2PreAmt;
	}
	public String getScheduleItem3dot3Name() {
		return scheduleItem3dot3Name;
	}
	public void setScheduleItem3dot3Name(String scheduleItem3dot3Name) {
		this.scheduleItem3dot3Name = scheduleItem3dot3Name;
	}
	public String getScheduleItem3dot3Amt() {
		return scheduleItem3dot3Amt;
	}
	public void setScheduleItem3dot3Amt(String scheduleItem3dot3Amt) {
		this.scheduleItem3dot3Amt = scheduleItem3dot3Amt;
	}
	public String getScheduleItem3dot3PreAmt() {
		return scheduleItem3dot3PreAmt;
	}
	public void setScheduleItem3dot3PreAmt(String scheduleItem3dot3PreAmt) {
		this.scheduleItem3dot3PreAmt = scheduleItem3dot3PreAmt;
	}
	public String getScheduleItem3dot4Name() {
		return scheduleItem3dot4Name;
	}
	public void setScheduleItem3dot4Name(String scheduleItem3dot4Name) {
		this.scheduleItem3dot4Name = scheduleItem3dot4Name;
	}
	public String getScheduleItem3dot4Amt() {
		return scheduleItem3dot4Amt;
	}
	public void setScheduleItem3dot4Amt(String scheduleItem3dot4Amt) {
		this.scheduleItem3dot4Amt = scheduleItem3dot4Amt;
	}
	public String getScheduleItem3dot4PreAmt() {
		return scheduleItem3dot4PreAmt;
	}
	public void setScheduleItem3dot4PreAmt(String scheduleItem3dot4PreAmt) {
		this.scheduleItem3dot4PreAmt = scheduleItem3dot4PreAmt;
	}
	public String getScheduleItem3dot5Name() {
		return scheduleItem3dot5Name;
	}
	public void setScheduleItem3dot5Name(String scheduleItem3dot5Name) {
		this.scheduleItem3dot5Name = scheduleItem3dot5Name;
	}
	public String getScheduleItem3dot5Amt() {
		return scheduleItem3dot5Amt;
	}
	public void setScheduleItem3dot5Amt(String scheduleItem3dot5Amt) {
		this.scheduleItem3dot5Amt = scheduleItem3dot5Amt;
	}
	public String getScheduleItem3dot5PreAmt() {
		return scheduleItem3dot5PreAmt;
	}
	public void setScheduleItem3dot5PreAmt(String scheduleItem3dot5PreAmt) {
		this.scheduleItem3dot5PreAmt = scheduleItem3dot5PreAmt;
	}
	public String getScheduleItem3dot6Name() {
		return scheduleItem3dot6Name;
	}
	public void setScheduleItem3dot6Name(String scheduleItem3dot6Name) {
		this.scheduleItem3dot6Name = scheduleItem3dot6Name;
	}
	public String getScheduleItem3dot6Amt() {
		return scheduleItem3dot6Amt;
	}
	public void setScheduleItem3dot6Amt(String scheduleItem3dot6Amt) {
		this.scheduleItem3dot6Amt = scheduleItem3dot6Amt;
	}
	public String getScheduleItem3dot6PreAmt() {
		return scheduleItem3dot6PreAmt;
	}
	public void setScheduleItem3dot6PreAmt(String scheduleItem3dot6PreAmt) {
		this.scheduleItem3dot6PreAmt = scheduleItem3dot6PreAmt;
	}
	public String getScheduleItem3dot7Name() {
		return scheduleItem3dot7Name;
	}
	public void setScheduleItem3dot7Name(String scheduleItem3dot7Name) {
		this.scheduleItem3dot7Name = scheduleItem3dot7Name;
	}
	public String getScheduleItem3dot7Amt() {
		return scheduleItem3dot7Amt;
	}
	public void setScheduleItem3dot7Amt(String scheduleItem3dot7Amt) {
		this.scheduleItem3dot7Amt = scheduleItem3dot7Amt;
	}
	public String getScheduleItem3dot7PreAmt() {
		return scheduleItem3dot7PreAmt;
	}
	public void setScheduleItem3dot7PreAmt(String scheduleItem3dot7PreAmt) {
		this.scheduleItem3dot7PreAmt = scheduleItem3dot7PreAmt;
	}
	public String getScheduleItem3dot8Name() {
		return scheduleItem3dot8Name;
	}
	public void setScheduleItem3dot8Name(String scheduleItem3dot8Name) {
		this.scheduleItem3dot8Name = scheduleItem3dot8Name;
	}
	public String getScheduleItem3dot8Amt() {
		return scheduleItem3dot8Amt;
	}
	public void setScheduleItem3dot8Amt(String scheduleItem3dot8Amt) {
		this.scheduleItem3dot8Amt = scheduleItem3dot8Amt;
	}
	public String getScheduleItem3dot8PreAmt() {
		return scheduleItem3dot8PreAmt;
	}
	public void setScheduleItem3dot8PreAmt(String scheduleItem3dot8PreAmt) {
		this.scheduleItem3dot8PreAmt = scheduleItem3dot8PreAmt;
	}
	public String getScheduleItem3dot9Name() {
		return scheduleItem3dot9Name;
	}
	public void setScheduleItem3dot9Name(String scheduleItem3dot9Name) {
		this.scheduleItem3dot9Name = scheduleItem3dot9Name;
	}
	public String getScheduleItem3dot9Amt() {
		return scheduleItem3dot9Amt;
	}
	public void setScheduleItem3dot9Amt(String scheduleItem3dot9Amt) {
		this.scheduleItem3dot9Amt = scheduleItem3dot9Amt;
	}
	public String getScheduleItem3dot9PreAmt() {
		return scheduleItem3dot9PreAmt;
	}
	public void setScheduleItem3dot9PreAmt(String scheduleItem3dot9PreAmt) {
		this.scheduleItem3dot9PreAmt = scheduleItem3dot9PreAmt;
	}
	public String getScheduleItem3dot10Name() {
		return scheduleItem3dot10Name;
	}
	public void setScheduleItem3dot10Name(String scheduleItem3dot10Name) {
		this.scheduleItem3dot10Name = scheduleItem3dot10Name;
	}
	public String getScheduleItem3dot10Amt() {
		return scheduleItem3dot10Amt;
	}
	public void setScheduleItem3dot10Amt(String scheduleItem3dot10Amt) {
		this.scheduleItem3dot10Amt = scheduleItem3dot10Amt;
	}
	public String getScheduleItem3dot10PreAmt() {
		return scheduleItem3dot10PreAmt;
	}
	public void setScheduleItem3dot10PreAmt(String scheduleItem3dot10PreAmt) {
		this.scheduleItem3dot10PreAmt = scheduleItem3dot10PreAmt;
	}
	
	public String getFinalScheduleName() {
		return finalScheduleName;
	}
	public void setFinalScheduleName(String finalScheduleName) {
		this.finalScheduleName = finalScheduleName;
	}
	public String getFinalSchedule3Amt() {
		return finalSchedule3Amt;
	}
	public void setFinalSchedule3Amt(String finalSchedule3Amt) {
		this.finalSchedule3Amt = finalSchedule3Amt;
	}
	public String getFinalSchedule3PreAmt() {
		return finalSchedule3PreAmt;
	}
	public void setFinalSchedule3PreAmt(String finalSchedule3PreAmt) {
		this.finalSchedule3PreAmt = finalSchedule3PreAmt;
	}
	
	
	
	
}
