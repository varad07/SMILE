package in.ecgc.smile.erp.reporting.jasper.be.model.accounts;

import java.util.List;

public class GLRangeStmtOut {
	
	private String logicalLocCd;
	private String branch;
	
	private List<GLRangeStmtDtl> glRangeStmtDtls;

	public String getLogicalLocCd() {
		return logicalLocCd;
	}

	public void setLogicalLocCd(String logicalLocCd) {
		this.logicalLocCd = logicalLocCd;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public List<GLRangeStmtDtl> getGlRangeStmtDtls() {
		return glRangeStmtDtls;
	}

	public void setGlRangeStmtDtls(List<GLRangeStmtDtl> glRangeStmtDtls) {
		this.glRangeStmtDtls = glRangeStmtDtls;
	}

	@Override
	public String toString() {
		return "GLRangeStmtOut [logicalLocCd=" + logicalLocCd + ", branch=" + branch + ", glRangeStmtDtls="
				+ glRangeStmtDtls + "]";
	}
	
	
}
