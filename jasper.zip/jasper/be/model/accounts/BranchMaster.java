package in.ecgc.smile.erp.reporting.jasper.be.model.accounts;

import java.util.Date;

public class BranchMaster {

	/* Branch code */
	private String branchCd;

	/* Branch Name */
	private String branchName;

	public String getBranchCd() {
		return branchCd;
	}

	public void setBranchCd(String branchCd) {
		this.branchCd = branchCd;
	}

	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	@Override
	public String toString() {
		return "BranchMaster [branchCd=" + branchCd + ", branchName=" + branchName + "]";
	}
	
	


}