package in.ecgc.smile.erp.reporting.jasper.be.model.accounts;

import java.math.BigDecimal;
import java.time.LocalDate;

public class TrialBalanceLocationWise {
	
	
	private LocalDate inputDate;
	private String mainglCd;
	private String subGlCd;
	private String glName;
	private String glType;
	private BigDecimal crAmount;
	private BigDecimal drAmount;
	private String logicalLocation;
	
	
	public LocalDate getInputDate() {
		return inputDate;
	}
	public void setInputDate(LocalDate inputDate) {
		this.inputDate = inputDate;
	}
	public String getMainglCd() {
		return mainglCd;
	}
	public void setMainglCd(String mainglCd) {
		this.mainglCd = mainglCd;
	}
	public String getSubGlCd() {
		return subGlCd;
	}
	public void setSubGlCd(String subGlCd) {
		this.subGlCd = subGlCd;
	}
	public String getGlName() {
		return glName;
	}
	public void setGlName(String glName) {
		this.glName = glName;
	}
	public String getGlType() {
		return glType;
	}
	public void setGlType(String glType) {
		this.glType = glType;
	}
	public BigDecimal getCrAmount() {
		return crAmount;
	}
	public void setCrAmount(BigDecimal crAmount) {
		this.crAmount = crAmount;
	}
	public BigDecimal getDrAmount() {
		return drAmount;
	}
	public void setDrAmount(BigDecimal drAmount) {
		this.drAmount = drAmount;
	}
	
	
	public String getLogicalLocation() {
		return logicalLocation;
	}
	public void setLogicalLocation(String logicalLocation) {
		this.logicalLocation = logicalLocation;
	}
	@Override
	public String toString() {
		return "TrialBalanceLocationWise [inputDate=" + inputDate + ", mainglCd=" + mainglCd + ", subGlCd=" + subGlCd
				+ ", glName=" + glName + ", glType=" + glType + ", crAmount=" + crAmount + ", drAmount=" + drAmount
				+ ", logicalLocation=" + logicalLocation + "]";
	}
	
	
	
	

}
