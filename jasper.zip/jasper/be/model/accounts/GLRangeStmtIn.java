package in.ecgc.smile.erp.reporting.jasper.be.model.accounts;

import java.time.LocalDate;

import org.springframework.format.annotation.DateTimeFormat;

public class GLRangeStmtIn {

	private String logicallocCd;
	private String fromMainglCd;
	private String fromSubglCd;
	private String toMainglCd;
	private String toSubglCd;
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate fromDt;
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate toDt;
	public String getLogicallocCd() {
		return logicallocCd;
	}
	public void setLogicallocCd(String logicallocCd) {
		this.logicallocCd = logicallocCd;
	}
	public String getFromMainglCd() {
		return fromMainglCd;
	}
	public void setFromMainglCd(String fromMainglCd) {
		this.fromMainglCd = fromMainglCd;
	}
	public String getFromSubglCd() {
		return fromSubglCd;
	}
	public void setFromSubglCd(String fromSubglCd) {
		this.fromSubglCd = fromSubglCd;
	}
	public String getToMainglCd() {
		return toMainglCd;
	}
	public void setToMainglCd(String toMainglCd) {
		this.toMainglCd = toMainglCd;
	}
	public String getToSubglCd() {
		return toSubglCd;
	}
	public void setToSubglCd(String toSubglCd) {
		this.toSubglCd = toSubglCd;
	}
	public LocalDate getFromDt() {
		return fromDt;
	}
	public void setFromDt(LocalDate fromDt) {
		this.fromDt = fromDt;
	}
	public LocalDate getToDt() {
		return toDt;
	}
	public void setToDt(LocalDate toDt) {
		this.toDt = toDt;
	}
	@Override
	public String toString() {
		return "GLRangeStmtIn [logicallocCd=" + logicallocCd + ", fromMainglCd=" + fromMainglCd + ", fromSubglCd="
				+ fromSubglCd + ", toMainglCd=" + toMainglCd + ", toSubglCd=" + toSubglCd + ", fromDt=" + fromDt
				+ ", toDt=" + toDt + "]";
	}
}
