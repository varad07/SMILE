package in.ecgc.smile.erp.reporting.jasper.be.model.accounts;

public class Schedule13 {
	
	private String createdBy;

	private String scheduleItem13dot1Name;
	private String scheduleItem13dot1Amt;
	private String scheduleItem13dot1PreAmt;
	
	private String scheduleItem13dot2Name;
	private String scheduleItem13dot2Amt;
	private String scheduleItem13dot2PreAmt;
	
	private String scheduleItem13dot3Name;
	private String scheduleItem13dot3Amt;
	private String scheduleItem13dot3PreAmt;
	
	private String scheduleItem13dot4Name;
	private String scheduleItem13dot4Amt;
	private String scheduleItem13dot4PreAmt;
	
	private String scheduleItem13dot5Name;
	private String scheduleItem13dot5Amt;
	private String scheduleItem13dot5PreAmt;
	
	private String scheduleItem13dot6Name;
	private String scheduleItem13dot6Amt;
	private String scheduleItem13dot6PreAmt;
	
	private String scheduleItem13dot7Name;
	private String scheduleItem13dot7Amt;
	private String scheduleItem13dot7PreAmt;
	
	private String sumScheduleItem13dot6and7Amt;
	private String sumScheduleItem13dot6and7PreAmt;
	
	private String scheduleItem13dot8Name;
	private String scheduleItem13dot8Amt;
	private String scheduleItem13dot8PreAmt;
	
	private String scheduleItem13dot9Name;
	private String scheduleItem13dot9Amt;
	private String scheduleItem13dot9PreAmt;
	
	private String scheduleItem13dot10Name;
	private String scheduleItem13dot10Amt;
	private String scheduleItem13dot10PreAmt;
	
	private String scheduleItem13dot11Name;
	private String scheduleItem13dot11Amt;
	private String scheduleItem13dot11PreAmt;
	
	private String scheduleItem13dot12Name;
	
	private String scheduleItem13dot13Name;
	private String scheduleItem13dot13Amt;
	private String scheduleItem13dot13PreAmt;
	
	private String scheduleItem13dot14Name;
	private String scheduleItem13dot14Amt;
	private String scheduleItem13dot14PreAmt;
	
	private String scheduleItem13dot15Name;
	private String scheduleItem13dot15Amt;
	private String scheduleItem13dot15PreAmt;
	
	private String scheduleItem13dot16Name;
	private String scheduleItem13dot16Amt;
	private String scheduleItem13dot16PreAmt;
	
	private String finalSchedule13Name;
	private String finalSchedule13Amt;
	private String finalSchedule13PreAmt;
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getScheduleItem13dot1Name() {
		return scheduleItem13dot1Name;
	}
	public void setScheduleItem13dot1Name(String scheduleItem13dot1Name) {
		this.scheduleItem13dot1Name = scheduleItem13dot1Name;
	}
	public String getScheduleItem13dot1Amt() {
		return scheduleItem13dot1Amt;
	}
	public void setScheduleItem13dot1Amt(String scheduleItem13dot1Amt) {
		this.scheduleItem13dot1Amt = scheduleItem13dot1Amt;
	}
	public String getScheduleItem13dot1PreAmt() {
		return scheduleItem13dot1PreAmt;
	}
	public void setScheduleItem13dot1PreAmt(String scheduleItem13dot1PreAmt) {
		this.scheduleItem13dot1PreAmt = scheduleItem13dot1PreAmt;
	}
	public String getScheduleItem13dot2Name() {
		return scheduleItem13dot2Name;
	}
	public void setScheduleItem13dot2Name(String scheduleItem13dot2Name) {
		this.scheduleItem13dot2Name = scheduleItem13dot2Name;
	}
	public String getScheduleItem13dot2Amt() {
		return scheduleItem13dot2Amt;
	}
	public void setScheduleItem13dot2Amt(String scheduleItem13dot2Amt) {
		this.scheduleItem13dot2Amt = scheduleItem13dot2Amt;
	}
	public String getScheduleItem13dot2PreAmt() {
		return scheduleItem13dot2PreAmt;
	}
	public void setScheduleItem13dot2PreAmt(String scheduleItem13dot2PreAmt) {
		this.scheduleItem13dot2PreAmt = scheduleItem13dot2PreAmt;
	}
	public String getScheduleItem13dot3Name() {
		return scheduleItem13dot3Name;
	}
	public void setScheduleItem13dot3Name(String scheduleItem13dot3Name) {
		this.scheduleItem13dot3Name = scheduleItem13dot3Name;
	}
	public String getScheduleItem13dot3Amt() {
		return scheduleItem13dot3Amt;
	}
	public void setScheduleItem13dot3Amt(String scheduleItem13dot3Amt) {
		this.scheduleItem13dot3Amt = scheduleItem13dot3Amt;
	}
	public String getScheduleItem13dot3PreAmt() {
		return scheduleItem13dot3PreAmt;
	}
	public void setScheduleItem13dot3PreAmt(String scheduleItem13dot3PreAmt) {
		this.scheduleItem13dot3PreAmt = scheduleItem13dot3PreAmt;
	}
	public String getScheduleItem13dot4Name() {
		return scheduleItem13dot4Name;
	}
	public void setScheduleItem13dot4Name(String scheduleItem13dot4Name) {
		this.scheduleItem13dot4Name = scheduleItem13dot4Name;
	}
	public String getScheduleItem13dot4Amt() {
		return scheduleItem13dot4Amt;
	}
	public void setScheduleItem13dot4Amt(String scheduleItem13dot4Amt) {
		this.scheduleItem13dot4Amt = scheduleItem13dot4Amt;
	}
	public String getScheduleItem13dot4PreAmt() {
		return scheduleItem13dot4PreAmt;
	}
	public void setScheduleItem13dot4PreAmt(String scheduleItem13dot4PreAmt) {
		this.scheduleItem13dot4PreAmt = scheduleItem13dot4PreAmt;
	}
	public String getScheduleItem13dot5Name() {
		return scheduleItem13dot5Name;
	}
	public void setScheduleItem13dot5Name(String scheduleItem13dot5Name) {
		this.scheduleItem13dot5Name = scheduleItem13dot5Name;
	}
	public String getScheduleItem13dot5Amt() {
		return scheduleItem13dot5Amt;
	}
	public void setScheduleItem13dot5Amt(String scheduleItem13dot5Amt) {
		this.scheduleItem13dot5Amt = scheduleItem13dot5Amt;
	}
	public String getScheduleItem13dot5PreAmt() {
		return scheduleItem13dot5PreAmt;
	}
	public void setScheduleItem13dot5PreAmt(String scheduleItem13dot5PreAmt) {
		this.scheduleItem13dot5PreAmt = scheduleItem13dot5PreAmt;
	}
	public String getScheduleItem13dot6Name() {
		return scheduleItem13dot6Name;
	}
	public void setScheduleItem13dot6Name(String scheduleItem13dot6Name) {
		this.scheduleItem13dot6Name = scheduleItem13dot6Name;
	}
	public String getScheduleItem13dot6Amt() {
		return scheduleItem13dot6Amt;
	}
	public void setScheduleItem13dot6Amt(String scheduleItem13dot6Amt) {
		this.scheduleItem13dot6Amt = scheduleItem13dot6Amt;
	}
	public String getScheduleItem13dot6PreAmt() {
		return scheduleItem13dot6PreAmt;
	}
	public void setScheduleItem13dot6PreAmt(String scheduleItem13dot6PreAmt) {
		this.scheduleItem13dot6PreAmt = scheduleItem13dot6PreAmt;
	}
	public String getScheduleItem13dot7Name() {
		return scheduleItem13dot7Name;
	}
	public void setScheduleItem13dot7Name(String scheduleItem13dot7Name) {
		this.scheduleItem13dot7Name = scheduleItem13dot7Name;
	}
	public String getScheduleItem13dot7Amt() {
		return scheduleItem13dot7Amt;
	}
	public void setScheduleItem13dot7Amt(String scheduleItem13dot7Amt) {
		this.scheduleItem13dot7Amt = scheduleItem13dot7Amt;
	}
	public String getScheduleItem13dot7PreAmt() {
		return scheduleItem13dot7PreAmt;
	}
	public void setScheduleItem13dot7PreAmt(String scheduleItem13dot7PreAmt) {
		this.scheduleItem13dot7PreAmt = scheduleItem13dot7PreAmt;
	}
	public String getSumScheduleItem13dot6and7Amt() {
		return sumScheduleItem13dot6and7Amt;
	}
	public void setSumScheduleItem13dot6and7Amt(String sumScheduleItem13dot6and7Amt) {
		this.sumScheduleItem13dot6and7Amt = sumScheduleItem13dot6and7Amt;
	}
	public String getSumScheduleItem13dot6and7PreAmt() {
		return sumScheduleItem13dot6and7PreAmt;
	}
	public void setSumScheduleItem13dot6and7PreAmt(String sumScheduleItem13dot6and7PreAmt) {
		this.sumScheduleItem13dot6and7PreAmt = sumScheduleItem13dot6and7PreAmt;
	}
	public String getScheduleItem13dot8Name() {
		return scheduleItem13dot8Name;
	}
	public void setScheduleItem13dot8Name(String scheduleItem13dot8Name) {
		this.scheduleItem13dot8Name = scheduleItem13dot8Name;
	}
	public String getScheduleItem13dot8Amt() {
		return scheduleItem13dot8Amt;
	}
	public void setScheduleItem13dot8Amt(String scheduleItem13dot8Amt) {
		this.scheduleItem13dot8Amt = scheduleItem13dot8Amt;
	}
	public String getScheduleItem13dot8PreAmt() {
		return scheduleItem13dot8PreAmt;
	}
	public void setScheduleItem13dot8PreAmt(String scheduleItem13dot8PreAmt) {
		this.scheduleItem13dot8PreAmt = scheduleItem13dot8PreAmt;
	}
	public String getScheduleItem13dot9Name() {
		return scheduleItem13dot9Name;
	}
	public void setScheduleItem13dot9Name(String scheduleItem13dot9Name) {
		this.scheduleItem13dot9Name = scheduleItem13dot9Name;
	}
	public String getScheduleItem13dot9Amt() {
		return scheduleItem13dot9Amt;
	}
	public void setScheduleItem13dot9Amt(String scheduleItem13dot9Amt) {
		this.scheduleItem13dot9Amt = scheduleItem13dot9Amt;
	}
	public String getScheduleItem13dot9PreAmt() {
		return scheduleItem13dot9PreAmt;
	}
	public void setScheduleItem13dot9PreAmt(String scheduleItem13dot9PreAmt) {
		this.scheduleItem13dot9PreAmt = scheduleItem13dot9PreAmt;
	}
	public String getScheduleItem13dot10Name() {
		return scheduleItem13dot10Name;
	}
	public void setScheduleItem13dot10Name(String scheduleItem13dot10Name) {
		this.scheduleItem13dot10Name = scheduleItem13dot10Name;
	}
	public String getScheduleItem13dot10Amt() {
		return scheduleItem13dot10Amt;
	}
	public void setScheduleItem13dot10Amt(String scheduleItem13dot10Amt) {
		this.scheduleItem13dot10Amt = scheduleItem13dot10Amt;
	}
	public String getScheduleItem13dot10PreAmt() {
		return scheduleItem13dot10PreAmt;
	}
	public void setScheduleItem13dot10PreAmt(String scheduleItem13dot10PreAmt) {
		this.scheduleItem13dot10PreAmt = scheduleItem13dot10PreAmt;
	}
	public String getScheduleItem13dot11Name() {
		return scheduleItem13dot11Name;
	}
	public void setScheduleItem13dot11Name(String scheduleItem13dot11Name) {
		this.scheduleItem13dot11Name = scheduleItem13dot11Name;
	}
	public String getScheduleItem13dot11Amt() {
		return scheduleItem13dot11Amt;
	}
	public void setScheduleItem13dot11Amt(String scheduleItem13dot11Amt) {
		this.scheduleItem13dot11Amt = scheduleItem13dot11Amt;
	}
	public String getScheduleItem13dot11PreAmt() {
		return scheduleItem13dot11PreAmt;
	}
	public void setScheduleItem13dot11PreAmt(String scheduleItem13dot11PreAmt) {
		this.scheduleItem13dot11PreAmt = scheduleItem13dot11PreAmt;
	}
	public String getScheduleItem13dot12Name() {
		return scheduleItem13dot12Name;
	}
	public void setScheduleItem13dot12Name(String scheduleItem13dot12Name) {
		this.scheduleItem13dot12Name = scheduleItem13dot12Name;
	}
	public String getScheduleItem13dot13Name() {
		return scheduleItem13dot13Name;
	}
	public void setScheduleItem13dot13Name(String scheduleItem13dot13Name) {
		this.scheduleItem13dot13Name = scheduleItem13dot13Name;
	}
	public String getScheduleItem13dot13Amt() {
		return scheduleItem13dot13Amt;
	}
	public void setScheduleItem13dot13Amt(String scheduleItem13dot13Amt) {
		this.scheduleItem13dot13Amt = scheduleItem13dot13Amt;
	}
	public String getScheduleItem13dot13PreAmt() {
		return scheduleItem13dot13PreAmt;
	}
	public void setScheduleItem13dot13PreAmt(String scheduleItem13dot13PreAmt) {
		this.scheduleItem13dot13PreAmt = scheduleItem13dot13PreAmt;
	}
	public String getScheduleItem13dot14Name() {
		return scheduleItem13dot14Name;
	}
	public void setScheduleItem13dot14Name(String scheduleItem13dot14Name) {
		this.scheduleItem13dot14Name = scheduleItem13dot14Name;
	}
	public String getScheduleItem13dot14Amt() {
		return scheduleItem13dot14Amt;
	}
	public void setScheduleItem13dot14Amt(String scheduleItem13dot14Amt) {
		this.scheduleItem13dot14Amt = scheduleItem13dot14Amt;
	}
	public String getScheduleItem13dot14PreAmt() {
		return scheduleItem13dot14PreAmt;
	}
	public void setScheduleItem13dot14PreAmt(String scheduleItem13dot14PreAmt) {
		this.scheduleItem13dot14PreAmt = scheduleItem13dot14PreAmt;
	}
	public String getScheduleItem13dot15Name() {
		return scheduleItem13dot15Name;
	}
	public void setScheduleItem13dot15Name(String scheduleItem13dot15Name) {
		this.scheduleItem13dot15Name = scheduleItem13dot15Name;
	}
	public String getScheduleItem13dot15Amt() {
		return scheduleItem13dot15Amt;
	}
	public void setScheduleItem13dot15Amt(String scheduleItem13dot15Amt) {
		this.scheduleItem13dot15Amt = scheduleItem13dot15Amt;
	}
	public String getScheduleItem13dot15PreAmt() {
		return scheduleItem13dot15PreAmt;
	}
	public void setScheduleItem13dot15PreAmt(String scheduleItem13dot15PreAmt) {
		this.scheduleItem13dot15PreAmt = scheduleItem13dot15PreAmt;
	}
	public String getScheduleItem13dot16Name() {
		return scheduleItem13dot16Name;
	}
	public void setScheduleItem13dot16Name(String scheduleItem13dot16Name) {
		this.scheduleItem13dot16Name = scheduleItem13dot16Name;
	}
	public String getScheduleItem13dot16Amt() {
		return scheduleItem13dot16Amt;
	}
	public void setScheduleItem13dot16Amt(String scheduleItem13dot16Amt) {
		this.scheduleItem13dot16Amt = scheduleItem13dot16Amt;
	}
	public String getScheduleItem13dot16PreAmt() {
		return scheduleItem13dot16PreAmt;
	}
	public void setScheduleItem13dot16PreAmt(String scheduleItem13dot16PreAmt) {
		this.scheduleItem13dot16PreAmt = scheduleItem13dot16PreAmt;
	}
	public String getFinalSchedule13Name() {
		return finalSchedule13Name;
	}
	public void setFinalSchedule13Name(String finalSchedule13Name) {
		this.finalSchedule13Name = finalSchedule13Name;
	}
	public String getFinalSchedule13Amt() {
		return finalSchedule13Amt;
	}
	public void setFinalSchedule13Amt(String finalSchedule13Amt) {
		this.finalSchedule13Amt = finalSchedule13Amt;
	}
	public String getFinalSchedule13PreAmt() {
		return finalSchedule13PreAmt;
	}
	public void setFinalSchedule13PreAmt(String finalSchedule13PreAmt) {
		this.finalSchedule13PreAmt = finalSchedule13PreAmt;
	}
	
	
	
}
