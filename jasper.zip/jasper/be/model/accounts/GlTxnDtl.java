package in.ecgc.smile.erp.reporting.jasper.be.model.accounts;

import java.math.BigDecimal;
import java.time.LocalDate;

import javax.validation.constraints.NotBlank;

import org.springframework.format.annotation.DateTimeFormat;

public class GlTxnDtl {

	private Integer glTxnNo;
	@NotBlank(message = "Required For Transaction")
	private Integer srNo;
	@NotBlank(message = "Required For Transaction")
	private String drCrFlag;
	@NotBlank(message = "Required For Transaction")
	private BigDecimal txnAmt;
	private String oldCode;
	private String codeType;
	private String entityGlCd;
	@NotBlank(message = "Required For Transaction")
	private String mainGlCd;
	@NotBlank(message = "Required For Transaction")
	private String subGlCd;
	@NotBlank(message = "GL Txn Type is Required For Transaction")
	private String glTxnType;
	private String LogicalLocCd;
	private String plCd;
	private String subBiFurcationCd;
	private String remarks;
	private String t1;
	private String t2;
	private String t3;
	private String t4;
	private String t5;
	private String t6;
	private String t7;
	private String t8;
	private String t9;
	private String t10;
	private String t11;
	private String t12;
	private String t13;
	private String t14;
	private String t15;
	private String t16;
	private String t17;
	private String t18;
	private String t19;
	private String t20;
	private String t21;
	private String t22;
	private String t23;
	private String t24;
	private String t25;
	private String t26;
	private String t27;
	private String t28;
	private String t29;
	private String t30;
	private String t31;
	private String t32;
	private String t33;
	private String t34;
	private String t35;
	private String t36;

	private LocalDate ad1;
	private LocalDate ad2;
	private LocalDate ad3;
	private LocalDate ad4;
	private String metaStatus;
	private String metaRemarks;
	private String createdBy;
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate createdDt;
	private String lastUpdatedBy;
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate lastUpdatedDt;

	public void setSubBiFurcationCd(String subBiFurcationCd) {
		if (subBiFurcationCd != null)
			this.subBiFurcationCd = subBiFurcationCd.trim();
		else
			this.subBiFurcationCd = subBiFurcationCd;
	}

	public void setPlCd(String plCd) {
		if (plCd != null)
			this.plCd = plCd.trim();
		else
			this.plCd = plCd;
	}

	public Integer getGlTxnNo() {
		return glTxnNo;
	}

	public void setGlTxnNo(Integer glTxnNo) {
		this.glTxnNo = glTxnNo;
	}

	public Integer getSrNo() {
		return srNo;
	}

	public void setSrNo(Integer srNo) {
		this.srNo = srNo;
	}

	public String getDrCrFlag() {
		return drCrFlag;
	}

	public void setDrCrFlag(String drCrFlag) {
		this.drCrFlag = drCrFlag;
	}

	public BigDecimal getTxnAmt() {
		return txnAmt;
	}

	public void setTxnAmt(BigDecimal txnAmt) {
		this.txnAmt = txnAmt;
	}

	public String getOldCode() {
		return oldCode;
	}

	public void setOldCode(String oldCode) {
		this.oldCode = oldCode;
	}

	public String getCodeType() {
		return codeType;
	}

	public void setCodeType(String codeType) {
		this.codeType = codeType;
	}

	public String getEntityGlCd() {
		return entityGlCd;
	}

	public void setEntityGlCd(String entityGlCd) {
		this.entityGlCd = entityGlCd;
	}

	public String getMainGlCd() {
		return mainGlCd;
	}

	public void setMainGlCd(String mainGlCd) {
		this.mainGlCd = mainGlCd;
	}

	public String getSubGlCd() {
		return subGlCd;
	}

	public void setSubGlCd(String subGlCd) {
		this.subGlCd = subGlCd;
	}

	public String getGlTxnType() {
		return glTxnType;
	}

	public void setGlTxnType(String glTxnType) {
		this.glTxnType = glTxnType;
	}

	public String getLogicalLocCd() {
		return LogicalLocCd;
	}

	public void setLogicalLocCd(String logicalLocCd) {
		LogicalLocCd = logicalLocCd;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getT1() {
		return t1;
	}

	public void setT1(String t1) {
		this.t1 = t1;
	}

	public String getT2() {
		return t2;
	}

	public void setT2(String t2) {
		this.t2 = t2;
	}

	public String getT3() {
		return t3;
	}

	public void setT3(String t3) {
		this.t3 = t3;
	}

	public String getT4() {
		return t4;
	}

	public void setT4(String t4) {
		this.t4 = t4;
	}

	public String getT5() {
		return t5;
	}

	public void setT5(String t5) {
		this.t5 = t5;
	}

	public String getT6() {
		return t6;
	}

	public void setT6(String t6) {
		this.t6 = t6;
	}

	public String getT7() {
		return t7;
	}

	public void setT7(String t7) {
		this.t7 = t7;
	}

	public String getT8() {
		return t8;
	}

	public void setT8(String t8) {
		this.t8 = t8;
	}

	public String getT9() {
		return t9;
	}

	public void setT9(String t9) {
		this.t9 = t9;
	}

	public String getT10() {
		return t10;
	}

	public void setT10(String t10) {
		this.t10 = t10;
	}

	public String getT11() {
		return t11;
	}

	public void setT11(String t11) {
		this.t11 = t11;
	}

	public String getT12() {
		return t12;
	}

	public void setT12(String t12) {
		this.t12 = t12;
	}

	public String getT13() {
		return t13;
	}

	public void setT13(String t13) {
		this.t13 = t13;
	}

	public String getT14() {
		return t14;
	}

	public void setT14(String t14) {
		this.t14 = t14;
	}

	public String getT15() {
		return t15;
	}

	public void setT15(String t15) {
		this.t15 = t15;
	}

	public String getT16() {
		return t16;
	}

	public void setT16(String t16) {
		this.t16 = t16;
	}

	public String getT17() {
		return t17;
	}

	public void setT17(String t17) {
		this.t17 = t17;
	}

	public String getT18() {
		return t18;
	}

	public void setT18(String t18) {
		this.t18 = t18;
	}

	public String getT19() {
		return t19;
	}

	public void setT19(String t19) {
		this.t19 = t19;
	}

	public String getT20() {
		return t20;
	}

	public void setT20(String t20) {
		this.t20 = t20;
	}

	public String getT21() {
		return t21;
	}

	public void setT21(String t21) {
		this.t21 = t21;
	}

	public String getT22() {
		return t22;
	}

	public void setT22(String t22) {
		this.t22 = t22;
	}

	public String getT23() {
		return t23;
	}

	public void setT23(String t23) {
		this.t23 = t23;
	}

	public String getT24() {
		return t24;
	}

	public void setT24(String t24) {
		this.t24 = t24;
	}

	public String getT25() {
		return t25;
	}

	public void setT25(String t25) {
		this.t25 = t25;
	}

	public String getT26() {
		return t26;
	}

	public void setT26(String t26) {
		this.t26 = t26;
	}

	public String getT27() {
		return t27;
	}

	public void setT27(String t27) {
		this.t27 = t27;
	}

	public String getT28() {
		return t28;
	}

	public void setT28(String t28) {
		this.t28 = t28;
	}

	public String getT29() {
		return t29;
	}

	public void setT29(String t29) {
		this.t29 = t29;
	}

	public String getT30() {
		return t30;
	}

	public void setT30(String t30) {
		this.t30 = t30;
	}

	public String getT31() {
		return t31;
	}

	public void setT31(String t31) {
		this.t31 = t31;
	}

	public String getT32() {
		return t32;
	}

	public void setT32(String t32) {
		this.t32 = t32;
	}

	public String getT33() {
		return t33;
	}

	public void setT33(String t33) {
		this.t33 = t33;
	}

	public String getT34() {
		return t34;
	}

	public void setT34(String t34) {
		this.t34 = t34;
	}

	public String getT35() {
		return t35;
	}

	public void setT35(String t35) {
		this.t35 = t35;
	}

	public String getT36() {
		return t36;
	}

	public void setT36(String t36) {
		this.t36 = t36;
	}

	public LocalDate getAd1() {
		return ad1;
	}

	public void setAd1(LocalDate ad1) {
		this.ad1 = ad1;
	}

	public LocalDate getAd2() {
		return ad2;
	}

	public void setAd2(LocalDate ad2) {
		this.ad2 = ad2;
	}

	public LocalDate getAd3() {
		return ad3;
	}

	public void setAd3(LocalDate ad3) {
		this.ad3 = ad3;
	}

	public LocalDate getAd4() {
		return ad4;
	}

	public void setAd4(LocalDate ad4) {
		this.ad4 = ad4;
	}

	public String getMetaStatus() {
		return metaStatus;
	}

	public void setMetaStatus(String metaStatus) {
		this.metaStatus = metaStatus;
	}

	public String getMetaRemarks() {
		return metaRemarks;
	}

	public void setMetaRemarks(String metaRemarks) {
		this.metaRemarks = metaRemarks;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public LocalDate getCreatedDt() {
		return createdDt;
	}

	public void setCreatedDt(LocalDate createdDt) {
		this.createdDt = createdDt;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public LocalDate getLastUpdatedDt() {
		return lastUpdatedDt;
	}

	public void setLastUpdatedDt(LocalDate lastUpdatedDt) {
		this.lastUpdatedDt = lastUpdatedDt;
	}

	public String getPlCd() {
		return plCd;
	}

	public String getSubBiFurcationCd() {
		return subBiFurcationCd;
	}

	@Override
	public String toString() {
		return "GlTxnDtl [glTxnNo=" + glTxnNo + ", srNo=" + srNo + ", drCrFlag=" + drCrFlag + ", txnAmt=" + txnAmt
				+ ", oldCode=" + oldCode + ", codeType=" + codeType + ", entityGlCd=" + entityGlCd + ", mainGlCd="
				+ mainGlCd + ", subGlCd=" + subGlCd + ", glTxnType=" + glTxnType + ", LogicalLocCd=" + LogicalLocCd
				+ ", plCd=" + plCd + ", subBiFurcationCd=" + subBiFurcationCd + ", remarks=" + remarks + ", t1=" + t1
				+ ", t2=" + t2 + ", t3=" + t3 + ", t4=" + t4 + ", t5=" + t5 + ", t6=" + t6 + ", t7=" + t7 + ", t8=" + t8
				+ ", t9=" + t9 + ", t10=" + t10 + ", t11=" + t11 + ", t12=" + t12 + ", t13=" + t13 + ", t14=" + t14
				+ ", t15=" + t15 + ", t16=" + t16 + ", t17=" + t17 + ", t18=" + t18 + ", t19=" + t19 + ", t20=" + t20
				+ ", t21=" + t21 + ", t22=" + t22 + ", t23=" + t23 + ", t24=" + t24 + ", t25=" + t25 + ", t26=" + t26
				+ ", t27=" + t27 + ", t28=" + t28 + ", t29=" + t29 + ", t30=" + t30 + ", t31=" + t31 + ", t32=" + t32
				+ ", t33=" + t33 + ", t34=" + t34 + ", t35=" + t35 + ", t36=" + t36 + ", ad1=" + ad1 + ", ad2=" + ad2
				+ ", ad3=" + ad3 + ", ad4=" + ad4 + ", metaStatus=" + metaStatus + ", metaRemarks=" + metaRemarks
				+ ", createdBy=" + createdBy + ", createdDt=" + createdDt + ", lastUpdatedBy=" + lastUpdatedBy
				+ ", lastUpdatedDt=" + lastUpdatedDt + "]";
	}

}
