package in.ecgc.smile.erp.reporting.jasper.be.model.accounts;

public class Schedule9 {
	
	private String createdBy;

	private String scheduleItem9dot1Name;
	private String scheduleItem9dot2Name;
	private String scheduleItem9dot3Name;
	
	
	private String scheduleItem9dot4Name;
	private String scheduleItem9dot4Amt;
	private String scheduleItem9dot4PreAmt;
	
	private String scheduleItem9dot5Name;
	private String scheduleItem9dot5Amt;
	private String scheduleItem9dot5PreAmt;
	
	private String scheduleItem9dot6Name;
	private String scheduleItem9dot6Amt;
	private String scheduleItem9dot6PreAmt;
	
	private String scheduleItem9dot7Amt;
	private String scheduleItem9dot7PreAmt;
	
	private String scheduleItem9dot8Name;
	private String scheduleItem9dot8Amt;
	private String scheduleItem9dot8PreAmt;
	
	private String scheduleItem9dot9Name;
	private String scheduleItem9dot9Amt;
	private String scheduleItem9dot9PreAmt;
	
	private String scheduleItem9dot10Name;
	private String scheduleItem9dot10Amt;
	private String scheduleItem9dot10PreAmt;
	
	private String scheduleItem9dot11Name;
	
	private String scheduleItem9dot12Name;
	private String scheduleItem9dot12Amt;
	private String scheduleItem9dot12PreAmt;
	
	private String scheduleItem9dot13Name;
	private String scheduleItem9dot13Amt;
	private String scheduleItem9dot13PreAmt;
	
	private String scheduleItem9dot14Name;
	private String scheduleItem9dot14Amt;
	private String scheduleItem9dot14PreAmt;

	private String scheduleItem9dot15Name;
	private String scheduleItem9dot15Amt;
	private String scheduleItem9dot15PreAmt;
	
	private String scheduleItem9dot16Name;
	private String scheduleItem9dot16Amt;
	private String scheduleItem9dot16PreAmt;
	
	private String scheduleItem9dot17Name;
	
	private String scheduleItem9dot18Name;
	
	private String scheduleItem9dot19Name;
	private String scheduleItem9dot19Amt;
	private String scheduleItem9dot19PreAmt;

	
	private String scheduleItem9dot20Name;
	private String scheduleItem9dot20Amt;
	private String scheduleItem9dot20PreAmt;
	
	private String scheduleItem9dot21Name;
	
	private String scheduleItem9dot22Name;
	private String scheduleItem9dot22Amt;
	private String scheduleItem9dot22PreAmt;
	
	private String scheduleItem9dot23Name;
	private String scheduleItem9dot23Amt;
	private String scheduleItem9dot23PreAmt;
	
	private String scheduleItem9dot24Name;
	
	private String scheduleItem9dot25Name;
	private String scheduleItem9dot25Amt;
	private String scheduleItem9dot25PreAmt;
	
	private String scheduleItem9dot26Name;
	private String scheduleItem9dot26Amt;
	private String scheduleItem9dot26PreAmt;
	
	
	private String scheduleItem9dot27Amt;
	private String scheduleItem9dot27PreAmt;
	
	
	private String finalSchedule9Name;
	private String finalSchedule9Amt;
	private String finalSchedule9PreAmt;
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getScheduleItem9dot1Name() {
		return scheduleItem9dot1Name;
	}
	public void setScheduleItem9dot1Name(String scheduleItem9dot1Name) {
		this.scheduleItem9dot1Name = scheduleItem9dot1Name;
	}
	public String getScheduleItem9dot2Name() {
		return scheduleItem9dot2Name;
	}
	public void setScheduleItem9dot2Name(String scheduleItem9dot2Name) {
		this.scheduleItem9dot2Name = scheduleItem9dot2Name;
	}
	public String getScheduleItem9dot3Name() {
		return scheduleItem9dot3Name;
	}
	public void setScheduleItem9dot3Name(String scheduleItem9dot3Name) {
		this.scheduleItem9dot3Name = scheduleItem9dot3Name;
	}
	public String getScheduleItem9dot4Name() {
		return scheduleItem9dot4Name;
	}
	public void setScheduleItem9dot4Name(String scheduleItem9dot4Name) {
		this.scheduleItem9dot4Name = scheduleItem9dot4Name;
	}
	public String getScheduleItem9dot4Amt() {
		return scheduleItem9dot4Amt;
	}
	public void setScheduleItem9dot4Amt(String scheduleItem9dot4Amt) {
		this.scheduleItem9dot4Amt = scheduleItem9dot4Amt;
	}
	public String getScheduleItem9dot4PreAmt() {
		return scheduleItem9dot4PreAmt;
	}
	public void setScheduleItem9dot4PreAmt(String scheduleItem9dot4PreAmt) {
		this.scheduleItem9dot4PreAmt = scheduleItem9dot4PreAmt;
	}
	public String getScheduleItem9dot5Name() {
		return scheduleItem9dot5Name;
	}
	public void setScheduleItem9dot5Name(String scheduleItem9dot5Name) {
		this.scheduleItem9dot5Name = scheduleItem9dot5Name;
	}
	public String getScheduleItem9dot5Amt() {
		return scheduleItem9dot5Amt;
	}
	public void setScheduleItem9dot5Amt(String scheduleItem9dot5Amt) {
		this.scheduleItem9dot5Amt = scheduleItem9dot5Amt;
	}
	public String getScheduleItem9dot5PreAmt() {
		return scheduleItem9dot5PreAmt;
	}
	public void setScheduleItem9dot5PreAmt(String scheduleItem9dot5PreAmt) {
		this.scheduleItem9dot5PreAmt = scheduleItem9dot5PreAmt;
	}
	public String getScheduleItem9dot6Name() {
		return scheduleItem9dot6Name;
	}
	public void setScheduleItem9dot6Name(String scheduleItem9dot6Name) {
		this.scheduleItem9dot6Name = scheduleItem9dot6Name;
	}
	public String getScheduleItem9dot6Amt() {
		return scheduleItem9dot6Amt;
	}
	public void setScheduleItem9dot6Amt(String scheduleItem9dot6Amt) {
		this.scheduleItem9dot6Amt = scheduleItem9dot6Amt;
	}
	public String getScheduleItem9dot6PreAmt() {
		return scheduleItem9dot6PreAmt;
	}
	public void setScheduleItem9dot6PreAmt(String scheduleItem9dot6PreAmt) {
		this.scheduleItem9dot6PreAmt = scheduleItem9dot6PreAmt;
	}
	public String getScheduleItem9dot7Amt() {
		return scheduleItem9dot7Amt;
	}
	public void setScheduleItem9dot7Amt(String scheduleItem9dot7Amt) {
		this.scheduleItem9dot7Amt = scheduleItem9dot7Amt;
	}
	public String getScheduleItem9dot7PreAmt() {
		return scheduleItem9dot7PreAmt;
	}
	public void setScheduleItem9dot7PreAmt(String scheduleItem9dot7PreAmt) {
		this.scheduleItem9dot7PreAmt = scheduleItem9dot7PreAmt;
	}
	public String getScheduleItem9dot8Name() {
		return scheduleItem9dot8Name;
	}
	public void setScheduleItem9dot8Name(String scheduleItem9dot8Name) {
		this.scheduleItem9dot8Name = scheduleItem9dot8Name;
	}
	public String getScheduleItem9dot8Amt() {
		return scheduleItem9dot8Amt;
	}
	public void setScheduleItem9dot8Amt(String scheduleItem9dot8Amt) {
		this.scheduleItem9dot8Amt = scheduleItem9dot8Amt;
	}
	public String getScheduleItem9dot8PreAmt() {
		return scheduleItem9dot8PreAmt;
	}
	public void setScheduleItem9dot8PreAmt(String scheduleItem9dot8PreAmt) {
		this.scheduleItem9dot8PreAmt = scheduleItem9dot8PreAmt;
	}
	public String getScheduleItem9dot9Name() {
		return scheduleItem9dot9Name;
	}
	public void setScheduleItem9dot9Name(String scheduleItem9dot9Name) {
		this.scheduleItem9dot9Name = scheduleItem9dot9Name;
	}
	public String getScheduleItem9dot9Amt() {
		return scheduleItem9dot9Amt;
	}
	public void setScheduleItem9dot9Amt(String scheduleItem9dot9Amt) {
		this.scheduleItem9dot9Amt = scheduleItem9dot9Amt;
	}
	public String getScheduleItem9dot9PreAmt() {
		return scheduleItem9dot9PreAmt;
	}
	public void setScheduleItem9dot9PreAmt(String scheduleItem9dot9PreAmt) {
		this.scheduleItem9dot9PreAmt = scheduleItem9dot9PreAmt;
	}
	public String getScheduleItem9dot10Name() {
		return scheduleItem9dot10Name;
	}
	public void setScheduleItem9dot10Name(String scheduleItem9dot10Name) {
		this.scheduleItem9dot10Name = scheduleItem9dot10Name;
	}
	public String getScheduleItem9dot10Amt() {
		return scheduleItem9dot10Amt;
	}
	public void setScheduleItem9dot10Amt(String scheduleItem9dot10Amt) {
		this.scheduleItem9dot10Amt = scheduleItem9dot10Amt;
	}
	public String getScheduleItem9dot10PreAmt() {
		return scheduleItem9dot10PreAmt;
	}
	public void setScheduleItem9dot10PreAmt(String scheduleItem9dot10PreAmt) {
		this.scheduleItem9dot10PreAmt = scheduleItem9dot10PreAmt;
	}
	public String getScheduleItem9dot11Name() {
		return scheduleItem9dot11Name;
	}
	public void setScheduleItem9dot11Name(String scheduleItem9dot11Name) {
		this.scheduleItem9dot11Name = scheduleItem9dot11Name;
	}
	public String getScheduleItem9dot12Name() {
		return scheduleItem9dot12Name;
	}
	public void setScheduleItem9dot12Name(String scheduleItem9dot12Name) {
		this.scheduleItem9dot12Name = scheduleItem9dot12Name;
	}
	public String getScheduleItem9dot12Amt() {
		return scheduleItem9dot12Amt;
	}
	public void setScheduleItem9dot12Amt(String scheduleItem9dot12Amt) {
		this.scheduleItem9dot12Amt = scheduleItem9dot12Amt;
	}
	public String getScheduleItem9dot12PreAmt() {
		return scheduleItem9dot12PreAmt;
	}
	public void setScheduleItem9dot12PreAmt(String scheduleItem9dot12PreAmt) {
		this.scheduleItem9dot12PreAmt = scheduleItem9dot12PreAmt;
	}
	public String getScheduleItem9dot13Name() {
		return scheduleItem9dot13Name;
	}
	public void setScheduleItem9dot13Name(String scheduleItem9dot13Name) {
		this.scheduleItem9dot13Name = scheduleItem9dot13Name;
	}
	public String getScheduleItem9dot13Amt() {
		return scheduleItem9dot13Amt;
	}
	public void setScheduleItem9dot13Amt(String scheduleItem9dot13Amt) {
		this.scheduleItem9dot13Amt = scheduleItem9dot13Amt;
	}
	public String getScheduleItem9dot13PreAmt() {
		return scheduleItem9dot13PreAmt;
	}
	public void setScheduleItem9dot13PreAmt(String scheduleItem9dot13PreAmt) {
		this.scheduleItem9dot13PreAmt = scheduleItem9dot13PreAmt;
	}
	public String getScheduleItem9dot14Name() {
		return scheduleItem9dot14Name;
	}
	public void setScheduleItem9dot14Name(String scheduleItem9dot14Name) {
		this.scheduleItem9dot14Name = scheduleItem9dot14Name;
	}
	public String getScheduleItem9dot14Amt() {
		return scheduleItem9dot14Amt;
	}
	public void setScheduleItem9dot14Amt(String scheduleItem9dot14Amt) {
		this.scheduleItem9dot14Amt = scheduleItem9dot14Amt;
	}
	public String getScheduleItem9dot14PreAmt() {
		return scheduleItem9dot14PreAmt;
	}
	public void setScheduleItem9dot14PreAmt(String scheduleItem9dot14PreAmt) {
		this.scheduleItem9dot14PreAmt = scheduleItem9dot14PreAmt;
	}
	public String getScheduleItem9dot15Name() {
		return scheduleItem9dot15Name;
	}
	public void setScheduleItem9dot15Name(String scheduleItem9dot15Name) {
		this.scheduleItem9dot15Name = scheduleItem9dot15Name;
	}
	public String getScheduleItem9dot15Amt() {
		return scheduleItem9dot15Amt;
	}
	public void setScheduleItem9dot15Amt(String scheduleItem9dot15Amt) {
		this.scheduleItem9dot15Amt = scheduleItem9dot15Amt;
	}
	public String getScheduleItem9dot15PreAmt() {
		return scheduleItem9dot15PreAmt;
	}
	public void setScheduleItem9dot15PreAmt(String scheduleItem9dot15PreAmt) {
		this.scheduleItem9dot15PreAmt = scheduleItem9dot15PreAmt;
	}
	public String getScheduleItem9dot16Name() {
		return scheduleItem9dot16Name;
	}
	public void setScheduleItem9dot16Name(String scheduleItem9dot16Name) {
		this.scheduleItem9dot16Name = scheduleItem9dot16Name;
	}
	public String getScheduleItem9dot16Amt() {
		return scheduleItem9dot16Amt;
	}
	public void setScheduleItem9dot16Amt(String scheduleItem9dot16Amt) {
		this.scheduleItem9dot16Amt = scheduleItem9dot16Amt;
	}
	public String getScheduleItem9dot16PreAmt() {
		return scheduleItem9dot16PreAmt;
	}
	public void setScheduleItem9dot16PreAmt(String scheduleItem9dot16PreAmt) {
		this.scheduleItem9dot16PreAmt = scheduleItem9dot16PreAmt;
	}
	public String getScheduleItem9dot17Name() {
		return scheduleItem9dot17Name;
	}
	public void setScheduleItem9dot17Name(String scheduleItem9dot17Name) {
		this.scheduleItem9dot17Name = scheduleItem9dot17Name;
	}
	public String getScheduleItem9dot18Name() {
		return scheduleItem9dot18Name;
	}
	public void setScheduleItem9dot18Name(String scheduleItem9dot18Name) {
		this.scheduleItem9dot18Name = scheduleItem9dot18Name;
	}
	public String getScheduleItem9dot19Name() {
		return scheduleItem9dot19Name;
	}
	public void setScheduleItem9dot19Name(String scheduleItem9dot19Name) {
		this.scheduleItem9dot19Name = scheduleItem9dot19Name;
	}
	public String getScheduleItem9dot19Amt() {
		return scheduleItem9dot19Amt;
	}
	public void setScheduleItem9dot19Amt(String scheduleItem9dot19Amt) {
		this.scheduleItem9dot19Amt = scheduleItem9dot19Amt;
	}
	public String getScheduleItem9dot19PreAmt() {
		return scheduleItem9dot19PreAmt;
	}
	public void setScheduleItem9dot19PreAmt(String scheduleItem9dot19PreAmt) {
		this.scheduleItem9dot19PreAmt = scheduleItem9dot19PreAmt;
	}
	public String getScheduleItem9dot20Name() {
		return scheduleItem9dot20Name;
	}
	public void setScheduleItem9dot20Name(String scheduleItem9dot20Name) {
		this.scheduleItem9dot20Name = scheduleItem9dot20Name;
	}
	public String getScheduleItem9dot20Amt() {
		return scheduleItem9dot20Amt;
	}
	public void setScheduleItem9dot20Amt(String scheduleItem9dot20Amt) {
		this.scheduleItem9dot20Amt = scheduleItem9dot20Amt;
	}
	public String getScheduleItem9dot20PreAmt() {
		return scheduleItem9dot20PreAmt;
	}
	public void setScheduleItem9dot20PreAmt(String scheduleItem9dot20PreAmt) {
		this.scheduleItem9dot20PreAmt = scheduleItem9dot20PreAmt;
	}
	public String getScheduleItem9dot21Name() {
		return scheduleItem9dot21Name;
	}
	public void setScheduleItem9dot21Name(String scheduleItem9dot21Name) {
		this.scheduleItem9dot21Name = scheduleItem9dot21Name;
	}
	public String getScheduleItem9dot22Name() {
		return scheduleItem9dot22Name;
	}
	public void setScheduleItem9dot22Name(String scheduleItem9dot22Name) {
		this.scheduleItem9dot22Name = scheduleItem9dot22Name;
	}
	public String getScheduleItem9dot22Amt() {
		return scheduleItem9dot22Amt;
	}
	public void setScheduleItem9dot22Amt(String scheduleItem9dot22Amt) {
		this.scheduleItem9dot22Amt = scheduleItem9dot22Amt;
	}
	public String getScheduleItem9dot22PreAmt() {
		return scheduleItem9dot22PreAmt;
	}
	public void setScheduleItem9dot22PreAmt(String scheduleItem9dot22PreAmt) {
		this.scheduleItem9dot22PreAmt = scheduleItem9dot22PreAmt;
	}
	public String getScheduleItem9dot23Name() {
		return scheduleItem9dot23Name;
	}
	public void setScheduleItem9dot23Name(String scheduleItem9dot23Name) {
		this.scheduleItem9dot23Name = scheduleItem9dot23Name;
	}
	public String getScheduleItem9dot23Amt() {
		return scheduleItem9dot23Amt;
	}
	public void setScheduleItem9dot23Amt(String scheduleItem9dot23Amt) {
		this.scheduleItem9dot23Amt = scheduleItem9dot23Amt;
	}
	public String getScheduleItem9dot23PreAmt() {
		return scheduleItem9dot23PreAmt;
	}
	public void setScheduleItem9dot23PreAmt(String scheduleItem9dot23PreAmt) {
		this.scheduleItem9dot23PreAmt = scheduleItem9dot23PreAmt;
	}
	public String getScheduleItem9dot24Name() {
		return scheduleItem9dot24Name;
	}
	public void setScheduleItem9dot24Name(String scheduleItem9dot24Name) {
		this.scheduleItem9dot24Name = scheduleItem9dot24Name;
	}
	public String getScheduleItem9dot25Name() {
		return scheduleItem9dot25Name;
	}
	public void setScheduleItem9dot25Name(String scheduleItem9dot25Name) {
		this.scheduleItem9dot25Name = scheduleItem9dot25Name;
	}
	public String getScheduleItem9dot25Amt() {
		return scheduleItem9dot25Amt;
	}
	public void setScheduleItem9dot25Amt(String scheduleItem9dot25Amt) {
		this.scheduleItem9dot25Amt = scheduleItem9dot25Amt;
	}
	public String getScheduleItem9dot25PreAmt() {
		return scheduleItem9dot25PreAmt;
	}
	public void setScheduleItem9dot25PreAmt(String scheduleItem9dot25PreAmt) {
		this.scheduleItem9dot25PreAmt = scheduleItem9dot25PreAmt;
	}
	public String getScheduleItem9dot26Name() {
		return scheduleItem9dot26Name;
	}
	public void setScheduleItem9dot26Name(String scheduleItem9dot26Name) {
		this.scheduleItem9dot26Name = scheduleItem9dot26Name;
	}
	public String getScheduleItem9dot26Amt() {
		return scheduleItem9dot26Amt;
	}
	public void setScheduleItem9dot26Amt(String scheduleItem9dot26Amt) {
		this.scheduleItem9dot26Amt = scheduleItem9dot26Amt;
	}
	public String getScheduleItem9dot26PreAmt() {
		return scheduleItem9dot26PreAmt;
	}
	public void setScheduleItem9dot26PreAmt(String scheduleItem9dot26PreAmt) {
		this.scheduleItem9dot26PreAmt = scheduleItem9dot26PreAmt;
	}
	public String getScheduleItem9dot27Amt() {
		return scheduleItem9dot27Amt;
	}
	public void setScheduleItem9dot27Amt(String scheduleItem9dot27Amt) {
		this.scheduleItem9dot27Amt = scheduleItem9dot27Amt;
	}
	public String getScheduleItem9dot27PreAmt() {
		return scheduleItem9dot27PreAmt;
	}
	public void setScheduleItem9dot27PreAmt(String scheduleItem9dot27PreAmt) {
		this.scheduleItem9dot27PreAmt = scheduleItem9dot27PreAmt;
	}
	public String getFinalSchedule9Name() {
		return finalSchedule9Name;
	}
	public void setFinalSchedule9Name(String finalSchedule9Name) {
		this.finalSchedule9Name = finalSchedule9Name;
	}
	public String getFinalSchedule9Amt() {
		return finalSchedule9Amt;
	}
	public void setFinalSchedule9Amt(String finalSchedule9Amt) {
		this.finalSchedule9Amt = finalSchedule9Amt;
	}
	public String getFinalSchedule9PreAmt() {
		return finalSchedule9PreAmt;
	}
	public void setFinalSchedule9PreAmt(String finalSchedule9PreAmt) {
		this.finalSchedule9PreAmt = finalSchedule9PreAmt;
	}
	@Override
	public String toString() {
		return "Schedule9 [createdBy=" + createdBy + ", scheduleItem9dot1Name=" + scheduleItem9dot1Name
				+ ", scheduleItem9dot2Name=" + scheduleItem9dot2Name + ", scheduleItem9dot3Name="
				+ scheduleItem9dot3Name + ", scheduleItem9dot4Name=" + scheduleItem9dot4Name + ", scheduleItem9dot4Amt="
				+ scheduleItem9dot4Amt + ", scheduleItem9dot4PreAmt=" + scheduleItem9dot4PreAmt
				+ ", scheduleItem9dot5Name=" + scheduleItem9dot5Name + ", scheduleItem9dot5Amt=" + scheduleItem9dot5Amt
				+ ", scheduleItem9dot5PreAmt=" + scheduleItem9dot5PreAmt + ", scheduleItem9dot6Name="
				+ scheduleItem9dot6Name + ", scheduleItem9dot6Amt=" + scheduleItem9dot6Amt
				+ ", scheduleItem9dot6PreAmt=" + scheduleItem9dot6PreAmt + ", scheduleItem9dot7Amt="
				+ scheduleItem9dot7Amt + ", scheduleItem9dot7PreAmt=" + scheduleItem9dot7PreAmt
				+ ", scheduleItem9dot8Name=" + scheduleItem9dot8Name + ", scheduleItem9dot8Amt=" + scheduleItem9dot8Amt
				+ ", scheduleItem9dot8PreAmt=" + scheduleItem9dot8PreAmt + ", scheduleItem9dot9Name="
				+ scheduleItem9dot9Name + ", scheduleItem9dot9Amt=" + scheduleItem9dot9Amt
				+ ", scheduleItem9dot9PreAmt=" + scheduleItem9dot9PreAmt + ", scheduleItem9dot10Name="
				+ scheduleItem9dot10Name + ", scheduleItem9dot10Amt=" + scheduleItem9dot10Amt
				+ ", scheduleItem9dot10PreAmt=" + scheduleItem9dot10PreAmt + ", scheduleItem9dot11Name="
				+ scheduleItem9dot11Name + ", scheduleItem9dot12Name=" + scheduleItem9dot12Name
				+ ", scheduleItem9dot12Amt=" + scheduleItem9dot12Amt + ", scheduleItem9dot12PreAmt="
				+ scheduleItem9dot12PreAmt + ", scheduleItem9dot13Name=" + scheduleItem9dot13Name
				+ ", scheduleItem9dot13Amt=" + scheduleItem9dot13Amt + ", scheduleItem9dot13PreAmt="
				+ scheduleItem9dot13PreAmt + ", scheduleItem9dot14Name=" + scheduleItem9dot14Name
				+ ", scheduleItem9dot14Amt=" + scheduleItem9dot14Amt + ", scheduleItem9dot14PreAmt="
				+ scheduleItem9dot14PreAmt + ", scheduleItem9dot15Name=" + scheduleItem9dot15Name
				+ ", scheduleItem9dot15Amt=" + scheduleItem9dot15Amt + ", scheduleItem9dot15PreAmt="
				+ scheduleItem9dot15PreAmt + ", scheduleItem9dot16Name=" + scheduleItem9dot16Name
				+ ", scheduleItem9dot16Amt=" + scheduleItem9dot16Amt + ", scheduleItem9dot16PreAmt="
				+ scheduleItem9dot16PreAmt + ", scheduleItem9dot17Name=" + scheduleItem9dot17Name
				+ ", scheduleItem9dot18Name=" + scheduleItem9dot18Name + ", scheduleItem9dot19Name="
				+ scheduleItem9dot19Name + ", scheduleItem9dot19Amt=" + scheduleItem9dot19Amt
				+ ", scheduleItem9dot19PreAmt=" + scheduleItem9dot19PreAmt + ", scheduleItem9dot20Name="
				+ scheduleItem9dot20Name + ", scheduleItem9dot20Amt=" + scheduleItem9dot20Amt
				+ ", scheduleItem9dot20PreAmt=" + scheduleItem9dot20PreAmt + ", scheduleItem9dot21Name="
				+ scheduleItem9dot21Name + ", scheduleItem9dot22Name=" + scheduleItem9dot22Name
				+ ", scheduleItem9dot22Amt=" + scheduleItem9dot22Amt + ", scheduleItem9dot22PreAmt="
				+ scheduleItem9dot22PreAmt + ", scheduleItem9dot23Name=" + scheduleItem9dot23Name
				+ ", scheduleItem9dot23Amt=" + scheduleItem9dot23Amt + ", scheduleItem9dot23PreAmt="
				+ scheduleItem9dot23PreAmt + ", scheduleItem9dot24Name=" + scheduleItem9dot24Name
				+ ", scheduleItem9dot25Name=" + scheduleItem9dot25Name + ", scheduleItem9dot25Amt="
				+ scheduleItem9dot25Amt + ", scheduleItem9dot25PreAmt=" + scheduleItem9dot25PreAmt
				+ ", scheduleItem9dot26Name=" + scheduleItem9dot26Name + ", scheduleItem9dot26Amt="
				+ scheduleItem9dot26Amt + ", scheduleItem9dot26PreAmt=" + scheduleItem9dot26PreAmt
				+ ", scheduleItem9dot27Amt=" + scheduleItem9dot27Amt + ", scheduleItem9dot27PreAmt="
				+ scheduleItem9dot27PreAmt + ", finalSchedule9Name=" + finalSchedule9Name + ", finalSchedule9Amt="
				+ finalSchedule9Amt + ", finalSchedule9PreAmt=" + finalSchedule9PreAmt + "]";
	}
	
	
	
}
