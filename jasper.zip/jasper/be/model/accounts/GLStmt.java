package in.ecgc.smile.erp.reporting.jasper.be.model.accounts;

import java.math.BigDecimal;
import java.time.LocalDate;

import org.springframework.format.annotation.DateTimeFormat;

public class GLStmt {
	private String logicallocCd;
	private BigDecimal txnDrAmt;
	private BigDecimal txnCrAmt;
	private BigDecimal balance;
	private String balanceType;
	private String remark;
	private String txnNo;
	private String mainGLCd;
	private String subGLCd;
	private String glName;
	private LocalDate txnDate;
	private String subBfCode;
	private String subBfName;

	public String getSubBfName() {
		return subBfName;
	}

	public void setSubBfName(String subBfName) {
		this.subBfName = subBfName;
	}

	public String getSubBfCode() {
		return subBfCode;
	}

	public void setSubBfCode(String subBfCode) {
		this.subBfCode = subBfCode;
	}

	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate fromDt;

	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate toDt;

	private String txnType;
	private TCodes tcodes;

	public String getLogicallocCd() {
		return logicallocCd;
	}

	public void setLogicallocCd(String logicallocCd) {
		this.logicallocCd = logicallocCd;
	}

	public BigDecimal getTxnDrAmt() {
		return txnDrAmt;
	}

	public void setTxnDrAmt(BigDecimal txnDrAmt) {
		this.txnDrAmt = txnDrAmt;
	}

	public BigDecimal getTxnCrAmt() {
		return txnCrAmt;
	}

	public void setTxnCrAmt(BigDecimal txnCrAmt) {
		this.txnCrAmt = txnCrAmt;
	}

	public BigDecimal getBalance() {
		return balance;
	}

	public void setBalance(BigDecimal balance) {
		this.balance = balance;
	}

	public String getBalanceType() {
		return balanceType;
	}

	public void setBalanceType(String balanceType) {
		this.balanceType = balanceType;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getTxnNo() {
		return txnNo;
	}

	public void setTxnNo(String txnNo) {
		this.txnNo = txnNo;
	}

	public String getMainGLCd() {
		return mainGLCd;
	}

	public void setMainGLCd(String mainGLCd) {
		this.mainGLCd = mainGLCd;
	}

	public String getSubGLCd() {
		return subGLCd;
	}

	public void setSubGLCd(String subGLCd) {
		this.subGLCd = subGLCd;
	}

	public String getGlName() {
		return glName;
	}

	public void setGlName(String glName) {
		this.glName = glName;
	}

	public LocalDate getTxnDate() {
		return txnDate;
	}

	public void setTxnDate(LocalDate txnDate) {
		this.txnDate = txnDate;
	}

	public LocalDate getFromDt() {
		return fromDt;
	}

	public void setFromDt(LocalDate fromDt) {
		this.fromDt = fromDt;
	}

	public LocalDate getToDt() {
		return toDt;
	}

	public void setToDt(LocalDate toDt) {
		this.toDt = toDt;
	}

	public String getTxnType() {
		return txnType;
	}

	public void setTxnType(String txnType) {
		this.txnType = txnType;
	}

	public TCodes getTcodes() {
		return tcodes;
	}

	public void setTcodes(TCodes tcodes) {
		this.tcodes = tcodes;
	}

	@Override
	public String toString() {
		return "GLStmt [logicallocCd=" + logicallocCd + ", txnDrAmt=" + txnDrAmt + ", txnCrAmt=" + txnCrAmt
				+ ", balance=" + balance + ", balanceType=" + balanceType + ", remark=" + remark + ", txnNo=" + txnNo
				+ ", mainGLCd=" + mainGLCd + ", subGLCd=" + subGLCd + ", glName=" + glName + ", txnDate=" + txnDate
				+ ", subBfCode=" + subBfCode + ", subBfName=" + subBfName + ", fromDt=" + fromDt + ", toDt=" + toDt
				+ ", txnType=" + txnType + ", tcodes=" + tcodes + "]";
	}

}
