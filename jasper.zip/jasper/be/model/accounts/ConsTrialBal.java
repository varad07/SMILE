package in.ecgc.smile.erp.reporting.jasper.be.model.accounts;

import java.math.BigDecimal;
import java.time.LocalDate;

public class ConsTrialBal {

	private int srNo;
	private String mainGlCd;
	private String subGlCd;
	private String glName;
	private String glType;
	private String branchName;
	private BigDecimal drAmt;
	private BigDecimal crAmt;
	private LocalDate inputDate;
	
	
	public int getSrNo() {
		return srNo;
	}
	public void setSrNo(int srNo) {
		this.srNo = srNo;
	}
	public String getBranchName() {
		return branchName;
	}
	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}
	public BigDecimal getDrAmt() {
		return drAmt;
	}
	public void setDrAmt(BigDecimal drAmt) {
		this.drAmt = drAmt;
	}
	public BigDecimal getCrAmt() {
		return crAmt;
	}
	public void setCrAmt(BigDecimal crAmt) {
		this.crAmt = crAmt;
	}
	public String getMainGlCd() {
		return mainGlCd;
	}
	public void setMainGlCd(String mainGlCd) {
		this.mainGlCd = mainGlCd;
	}
	public String getSubGlCd() {
		return subGlCd;
	}
	public void setSubGlCd(String subGlCd) {
		this.subGlCd = subGlCd;
	}
	public String getGlName() {
		return glName;
	}
	public void setGlName(String glName) {
		this.glName = glName;
	}
	public String getGlType() {
		return glType;
	}
	public void setGlType(String glType) {
		this.glType = glType;
	}
	public LocalDate getInputDate() {
		return inputDate;
	}
	public void setInputDate(LocalDate inputDate) {
		this.inputDate = inputDate;
	}
	@Override
	public String toString() {
		return "ConsTrialBal [srNo=" + srNo + ", mainGlCd=" + mainGlCd + ", subGlCd=" + subGlCd + ", glName=" + glName
				+ ", glType=" + glType + ", branchName=" + branchName + ", drAmt=" + drAmt + ", crAmt=" + crAmt
				+ ", inputDate=" + inputDate + "]";
	}

	
	
	
}
