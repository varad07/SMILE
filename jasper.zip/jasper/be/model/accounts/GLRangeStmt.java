package in.ecgc.smile.erp.reporting.jasper.be.model.accounts;

import java.math.BigDecimal;
import java.time.LocalDate;

import org.springframework.format.annotation.DateTimeFormat;

public class GLRangeStmt {
	private String txnNo;
	private String txnType;
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate txnDate;
	private BigDecimal txnDrAmt;
	private BigDecimal txnCrAmt;
	private BigDecimal txnTotal;
	private String txnTotalType;
	private String remark;

	public String getTxnNo() {
		return txnNo;
	}

	public void setTxnNo(String txnNo) {
		this.txnNo = txnNo;
	}

	public String getTxnType() {
		return txnType;
	}

	public void setTxnType(String txnType) {
		this.txnType = txnType;
	}

	public LocalDate getTxnDate() {
		return txnDate;
	}

	public void setTxnDate(LocalDate txnDate) {
		this.txnDate = txnDate;
	}

	public BigDecimal getTxnDrAmt() {
		return txnDrAmt;
	}

	public void setTxnDrAmt(BigDecimal txnDrAmt) {
		this.txnDrAmt = txnDrAmt;
	}

	public BigDecimal getTxnCrAmt() {
		return txnCrAmt;
	}

	public void setTxnCrAmt(BigDecimal txnCrAmt) {
		this.txnCrAmt = txnCrAmt;
	}

	public BigDecimal getTxnTotal() {
		return txnTotal;
	}

	public void setTxnTotal(BigDecimal txnTotal) {
		this.txnTotal = txnTotal;
	}

	public String getTxnTotalType() {
		return txnTotalType;
	}

	public void setTxnTotalType(String txnTotalType) {
		this.txnTotalType = txnTotalType;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	@Override
	public String toString() {
		return "GLRangeStmt [txnNo=" + txnNo + ", txnType=" + txnType + ", txnDate=" + txnDate + ", txnDrAmt="
				+ txnDrAmt + ", txnCrAmt=" + txnCrAmt + ", txnTotal=" + txnTotal + ", txnTotalType=" + txnTotalType
				+ ", remark=" + remark + "]";
	}

}
