package in.ecgc.smile.erp.reporting.jasper.be.model.accounts;

public class Schedule8 {
	
	private Schedule8A schedule8a;
	
	private String createdBy;

	private String scheduleItem8dot1Name;
	
	private String scheduleItem8dot2Name;
	private String scheduleItem8dot2Amt;
	private String scheduleItem8dot2PreAmt;
	
	private String scheduleItem8dot3Name;
	private String scheduleItem8dot3Amt;
	private String scheduleItem8dot3PreAmt;
	
	private String scheduleItem8dot4Name;
	
	private String scheduleItem8dot5Name;
	
	private String scheduleItem8dot6Name;
	private String scheduleItem8dot6Amt;
	private String scheduleItem8dot6PreAmt;
	
	private String scheduleItem8dot7Name;
	private String scheduleItem8dot7Amt;
	private String scheduleItem8dot7PreAmt;
	
	private String scheduleItem8dot8Name;
	private String scheduleItem8dot8Amt;
	private String scheduleItem8dot8PreAmt;
	
	private String scheduleItem8dot9Name;
	private String scheduleItem8dot9Amt;
	private String scheduleItem8dot9PreAmt;
	
	private String scheduleItem8dot10Name;
	private String scheduleItem8dot10Amt;
	private String scheduleItem8dot10PreAmt;
	
	private String scheduleItem8dot11Name;
	private String scheduleItem8dot11Amt;
	private String scheduleItem8dot11PreAmt;
	
	private String scheduleItem8dot12Name;
	private String scheduleItem8dot12Amt;
	private String scheduleItem8dot12PreAmt;
	
	private String scheduleItem8dot13Name;
	private String scheduleItem8dot13Amt;
	private String scheduleItem8dot13PreAmt;
	
	private String scheduleItem8dot14Name;
	private String scheduleItem8dot14Amt;
	private String scheduleItem8dot14PreAmt;
	
	private String scheduleItem8dot15Name;
	private String scheduleItem8dot15Amt;
	private String scheduleItem8dot15PreAmt;
	
	private String scheduleItem8dot16Name;
	private String scheduleItem8dot16Amt;
	private String scheduleItem8dot16PreAmt;
	
	private String scheduleItem8dot17Name;
	
	private String scheduleItem8dot18Name;
	private String scheduleItem8dot18Amt;
	private String scheduleItem8dot18PreAmt;
	
	private String scheduleItem8dot19Name;
	private String scheduleItem8dot19Amt;
	private String scheduleItem8dot19PreAmt;
	
	private String scheduleItem8dot20Name;
	
	private String scheduleItem8dot21Name;
	
	private String scheduleItem8dot22Name;
	private String scheduleItem8dot22Amt;
	private String scheduleItem8dot22PreAmt;
	
	private String scheduleItem8dot23Name;
	private String scheduleItem8dot23Amt;
	private String scheduleItem8dot23PreAmt;
	
	private String scheduleItem8dot24Name;
	private String scheduleItem8dot24Amt;
	private String scheduleItem8dot24PreAmt;
	
	private String scheduleItem8dot25Name;
	private String scheduleItem8dot25Amt;
	private String scheduleItem8dot25PreAmt;
	
	private String scheduleItem8dot26Name;
	private String scheduleItem8dot26Amt;
	private String scheduleItem8dot26PreAmt;
	
	private String scheduleItem8dot27Name;
	private String scheduleItem8dot27Amt;
	private String scheduleItem8dot27PreAmt;
	
	private String scheduleItem8dot28Name;
	private String scheduleItem8dot28Amt;
	private String scheduleItem8dot28PreAmt;
	
	private String scheduleItem8dot29Name;
	private String scheduleItem8dot29Amt;
	private String scheduleItem8dot29PreAmt;
	
	private String scheduleItem8dot30Name;
	private String scheduleItem8dot30Amt;
	private String scheduleItem8dot30PreAmt;
	
	private String scheduleItem8dot31Name;
	private String scheduleItem8dot31Amt;
	private String scheduleItem8dot31PreAmt;
	
	private String scheduleItem8dot32Name;
	private String scheduleItem8dot32Amt;
	private String scheduleItem8dot32PreAmt;

	
	private String finalSchedule8Name;
	private String finalSchedule8Amt;
	private String finalSchedule8PreAmt;
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getScheduleItem8dot1Name() {
		return scheduleItem8dot1Name;
	}
	public void setScheduleItem8dot1Name(String scheduleItem8dot1Name) {
		this.scheduleItem8dot1Name = scheduleItem8dot1Name;
	}
	public String getScheduleItem8dot2Name() {
		return scheduleItem8dot2Name;
	}
	public void setScheduleItem8dot2Name(String scheduleItem8dot2Name) {
		this.scheduleItem8dot2Name = scheduleItem8dot2Name;
	}
	public String getScheduleItem8dot2Amt() {
		return scheduleItem8dot2Amt;
	}
	public void setScheduleItem8dot2Amt(String scheduleItem8dot2Amt) {
		this.scheduleItem8dot2Amt = scheduleItem8dot2Amt;
	}
	public String getScheduleItem8dot2PreAmt() {
		return scheduleItem8dot2PreAmt;
	}
	public void setScheduleItem8dot2PreAmt(String scheduleItem8dot2PreAmt) {
		this.scheduleItem8dot2PreAmt = scheduleItem8dot2PreAmt;
	}
	public String getScheduleItem8dot3Name() {
		return scheduleItem8dot3Name;
	}
	public void setScheduleItem8dot3Name(String scheduleItem8dot3Name) {
		this.scheduleItem8dot3Name = scheduleItem8dot3Name;
	}
	public String getScheduleItem8dot3Amt() {
		return scheduleItem8dot3Amt;
	}
	public void setScheduleItem8dot3Amt(String scheduleItem8dot3Amt) {
		this.scheduleItem8dot3Amt = scheduleItem8dot3Amt;
	}
	public String getScheduleItem8dot3PreAmt() {
		return scheduleItem8dot3PreAmt;
	}
	public void setScheduleItem8dot3PreAmt(String scheduleItem8dot3PreAmt) {
		this.scheduleItem8dot3PreAmt = scheduleItem8dot3PreAmt;
	}
	public String getScheduleItem8dot4Name() {
		return scheduleItem8dot4Name;
	}
	public void setScheduleItem8dot4Name(String scheduleItem8dot4Name) {
		this.scheduleItem8dot4Name = scheduleItem8dot4Name;
	}
	public String getScheduleItem8dot5Name() {
		return scheduleItem8dot5Name;
	}
	public void setScheduleItem8dot5Name(String scheduleItem8dot5Name) {
		this.scheduleItem8dot5Name = scheduleItem8dot5Name;
	}
	public String getScheduleItem8dot6Name() {
		return scheduleItem8dot6Name;
	}
	public void setScheduleItem8dot6Name(String scheduleItem8dot6Name) {
		this.scheduleItem8dot6Name = scheduleItem8dot6Name;
	}
	public String getScheduleItem8dot6Amt() {
		return scheduleItem8dot6Amt;
	}
	public void setScheduleItem8dot6Amt(String scheduleItem8dot6Amt) {
		this.scheduleItem8dot6Amt = scheduleItem8dot6Amt;
	}
	public String getScheduleItem8dot6PreAmt() {
		return scheduleItem8dot6PreAmt;
	}
	public void setScheduleItem8dot6PreAmt(String scheduleItem8dot6PreAmt) {
		this.scheduleItem8dot6PreAmt = scheduleItem8dot6PreAmt;
	}
	public String getScheduleItem8dot7Name() {
		return scheduleItem8dot7Name;
	}
	public void setScheduleItem8dot7Name(String scheduleItem8dot7Name) {
		this.scheduleItem8dot7Name = scheduleItem8dot7Name;
	}
	public String getScheduleItem8dot7Amt() {
		return scheduleItem8dot7Amt;
	}
	public void setScheduleItem8dot7Amt(String scheduleItem8dot7Amt) {
		this.scheduleItem8dot7Amt = scheduleItem8dot7Amt;
	}
	public String getScheduleItem8dot7PreAmt() {
		return scheduleItem8dot7PreAmt;
	}
	public void setScheduleItem8dot7PreAmt(String scheduleItem8dot7PreAmt) {
		this.scheduleItem8dot7PreAmt = scheduleItem8dot7PreAmt;
	}
	public String getScheduleItem8dot8Name() {
		return scheduleItem8dot8Name;
	}
	public void setScheduleItem8dot8Name(String scheduleItem8dot8Name) {
		this.scheduleItem8dot8Name = scheduleItem8dot8Name;
	}
	public String getScheduleItem8dot8Amt() {
		return scheduleItem8dot8Amt;
	}
	public void setScheduleItem8dot8Amt(String scheduleItem8dot8Amt) {
		this.scheduleItem8dot8Amt = scheduleItem8dot8Amt;
	}
	public String getScheduleItem8dot8PreAmt() {
		return scheduleItem8dot8PreAmt;
	}
	public void setScheduleItem8dot8PreAmt(String scheduleItem8dot8PreAmt) {
		this.scheduleItem8dot8PreAmt = scheduleItem8dot8PreAmt;
	}
	public String getScheduleItem8dot9Name() {
		return scheduleItem8dot9Name;
	}
	public void setScheduleItem8dot9Name(String scheduleItem8dot9Name) {
		this.scheduleItem8dot9Name = scheduleItem8dot9Name;
	}
	public String getScheduleItem8dot9Amt() {
		return scheduleItem8dot9Amt;
	}
	public void setScheduleItem8dot9Amt(String scheduleItem8dot9Amt) {
		this.scheduleItem8dot9Amt = scheduleItem8dot9Amt;
	}
	public String getScheduleItem8dot9PreAmt() {
		return scheduleItem8dot9PreAmt;
	}
	public void setScheduleItem8dot9PreAmt(String scheduleItem8dot9PreAmt) {
		this.scheduleItem8dot9PreAmt = scheduleItem8dot9PreAmt;
	}
	public String getScheduleItem8dot10Name() {
		return scheduleItem8dot10Name;
	}
	public void setScheduleItem8dot10Name(String scheduleItem8dot10Name) {
		this.scheduleItem8dot10Name = scheduleItem8dot10Name;
	}
	public String getScheduleItem8dot10Amt() {
		return scheduleItem8dot10Amt;
	}
	public void setScheduleItem8dot10Amt(String scheduleItem8dot10Amt) {
		this.scheduleItem8dot10Amt = scheduleItem8dot10Amt;
	}
	public String getScheduleItem8dot10PreAmt() {
		return scheduleItem8dot10PreAmt;
	}
	public void setScheduleItem8dot10PreAmt(String scheduleItem8dot10PreAmt) {
		this.scheduleItem8dot10PreAmt = scheduleItem8dot10PreAmt;
	}
	public String getScheduleItem8dot11Name() {
		return scheduleItem8dot11Name;
	}
	public void setScheduleItem8dot11Name(String scheduleItem8dot11Name) {
		this.scheduleItem8dot11Name = scheduleItem8dot11Name;
	}
	public String getScheduleItem8dot11Amt() {
		return scheduleItem8dot11Amt;
	}
	public void setScheduleItem8dot11Amt(String scheduleItem8dot11Amt) {
		this.scheduleItem8dot11Amt = scheduleItem8dot11Amt;
	}
	public String getScheduleItem8dot11PreAmt() {
		return scheduleItem8dot11PreAmt;
	}
	public void setScheduleItem8dot11PreAmt(String scheduleItem8dot11PreAmt) {
		this.scheduleItem8dot11PreAmt = scheduleItem8dot11PreAmt;
	}
	public String getScheduleItem8dot12Name() {
		return scheduleItem8dot12Name;
	}
	public void setScheduleItem8dot12Name(String scheduleItem8dot12Name) {
		this.scheduleItem8dot12Name = scheduleItem8dot12Name;
	}
	public String getScheduleItem8dot12Amt() {
		return scheduleItem8dot12Amt;
	}
	public void setScheduleItem8dot12Amt(String scheduleItem8dot12Amt) {
		this.scheduleItem8dot12Amt = scheduleItem8dot12Amt;
	}
	public String getScheduleItem8dot12PreAmt() {
		return scheduleItem8dot12PreAmt;
	}
	public void setScheduleItem8dot12PreAmt(String scheduleItem8dot12PreAmt) {
		this.scheduleItem8dot12PreAmt = scheduleItem8dot12PreAmt;
	}
	public String getScheduleItem8dot13Name() {
		return scheduleItem8dot13Name;
	}
	public void setScheduleItem8dot13Name(String scheduleItem8dot13Name) {
		this.scheduleItem8dot13Name = scheduleItem8dot13Name;
	}
	public String getScheduleItem8dot13Amt() {
		return scheduleItem8dot13Amt;
	}
	public void setScheduleItem8dot13Amt(String scheduleItem8dot13Amt) {
		this.scheduleItem8dot13Amt = scheduleItem8dot13Amt;
	}
	public String getScheduleItem8dot13PreAmt() {
		return scheduleItem8dot13PreAmt;
	}
	public void setScheduleItem8dot13PreAmt(String scheduleItem8dot13PreAmt) {
		this.scheduleItem8dot13PreAmt = scheduleItem8dot13PreAmt;
	}
	public String getScheduleItem8dot14Name() {
		return scheduleItem8dot14Name;
	}
	public void setScheduleItem8dot14Name(String scheduleItem8dot14Name) {
		this.scheduleItem8dot14Name = scheduleItem8dot14Name;
	}
	public String getScheduleItem8dot14Amt() {
		return scheduleItem8dot14Amt;
	}
	public void setScheduleItem8dot14Amt(String scheduleItem8dot14Amt) {
		this.scheduleItem8dot14Amt = scheduleItem8dot14Amt;
	}
	public String getScheduleItem8dot14PreAmt() {
		return scheduleItem8dot14PreAmt;
	}
	public void setScheduleItem8dot14PreAmt(String scheduleItem8dot14PreAmt) {
		this.scheduleItem8dot14PreAmt = scheduleItem8dot14PreAmt;
	}
	public String getScheduleItem8dot15Name() {
		return scheduleItem8dot15Name;
	}
	public void setScheduleItem8dot15Name(String scheduleItem8dot15Name) {
		this.scheduleItem8dot15Name = scheduleItem8dot15Name;
	}
	public String getScheduleItem8dot15Amt() {
		return scheduleItem8dot15Amt;
	}
	public void setScheduleItem8dot15Amt(String scheduleItem8dot15Amt) {
		this.scheduleItem8dot15Amt = scheduleItem8dot15Amt;
	}
	public String getScheduleItem8dot15PreAmt() {
		return scheduleItem8dot15PreAmt;
	}
	public void setScheduleItem8dot15PreAmt(String scheduleItem8dot15PreAmt) {
		this.scheduleItem8dot15PreAmt = scheduleItem8dot15PreAmt;
	}
	public String getScheduleItem8dot16Name() {
		return scheduleItem8dot16Name;
	}
	public void setScheduleItem8dot16Name(String scheduleItem8dot16Name) {
		this.scheduleItem8dot16Name = scheduleItem8dot16Name;
	}
	public String getScheduleItem8dot16Amt() {
		return scheduleItem8dot16Amt;
	}
	public void setScheduleItem8dot16Amt(String scheduleItem8dot16Amt) {
		this.scheduleItem8dot16Amt = scheduleItem8dot16Amt;
	}
	public String getScheduleItem8dot16PreAmt() {
		return scheduleItem8dot16PreAmt;
	}
	public void setScheduleItem8dot16PreAmt(String scheduleItem8dot16PreAmt) {
		this.scheduleItem8dot16PreAmt = scheduleItem8dot16PreAmt;
	}
	public String getScheduleItem8dot17Name() {
		return scheduleItem8dot17Name;
	}
	public void setScheduleItem8dot17Name(String scheduleItem8dot17Name) {
		this.scheduleItem8dot17Name = scheduleItem8dot17Name;
	}
	public String getScheduleItem8dot18Name() {
		return scheduleItem8dot18Name;
	}
	public void setScheduleItem8dot18Name(String scheduleItem8dot18Name) {
		this.scheduleItem8dot18Name = scheduleItem8dot18Name;
	}
	public String getScheduleItem8dot18Amt() {
		return scheduleItem8dot18Amt;
	}
	public void setScheduleItem8dot18Amt(String scheduleItem8dot18Amt) {
		this.scheduleItem8dot18Amt = scheduleItem8dot18Amt;
	}
	public String getScheduleItem8dot18PreAmt() {
		return scheduleItem8dot18PreAmt;
	}
	public void setScheduleItem8dot18PreAmt(String scheduleItem8dot18PreAmt) {
		this.scheduleItem8dot18PreAmt = scheduleItem8dot18PreAmt;
	}
	public String getScheduleItem8dot19Name() {
		return scheduleItem8dot19Name;
	}
	public void setScheduleItem8dot19Name(String scheduleItem8dot19Name) {
		this.scheduleItem8dot19Name = scheduleItem8dot19Name;
	}
	public String getScheduleItem8dot19Amt() {
		return scheduleItem8dot19Amt;
	}
	public void setScheduleItem8dot19Amt(String scheduleItem8dot19Amt) {
		this.scheduleItem8dot19Amt = scheduleItem8dot19Amt;
	}
	public String getScheduleItem8dot19PreAmt() {
		return scheduleItem8dot19PreAmt;
	}
	public void setScheduleItem8dot19PreAmt(String scheduleItem8dot19PreAmt) {
		this.scheduleItem8dot19PreAmt = scheduleItem8dot19PreAmt;
	}
	public String getScheduleItem8dot20Name() {
		return scheduleItem8dot20Name;
	}
	public void setScheduleItem8dot20Name(String scheduleItem8dot20Name) {
		this.scheduleItem8dot20Name = scheduleItem8dot20Name;
	}
	public String getScheduleItem8dot21Name() {
		return scheduleItem8dot21Name;
	}
	public void setScheduleItem8dot21Name(String scheduleItem8dot21Name) {
		this.scheduleItem8dot21Name = scheduleItem8dot21Name;
	}
	public String getScheduleItem8dot22Name() {
		return scheduleItem8dot22Name;
	}
	public void setScheduleItem8dot22Name(String scheduleItem8dot22Name) {
		this.scheduleItem8dot22Name = scheduleItem8dot22Name;
	}
	public String getScheduleItem8dot22Amt() {
		return scheduleItem8dot22Amt;
	}
	public void setScheduleItem8dot22Amt(String scheduleItem8dot22Amt) {
		this.scheduleItem8dot22Amt = scheduleItem8dot22Amt;
	}
	public String getScheduleItem8dot22PreAmt() {
		return scheduleItem8dot22PreAmt;
	}
	public void setScheduleItem8dot22PreAmt(String scheduleItem8dot22PreAmt) {
		this.scheduleItem8dot22PreAmt = scheduleItem8dot22PreAmt;
	}
	public String getScheduleItem8dot23Name() {
		return scheduleItem8dot23Name;
	}
	public void setScheduleItem8dot23Name(String scheduleItem8dot23Name) {
		this.scheduleItem8dot23Name = scheduleItem8dot23Name;
	}
	public String getScheduleItem8dot23Amt() {
		return scheduleItem8dot23Amt;
	}
	public void setScheduleItem8dot23Amt(String scheduleItem8dot23Amt) {
		this.scheduleItem8dot23Amt = scheduleItem8dot23Amt;
	}
	public String getScheduleItem8dot23PreAmt() {
		return scheduleItem8dot23PreAmt;
	}
	public void setScheduleItem8dot23PreAmt(String scheduleItem8dot23PreAmt) {
		this.scheduleItem8dot23PreAmt = scheduleItem8dot23PreAmt;
	}
	public String getScheduleItem8dot24Name() {
		return scheduleItem8dot24Name;
	}
	public void setScheduleItem8dot24Name(String scheduleItem8dot24Name) {
		this.scheduleItem8dot24Name = scheduleItem8dot24Name;
	}
	public String getScheduleItem8dot24Amt() {
		return scheduleItem8dot24Amt;
	}
	public void setScheduleItem8dot24Amt(String scheduleItem8dot24Amt) {
		this.scheduleItem8dot24Amt = scheduleItem8dot24Amt;
	}
	public String getScheduleItem8dot24PreAmt() {
		return scheduleItem8dot24PreAmt;
	}
	public void setScheduleItem8dot24PreAmt(String scheduleItem8dot24PreAmt) {
		this.scheduleItem8dot24PreAmt = scheduleItem8dot24PreAmt;
	}
	public String getScheduleItem8dot25Name() {
		return scheduleItem8dot25Name;
	}
	public void setScheduleItem8dot25Name(String scheduleItem8dot25Name) {
		this.scheduleItem8dot25Name = scheduleItem8dot25Name;
	}
	public String getScheduleItem8dot25Amt() {
		return scheduleItem8dot25Amt;
	}
	public void setScheduleItem8dot25Amt(String scheduleItem8dot25Amt) {
		this.scheduleItem8dot25Amt = scheduleItem8dot25Amt;
	}
	public String getScheduleItem8dot25PreAmt() {
		return scheduleItem8dot25PreAmt;
	}
	public void setScheduleItem8dot25PreAmt(String scheduleItem8dot25PreAmt) {
		this.scheduleItem8dot25PreAmt = scheduleItem8dot25PreAmt;
	}
	public String getScheduleItem8dot26Name() {
		return scheduleItem8dot26Name;
	}
	public void setScheduleItem8dot26Name(String scheduleItem8dot26Name) {
		this.scheduleItem8dot26Name = scheduleItem8dot26Name;
	}
	public String getScheduleItem8dot26Amt() {
		return scheduleItem8dot26Amt;
	}
	public void setScheduleItem8dot26Amt(String scheduleItem8dot26Amt) {
		this.scheduleItem8dot26Amt = scheduleItem8dot26Amt;
	}
	public String getScheduleItem8dot26PreAmt() {
		return scheduleItem8dot26PreAmt;
	}
	public void setScheduleItem8dot26PreAmt(String scheduleItem8dot26PreAmt) {
		this.scheduleItem8dot26PreAmt = scheduleItem8dot26PreAmt;
	}
	public String getScheduleItem8dot27Name() {
		return scheduleItem8dot27Name;
	}
	public void setScheduleItem8dot27Name(String scheduleItem8dot27Name) {
		this.scheduleItem8dot27Name = scheduleItem8dot27Name;
	}
	public String getScheduleItem8dot27Amt() {
		return scheduleItem8dot27Amt;
	}
	public void setScheduleItem8dot27Amt(String scheduleItem8dot27Amt) {
		this.scheduleItem8dot27Amt = scheduleItem8dot27Amt;
	}
	public String getScheduleItem8dot27PreAmt() {
		return scheduleItem8dot27PreAmt;
	}
	public void setScheduleItem8dot27PreAmt(String scheduleItem8dot27PreAmt) {
		this.scheduleItem8dot27PreAmt = scheduleItem8dot27PreAmt;
	}
	public String getScheduleItem8dot28Name() {
		return scheduleItem8dot28Name;
	}
	public void setScheduleItem8dot28Name(String scheduleItem8dot28Name) {
		this.scheduleItem8dot28Name = scheduleItem8dot28Name;
	}
	public String getScheduleItem8dot28Amt() {
		return scheduleItem8dot28Amt;
	}
	public void setScheduleItem8dot28Amt(String scheduleItem8dot28Amt) {
		this.scheduleItem8dot28Amt = scheduleItem8dot28Amt;
	}
	public String getScheduleItem8dot28PreAmt() {
		return scheduleItem8dot28PreAmt;
	}
	public void setScheduleItem8dot28PreAmt(String scheduleItem8dot28PreAmt) {
		this.scheduleItem8dot28PreAmt = scheduleItem8dot28PreAmt;
	}
	public String getScheduleItem8dot29Name() {
		return scheduleItem8dot29Name;
	}
	public void setScheduleItem8dot29Name(String scheduleItem8dot29Name) {
		this.scheduleItem8dot29Name = scheduleItem8dot29Name;
	}
	public String getScheduleItem8dot29Amt() {
		return scheduleItem8dot29Amt;
	}
	public void setScheduleItem8dot29Amt(String scheduleItem8dot29Amt) {
		this.scheduleItem8dot29Amt = scheduleItem8dot29Amt;
	}
	public String getScheduleItem8dot29PreAmt() {
		return scheduleItem8dot29PreAmt;
	}
	public void setScheduleItem8dot29PreAmt(String scheduleItem8dot29PreAmt) {
		this.scheduleItem8dot29PreAmt = scheduleItem8dot29PreAmt;
	}
	public String getScheduleItem8dot30Name() {
		return scheduleItem8dot30Name;
	}
	public void setScheduleItem8dot30Name(String scheduleItem8dot30Name) {
		this.scheduleItem8dot30Name = scheduleItem8dot30Name;
	}
	public String getScheduleItem8dot30Amt() {
		return scheduleItem8dot30Amt;
	}
	public void setScheduleItem8dot30Amt(String scheduleItem8dot30Amt) {
		this.scheduleItem8dot30Amt = scheduleItem8dot30Amt;
	}
	public String getScheduleItem8dot30PreAmt() {
		return scheduleItem8dot30PreAmt;
	}
	public void setScheduleItem8dot30PreAmt(String scheduleItem8dot30PreAmt) {
		this.scheduleItem8dot30PreAmt = scheduleItem8dot30PreAmt;
	}
	public String getScheduleItem8dot31Name() {
		return scheduleItem8dot31Name;
	}
	public void setScheduleItem8dot31Name(String scheduleItem8dot31Name) {
		this.scheduleItem8dot31Name = scheduleItem8dot31Name;
	}
	public String getScheduleItem8dot31Amt() {
		return scheduleItem8dot31Amt;
	}
	public void setScheduleItem8dot31Amt(String scheduleItem8dot31Amt) {
		this.scheduleItem8dot31Amt = scheduleItem8dot31Amt;
	}
	public String getScheduleItem8dot31PreAmt() {
		return scheduleItem8dot31PreAmt;
	}
	public void setScheduleItem8dot31PreAmt(String scheduleItem8dot31PreAmt) {
		this.scheduleItem8dot31PreAmt = scheduleItem8dot31PreAmt;
	}
	public String getFinalSchedule8Name() {
		return finalSchedule8Name;
	}
	public void setFinalSchedule8Name(String finalSchedule8Name) {
		this.finalSchedule8Name = finalSchedule8Name;
	}
	public String getFinalSchedule8Amt() {
		return finalSchedule8Amt;
	}
	public void setFinalSchedule8Amt(String finalSchedule8Amt) {
		this.finalSchedule8Amt = finalSchedule8Amt;
	}
	public String getFinalSchedule8PreAmt() {
		return finalSchedule8PreAmt;
	}
	public void setFinalSchedule8PreAmt(String finalSchedule8PreAmt) {
		this.finalSchedule8PreAmt = finalSchedule8PreAmt;
	}
	public String getScheduleItem8dot32Name() {
		return scheduleItem8dot32Name;
	}
	public void setScheduleItem8dot32Name(String scheduleItem8dot32Name) {
		this.scheduleItem8dot32Name = scheduleItem8dot32Name;
	}
	public String getScheduleItem8dot32Amt() {
		return scheduleItem8dot32Amt;
	}
	public void setScheduleItem8dot32Amt(String scheduleItem8dot32Amt) {
		this.scheduleItem8dot32Amt = scheduleItem8dot32Amt;
	}
	public String getScheduleItem8dot32PreAmt() {
		return scheduleItem8dot32PreAmt;
	}
	public void setScheduleItem8dot32PreAmt(String scheduleItem8dot32PreAmt) {
		this.scheduleItem8dot32PreAmt = scheduleItem8dot32PreAmt;
	}
	public Schedule8A getSchedule8a() {
		return schedule8a;
	}
	public void setSchedule8a(Schedule8A schedule8a) {
		this.schedule8a = schedule8a;
	}
	
	
	
	
	
	

}
