package in.ecgc.smile.erp.reporting.jasper.be.model.accounts;

public class Schedule4 {
	
	private String createdBy;

	private String scheduleItem4dot1Name;
	private String scheduleItem4dot1Amt;
	private String scheduleItem4dot1PreAmt;
	
	private String scheduleItem4dot2Name;
	private String scheduleItem4dot2Amt;
	private String scheduleItem4dot2PreAmt;

	private String scheduleItem4dot3Name;
	private String scheduleItem4dot3Amt;
	private String scheduleItem4dot3PreAmt;
	
	
	private String scheduleItem4dot4Name;
	private String scheduleItem4dot4Amt;
	private String scheduleItem4dot4PreAmt;
	
	
	private String scheduleItem4dot5Name;
	private String scheduleItem4dot5Amt;
	private String scheduleItem4dot5PreAmt;
	
	private String scheduleItem4dot6Name;
	private String scheduleItem4dot6Amt;
	private String scheduleItem4dot6PreAmt;
	
	private String scheduleItem4dot7Name;
	private String scheduleItem4dot7Amt;
	private String scheduleItem4dot7PreAmt;
	
	private String scheduleItem4dot8Name;
	private String scheduleItem4dot8Amt;
	private String scheduleItem4dot8PreAmt;
	
	private String scheduleItem4dot9Name;
	
	private String scheduleItem4dot10Name;
	private String scheduleItem4dot10Amt;
	private String scheduleItem4dot10PreAmt;
	
	private String scheduleItem4dot11Name;
	
	private String scheduleItem4dot12Name;
	private String scheduleItem4dot12Amt;
	private String scheduleItem4dot12PreAmt;
	
	private String scheduleItem4dot13Name;
	private String scheduleItem4dot13Amt;
	private String scheduleItem4dot13PreAmt;
	
	private String scheduleItem4dot14Name;
	private String scheduleItem4dot14Amt;
	private String scheduleItem4dot14PreAmt;
	
	private String scheduleItem4dot15Name;
	private String scheduleItem4dot15Amt;
	private String scheduleItem4dot15PreAmt;
	
	private String scheduleItem4dot16Name;
	private String scheduleItem4dot16Amt;
	private String scheduleItem4dot16PreAmt;
	
	private String scheduleItem4dot17Name;
	private String scheduleItem4dot17Amt;
	private String scheduleItem4dot17PreAmt;
	
	private String scheduleItem4dot18Name;
	private String scheduleItem4dot18Amt;
	private String scheduleItem4dot18PreAmt;
	
	private String scheduleItem4dot19Name;
	private String scheduleItem4dot19Amt;
	private String scheduleItem4dot19PreAmt;
	
	private String finalSchedule4Name;
	private String finalSchedule4Amt;
	private String finalSchedule4PreAmt;
	
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getScheduleItem4dot1Name() {
		return scheduleItem4dot1Name;
	}
	public void setScheduleItem4dot1Name(String scheduleItem4dot1Name) {
		this.scheduleItem4dot1Name = scheduleItem4dot1Name;
	}
	public String getScheduleItem4dot1Amt() {
		return scheduleItem4dot1Amt;
	}
	public void setScheduleItem4dot1Amt(String scheduleItem4dot1Amt) {
		this.scheduleItem4dot1Amt = scheduleItem4dot1Amt;
	}
	public String getScheduleItem4dot1PreAmt() {
		return scheduleItem4dot1PreAmt;
	}
	public void setScheduleItem4dot1PreAmt(String scheduleItem4dot1PreAmt) {
		this.scheduleItem4dot1PreAmt = scheduleItem4dot1PreAmt;
	}
	public String getScheduleItem4dot2Name() {
		return scheduleItem4dot2Name;
	}
	public void setScheduleItem4dot2Name(String scheduleItem4dot2Name) {
		this.scheduleItem4dot2Name = scheduleItem4dot2Name;
	}
	public String getScheduleItem4dot2Amt() {
		return scheduleItem4dot2Amt;
	}
	public void setScheduleItem4dot2Amt(String scheduleItem4dot2Amt) {
		this.scheduleItem4dot2Amt = scheduleItem4dot2Amt;
	}
	public String getScheduleItem4dot2PreAmt() {
		return scheduleItem4dot2PreAmt;
	}
	public void setScheduleItem4dot2PreAmt(String scheduleItem4dot2PreAmt) {
		this.scheduleItem4dot2PreAmt = scheduleItem4dot2PreAmt;
	}
	public String getScheduleItem4dot3Name() {
		return scheduleItem4dot3Name;
	}
	public void setScheduleItem4dot3Name(String scheduleItem4dot3Name) {
		this.scheduleItem4dot3Name = scheduleItem4dot3Name;
	}
	public String getScheduleItem4dot3Amt() {
		return scheduleItem4dot3Amt;
	}
	public void setScheduleItem4dot3Amt(String scheduleItem4dot3Amt) {
		this.scheduleItem4dot3Amt = scheduleItem4dot3Amt;
	}
	public String getScheduleItem4dot3PreAmt() {
		return scheduleItem4dot3PreAmt;
	}
	public void setScheduleItem4dot3PreAmt(String scheduleItem4dot3PreAmt) {
		this.scheduleItem4dot3PreAmt = scheduleItem4dot3PreAmt;
	}
	public String getScheduleItem4dot4Name() {
		return scheduleItem4dot4Name;
	}
	public void setScheduleItem4dot4Name(String scheduleItem4dot4Name) {
		this.scheduleItem4dot4Name = scheduleItem4dot4Name;
	}
	public String getScheduleItem4dot4Amt() {
		return scheduleItem4dot4Amt;
	}
	public void setScheduleItem4dot4Amt(String scheduleItem4dot4Amt) {
		this.scheduleItem4dot4Amt = scheduleItem4dot4Amt;
	}
	public String getScheduleItem4dot4PreAmt() {
		return scheduleItem4dot4PreAmt;
	}
	public void setScheduleItem4dot4PreAmt(String scheduleItem4dot4PreAmt) {
		this.scheduleItem4dot4PreAmt = scheduleItem4dot4PreAmt;
	}
	public String getScheduleItem4dot5Name() {
		return scheduleItem4dot5Name;
	}
	public void setScheduleItem4dot5Name(String scheduleItem4dot5Name) {
		this.scheduleItem4dot5Name = scheduleItem4dot5Name;
	}
	public String getScheduleItem4dot5Amt() {
		return scheduleItem4dot5Amt;
	}
	public void setScheduleItem4dot5Amt(String scheduleItem4dot5Amt) {
		this.scheduleItem4dot5Amt = scheduleItem4dot5Amt;
	}
	public String getScheduleItem4dot5PreAmt() {
		return scheduleItem4dot5PreAmt;
	}
	public void setScheduleItem4dot5PreAmt(String scheduleItem4dot5PreAmt) {
		this.scheduleItem4dot5PreAmt = scheduleItem4dot5PreAmt;
	}
	public String getScheduleItem4dot6Name() {
		return scheduleItem4dot6Name;
	}
	public void setScheduleItem4dot6Name(String scheduleItem4dot6Name) {
		this.scheduleItem4dot6Name = scheduleItem4dot6Name;
	}
	public String getScheduleItem4dot6Amt() {
		return scheduleItem4dot6Amt;
	}
	public void setScheduleItem4dot6Amt(String scheduleItem4dot6Amt) {
		this.scheduleItem4dot6Amt = scheduleItem4dot6Amt;
	}
	public String getScheduleItem4dot6PreAmt() {
		return scheduleItem4dot6PreAmt;
	}
	public void setScheduleItem4dot6PreAmt(String scheduleItem4dot6PreAmt) {
		this.scheduleItem4dot6PreAmt = scheduleItem4dot6PreAmt;
	}
	public String getScheduleItem4dot7Name() {
		return scheduleItem4dot7Name;
	}
	public void setScheduleItem4dot7Name(String scheduleItem4dot7Name) {
		this.scheduleItem4dot7Name = scheduleItem4dot7Name;
	}
	public String getScheduleItem4dot7Amt() {
		return scheduleItem4dot7Amt;
	}
	public void setScheduleItem4dot7Amt(String scheduleItem4dot7Amt) {
		this.scheduleItem4dot7Amt = scheduleItem4dot7Amt;
	}
	public String getScheduleItem4dot7PreAmt() {
		return scheduleItem4dot7PreAmt;
	}
	public void setScheduleItem4dot7PreAmt(String scheduleItem4dot7PreAmt) {
		this.scheduleItem4dot7PreAmt = scheduleItem4dot7PreAmt;
	}
	public String getScheduleItem4dot8Name() {
		return scheduleItem4dot8Name;
	}
	public void setScheduleItem4dot8Name(String scheduleItem4dot8Name) {
		this.scheduleItem4dot8Name = scheduleItem4dot8Name;
	}
	public String getScheduleItem4dot8Amt() {
		return scheduleItem4dot8Amt;
	}
	public void setScheduleItem4dot8Amt(String scheduleItem4dot8Amt) {
		this.scheduleItem4dot8Amt = scheduleItem4dot8Amt;
	}
	public String getScheduleItem4dot8PreAmt() {
		return scheduleItem4dot8PreAmt;
	}
	public void setScheduleItem4dot8PreAmt(String scheduleItem4dot8PreAmt) {
		this.scheduleItem4dot8PreAmt = scheduleItem4dot8PreAmt;
	}
	public String getScheduleItem4dot9Name() {
		return scheduleItem4dot9Name;
	}
	public void setScheduleItem4dot9Name(String scheduleItem4dot9Name) {
		this.scheduleItem4dot9Name = scheduleItem4dot9Name;
	}
	public String getScheduleItem4dot10Name() {
		return scheduleItem4dot10Name;
	}
	public void setScheduleItem4dot10Name(String scheduleItem4dot10Name) {
		this.scheduleItem4dot10Name = scheduleItem4dot10Name;
	}
	public String getScheduleItem4dot10Amt() {
		return scheduleItem4dot10Amt;
	}
	public void setScheduleItem4dot10Amt(String scheduleItem4dot10Amt) {
		this.scheduleItem4dot10Amt = scheduleItem4dot10Amt;
	}
	public String getScheduleItem4dot10PreAmt() {
		return scheduleItem4dot10PreAmt;
	}
	public void setScheduleItem4dot10PreAmt(String scheduleItem4dot10PreAmt) {
		this.scheduleItem4dot10PreAmt = scheduleItem4dot10PreAmt;
	}
	public String getScheduleItem4dot11Name() {
		return scheduleItem4dot11Name;
	}
	public void setScheduleItem4dot11Name(String scheduleItem4dot11Name) {
		this.scheduleItem4dot11Name = scheduleItem4dot11Name;
	}
	public String getScheduleItem4dot12Name() {
		return scheduleItem4dot12Name;
	}
	public void setScheduleItem4dot12Name(String scheduleItem4dot12Name) {
		this.scheduleItem4dot12Name = scheduleItem4dot12Name;
	}
	public String getScheduleItem4dot12Amt() {
		return scheduleItem4dot12Amt;
	}
	public void setScheduleItem4dot12Amt(String scheduleItem4dot12Amt) {
		this.scheduleItem4dot12Amt = scheduleItem4dot12Amt;
	}
	public String getScheduleItem4dot12PreAmt() {
		return scheduleItem4dot12PreAmt;
	}
	public void setScheduleItem4dot12PreAmt(String scheduleItem4dot12PreAmt) {
		this.scheduleItem4dot12PreAmt = scheduleItem4dot12PreAmt;
	}
	public String getScheduleItem4dot13Name() {
		return scheduleItem4dot13Name;
	}
	public void setScheduleItem4dot13Name(String scheduleItem4dot13Name) {
		this.scheduleItem4dot13Name = scheduleItem4dot13Name;
	}
	public String getScheduleItem4dot13Amt() {
		return scheduleItem4dot13Amt;
	}
	public void setScheduleItem4dot13Amt(String scheduleItem4dot13Amt) {
		this.scheduleItem4dot13Amt = scheduleItem4dot13Amt;
	}
	public String getScheduleItem4dot13PreAmt() {
		return scheduleItem4dot13PreAmt;
	}
	public void setScheduleItem4dot13PreAmt(String scheduleItem4dot13PreAmt) {
		this.scheduleItem4dot13PreAmt = scheduleItem4dot13PreAmt;
	}
	public String getScheduleItem4dot14Name() {
		return scheduleItem4dot14Name;
	}
	public void setScheduleItem4dot14Name(String scheduleItem4dot14Name) {
		this.scheduleItem4dot14Name = scheduleItem4dot14Name;
	}
	public String getScheduleItem4dot14Amt() {
		return scheduleItem4dot14Amt;
	}
	public void setScheduleItem4dot14Amt(String scheduleItem4dot14Amt) {
		this.scheduleItem4dot14Amt = scheduleItem4dot14Amt;
	}
	public String getScheduleItem4dot14PreAmt() {
		return scheduleItem4dot14PreAmt;
	}
	public void setScheduleItem4dot14PreAmt(String scheduleItem4dot14PreAmt) {
		this.scheduleItem4dot14PreAmt = scheduleItem4dot14PreAmt;
	}
	public String getScheduleItem4dot15Name() {
		return scheduleItem4dot15Name;
	}
	public void setScheduleItem4dot15Name(String scheduleItem4dot15Name) {
		this.scheduleItem4dot15Name = scheduleItem4dot15Name;
	}
	public String getScheduleItem4dot15Amt() {
		return scheduleItem4dot15Amt;
	}
	public void setScheduleItem4dot15Amt(String scheduleItem4dot15Amt) {
		this.scheduleItem4dot15Amt = scheduleItem4dot15Amt;
	}
	public String getScheduleItem4dot15PreAmt() {
		return scheduleItem4dot15PreAmt;
	}
	public void setScheduleItem4dot15PreAmt(String scheduleItem4dot15PreAmt) {
		this.scheduleItem4dot15PreAmt = scheduleItem4dot15PreAmt;
	}
	public String getScheduleItem4dot16Name() {
		return scheduleItem4dot16Name;
	}
	public void setScheduleItem4dot16Name(String scheduleItem4dot16Name) {
		this.scheduleItem4dot16Name = scheduleItem4dot16Name;
	}
	public String getScheduleItem4dot16Amt() {
		return scheduleItem4dot16Amt;
	}
	public void setScheduleItem4dot16Amt(String scheduleItem4dot16Amt) {
		this.scheduleItem4dot16Amt = scheduleItem4dot16Amt;
	}
	public String getScheduleItem4dot16PreAmt() {
		return scheduleItem4dot16PreAmt;
	}
	public void setScheduleItem4dot16PreAmt(String scheduleItem4dot16PreAmt) {
		this.scheduleItem4dot16PreAmt = scheduleItem4dot16PreAmt;
	}
	public String getScheduleItem4dot17Name() {
		return scheduleItem4dot17Name;
	}
	public void setScheduleItem4dot17Name(String scheduleItem4dot17Name) {
		this.scheduleItem4dot17Name = scheduleItem4dot17Name;
	}
	public String getScheduleItem4dot17Amt() {
		return scheduleItem4dot17Amt;
	}
	public void setScheduleItem4dot17Amt(String scheduleItem4dot17Amt) {
		this.scheduleItem4dot17Amt = scheduleItem4dot17Amt;
	}
	public String getScheduleItem4dot17PreAmt() {
		return scheduleItem4dot17PreAmt;
	}
	public void setScheduleItem4dot17PreAmt(String scheduleItem4dot17PreAmt) {
		this.scheduleItem4dot17PreAmt = scheduleItem4dot17PreAmt;
	}
	public String getScheduleItem4dot18Name() {
		return scheduleItem4dot18Name;
	}
	public void setScheduleItem4dot18Name(String scheduleItem4dot18Name) {
		this.scheduleItem4dot18Name = scheduleItem4dot18Name;
	}
	public String getScheduleItem4dot18Amt() {
		return scheduleItem4dot18Amt;
	}
	public void setScheduleItem4dot18Amt(String scheduleItem4dot18Amt) {
		this.scheduleItem4dot18Amt = scheduleItem4dot18Amt;
	}
	public String getScheduleItem4dot18PreAmt() {
		return scheduleItem4dot18PreAmt;
	}
	public void setScheduleItem4dot18PreAmt(String scheduleItem4dot18PreAmt) {
		this.scheduleItem4dot18PreAmt = scheduleItem4dot18PreAmt;
	}
	public String getScheduleItem4dot19Name() {
		return scheduleItem4dot19Name;
	}
	public void setScheduleItem4dot19Name(String scheduleItem4dot19Name) {
		this.scheduleItem4dot19Name = scheduleItem4dot19Name;
	}
	public String getScheduleItem4dot19Amt() {
		return scheduleItem4dot19Amt;
	}
	public void setScheduleItem4dot19Amt(String scheduleItem4dot19Amt) {
		this.scheduleItem4dot19Amt = scheduleItem4dot19Amt;
	}
	public String getScheduleItem4dot19PreAmt() {
		return scheduleItem4dot19PreAmt;
	}
	public void setScheduleItem4dot19PreAmt(String scheduleItem4dot19PreAmt) {
		this.scheduleItem4dot19PreAmt = scheduleItem4dot19PreAmt;
	}
	public String getFinalSchedule4Name() {
		return finalSchedule4Name;
	}
	public void setFinalSchedule4Name(String finalSchedule4Name) {
		this.finalSchedule4Name = finalSchedule4Name;
	}
	public String getFinalSchedule4Amt() {
		return finalSchedule4Amt;
	}
	public void setFinalSchedule4Amt(String finalSchedule4Amt) {
		this.finalSchedule4Amt = finalSchedule4Amt;
	}
	public String getFinalSchedule4PreAmt() {
		return finalSchedule4PreAmt;
	}
	public void setFinalSchedule4PreAmt(String finalSchedule4PreAmt) {
		this.finalSchedule4PreAmt = finalSchedule4PreAmt;
	}
	
	
	
	
}
