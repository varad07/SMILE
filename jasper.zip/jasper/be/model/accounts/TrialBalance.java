package in.ecgc.smile.erp.reporting.jasper.be.model.accounts;

import java.math.BigDecimal;
import java.time.LocalDate;

public class TrialBalance {

	private String logicalLocCd;
	private String mainGlCd;
	private String subGlCd;
	private String glName;
	private String gltype;
	private BigDecimal drAmount;
	private BigDecimal crAmount;
	private LocalDate balDate;
	private String plCd;
	
	
	public String getPlCd() {
		return plCd;
	}
	public void setPlCd(String plCd) {
		this.plCd = plCd;
	}
	public String getLogicalLocCd() {
		return logicalLocCd;
	}
	public void setLogicalLocCd(String logicalLocCd) {
		this.logicalLocCd = logicalLocCd;
	}
	public String getMainGlCd() {
		return mainGlCd;
	}
	public void setMainGlCd(String mainGlCd) {
		this.mainGlCd = mainGlCd;
	}
	public String getSubGlCd() {
		return subGlCd;
	}
	public void setSubGlCd(String subGlCd) {
		this.subGlCd = subGlCd;
	}
	public String getGlName() {
		return glName;
	}
	public void setGlName(String glName) {
		this.glName = glName;
	}
	public String getGltype() {
		return gltype;
	}
	public void setGltype(String gltype) {
		this.gltype = gltype;
	}
	public BigDecimal getDrAmount() {
		return drAmount;
	}
	public void setDrAmount(BigDecimal drAmount) {
		this.drAmount = drAmount;
	}
	public BigDecimal getCrAmount() {
		return crAmount;
	}
	public void setCrAmount(BigDecimal crAmount) {
		this.crAmount = crAmount;
	}
	public LocalDate getBalDate() {
		return balDate;
	}
	public void setBalDate(LocalDate balDate) {
		this.balDate = balDate;
	}
	@Override
	public String toString() {
		return "TrialBalance [logicalLocCd=" + logicalLocCd + ", mainGlCd=" + mainGlCd + ", subGlCd=" + subGlCd
				+ ", glName=" + glName + ", gltype=" + gltype + ", drAmount=" + drAmount + ", crAmount=" + crAmount
				+ ", balDate=" + balDate + ", plCd=" + plCd + "]";
	}
	
	
}

