package in.ecgc.smile.erp.reporting.jasper.be.model.accounts.TcodeLevel;
import java.math.BigDecimal;
import java.time.LocalDate;
 
public class TcodeTransactions {

    private LocalDate txnDt;

    private String transactionNo;

    private String txnRemarks;

    private BigDecimal drAmt;

    private BigDecimal crAmt;

	public LocalDate getTxnDt() {
		return txnDt;
	}

	public void setTxnDt(LocalDate txnDt) {
		this.txnDt = txnDt;
	}

	public String getTransactionNo() {
		return transactionNo;
	}

	public void setTransactionNo(String transactionNo) {
		this.transactionNo = transactionNo;
	}

	public String getTxnRemarks() {
		return txnRemarks;
	}

	public void setTxnRemarks(String txnRemarks) {
		this.txnRemarks = txnRemarks;
	}

	public BigDecimal getDrAmt() {
		return drAmt;
	}

	public void setDrAmt(BigDecimal drAmt) {
		this.drAmt = drAmt;
	}

	public BigDecimal getCrAmt() {
		return crAmt;
	}

	public void setCrAmt(BigDecimal crAmt) {
		this.crAmt = crAmt;
	}

	@Override
	public String toString() {
		return "TcodeTransactions [txnDt=" + txnDt + ", transactionNo=" + transactionNo + ", txnRemarks=" + txnRemarks
				+ ", drAmt=" + drAmt + ", crAmt=" + crAmt + "]";
	}

    
    
}
 
