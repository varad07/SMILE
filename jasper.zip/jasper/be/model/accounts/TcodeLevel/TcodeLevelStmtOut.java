package in.ecgc.smile.erp.reporting.jasper.be.model.accounts.TcodeLevel;

import java.util.ArrayList;
import java.util.List;


public class TcodeLevelStmtOut {

    private String name;

    private List<TcodeLevelStmtOut> subLevels;

    private List<TcodeTransactions> transactions;
 
    public TcodeLevelStmtOut(String name) {

        this.name = name;

        this.subLevels = new ArrayList<>();

        this.transactions = new ArrayList<>();

    }
 
    // Getters and setters

    public String getName() { return name; }

    public void setName(String name) { this.name = name; }
 
    public List<TcodeLevelStmtOut> getSubLevels() { return subLevels; }

    public void setSubLevels(List<TcodeLevelStmtOut> subLevels) { this.subLevels = subLevels; }
 
    public List<TcodeTransactions> getTransactions() { return transactions; }

    public void setTransactions(List<TcodeTransactions> transactions) { this.transactions = transactions; }

	@Override
	public String toString() {
		return "Level [name=" + name + ", subLevels=" + subLevels + ", transactions=" + transactions + "]";
	}

    
    
}

 