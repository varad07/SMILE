package in.ecgc.smile.erp.reporting.jasper.be.model.accounts;

public class Schedule5A {
	private String createdBy;

	private String scheduleItem5dot1Name;
	
	private String scheduleItem5dot2Name;

	private String scheduleItem5dot3Name;
	private String scheduleItem5dot3Amt;
	private String scheduleItem5dot3PreAmt;

	private String scheduleItem5dot4Name;
	private String scheduleItem5dot4Amt;
	private String scheduleItem5dot4PreAmt;
	
	private String scheduleItem5dot5Name;
	private String scheduleItem5dot5Amt;
	private String scheduleItem5dot5PreAmt;
	
	
	private String finalSchedule5Name;
	private String finalSchedule5Amt;
	private String finalSchedule5PreAmt;
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getScheduleItem5dot1Name() {
		return scheduleItem5dot1Name;
	}
	public void setScheduleItem5dot1Name(String scheduleItem5dot1Name) {
		this.scheduleItem5dot1Name = scheduleItem5dot1Name;
	}
	public String getScheduleItem5dot2Name() {
		return scheduleItem5dot2Name;
	}
	public void setScheduleItem5dot2Name(String scheduleItem5dot2Name) {
		this.scheduleItem5dot2Name = scheduleItem5dot2Name;
	}
	public String getScheduleItem5dot3Name() {
		return scheduleItem5dot3Name;
	}
	public void setScheduleItem5dot3Name(String scheduleItem5dot3Name) {
		this.scheduleItem5dot3Name = scheduleItem5dot3Name;
	}
	public String getScheduleItem5dot3Amt() {
		return scheduleItem5dot3Amt;
	}
	public void setScheduleItem5dot3Amt(String scheduleItem5dot3Amt) {
		this.scheduleItem5dot3Amt = scheduleItem5dot3Amt;
	}
	public String getScheduleItem5dot3PreAmt() {
		return scheduleItem5dot3PreAmt;
	}
	public void setScheduleItem5dot3PreAmt(String scheduleItem5dot3PreAmt) {
		this.scheduleItem5dot3PreAmt = scheduleItem5dot3PreAmt;
	}
	public String getScheduleItem5dot4Name() {
		return scheduleItem5dot4Name;
	}
	public void setScheduleItem5dot4Name(String scheduleItem5dot4Name) {
		this.scheduleItem5dot4Name = scheduleItem5dot4Name;
	}
	public String getScheduleItem5dot4Amt() {
		return scheduleItem5dot4Amt;
	}
	public void setScheduleItem5dot4Amt(String scheduleItem5dot4Amt) {
		this.scheduleItem5dot4Amt = scheduleItem5dot4Amt;
	}
	public String getScheduleItem5dot4PreAmt() {
		return scheduleItem5dot4PreAmt;
	}
	public void setScheduleItem5dot4PreAmt(String scheduleItem5dot4PreAmt) {
		this.scheduleItem5dot4PreAmt = scheduleItem5dot4PreAmt;
	}
	public String getScheduleItem5dot5Name() {
		return scheduleItem5dot5Name;
	}
	public void setScheduleItem5dot5Name(String scheduleItem5dot5Name) {
		this.scheduleItem5dot5Name = scheduleItem5dot5Name;
	}
	public String getScheduleItem5dot5Amt() {
		return scheduleItem5dot5Amt;
	}
	public void setScheduleItem5dot5Amt(String scheduleItem5dot5Amt) {
		this.scheduleItem5dot5Amt = scheduleItem5dot5Amt;
	}
	public String getScheduleItem5dot5PreAmt() {
		return scheduleItem5dot5PreAmt;
	}
	public void setScheduleItem5dot5PreAmt(String scheduleItem5dot5PreAmt) {
		this.scheduleItem5dot5PreAmt = scheduleItem5dot5PreAmt;
	}
	public String getFinalSchedule5Name() {
		return finalSchedule5Name;
	}
	public void setFinalSchedule5Name(String finalSchedule5Name) {
		this.finalSchedule5Name = finalSchedule5Name;
	}
	public String getFinalSchedule5Amt() {
		return finalSchedule5Amt;
	}
	public void setFinalSchedule5Amt(String finalSchedule5Amt) {
		this.finalSchedule5Amt = finalSchedule5Amt;
	}
	public String getFinalSchedule5PreAmt() {
		return finalSchedule5PreAmt;
	}
	public void setFinalSchedule5PreAmt(String finalSchedule5PreAmt) {
		this.finalSchedule5PreAmt = finalSchedule5PreAmt;
	}
	@Override
	public String toString() {
		return "Schedule5A [createdBy=" + createdBy + ", scheduleItem5dot1Name=" + scheduleItem5dot1Name
				+ ", scheduleItem5dot2Name=" + scheduleItem5dot2Name + ", scheduleItem5dot3Name="
				+ scheduleItem5dot3Name + ", scheduleItem5dot3Amt=" + scheduleItem5dot3Amt
				+ ", scheduleItem5dot3PreAmt=" + scheduleItem5dot3PreAmt + ", scheduleItem5dot4Name="
				+ scheduleItem5dot4Name + ", scheduleItem5dot4Amt=" + scheduleItem5dot4Amt
				+ ", scheduleItem5dot4PreAmt=" + scheduleItem5dot4PreAmt + ", scheduleItem5dot5Name="
				+ scheduleItem5dot5Name + ", scheduleItem5dot5Amt=" + scheduleItem5dot5Amt
				+ ", scheduleItem5dot5PreAmt=" + scheduleItem5dot5PreAmt + ", finalSchedule5Name=" + finalSchedule5Name
				+ ", finalSchedule5Amt=" + finalSchedule5Amt + ", finalSchedule5PreAmt=" + finalSchedule5PreAmt + "]";
	}
	
	
}
