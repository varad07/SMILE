package in.ecgc.smile.erp.reporting.jasper.be.model.grv;

import java.math.BigDecimal;

import org.springframework.stereotype.Component;

@Component
public class PragatiReport {
	
	private int week;
	private long no_of_complaints_a;
	private long no_of_complaints_b;
	private long no_of_complaints_c;
	private long no_of_complaints_d;
	private long total_e;
	private long no_of_complaints_g;
	private long favour;
	private long favour_percent;
	private long against;
	private long  against_percent;
	private int month;
	private int year;
	
	public int getWeek() {
		return week;
	}
	public void setWeek(int week) {
		this.week = week;
	}
	public long getNo_of_complaints_a() {
		return no_of_complaints_a;
	}
	public void setNo_of_complaints_a(long no_of_complaints_a) {
		this.no_of_complaints_a = no_of_complaints_a;
	}
	public long getNo_of_complaints_b() {
		return no_of_complaints_b;
	}
	public void setNo_of_complaints_b(long no_of_complaints_b) {
		this.no_of_complaints_b = no_of_complaints_b;
	}
	public long getNo_of_complaints_c() {
		return no_of_complaints_c;
	}
	public void setNo_of_complaints_c(long no_of_complaints_c) {
		this.no_of_complaints_c = no_of_complaints_c;
	}
	public long getNo_of_complaints_d() {
		return no_of_complaints_d;
	}
	public void setNo_of_complaints_d(long no_of_complaints_d) {
		this.no_of_complaints_d = no_of_complaints_d;
	}
	public long getTotal_e() {
		return total_e;
	}
	public void setTotal_e(long total_e) {
		this.total_e = total_e;
	}
	public long getNo_of_complaints_g() {
		return no_of_complaints_g;
	}
	public void setNo_of_complaints_g(long no_of_complaints_g) {
		this.no_of_complaints_g = no_of_complaints_g;
	}
	public long getFavour() {
		return favour;
	}
	public void setFavour(long favour) {
		this.favour = favour;
	}
	public long getFavour_percent() {
		return favour_percent;
	}
	public void setFavour_percent(long favour_percent) {
		this.favour_percent = favour_percent;
	}
	public long getAgainst() {
		return against;
	}
	public void setAgainst(long against) {
		this.against = against;
	}
	public long getAgainst_percent() {
		return against_percent;
	}
	public void setAgainst_percent(long against_percent) {
		this.against_percent = against_percent;
	}


	
	public int getMonth() {
		return month;
	}
	public void setMonth(int month) {
		this.month = month;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	@Override
	public String toString() {
		return "PragatiReport [week=" + week + ", no_of_complaints_a=" + no_of_complaints_a + ", no_of_complaints_b="
				+ no_of_complaints_b + ", no_of_complaints_c=" + no_of_complaints_c + ", no_of_complaints_d="
				+ no_of_complaints_d + ", total_e=" + total_e + ", no_of_complaints_g=" + no_of_complaints_g
				+ ", favour=" + favour + ", favour_percent=" + favour_percent + ", against=" + against
				+ ", against_percent=" + against_percent + ", month=" + month + ", year=" + year + "]";
	}


	
	
	
	
	
}
