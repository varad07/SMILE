package in.ecgc.smile.erp.reporting.jasper.be.model.grv;

public class Grv_R01 {

	double year;
	double quarter;
	String grv_complaint_type; 
	int rejected;
	int additions_during_the_quarter;
	
	int fully_accepted;
	int partially_accepted;
	int opening_balance;
	int complaints_pending;
	public double getYear() {
		return year;
	}
	public void setYear(double year) {
		this.year = year;
	}
	public double getQuarter() {
		return quarter;
	}
	public void setQuarter(double quarter) {
		this.quarter = quarter;
	}
	public String getGrv_complaint_type() {
		return grv_complaint_type;
	}
	public void setGrv_complaint_type(String grv_complaint_type) {
		this.grv_complaint_type = grv_complaint_type;
	}
	public int getRejected() {
		return rejected;
	}
	public void setRejected(int rejected) {
		this.rejected = rejected;
	}
	public int getAdditions_during_the_quarter() {
		return additions_during_the_quarter;
	}
	public void setAdditions_during_the_quarter(int additions_during_the_quarter) {
		this.additions_during_the_quarter = additions_during_the_quarter;
	}
	public int getFully_accepted() {
		return fully_accepted;
	}
	public void setFully_accepted(int fully_accepted) {
		this.fully_accepted = fully_accepted;
	}
	public int getPartially_accepted() {
		return partially_accepted;
	}
	public void setPartially_accepted(int partially_accepted) {
		this.partially_accepted = partially_accepted;
	}
	public int getOpening_balance() {
		return opening_balance;
	}
	public void setOpening_balance(int opening_balance) {
		this.opening_balance = opening_balance;
	}
	public int getComplaints_pending() {
		return complaints_pending;
	}
	public void setComplaints_pending(int complaints_pending) {
		this.complaints_pending = complaints_pending;
	}
	@Override
	public String toString() {
		return "Grv_R01 [year=" + year + ", quarter=" + quarter + ", grv_complaint_type=" + grv_complaint_type
				+ ", rejected=" + rejected + ", additions_during_the_quarter=" + additions_during_the_quarter
				+ ", fully_accepted=" + fully_accepted + ", partially_accepted=" + partially_accepted
				+ ", opening_balance=" + opening_balance + ", complaints_pending=" + complaints_pending + "]";
	}
	
	
}
