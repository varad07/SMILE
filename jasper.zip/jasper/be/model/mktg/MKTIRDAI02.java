package in.ecgc.smile.erp.reporting.jasper.be.model.mktg;

import org.springframework.stereotype.Component;

@Component
public class MKTIRDAI02 {
	
	private String office_name;
	
	private String office_type_id_fk;
	
	private Long new_offices;
	
	private Long offices_closed_during_month;
	
	private String offices_relocated_during_month;

	public String getOffice_name() {
		return office_name;
	}

	public void setOffice_name(String office_name) {
		this.office_name = office_name;
	}

	public String getOffice_type_id_fk() {
		return office_type_id_fk;
	}

	public void setOffice_type_id_fk(String office_type_id_fk) {
		this.office_type_id_fk = office_type_id_fk;
	}

	public Long getNew_offices() {
		return new_offices;
	}

	public void setNew_offices(Long new_offices) {
		this.new_offices = new_offices;
	}

	public Long getOffices_closed_during_month() {
		return offices_closed_during_month;
	}

	public void setOffices_closed_during_month(Long offices_closed_during_month) {
		this.offices_closed_during_month = offices_closed_during_month;
	}

	public String getOffices_relocated_during_month() {
		return offices_relocated_during_month;
	}

	public void setOffices_relocated_during_month(String offices_relocated_during_month) {
		this.offices_relocated_during_month = offices_relocated_during_month;
	}

	@Override
	public String toString() {
		return "MKTIRDAI02 [office_name=" + office_name + ", office_type_id_fk=" + office_type_id_fk + ", new_offices="
				+ new_offices + ", offices_closed_during_month=" + offices_closed_during_month
				+ ", offices_relocated_during_month=" + offices_relocated_during_month + "]";
	}
	
	

}
