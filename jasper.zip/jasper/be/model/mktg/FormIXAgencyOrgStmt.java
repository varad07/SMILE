package in.ecgc.smile.erp.reporting.jasper.be.model.mktg;

import java.math.BigDecimal;

import org.springframework.stereotype.Component;

@Component
public class FormIXAgencyOrgStmt {
	
	private String brokerageAgencyTypeId;
	
	private Long noAtBeginningOfQuater;
	
	private Long additionDuringQuarter;

	public String getBrokerageAgencyTypeId() {
		return brokerageAgencyTypeId;
	}

	public void setBrokerageAgencyTypeId(String brokerageAgencyTypeId) {
		this.brokerageAgencyTypeId = brokerageAgencyTypeId;
	}

	public Long getNoAtBeginningOfQuater() {
		return noAtBeginningOfQuater;
	}

	public void setNoAtBeginningOfQuater(Long noAtBeginningOfQuater) {
		this.noAtBeginningOfQuater = noAtBeginningOfQuater;
	}

	public Long getAdditionDuringQuarter() {
		return additionDuringQuarter;
	}

	public void setAdditionDuringQuarter(Long additionDuringQuarter) {
		this.additionDuringQuarter = additionDuringQuarter;
	}

	@Override
	public String toString() {
		return "FormIXAgencyOrgStmt [brokerageAgencyTypeId=" + brokerageAgencyTypeId + ", noAtBeginningOfQuater="
				+ noAtBeginningOfQuater + ", additionDuringQuarter=" + additionDuringQuarter + "]";
	}

	
	
	
	

}
