package in.ecgc.smile.erp.reporting.jasper.be.model.mktg;

import org.springframework.stereotype.Component;

@Component
public class MKTIDRAI07 {
	
	private String agents;
	
	private Long noOfPolicyCurrentQuarter;
	
	private String premiumAmtOfCurrentQuarter;
	
	private Long noOfpolicyPrvYrCurrentQuarter;
	
	private String premiumAmtOfPrvYrCurrentQuarter;
	
	private Long noOfPoliciesUptoThePeriodCurrentYr;
	
	private String premiumAmtUptoThePeriodCurrentYr;
	
	private Long noOfPolicyUptoThePeriodPrvYr;
	
	private String premiumAmtUptoThePeriodPrvYr;

	public String getAgents() {
		return agents;
	}

	public void setAgents(String agents) {
		this.agents = agents;
	}

	public Long getNoOfPolicyCurrentQuarter() {
		return noOfPolicyCurrentQuarter;
	}

	public void setNoOfPolicyCurrentQuarter(Long noOfPolicyCurrentQuarter) {
		this.noOfPolicyCurrentQuarter = noOfPolicyCurrentQuarter;
	}

	public String getPremiumAmtOfCurrentQuarter() {
		return premiumAmtOfCurrentQuarter;
	}

	public void setPremiumAmtOfCurrentQuarter(String premiumAmtOfCurrentQuarter) {
		this.premiumAmtOfCurrentQuarter = premiumAmtOfCurrentQuarter;
	}

	public Long getNoOfpolicyPrvYrCurrentQuarter() {
		return noOfpolicyPrvYrCurrentQuarter;
	}

	public void setNoOfpolicyPrvYrCurrentQuarter(Long noOfpolicyPrvYrCurrentQuarter) {
		this.noOfpolicyPrvYrCurrentQuarter = noOfpolicyPrvYrCurrentQuarter;
	}

	public String getPremiumAmtOfPrvYrCurrentQuarter() {
		return premiumAmtOfPrvYrCurrentQuarter;
	}

	public void setPremiumAmtOfPrvYrCurrentQuarter(String premiumAmtOfPrvYrCurrentQuarter) {
		this.premiumAmtOfPrvYrCurrentQuarter = premiumAmtOfPrvYrCurrentQuarter;
	}

	public Long getNoOfPoliciesUptoThePeriodCurrentYr() {
		return noOfPoliciesUptoThePeriodCurrentYr;
	}

	public void setNoOfPoliciesUptoThePeriodCurrentYr(Long noOfPoliciesUptoThePeriodCurrentYr) {
		this.noOfPoliciesUptoThePeriodCurrentYr = noOfPoliciesUptoThePeriodCurrentYr;
	}

	public String getPremiumAmtUptoThePeriodCurrentYr() {
		return premiumAmtUptoThePeriodCurrentYr;
	}

	public void setPremiumAmtUptoThePeriodCurrentYr(String premiumAmtUptoThePeriodCurrentYr) {
		this.premiumAmtUptoThePeriodCurrentYr = premiumAmtUptoThePeriodCurrentYr;
	}

	public Long getNoOfPolicyUptoThePeriodPrvYr() {
		return noOfPolicyUptoThePeriodPrvYr;
	}

	public void setNoOfPolicyUptoThePeriodPrvYr(Long noOfPolicyUptoThePeriodPrvYr) {
		this.noOfPolicyUptoThePeriodPrvYr = noOfPolicyUptoThePeriodPrvYr;
	}

	public String getPremiumAmtUptoThePeriodPrvYr() {
		return premiumAmtUptoThePeriodPrvYr;
	}

	public void setPremiumAmtUptoThePeriodPrvYr(String premiumAmtUptoThePeriodPrvYr) {
		this.premiumAmtUptoThePeriodPrvYr = premiumAmtUptoThePeriodPrvYr;
	}

	@Override
	public String toString() {
		return "MKTIDRAI07 [agents=" + agents + ", noOfPolicyCurrentQuarter=" + noOfPolicyCurrentQuarter
				+ ", premiumAmtOfCurrentQuarter=" + premiumAmtOfCurrentQuarter + ", noOfpolicyPrvYrCurrentQuarter="
				+ noOfpolicyPrvYrCurrentQuarter + ", premiumAmtOfPrvYrCurrentQuarter=" + premiumAmtOfPrvYrCurrentQuarter
				+ ", noOfPoliciesUptoThePeriodCurrentYr=" + noOfPoliciesUptoThePeriodCurrentYr
				+ ", premiumAmtUptoThePeriodCurrentYr=" + premiumAmtUptoThePeriodCurrentYr
				+ ", noOfPolicyUptoThePeriodPrvYr=" + noOfPolicyUptoThePeriodPrvYr + ", premiumAmtUptoThePeriodPrvYr="
				+ premiumAmtUptoThePeriodPrvYr + "]";
	}
	

}
