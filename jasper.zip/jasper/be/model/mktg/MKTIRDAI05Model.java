package in.ecgc.smile.erp.reporting.jasper.be.model.mktg;

import org.springframework.stereotype.Component;

@Component
public class MKTIRDAI05Model {
	
	private String office_name;
	
	private String office_type_id_fk;
	
	private Long offices_at_beginning;
	
	private Long offices_during_quarter;
	
	private Long offices_closed_during_quarter;
	
	private Long offices_at_end_of_quarter;
	
	private String offices_relocated_during_quarter;

	public String getOffice_name() {
		return office_name;
	}

	public void setOffice_name(String office_name) {
		this.office_name = office_name;
	}

	public String getOffice_type_id_fk() {
		return office_type_id_fk;
	}

	public void setOffice_type_id_fk(String office_type_id_fk) {
		this.office_type_id_fk = office_type_id_fk;
	}

	public Long getOffices_at_beginning() {
		return offices_at_beginning;
	}

	public void setOffices_at_beginning(Long offices_at_beginning) {
		this.offices_at_beginning = offices_at_beginning;
	}

	public Long getOffices_during_quarter() {
		return offices_during_quarter;
	}

	public void setOffices_during_quarter(Long offices_during_quarter) {
		this.offices_during_quarter = offices_during_quarter;
	}

	public Long getOffices_closed_during_quarter() {
		return offices_closed_during_quarter;
	}

	public void setOffices_closed_during_quarter(Long offices_closed_during_quarter) {
		this.offices_closed_during_quarter = offices_closed_during_quarter;
	}

	public Long getOffices_at_end_of_quarter() {
		return offices_at_end_of_quarter;
	}

	public void setOffices_at_end_of_quarter(Long offices_at_end_of_quarter) {
		this.offices_at_end_of_quarter = offices_at_end_of_quarter;
	}

	public String getOffices_relocated_during_quarter() {
		return offices_relocated_during_quarter;
	}

	public void setOffices_relocated_during_quarter(String offices_relocated_during_quarter) {
		this.offices_relocated_during_quarter = offices_relocated_during_quarter;
	}

	@Override
	public String toString() {
		return "MKTIRDAI02Model [office_name=" + office_name + ", office_type_id_fk=" + office_type_id_fk
				+ ", offices_at_beginning=" + offices_at_beginning + ", offices_during_quarter="
				+ offices_during_quarter + ", offices_closed_during_quarter=" + offices_closed_during_quarter
				+ ", offices_at_end_of_quarter=" + offices_at_end_of_quarter + ", offices_relocated_during_quarter="
				+ offices_relocated_during_quarter + "]";
	}
	
	

}
