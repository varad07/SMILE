package in.ecgc.smile.erp.reporting.jasper.be.model.poluw;

import java.math.BigDecimal;
import java.time.LocalDate;

public class poluw_011 {

	private String exportercd;
	private String exportergrp;
	private String exporterName;
	private String policyType;
	private Integer policyNo;
	private String logicalloccd;
	private BigDecimal adjAmt;
	private LocalDate fromAdjustedDate;
	private LocalDate toAdjustedDate;

	public String getExporterName() {
		return exporterName;
	}

	public void setExporterName(String exporterName) {
		this.exporterName = exporterName;
	}

	public String getPolicyType() {
		return policyType;
	}

	public void setPolicyType(String policyType) {
		this.policyType = policyType;
	}

	public Integer getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(Integer policyNo) {
		this.policyNo = policyNo;
	}

	public String getLogicalloccd() {
		return logicalloccd;
	}

	public void setLogicalloccd(String logicalloccd) {
		this.logicalloccd = logicalloccd;
	}

	public BigDecimal getAdjAmt() {
		return adjAmt;
	}

	public void setAdjAmt(BigDecimal adjAmt) {
		this.adjAmt = adjAmt;
	}

	public LocalDate getFromAdjustedDate() {
		return fromAdjustedDate;
	}

	public void setFromAdjustedDate(LocalDate fromAdjustedDate) {
		this.fromAdjustedDate = fromAdjustedDate;
	}

	public LocalDate getToAdjustedDate() {
		return toAdjustedDate;
	}

	public void setToAdjustedDate(LocalDate toAdjustedDate) {
		this.toAdjustedDate = toAdjustedDate;
	}

	public String getExportercd() {
		return exportercd;
	}

	public void setExportercd(String exportercd) {
		this.exportercd = exportercd;
	}

	public String getExportergrp() {
		return exportergrp;
	}

	public void setExportergrp(String exportergrp) {
		this.exportergrp = exportergrp;
	}

	@Override
	public String toString() {
		return "poluw_011 [exportercd=" + exportercd + ", exportergrp=" + exportergrp + ", exporterName=" + exporterName
				+ ", policyType=" + policyType + ", policyNo=" + policyNo + ", logicalloccd=" + logicalloccd
				+ ", adjAmt=" + adjAmt + ", fromAdjustedDate=" + fromAdjustedDate + ", toAdjustedDate=" + toAdjustedDate
				+ "]";
	}

}
