package in.ecgc.smile.erp.reporting.jasper.be.model.poluw;

import java.math.BigDecimal;

public class poluw_013 {
	
	
    private String regionName;
    private String logicalloccd;
    private Integer policyNo;
    private BigDecimal riskvalue;
    private BigDecimal totalPremiumPaid;
	public String getRegionName() {
		return regionName;
	}
	public void setRegionName(String regionName) {
		this.regionName = regionName;
	}
	public String getLogicalloccd() {
		return logicalloccd;
	}
	public void setLogicalloccd(String logicalloccd) {
		this.logicalloccd = logicalloccd;
	}
	public Integer getPolicyNo() {
		return policyNo;
	}
	public void setPolicyNo(Integer policyNo) {
		this.policyNo = policyNo;
	}
	public BigDecimal getRiskvalue() {
		return riskvalue;
	}
	public void setRiskvalue(BigDecimal riskvalue) {
		this.riskvalue = riskvalue;
	}
	public BigDecimal getTotalPremiumPaid() {
		return totalPremiumPaid;
	}
	public void setTotalPremiumPaid(BigDecimal totalPremiumPaid) {
		this.totalPremiumPaid = totalPremiumPaid;
	}
	@Override
	public String toString() {
		return "poluw_013 [regionName=" + regionName + ", logicalloccd=" + logicalloccd + ", policyNo=" + policyNo
				+ ", riskvalue=" + riskvalue + ", totalPremiumPaid=" + totalPremiumPaid + "]";
	}
    
	
    

    

}
