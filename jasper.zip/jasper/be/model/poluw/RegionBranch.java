package in.ecgc.smile.erp.reporting.jasper.be.model.poluw;



public class RegionBranch {
	
	
	private String region;
	
	private String officeId;

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getOfficeId() {
		return officeId;
	}

	public void setOfficeId(String officeId) {
		this.officeId = officeId;
	}

	@Override
	public String toString() {
		return "RegionBranch [region=" + region + ", officeId=" + officeId + "]";
	}
	
	

}
