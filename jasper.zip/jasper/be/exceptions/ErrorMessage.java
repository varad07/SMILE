package in.ecgc.smile.erp.reporting.jasper.be.exceptions;

import org.springframework.stereotype.Component;

@Component
public class ErrorMessage {

	private String message;

	private String errorCode;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	@Override
	public String toString() {
		return "ErrorMessage [message=" + message + ", errorCode=" + errorCode + "]";
	}
	
	

}
