package in.ecgc.smile.erp.reporting.jasper.be.exceptions;

@SuppressWarnings("serial")
public class ReportGenerationException extends RuntimeException {
	
	 private String ErrorCode;
	 
     public ReportGenerationException(String message, String ErrorCode){
         super(message);
         this.ErrorCode =ErrorCode;
     }

	public String getErrorCode() {
		return ErrorCode;
	}

	public void setErrorCode(String errorCode) {
		ErrorCode = errorCode;
	};

     
     
}
