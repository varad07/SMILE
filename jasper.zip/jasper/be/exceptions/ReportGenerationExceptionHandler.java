package in.ecgc.smile.erp.reporting.jasper.be.exceptions;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@RestControllerAdvice
public class ReportGenerationExceptionHandler extends ResponseEntityExceptionHandler {
	
	@Autowired
    private ErrorMessage errorMessage;
	
	
	@ExceptionHandler(ReportGenerationException.class)
    @ResponseBody
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ResponseEntity<ErrorMessage> productNotFoundHandler(ReportGenerationException reportGenerationException){
        errorMessage.setMessage(reportGenerationException.getMessage());
        errorMessage.setErrorCode(reportGenerationException.getErrorCode());

    return new ResponseEntity<>(errorMessage,HttpStatus.INTERNAL_SERVER_ERROR);
    }


    @ExceptionHandler
    @ResponseBody
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ErrorMessage genericException(Exception exception){
        errorMessage.setErrorCode(HttpStatus.INTERNAL_SERVER_ERROR.toString());
        errorMessage.setMessage(exception.getMessage());
        return errorMessage;
    }
	
	

}
