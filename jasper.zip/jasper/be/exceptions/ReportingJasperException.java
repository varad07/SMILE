package in.ecgc.smile.erp.reporting.jasper.be.exceptions;

public class ReportingJasperException extends RuntimeException {

}
