package in.ecgc.smile.erp.reporting.jasper.be.proxy;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.context.annotation.Profile;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import in.ecgc.smile.erp.reporting.jasper.be.model.external.VendorManagement;

public interface VendorMgmtClient {

	@Profile({ "local-secured || dev-secured || local" })
	@FeignClient(name = "erp-admin-vendor-mgmt-be", url = "http://10.210.0.140:31335", contextId = "VendorMgmtClient", configuration = FeignErrorDecoder.class)
	public interface VendorMgmtClientLocal extends VendorMgmtClient {

	}

	@Profile({ "qa-secured || qa || sit-secured || sit || uat || prod" })
	@FeignClient(name = "${api.gateway}", contextId = "VendorMgmtClient", fallbackFactory = VendorMgmtClientFallback.class, configuration = FeignErrorDecoder.class)
	public interface VendorMgmtClientQA extends VendorMgmtClient {
	}

	// Get All Vendors Request Made : From BE Service
	@GetMapping("/erp-admin-vendor-mgmt-be/admin/get/list/vendor")
	public List<VendorManagement> getAllVendor();

	@GetMapping("/erp-admin-vendor-mgmt-be/admin/vendor/view/{vendorCode}")
	public VendorManagement getPanByVendorCode(@PathVariable("vendorCode") String vendorCode);

}
