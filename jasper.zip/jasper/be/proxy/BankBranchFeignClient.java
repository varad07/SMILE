package in.ecgc.smile.erp.reporting.jasper.be.proxy;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.context.annotation.Profile;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import in.ecgc.smile.erp.reporting.jasper.be.model.external.BankBranch;

public interface BankBranchFeignClient {

	@Profile({ "local-secured || dev-secured || local" })
	@FeignClient(name = "erp-accounts-accounts-be", contextId = "BankBranchFeignClient", url = "http://10.210.0.140:31335", fallbackFactory = BankBranchFeignClientFallback.class, configuration = FeignErrorDecoder.class)
	public interface BankBranchFeignClientLocal extends BankBranchFeignClient {

	}

	@Profile({ "qa-secured || qa || sit-secured || sit || uat || prod" })
	@FeignClient(name = "${api.gateway}", contextId = "BankBranchFeignClient", fallbackFactory = BankBranchFeignClientFallback.class, configuration = FeignErrorDecoder.class)
	public interface BankBranchFeignClientQA extends BankBranchFeignClient {
	}

	@GetMapping("/erp-accounts-accounts-be}/bank-branch-master/view/{logicalLocCode}")
	public BankBranch findBankByLogicalLocation(@PathVariable String logicalLocCode);

}
