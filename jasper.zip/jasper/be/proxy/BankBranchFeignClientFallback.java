package in.ecgc.smile.erp.reporting.jasper.be.proxy;

import java.util.List;

import org.springframework.stereotype.Component;

import feign.hystrix.FallbackFactory;
import in.ecgc.smile.erp.reporting.jasper.be.model.external.BankBranch;

@Component
public class BankBranchFeignClientFallback implements FallbackFactory<BankBranchFeignClient> {

	@Override
	public BankBranchFeignClient create(Throwable cause) {
		return new BankBranchFeignClient() {

			@Override
			public BankBranch findBankByLogicalLocation(String logicalLocCode) {

				return null;
			}

		};
	}

}
