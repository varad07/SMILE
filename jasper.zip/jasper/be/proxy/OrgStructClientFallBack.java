package in.ecgc.smile.erp.reporting.jasper.be.proxy;

import java.util.List;

import org.springframework.stereotype.Component;

import feign.hystrix.FallbackFactory;
import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.BranchMaster;
import in.ecgc.smile.erp.reporting.jasper.be.model.external.ParentOfficeMaster;

@Component
public class OrgStructClientFallBack implements FallbackFactory<OrgStructClient> {

	@Override
	public OrgStructClient create(Throwable cause) {

		return new OrgStructClient() {

			@Override
			public List<ParentOfficeMaster> getParentOfficeDetails() {
				// log.info("Service to fetch parent office is down due to {}",
				// cause.getMessage());
				return null;
			}

			@Override
			public BranchMaster getBranchDtlsByOfficeId(String officeId) {
			
				return null;
			}

		};
	}

}
