package in.ecgc.smile.erp.reporting.jasper.be.proxy;

import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ResponseStatusException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import feign.Response;
import feign.codec.ErrorDecoder;
import in.ecgc.smile.erp.reporting.jasper.be.exceptions.ErrorResponse;

@Component
public class FeignErrorDecoder implements ErrorDecoder {

	private static final Logger log = LoggerFactory.getLogger(FeignErrorDecoder.class);

	@Override
	public Exception decode(String methodKey, Response response) {
		String reason = response.body().toString();

		switch (response.status()) {
		case 400: {
			log.error("Error took place when using Feign client to send HTTP Request. Status code " + response.status()
					+ ", methodKey = " + methodKey);
			return new ResponseStatusException(HttpStatus.valueOf(response.status()), reason);
		}
		case 404: {
			log.error("Error took place when using Feign client to send HTTP Request. Status code " + response.status()
					+ ", methodKey = " + methodKey);
			ErrorResponse errResponse = new ErrorResponse();
			errResponse.setCode("404");
			errResponse.setCorrelationId(UUID.randomUUID().toString());
			errResponse.setMessage("Error while calling BE " + methodKey);
			errResponse.setDetail("Error while calling BE " + methodKey);
			ObjectMapper objMapper = new ObjectMapper();
			String errResponseString = "";
			try {
				errResponseString = objMapper.writeValueAsString(errResponse);
			} catch (JsonProcessingException e) {
				log.error("JsonProcessingException while creating json from ErrorResponse", e);
			}
			return new ResponseStatusException(HttpStatus.valueOf(response.status()), errResponseString);
		}
		case 500: {
			log.error("Error took place when using Feign client to send HTTP Request. Status code " + response.status()
					+ ", methodKey = " + methodKey);
			try {
				ErrorResponse errorResponse = new ObjectMapper()
						.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
						.readValue(reason, ErrorResponse.class);
				log.info("Within FeignErrorDecoder handle500 error errorResponseBody {}", errorResponse);
			} catch (JsonMappingException e) {
				log.error("JSONParsingException while parsing ErrorResponse body", e);
			} catch (JsonProcessingException e) {
				log.error("JSONParsingException while parsing ErrorResponse body", e);
			}
			return new ResponseStatusException(HttpStatus.valueOf(response.status()), reason);
		}
		default:
			log.error("Error took place when using Feign client to send HTTP Request Default Block" + response.status()
					+ ", methodKey = " + methodKey);
			return new Exception("Default feign exception");
		}
	}

}
