package in.ecgc.smile.erp.reporting.jasper.be.proxy;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.context.annotation.Profile;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import in.ecgc.smile.erp.reporting.jasper.be.model.accounts.BranchMaster;
import in.ecgc.smile.erp.reporting.jasper.be.model.external.ParentOfficeMaster;

public interface OrgStructClient {

	@Profile({ "local-secured || dev-secured || local" })
	@FeignClient(name = "erp-hrd-org-struct-be", url = "http://10.210.0.140:31335", contextId = "OrgStructClient", fallbackFactory = OrgStructClientFallBack.class)
	public interface OrgStructClientLocal extends OrgStructClient {

	}

	@Profile({ "qa-secured || qa || sit-secured || sit || uat || prod" })
	@FeignClient(name = "${api.gateway}", contextId = "OrgStructClient", fallbackFactory = OrgStructClientFallBack.class, configuration = FeignErrorDecoder.class)
	public interface OrgStructClientQA extends OrgStructClient {
	}

	// Employee Branch Office
	@GetMapping("erp-hrd-org-struct-be/get-branch-by-office-id/{officeId}")
	public BranchMaster getBranchDtlsByOfficeId(@PathVariable("officeId") String officeId);

	// Employee Office Location
	@GetMapping("/erp-hrd-org-struct-be/get-parent-office-details")
	List<ParentOfficeMaster> getParentOfficeDetails();

}
